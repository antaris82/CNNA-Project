import REALOQS.Meta.PillarB_Closure_FromA_Strict
import REALOQS.Meta.PillarB_Closure_Target

set_option autoImplicit false

namespace Meta
namespace PillarB_BQ9_Closed

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
open _root_.PillarB.AQFT.Derived.TreeOfCliquesExtendedFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

theorem bq9_closed_marker [Fact (0 < b)] :
    (modularDatum_top_ToC (b := b) (p := p)).gns =
      gnsDatum_top_ToC (b := b) (p := p) := by
  rfl

end
end PillarB_BQ9_Closed
end Meta
