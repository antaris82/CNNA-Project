import REALOQS.PillarB.AQFT

set_option autoImplicit false

namespace Meta
namespace PillarB_ObservableSubnet

noncomputable section

open _root_.PillarB.AQFT.Derived
open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

theorem toc_additive_subnet_exists :
    _root_.PillarB.AQFT.LocalStarAlgebraNet
      (Ω := Ω (b := b) (p := p)) :=
  N_add_ToC (b := b) (p := p)

theorem toc_observable_includes_into_rich
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    _root_.PillarB.AQFT.StarAlgHom
      ((N_add_ToC (b := b) (p := p)).SA r)
      ((N_rich_ToC (b := b) (p := p)).SA r) :=
  observableInclRich_ToC (b := b) (p := p) r

theorem toc_additive_iso_rich_on_basic_ball
    (i : Ω (b := b) (p := p)) :
    _root_.PillarB.AQFT.HaagKastler.StarAlgIso
      (SA := (N_add_ToC (b := b) (p := p)).SA
        (_root_.PillarB.AQFT.Derived.boundaryBallFromL
          (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i))
      (SB := (N_rich_ToC (b := b) (p := p)).SA
        (_root_.PillarB.AQFT.Derived.boundaryBallFromL
          (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)) :=
  boundaryMatrixAdditiveIsoRichOnBasic
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (B_ToC_basic_ball (b := b) (p := p) i)

end
end PillarB_ObservableSubnet
end Meta
