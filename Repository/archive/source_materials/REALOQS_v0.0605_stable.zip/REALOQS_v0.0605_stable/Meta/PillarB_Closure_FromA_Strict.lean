import REALOQS.Meta.PillarB_StrictSurface

set_option autoImplicit false

namespace Meta
namespace PillarB_Closure_FromA_Strict

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC
open _root_.PillarB.AQFT.Derived.TreeOfCliquesExtendedFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

theorem toc_quasilocal_univ_marker [Fact (0 < b)] :
    _root_.PillarB.AQFT.QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_ToC (b := b) (p := p))
        (Φ_FromA (b := b) (p := p))
        (Finset.univ : Finset (Ω (b := b) (p := p))) =
      ρRegion (b := b) (p := p)
        (Finset.univ : Finset (Ω (b := b) (p := p))) :=
  restrictToRegion_univ_Φ_FromA (b := b) (p := p)

theorem toc_locality_marker [Fact (0 < b)] :
    _root_.PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_ToC (b := b) (p := p))
      (D := D_ToC (b := b) (p := p)) :=
  locality_ToC (b := b) (p := p)

theorem toc_isotony_marker [Fact (0 < b)] :
    _root_.PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_ToC (b := b) (p := p)) :=
  isotony_ToC (b := b) (p := p)

theorem toc_split_marker [Fact (0 < b)] :
    _root_.PillarB.AQFT.Gates.SplitProperty
      (N := N_ToC (b := b) (p := p)) :=
  splitProperty_ToC (b := b) (p := p)

theorem toc_top_state_marker [Fact (0 < b)] :
    (modularDatum_top_ToC (b := b) (p := p)).topKMS.state =
      ρTop (b := b) (p := p) := by
  rfl

theorem toc_gns_state_from_cyclic_marker [Fact (0 < b)]
    (A : (N_ToC (b := b) (p := p)).LAN.Alg (topRegion (b := b) (p := p))) :
    ρTop (b := b) (p := p) A =
      (gnsDatum_top_ToC (b := b) (p := p)).sesq
        (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec
        ((gnsDatum_top_ToC (b := b) (p := p)).pi A
          (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec) :=
  state_top_ToC_from_cyclic (b := b) (p := p) A

end
end PillarB_Closure_FromA_Strict
end Meta
