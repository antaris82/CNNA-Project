import REALOQS.Meta.PillarB_ActivePath

set_option autoImplicit false

namespace Meta
namespace PillarB_NoConfigHarnessInCriticalPath

noncomputable section

open _root_.PillarB.AQFT.Derived.TreeOfCliquesFromPillarA.ToC

variable {b : Nat}
variable (p : _root_.PillarA.LayerA.Policy b)

@[simp] theorem toc_quasilocal_state_is_strict_restriction [Fact (0 < b)] :
    Φ_FromA (b := b) (p := p) =
      _root_.PillarB.AQFT.Derived.boundaryMatrixQuasiLocalStateFromStrongTop
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

end
end PillarB_NoConfigHarnessInCriticalPath
end Meta
