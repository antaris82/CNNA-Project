import Mathlib
import REALOQS.PillarA.OQS.DtNStabilized

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace OQS
namespace Split
namespace DtNStabilized

noncomputable section

open PillarA.LayerA

variable {V : Type} [Fintype V] [DecidableEq V]
variable (s : PillarA.OQS.Split V)

variable {b : Nat}

theorem det_stabilize_ne_zero_of_posSemidef
    {ι : Type} [Fintype ι] [DecidableEq ι]
    (A : Matrix ι ι ℝ) (hA : A.PosSemidef)
    {δ : ℝ} (hδ : 0 < δ) :
    (stabilize (ι := ι) A δ).det ≠ 0 := by
  classical
  have hI : (1 : Matrix ι ι ℝ).PosDef := by
    simpa using (Matrix.PosDef.one (n := ι) (R := ℝ))
  have hδI : (δ • (1 : Matrix ι ι ℝ)).PosDef := hI.smul hδ
  have hpos : (A + δ • (1 : Matrix ι ι ℝ)).PosDef :=
    Matrix.PosDef.posSemidef_add (A := A) (B := δ • (1 : Matrix ι ι ℝ)) hA hδI

  have hunit : IsUnit (A + δ • (1 : Matrix ι ι ℝ)) := Matrix.PosDef.isUnit hpos
  have hdetUnit : IsUnit ((A + δ • (1 : Matrix ι ι ℝ)).det) :=
    (Matrix.isUnit_iff_isUnit_det (A + δ • (1 : Matrix ι ι ℝ))).1 hunit

  have hdet : ((A + δ • (1 : Matrix ι ι ℝ)).det) ≠ 0 := by
    rcases hdetUnit with ⟨u, hu⟩
    simpa [hu] using (u.ne_zero)

  simpa [stabilize] using hdet

theorem det_LII_stabilized_ne_zero_of_posSemidef
    (p : Policy b) (L : Matrix V V ℝ)
    (hpsd : (symm (ι := s.I) (s.blockII L)).PosSemidef) :
    (LII_stabilized (s := s) (p := p) L).det ≠ 0 := by
  classical
  let A : Matrix s.I s.I ℝ := symm (ι := s.I) (s.blockII L)
  have hδ : 0 < deltaNum (p := p) (ι := s.I) A := deltaNum_pos (p := p) (ι := s.I) A
  have hdet : (stabilize (ι := s.I) A (deltaNum (p := p) (ι := s.I) A)).det ≠ 0 :=
    det_stabilize_ne_zero_of_posSemidef (A := A) (hA := hpsd) (hδ := hδ)
  simpa [LII_stabilized, A, deltaNum, deltaSPD] using hdet

end

end DtNStabilized
end Split
end OQS
end PillarA
