import Mathlib
import REALOQS.PillarA.Core.TailInterface
import REALOQS.PillarA.OQS.DtN

set_option autoImplicit false

namespace PillarA

namespace OQS

open scoped BigOperators

open PillarA.LayerA

section

variable {V : Type} [Fintype V]

structure DtNTailData where

  decV : DecidableEq V

  split : @OQS.Split V _ decV

  fullOp : Matrix V V ℝ

  inv : @OQS.Split.InteriorInv V _ decV split fullOp

abbrev DtNBoundaryData : Type _ :=
  Σ decV : DecidableEq V, Σ s : @OQS.Split V _ decV, Matrix s.B s.B ℝ

instance instTailInterface_const : TailInterface (Cell := fun _ : Nat => V) where
  Tail := fun _ => DtNTailData (V := V)

instance instTailEliminationHook_const : TailEliminationHook (Cell := fun _ : Nat => V) where
  EffectiveBoundaryData := fun _ => DtNBoundaryData (V := V)
  eliminate := by
    intro L
    intro _dec
    intro A t bp
    cases t with
    | mk decV split fullOp inv =>
        letI : DecidableEq V := decV
        refine ⟨decV, ⟨split, ?_⟩⟩
        simpa using (OQS.Split.DtN_of (s := split) fullOp inv)

end

end OQS

end PillarA
