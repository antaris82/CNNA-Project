import Mathlib

namespace PillarA
namespace OQS

namespace SysEnvTail

open scoped BigOperators

section Split

variable {α : Type}

structure Split where
  sys : Finset α
  env : Finset α
  tail : Finset α
  disj_sys_env : Disjoint sys env
  disj_sys_tail : Disjoint sys tail
  disj_env_tail : Disjoint env tail

def covers (Ω : Finset α) (s : Split (α := α)) : Prop := by
  classical
  exact s.sys ∪ s.env ∪ s.tail = Ω

theorem gate_mem_sys_not_mem_env (s : Split (α := α)) {x : α} (hx : x ∈ s.sys) : x ∉ s.env := by
  intro hxE
  exact (Finset.disjoint_left.1 s.disj_sys_env hx hxE)

theorem gate_mem_sys_not_mem_tail (s : Split (α := α)) {x : α} (hx : x ∈ s.sys) : x ∉ s.tail := by
  intro hxT
  exact (Finset.disjoint_left.1 s.disj_sys_tail hx hxT)

theorem gate_mem_env_not_mem_tail (s : Split (α := α)) {x : α} (hx : x ∈ s.env) : x ∉ s.tail := by
  intro hxT
  exact (Finset.disjoint_left.1 s.disj_env_tail hx hxT)

def uniqueOwner (s : Split (α := α)) (x : α) : Prop := ¬ ((x ∈ s.sys ∧ x ∈ s.env)
      ∨ (x ∈ s.sys ∧ x ∈ s.tail)
      ∨ (x ∈ s.env ∧ x ∈ s.tail))

theorem gate_disjoint_implies_uniqueOwner (s : Split (α := α)) (x : α) :
    uniqueOwner (s := s) x := by
  unfold uniqueOwner
  intro h
  rcases h with hse | hrest
  · rcases hse with ⟨hs, he⟩
    exact (Finset.disjoint_left.1 s.disj_sys_env hs he)
  · rcases hrest with hst | het
    · rcases hst with ⟨hs, ht⟩
      exact (Finset.disjoint_left.1 s.disj_sys_tail hs ht)
    · rcases het with ⟨he, ht⟩
      exact (Finset.disjoint_left.1 s.disj_env_tail he ht)

def ownerTrichotomy (s : Split (α := α)) (x : α) : Prop := (x ∈ s.sys ∧ x ∉ s.env ∧ x ∉ s.tail)
    ∨ (x ∈ s.env ∧ x ∉ s.sys ∧ x ∉ s.tail)
    ∨ (x ∈ s.tail ∧ x ∉ s.sys ∧ x ∉ s.env)

theorem gate_covers_ownerTrichotomy (Ω : Finset α) (s : Split (α := α))
    (hc : covers (α := α) Ω s) {x : α} (hx : x ∈ Ω) : ownerTrichotomy (s := s) x := by
  classical
  have hΩ : Ω = s.sys ∪ s.env ∪ s.tail := by
    simpa [covers] using hc.symm
  have hxU : x ∈ s.sys ∪ s.env ∪ s.tail := by
    simpa [hΩ] using hx
  rcases Finset.mem_union.1 hxU with hxSE | hxT
  · rcases Finset.mem_union.1 hxSE with hxS | hxE
    · left
      refine ⟨hxS, ?_, ?_⟩
      · exact gate_mem_sys_not_mem_env (s := s) (α := α) hxS
      · exact gate_mem_sys_not_mem_tail (s := s) (α := α) hxS
    · right; left
      refine ⟨hxE, ?_, ?_⟩
      · intro hxS
        exact (Finset.disjoint_left.1 s.disj_sys_env hxS hxE)
      · exact gate_mem_env_not_mem_tail (s := s) (α := α) hxE
  · right; right
    refine ⟨hxT, ?_, ?_⟩
    · intro hxS
      exact (Finset.disjoint_left.1 s.disj_sys_tail hxS hxT)
    · intro hxE
      exact (Finset.disjoint_left.1 s.disj_env_tail hxE hxT)

end Split

end SysEnvTail
end OQS
end PillarA
