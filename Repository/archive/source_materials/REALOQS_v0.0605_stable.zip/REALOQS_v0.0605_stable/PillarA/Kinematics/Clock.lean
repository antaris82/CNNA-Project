import Mathlib
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.ProperTime

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace Kinematics

structure Clock (V : Type) where
  Q : Type
  init : Q
  step : Nat → V → V → Q → Q
  read : Q → ENNReal

namespace Clock

variable {V : Type} (C : Clock V)

def run (γ : Worldline V) : Nat → C.Q
| 0     => C.init
| (n+1) => C.step n (γ n) (γ (n+1)) (run γ n)

def reading (γ : Worldline V) (N : Nat) : ENNReal := C.read (C.run γ N)

def readingST {X : Type} (ST : DiscreteSpacetime X) (C : Clock X)
    (γ : ST.Worldline) (N : Nat) : ENNReal := C.reading (V := X) γ.x N

end Clock

structure Operationalizes {V : Type} (C : Clock V) (cost : StepCost V) : Prop where
  read_init : C.read C.init = 0
  read_step : ∀ n x y q, C.read (C.step n x y q) = C.read q + cost x y

namespace Operationalizes

variable {V : Type} {C : Clock V} {cost : StepCost V}

theorem gate_reading_eq_properTimeUpTo (h : Operationalizes (C := C) (cost := cost))
    (γ : Worldline V) :
    ∀ N, C.reading γ N = properTimeUpTo (V := V) cost γ N := by
  intro N
  induction N with
  | zero =>
      simp [Clock.reading, Clock.run, properTimeUpTo, h.read_init]
  | succ N ih =>
      simpa [Clock.reading, Clock.run, properTimeUpTo, Finset.sum_range_succ, h.read_step] using
        congrArg (fun t => t + cost (γ N) (γ (N + 1))) ih

theorem gate_readingST_eq_properTimeUpTo (ST : DiscreteSpacetime V)
    (h : Operationalizes (C := C) (cost := cost)) (γ : ST.Worldline) :
    ∀ N, Clock.readingST (ST := ST) (C := C) γ N = properTimeUpTo (V := V) cost γ.x N := by
  intro N
  simpa [Clock.readingST] using gate_reading_eq_properTimeUpTo (C := C) (cost := cost) h γ.x N

noncomputable def accumulator (V : Type) (cost : StepCost V) : Clock V where
  Q := ENNReal
  init := 0
  step := fun _ x y q => q + cost x y
  read := fun q => q

theorem gate_accumulator_operationalizes (V : Type) (cost : StepCost V) :
    Operationalizes (C := accumulator (V := V) cost) (cost := cost) := by
  refine ⟨?_, ?_⟩
  · simp [accumulator]
  · intro n x y q
    simp [accumulator]

theorem theorem_CLOCK_accumulator_reads_properTimeUpTo {V : Type}
    (cost : StepCost V) (γ : Worldline V) (N : Nat) :
    (accumulator (V := V) cost).reading γ N = properTimeUpTo (V := V) cost γ N := by
  have h := gate_accumulator_operationalizes (V := V) cost
  simpa using (gate_reading_eq_properTimeUpTo (C := accumulator (V := V) cost) (cost := cost) h γ N)

end Operationalizes

end Kinematics
end PillarA
