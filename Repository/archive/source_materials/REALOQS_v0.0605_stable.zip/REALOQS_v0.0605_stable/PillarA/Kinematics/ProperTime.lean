import Mathlib
import REALOQS.PillarA.Kinematics.Worldline

set_option linter.style.longLine false

set_option autoImplicit false

open scoped BigOperators

namespace PillarA

namespace Kinematics

abbrev StepCost (V : Type) := V → V → ENNReal

def properTimeUpTo {V : Type} (cost : StepCost V) (γ : Worldline V) (N : ℕ) : ENNReal :=
  Finset.sum (Finset.range N) (fun n => cost (γ n) (γ (n+1)))

theorem gate_PROPERTIME_zero {V : Type} (cost : StepCost V) (γ : Worldline V) :
    properTimeUpTo (V := V) cost γ 0 = 0 := by
  simp [properTimeUpTo]

theorem gate_PROPERTIME_one {V : Type} (cost : StepCost V) (γ : Worldline V) :
    properTimeUpTo (V := V) cost γ 1 = cost (γ 0) (γ 1) := by
  simp [properTimeUpTo]

class ProperTimeLaws (V : Type) where
  cost : StepCost V
  additivity : ∀ (γ : Worldline V) (N M : ℕ),
    properTimeUpTo (V := V) cost γ (N+M)
      = properTimeUpTo (V := V) cost γ N
        + Finset.sum (Finset.range M) (fun n => cost (γ (N+n)) (γ (N+n+1)))

namespace ProperTimeLaws

def zeroCost (V : Type) : ProperTimeLaws V := by
  refine ⟨?_, ?_⟩
  · exact fun _ _ => 0
  · intro γ N M
    simp [PillarA.Kinematics.properTimeUpTo]

end ProperTimeLaws

end Kinematics
end PillarA
