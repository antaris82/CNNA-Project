import Mathlib
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Kinematics.Causality
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.ProperTime

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace Kinematics

open PillarA.LayerA

noncomputable section

structure ProperTimeMetricHook {X : Type}
    (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) : Type where
  SL : CausalSpeedLimit ST rm
  cost : StepCost X

  cost_self : ∀ x : X, cost x x = 1

  cost_zero_of_maxspeed : ∀ {x y : X}, dist (rm := rm) x y = SL.c → cost x y = 0

  cost_defined_of_step : ∀ {x y : X}, ST.step x y → cost x y ≠ (⊤ : ENNReal)

  cost_antitone_in_dist :
    ∀ {x y x' y' : X}, dist (rm := rm) x y ≤ dist (rm := rm) x' y' → cost x' y' ≤ cost x y

namespace ProperTimeMetricHook

variable {X : Type} {ST : DiscreteSpacetime X} {rm : ResistanceMetric X}

def properTimeOf (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) (n : Nat) : ENNReal :=
  properTimeUpTo (V := X) H.cost γ.x n

theorem gate_properTimeOf_succ (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) (n : Nat) :
    H.properTimeOf γ (n+1) = H.properTimeOf γ n + H.cost (γ.x n) (γ.x (n+1)) := by
  classical
  simp [properTimeOf, properTimeUpTo, Finset.sum_range_succ]

theorem gate_cost_defined_along_worldline (H : ProperTimeMetricHook ST rm) (γ : ST.Worldline) :
    ∀ n, H.cost (γ.x n) (γ.x (n+1)) ≠ (⊤ : ENNReal) := by
  intro n
  exact H.cost_defined_of_step (γ.step_ok n)

def mkTopSpeedLimit {X : Type} (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) :
    ProperTimeMetricHook ST rm :=
by
  classical
  let cost' : StepCost X := fun x y => if dist (rm := rm) x y = (⊤ : ENNReal) then 0 else 1
  refine
    { SL :=
        { c := (⊤ : ENNReal)
          step_bound := by
            intro x y hstep
            exact le_top }
      cost := cost'
      cost_self := by
        intro x
        simp [cost', PillarA.LayerA.gate_dist_self (rm := rm) x]
      cost_zero_of_maxspeed := by
        intro x y h
        simp [cost', h]
      cost_defined_of_step := by
        intro x y hstep
        by_cases hxy : dist (rm := rm) x y = (⊤ : ENNReal)
        · simp [cost', hxy]
        · simp [cost', hxy]
      cost_antitone_in_dist := by
        intro x y x' y' hle
        by_cases hxy : dist (rm := rm) x y = (⊤ : ENNReal)
        · have hx'y' : dist (rm := rm) x' y' = (⊤ : ENNReal) := by
            have : (⊤ : ENNReal) ≤ dist (rm := rm) x' y' := by
              simpa [hxy] using hle
            exact top_le_iff.mp this
          simp [cost', hxy, hx'y']
        · by_cases hx'y' : dist (rm := rm) x' y' = (⊤ : ENNReal)
          · simp [cost', hxy, hx'y']
          · simp [cost', hxy, hx'y'] }

end ProperTimeMetricHook

end

end Kinematics
end PillarA
