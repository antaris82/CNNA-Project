import Mathlib
import REALOQS.PillarA.Core.ResistanceMetric
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.SpatialMetric

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace Kinematics

open PillarA.LayerA

structure CausalSpeedLimit {X : Type}
    (ST : DiscreteSpacetime X) (rm : ResistanceMetric X) : Type where
    c : ENNReal
    step_bound : ∀ {x y : X}, ST.step x y → dist (rm := rm) x y ≤ c

namespace CausalSpeedLimit

variable {X : Type} {ST : DiscreteSpacetime X} {rm : ResistanceMetric X}

def WorldlineBounded (SL : CausalSpeedLimit ST rm) (γ : ST.Worldline) : Prop :=
  ∀ n, dist (rm := rm) (γ.x n) (γ.x (n + 1)) ≤ SL.c

theorem gate_worldline_bounded (SL : CausalSpeedLimit ST rm) (γ : ST.Worldline) :
    WorldlineBounded (ST := ST) (rm := rm) SL γ := by
  intro n
  exact SL.step_bound (γ.step_ok n)

end CausalSpeedLimit

end Kinematics
end PillarA
