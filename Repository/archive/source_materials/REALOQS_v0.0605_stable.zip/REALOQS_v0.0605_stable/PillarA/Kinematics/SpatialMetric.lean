import Mathlib
import REALOQS.PillarA.Core.ResistanceMetric

set_option autoImplicit false

namespace PillarA
namespace Kinematics

open PillarA.LayerA

variable {V T : Type}

noncomputable def prod (rm : ResistanceMetric V) : ResistanceMetric (V × T) :=
{ R := fun x y => rm.R x.1 y.1,
  symm := by
    intro x y
    simpa using rm.symm x.1 y.1,
  self := by
    intro x
    simpa using rm.self x.1 }

end Kinematics
end PillarA
