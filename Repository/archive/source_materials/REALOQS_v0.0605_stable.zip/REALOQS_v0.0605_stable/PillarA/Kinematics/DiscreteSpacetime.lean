import Mathlib

set_option autoImplicit false

namespace PillarA
namespace Kinematics

universe u

structure DiscreteSpacetime (X : Type u) where
  τ : X → Nat
  step : X → X → Prop
  step_tau : ∀ {x y}, step x y → τ y = τ x + 1

namespace DiscreteSpacetime

variable {X : Type u} (ST : DiscreteSpacetime X)

def Sigma (n : Nat) : Set X := {x | ST.τ x = n}

structure Worldline where
  x : Nat → X
  step_ok : ∀ n, ST.step (x n) (x (n+1))

structure WorldTube where
  W : Nat → Finset X
  adapted : ∀ n x, x ∈ W n → ST.τ x = n

def Centerline (T : WorldTube ST) : Type u := {γ : Nat → X // ∀ n, γ n ∈ T.W n}

def IsCausalCenterline (ST : DiscreteSpacetime X) (T : WorldTube ST) (γ : Nat → X) : Prop :=
  (∀ n, γ n ∈ T.W n) ∧ (∀ n, ST.step (γ n) (γ (n+1)))

def gate_centerline_is_worldline (T : WorldTube ST) (γ : Nat → X)
    (h : IsCausalCenterline ST T γ) : Worldline ST := by
  refine ⟨γ, ?_⟩
  intro n
  exact h.2 n

theorem gate_tube_subset_slice (T : WorldTube ST) (n : Nat) :
    ∀ x, x ∈ T.W n → x ∈ ST.Sigma n := by
  intro x hx
  exact T.adapted n x hx

def mkEmpty (X : Type u) [Inhabited X] : DiscreteSpacetime X := by
  refine ⟨?_, ?_, ?_⟩
  · exact fun _ => 0
  · exact fun _ _ => False
  · intro x y h
    cases h

end DiscreteSpacetime

end Kinematics
end PillarA
