import REALOQS.PillarA.Core.BInterfaces.CovariantNets
import REALOQS.PillarA.Core.BInterfaces.GlobalCone
import REALOQS.PillarA.Core.DynamicsEquivariant
import REALOQS.PillarA.Core.InfiniteCarrier
import REALOQS.PillarA.Core.InfiniteCarrierSymmetry

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v

namespace SymmetryCoverageGates

variable {Cell : Nat → Type u} [Substrate Cell]

theorem gate_infiniteCarrier_coh (U : InfiniteCarrier (Cell := Cell)) (L : Nat) :
    U.cell L ∈ Substrate.parents (Cell := Cell) (U.cell (L + 1)) :=
  U.coh L

theorem gate_infiniteCarrier_ext
    (U V : InfiniteCarrier (Cell := Cell))
    (h : ∀ L : Nat, U.cell L = V.cell L) :
    U = V :=
  InfiniteCarrier.ext (U := U) (V := V) h

theorem gate_infiniteCarrier_proj_def
    (U : InfiniteCarrier (Cell := Cell)) (L : Nat) :
    InfiniteCarrier.proj (Cell := Cell) U L = U.cell L :=
  rfl

open SymmetryAction

theorem gate_actInf_one
    (S : SymmetryAction (Cell := Cell))
    (U : InfiniteCarrier (Cell := Cell)) :
    S.actInf (Cell := Cell) (1 : S.G) U = U :=
  SymmetryAction.actInf_one (Cell := Cell) (S := S) U

theorem gate_actInf_mul
    (S : SymmetryAction (Cell := Cell))
    (g h : S.G) (U : InfiniteCarrier (Cell := Cell)) :
    S.actInf (Cell := Cell) (g * h) U =
      S.actInf (Cell := Cell) g (S.actInf (Cell := Cell) h U) :=
  SymmetryAction.actInf_mul (Cell := Cell) (S := S) g h U

theorem gate_actInf_commutes_with_proj
    (S : SymmetryAction (Cell := Cell)) (g : S.G)
    (U : InfiniteCarrier (Cell := Cell)) (L : Nat) :
    InfiniteCarrier.proj (Cell := Cell) (S.actInf (Cell := Cell) g U) L =
      S.act (L := L) g (InfiniteCarrier.proj (Cell := Cell) U L) :=
  rfl

namespace Covariant

open CovariantNets

variable {Ω : Type u} {G : Type v} [Group G]

theorem gate_covariant_alg_naturality
    (C : CovariantNets.CovariantLocalAlgebraNet (Ω := Ω) (G := G))
    (g : G) {a b : C.LAN.RN.Region} (hab : a ≤ b) (x : C.LAN.Alg a) :
    C.actAlg g b (C.LAN.incl hab x) =
      C.LAN.incl (C.RA.act_le (RN := C.LAN.RN) (G := G) g hab) (C.actAlg g a x) :=
  CovariantNets.gate_alg_naturality (C := C) g hab x

theorem gate_covariant_state_naturality
    (C : CovariantNets.CovariantStateNet (Ω := Ω) (G := G))
    (g : G) {a b : C.SN.RN.Region} (hab : a ≤ b) (ρ : C.SN.State b) :
    C.actState g a (C.SN.restrict hab ρ) =
      C.SN.restrict (C.RA.act_le (RN := C.SN.RN) (G := G) g hab) (C.actState g b ρ) :=
  CovariantNets.gate_state_naturality (C := C) g hab ρ

theorem gate_covariant_channel_naturality
    (C : CovariantNets.CovariantChannelNet (Ω := Ω) (G := G))
    (g : G) {a b : C.CN.RN.Region} (hab : a ≤ b)
    (Φ : C.CN.Chan hab) (x : C.CN.Obj b) :
    C.actObj g a (C.CN.apply hab Φ x) =
      C.CN.apply (C.RA.act_le (RN := C.CN.RN) (G := G) g hab)
        (C.actChan g hab Φ) (C.actObj g b x) :=
  CovariantNets.gate_channel_naturality (C := C) g hab Φ x

end Covariant

namespace GlobalCone

variable {Ω : Type u} {SN : StateNet (Ω := Ω)}

theorem gate_cone_compat
    (C : GlobalStateCone (SN := SN)) {a b : SN.RN.Region} (hab : a ≤ b) :
    SN.restrict hab (C.ω b) = C.ω a :=
  GlobalStateCone.gate_cone_compat (C := C) hab

theorem gate_cone_fromTop_compat
    (ρTop : SN.State SN.RN.top) {a b : SN.RN.Region} (hab : a ≤ b) :
    SN.restrict hab ((GlobalStateCone.fromTop (SN := SN) ρTop).ω b) =
      (GlobalStateCone.fromTop (SN := SN) ρTop).ω a :=
  GlobalStateCone.gate_cone_fromTop_compat (SN := SN) ρTop hab

end GlobalCone

namespace Dyn

variable {G : Type v} [Group G]
variable {A : Type}

theorem gate_equivariant_dynamics
    (ED : EquivariantDynamics (G := G) (A := A))
    (g : G) (t : ℝ) (a : A) :
    ED.act g (ED.dyn.α t a) = ED.dyn.α t (ED.act g a) :=
  EquivariantDynamics.gate_DYN_equivariant (ED := ED) g t a

end Dyn

end SymmetryCoverageGates

end LayerA
end PillarA
