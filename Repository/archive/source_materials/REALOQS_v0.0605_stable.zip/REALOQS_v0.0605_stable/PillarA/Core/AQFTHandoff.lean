import Mathlib
import REALOQS.PillarA.Core.RegionNet

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v

structure AQFTHandoffData where
  Ω : Type u
  instFintypeΩ : Fintype Ω
  instDecEqΩ : DecidableEq Ω
  RN : RegionNet Ω
  State : Type v
  stage1 : State → State
  boundaryOp : State → Matrix Ω Ω ℝ
  cfgArity : Nat
  cfgArity_pos : 0 < cfgArity
  beta : State → ℝ
  beta_pos : ∀ s : State, 0 < beta s
  phi : Fin cfgArity → ℝ

attribute [instance] AQFTHandoffData.instFintypeΩ AQFTHandoffData.instDecEqΩ

namespace AQFTHandoffData

variable (H : AQFTHandoffData)

instance : SemilatticeSup H.RN.Region := by
  infer_instance

theorem gate_cfgArity_pos : 0 < H.cfgArity :=
  H.cfgArity_pos

theorem gate_beta_pos (s : H.State) : 0 < H.beta s :=
  H.beta_pos s

end AQFTHandoffData

end LayerA
end PillarA
