import REALOQS.PillarA.Core.NoetherHooks

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe v

abbrev Dynamics (A : Type) := REALOQS.PillarA.LayerA.Dynamics A

structure EquivariantDynamics (G : Type v) [Group G] (A : Type) : Type (max v 1) where
  dyn : Dynamics A
  act : G → A → A
  act_one : ∀ a : A, act (1 : G) a = a
  act_mul : ∀ g h : G, ∀ a : A, act (g * h) a = act g (act h a)

  intertwine : ∀ (g : G) (t : ℝ) (a : A), act g (dyn.α t a) = dyn.α t (act g a)

namespace EquivariantDynamics

variable {G : Type v} [Group G]
variable {A : Type}
variable (ED : EquivariantDynamics (G := G) (A := A))

@[simp] theorem act_one_simp (a : A) : ED.act (1 : G) a = a :=
  ED.act_one a

@[simp] theorem act_mul_simp (g h : G) (a : A) : ED.act (g * h) a = ED.act g (ED.act h a) :=
  ED.act_mul g h a

theorem gate_DYN_equivariant (g : G) (t : ℝ) (a : A) :
    ED.act g (ED.dyn.α t a) = ED.dyn.α t (ED.act g a) :=
  ED.intertwine g t a

end EquivariantDynamics

end LayerA
end PillarA
