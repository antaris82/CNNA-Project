import Mathlib.Data.Complex.Basic
import REALOQS.PillarA.Core.Exports
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarA
namespace ToC

universe u v

structure AQFTSubstrate (A : Type u) where
  SA : PillarB.AQFT.StarAlgebra A

  StateOn : Type u

  eval : StateOn → A → Complex

  isState : StateOn → Prop

  GNSData : StateOn → Type (u + 1)

  ModularKMSData : StateOn → Type (u + 1)

attribute [instance] AQFTSubstrate.SA

end ToC
end PillarA
