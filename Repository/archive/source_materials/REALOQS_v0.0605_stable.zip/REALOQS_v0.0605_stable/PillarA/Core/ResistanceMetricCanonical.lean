import Mathlib
import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Core.Policy
import REALOQS.PillarA.Core.ResistanceMetric

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace LayerA

open scoped BigOperators

noncomputable section

namespace CanonicalResistance

section

variable {b n : Nat}

abbrev V := Fin (Nat.succ n)
abbrev I := Fin n

def ground (_p : Policy b) : V (n := n) := 0

def embedExcl (g : V (n := n)) : I (n := n) → V (n := n) := Fin.succAbove g

def groundedMinor
    (g : V (n := n))
    (L : Matrix (V (n := n)) (V (n := n)) ℝ) :
    Matrix (I (n := n)) (I (n := n)) ℝ := L.submatrix (embedExcl (n := n) g) (embedExcl (n := n) g)

def symm (A : Matrix (I (n := n)) (I (n := n)) ℝ) : Matrix (I (n := n)) (I (n := n)) ℝ :=
  ((1 / 2 : ℝ) • (A + A.transpose))

def stabilized (A : Matrix (I (n := n)) (I (n := n)) ℝ) (δ : ℝ) :
    Matrix (I (n := n)) (I (n := n)) ℝ :=
  A + δ • (1 : Matrix (I (n := n)) (I (n := n)) ℝ)

def rhs (g : V (n := n)) (u v : V (n := n)) : (I (n := n) → ℝ) := fun i =>
    let j := embedExcl (n := n) g i
    (if j = u then 1 else 0) - (if j = v then 1 else 0)

def dot (b x : I (n := n) → ℝ) : ℝ := ∑ i, b i * x i

def solves (A : Matrix (I (n := n)) (I (n := n)) ℝ) (b x : I (n := n) → ℝ) : Prop :=
  ∀ i, (∑ j, A i j * x j) = b i

def delta (p : Policy b) (A : Matrix (I (n := n)) (I (n := n)) ℝ) : ℝ :=
  MatrixNorm.deltaSPD (ι := I (n := n)) (Policy.eps p) A

def systemMatrix
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n)) :
    Matrix (I (n := n)) (I (n := n)) ℝ := let S := symm (n := n) (groundedMinor (n := n) g L)
  stabilized (n := n) S (delta (n := n) p S)

def gate_STABILIZED_INVERTIBLE
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n)) : Prop := ∃ Ainv : Matrix (I (n := n)) (I (n := n)) ℝ,
    TwoSidedInv (systemMatrix (n := n) p L g) Ainv

def gate_RESISTANCE_SOLVE_WITNESS
    (p : Policy b)
    (L : Matrix (V (n := n)) (V (n := n)) ℝ)
    (g : V (n := n))
    (success : V (n := n) → V (n := n) → Prop)
    (rm : ResistanceMetric (V (n := n))) : Prop := ∀ u v, u ≠ v → success u v →
    ∃ x : I (n := n) → ℝ,
      solves (n := n) (A := systemMatrix (n := n) p L g) (b := rhs (n := n) g u v) x
      ∧ rm.R u v = ENNReal.ofReal (dot (n := n) (rhs (n := n) g u v) x)

def gate_RESISTANCE_FAIL_TOP
    (success : V (n := n) → V (n := n) → Prop)
    (rm : ResistanceMetric (V (n := n))) : Prop := ∀ u v, u ≠ v → ¬ success u v → rm.R u v = ⊤

def gate_SUCCESS_SYMM (success : V (n := n) → V (n := n) → Prop) : Prop :=
  ∀ u v, success u v ↔ success v u

structure ResistanceWellposedAxis where
  policy : Policy b
  c : PillarA.LayerA.Weight (V (n := n))
  c_symm : ∀ i j, c i j = c j i
  c_nonneg : ∀ i j, 0 ≤ c i j

  Connected : Prop

  success : V (n := n) → V (n := n) → Prop

  invertible_of_connected :
    Connected → gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy (PillarA.LayerA.laplacian c)
      (ground (b := b) (n := n) policy)

  success_of_connected :
    Connected → ∀ u v, u ≠ v → success u v

namespace ResistanceWellposedAxis

variable (A : ResistanceWellposedAxis (b := b) (n := n))

def canonWeight (c : PillarA.LayerA.Weight (V (n := n))) :
    PillarA.LayerA.Weight (V (n := n)) :=
  fun i j => max (max (c i j) 0) (max (c j i) 0)

theorem canonWeight_symm (c : PillarA.LayerA.Weight (V (n := n))) :
    (∀ i j, canonWeight (n := n) c i j = canonWeight (n := n) c j i) := by
  intro i j
  simp [canonWeight, max_comm]

theorem canonWeight_nonneg (c : PillarA.LayerA.Weight (V (n := n))) :
    (∀ i j, 0 ≤ canonWeight (n := n) c i j) := by
  intro i j
  have h₁ : (0 : ℝ) ≤ max (c i j) 0 := by exact le_max_right _ _
  exact le_trans h₁ (le_max_left _ _)

def mkOf
    (policy : Policy b)
    (c : PillarA.LayerA.Weight (V (n := n)))
    (c_symm : ∀ i j, c i j = c j i)
    (c_nonneg : ∀ i j, 0 ≤ c i j)
    (Connected : Prop)
    (success : V (n := n) → V (n := n) → Prop)
    (invertible_of_connected :
      Connected → gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy (PillarA.LayerA.laplacian c)
        (ground (b := b) (n := n) policy))
    (success_of_connected : Connected → ∀ u v, u ≠ v → success u v) :
    ResistanceWellposedAxis (b := b) (n := n) :=
  { policy := policy
    c := c
    c_symm := c_symm
    c_nonneg := c_nonneg
    Connected := Connected
    success := success
    invertible_of_connected := invertible_of_connected
    success_of_connected := success_of_connected }

def mkNonvacuous
    (policy : Policy b)
    (c_in : PillarA.LayerA.Weight (V (n := n))) :
    ResistanceWellposedAxis (b := b) (n := n) := by
  classical
  let c : PillarA.LayerA.Weight (V (n := n)) := canonWeight (n := n) c_in
  let g : V (n := n) := ground (b := b) (n := n) policy
  let L : Matrix (V (n := n)) (V (n := n)) ℝ := PillarA.LayerA.laplacian c
  let A : Matrix (I (n := n)) (I (n := n)) ℝ := systemMatrix (b := b) (n := n) policy L g
  refine
    { policy := policy
      c := c
      c_symm := canonWeight_symm (n := n) c_in
      c_nonneg := canonWeight_nonneg (n := n) c_in
      Connected := gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy L g
      success := fun u v => ∃ x : I (n := n) → ℝ,
        solves (n := n) (A := A) (b := rhs (n := n) g u v) x
      invertible_of_connected := by
        intro h; exact h
      success_of_connected := by
        intro hConn u v _huv
        rcases hConn with ⟨Ainv, hInv⟩
        refine ⟨Ainv.mulVec (rhs (n := n) g u v), ?_⟩
        intro i
        have hAA : A * Ainv = (1 : Matrix (I (n := n)) (I (n := n)) ℝ) := by
          simpa [A] using hInv.2
        have hmul : A.mulVec (Ainv.mulVec (rhs (n := n) g u v)) = rhs (n := n) g u v := by
          calc
            A.mulVec (Ainv.mulVec (rhs (n := n) g u v))
                = (A * Ainv).mulVec (rhs (n := n) g u v) := by
                    exact (Matrix.mulVec_mulVec (rhs (n := n) g u v) A Ainv)
            _ = (1 : Matrix (I (n := n)) (I (n := n)) ℝ).mulVec (rhs (n := n) g u v) := by
                    simp [hAA]
            _ = rhs (n := n) g u v := by
                    simp
        simpa [solves, Matrix.mulVec] using congrArg (fun f => f i) hmul
      }

end ResistanceWellposedAxis

structure CanonicalResistanceSpec where
  policy : Policy b
  L : Matrix (V (n := n)) (V (n := n)) ℝ
  g : V (n := n)
  g_def : g = ground (b := b) (n := n) policy
  success : V (n := n) → V (n := n) → Prop
  rm : ResistanceMetric (V (n := n))
  invertible : gate_STABILIZED_INVERTIBLE (b := b) (n := n) policy L g
  solve_witness : gate_RESISTANCE_SOLVE_WITNESS (b := b) (n := n) policy L g success rm
  fail_top : gate_RESISTANCE_FAIL_TOP (n := n) success rm
  success_symm : gate_SUCCESS_SYMM (n := n) success
  laws : ResistanceMetricLaws rm

namespace CanonicalResistanceSpec

variable (S : CanonicalResistanceSpec (b := b) (n := n))

def δ : ℝ := let A := symm (n := n) (groundedMinor (n := n) S.g S.L)
  delta (n := n) S.policy A

def dist : V (n := n) → V (n := n) → ENNReal := LayerA.dist S.rm

theorem gate_success_finite {u v : V (n := n)}
    (huv : u ≠ v) (hs : S.success u v) :
    S.rm.R u v ≠ (⊤ : ENNReal) := by
  obtain ⟨x, _hxSol, hR⟩ := S.solve_witness u v huv hs
  simp [hR]

theorem gate_delta_pos : (0 : ℝ) < S.δ := by
  have hε : (0 : ℝ) < Policy.eps S.policy := Policy.eps_pos (b := b) S.policy
  dsimp [CanonicalResistanceSpec.δ, delta]
  exact
    MatrixNorm.deltaSPD_pos (ι := I (n := n)) (ε := Policy.eps S.policy) hε
      (symm (n := n) (groundedMinor (n := n) S.g S.L))

end CanonicalResistanceSpec

end

end CanonicalResistance

end

end LayerA
end PillarA
