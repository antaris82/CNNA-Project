import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Data.Complex.Basic
import REALOQS.PillarA.Core.Derived.GNS

set_option autoImplicit false

namespace PillarA
namespace Derived

section CStar

def gnsCStarShim : Unit := ()

end CStar

end Derived
end PillarA
