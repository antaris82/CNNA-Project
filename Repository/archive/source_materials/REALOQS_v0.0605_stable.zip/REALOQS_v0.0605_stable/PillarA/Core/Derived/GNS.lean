import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Data.Complex.Basic
import REALOQS.PillarA.Core.ToC.AQFTSubstrate

set_option autoImplicit false

namespace PillarA
namespace Derived

universe u

structure GNSData (A : Type u) where

  H : Type u

  omegaVec : H

class HasDerivedGNS (A : Type u) where
  StateOn : Type u
  isState : StateOn → Prop
  mkGNSData : ∀ ω : StateOn, isState ω → GNSData A

end Derived
end PillarA
