import REALOQS.PillarA.Core.RegionNet

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v w

structure ChannelNet (Ω : Type u) where
  RN : RegionNet Ω
  Obj : RN.Region → Type v
  Chan : ∀ {a b : RN.Region}, a ≤ b → Type w
  apply : ∀ {a b : RN.Region} (hab : a ≤ b), Chan hab → Obj b → Obj a
  id : ∀ (a : RN.Region), Chan (a := a) (b := a) (le_rfl)
  apply_id : ∀ (a : RN.Region) (x : Obj a), apply (a := a) (b := a) (le_rfl) (id a) x = x
  comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c),
    Chan hab → Chan hbc → Chan (a := a) (b := c) (le_trans hab hbc)
  apply_comp : ∀ {a b c : RN.Region} (hab : a ≤ b) (hbc : b ≤ c)
      (Φab : Chan hab) (Φbc : Chan hbc) (x : Obj c),
    apply (a := a) (b := b) hab Φab (apply (a := b) (b := c) hbc Φbc x) =
      apply (a := a) (b := c) (le_trans hab hbc) (comp hab hbc Φab Φbc) x

namespace ChannelNet

variable {Ω : Type u} (CN : ChannelNet (Ω := Ω))

instance : SemilatticeSup CN.RN.Region := by
  infer_instance

theorem gate_CHAN_apply_id (a : CN.RN.Region) (x : CN.Obj a) :
    CN.apply (a := a) (b := a) (le_rfl) (CN.id a) x = x :=
  CN.apply_id a x

theorem gate_CHAN_apply_comp {a b c : CN.RN.Region}
    (hab : a ≤ b) (hbc : b ≤ c) (Φab : CN.Chan hab) (Φbc : CN.Chan hbc) (x : CN.Obj c) :
    CN.apply (a := a) (b := b) hab Φab (CN.apply (a := b) (b := c) hbc Φbc x) =
      CN.apply (a := a) (b := c) (le_trans hab hbc) (CN.comp hab hbc Φab Φbc) x :=
  CN.apply_comp hab hbc Φab Φbc x

end ChannelNet

end LayerA
end PillarA
