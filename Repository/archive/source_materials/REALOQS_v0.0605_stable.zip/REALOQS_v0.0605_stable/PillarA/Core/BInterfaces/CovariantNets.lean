import REALOQS.PillarA.Core.BInterfaces.ChannelNet
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarA.Core.BInterfaces.StateNet

set_option autoImplicit false

namespace PillarA
namespace LayerA

universe u v

namespace CovariantNets

open RegionNet

structure RegionAction {Ω : Type u} (RN : RegionNet Ω) (G : Type v) [Group G] where
  act : G → RN.Region → RN.Region
  act_mono : ∀ g : G, Monotone (act g)
  act_one : ∀ r : RN.Region, act (1 : G) r = r
  act_mul : ∀ (g h : G) (r : RN.Region), act (g * h) r = act g (act h r)

namespace RegionAction

variable {Ω : Type u} {RN : RegionNet Ω} {G : Type v} [Group G]

theorem act_le (A : RegionAction (RN := RN) (G := G)) (g : G)
    {a b : RN.Region} (hab : a ≤ b) : A.act g a ≤ A.act g b :=
  A.act_mono g hab

end RegionAction

structure CovariantLocalAlgebraNet (Ω : Type u) (G : Type v) [Group G] where
  LAN : LocalAlgebraNet Ω
  RA : RegionAction (RN := LAN.RN) (G := G)
  actAlg : ∀ g : G, ∀ r : LAN.RN.Region, LAN.Alg r → LAN.Alg (RA.act g r)
  naturality :
    ∀ (g : G) {a b : LAN.RN.Region} (hab : a ≤ b) (x : LAN.Alg a),
      actAlg g b (LAN.incl hab x) =
        LAN.incl (RA.act_le (RN := LAN.RN) (G := G) g hab) (actAlg g a x)

structure CovariantStateNet (Ω : Type u) (G : Type v) [Group G] where
  SN : StateNet Ω
  RA : RegionAction (RN := SN.RN) (G := G)
  actState : ∀ g : G, ∀ r : SN.RN.Region, SN.State r → SN.State (RA.act g r)
  naturality :
    ∀ (g : G) {a b : SN.RN.Region} (hab : a ≤ b) (ρ : SN.State b),
      actState g a (SN.restrict hab ρ) =
        SN.restrict (RA.act_le (RN := SN.RN) (G := G) g hab) (actState g b ρ)

structure CovariantChannelNet (Ω : Type u) (G : Type v) [Group G] where
  CN : ChannelNet Ω
  RA : RegionAction (RN := CN.RN) (G := G)
  actObj : ∀ g : G, ∀ r : CN.RN.Region, CN.Obj r → CN.Obj (RA.act g r)
  actChan :
    ∀ (g : G) {a b : CN.RN.Region} (hab : a ≤ b),
      CN.Chan hab → CN.Chan (RA.act_le (RN := CN.RN) (G := G) g hab)
  naturality :
    ∀ (g : G) {a b : CN.RN.Region} (hab : a ≤ b)
      (Φ : CN.Chan hab) (x : CN.Obj b),
        actObj g a (CN.apply hab Φ x) =
          CN.apply (RA.act_le (RN := CN.RN) (G := G) g hab)
            (actChan g hab Φ) (actObj g b x)

theorem gate_alg_naturality {Ω : Type u} {G : Type v} [Group G]
    (C : CovariantLocalAlgebraNet (Ω := Ω) (G := G))
    (g : G) {a b : C.LAN.RN.Region} (hab : a ≤ b) (x : C.LAN.Alg a) :
    C.actAlg g b (C.LAN.incl hab x) =
      C.LAN.incl (C.RA.act_le (RN := C.LAN.RN) (G := G) g hab) (C.actAlg g a x) :=
  C.naturality g hab x

theorem gate_state_naturality {Ω : Type u} {G : Type v} [Group G]
    (C : CovariantStateNet (Ω := Ω) (G := G))
    (g : G) {a b : C.SN.RN.Region} (hab : a ≤ b) (ρ : C.SN.State b) :
    C.actState g a (C.SN.restrict hab ρ) =
      C.SN.restrict (C.RA.act_le (RN := C.SN.RN) (G := G) g hab) (C.actState g b ρ) :=
  C.naturality g hab ρ

theorem gate_channel_naturality {Ω : Type u} {G : Type v} [Group G]
    (C : CovariantChannelNet (Ω := Ω) (G := G))
    (g : G) {a b : C.CN.RN.Region} (hab : a ≤ b)
    (Φ : C.CN.Chan hab) (x : C.CN.Obj b) :
    C.actObj g a (C.CN.apply hab Φ x) =
      C.CN.apply (C.RA.act_le (RN := C.CN.RN) (G := G) g hab)
        (C.actChan g hab Φ) (C.actObj g b x) :=
  C.naturality g hab Φ x

end CovariantNets

end LayerA
end PillarA
