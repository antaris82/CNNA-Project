import Mathlib
import REALOQS.PillarA.Core.Policy

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace LayerA

namespace MatrixNorm

section Frob

variable {ι : Type} [Fintype ι]

def frobSq (A : Matrix ι ι ℝ) : ℝ := ∑ i : ι, ∑ j : ι, (A i j) ^ 2

noncomputable def frob (A : Matrix ι ι ℝ) : ℝ := Real.sqrt (frobSq A)

noncomputable def deltaSPD (ε : ℝ) (A : Matrix ι ι ℝ) : ℝ := ε * max (1:ℝ) (frob A)

theorem deltaSPD_pos (ε : ℝ) (hε : 0 < ε) (A : Matrix ι ι ℝ) :
    0 < deltaSPD (ι := ι) ε A := by
  have hmax : 0 < max (1:ℝ) (frob (ι := ι) A) := by
    have h1 : (0:ℝ) < 1 := by norm_num
    exact lt_of_lt_of_le h1 (le_max_left _ _)
  simpa [deltaSPD] using mul_pos hε hmax

theorem frobSq_nonneg (A : Matrix ι ι ℝ) : 0 ≤ frobSq (ι := ι) A := by
  classical
  unfold frobSq
  refine Finset.sum_nonneg ?_
  intro i _
  refine Finset.sum_nonneg ?_
  intro j _
  exact sq_nonneg (A i j)

theorem frobSq_eq_zero_iff (A : Matrix ι ι ℝ) : frobSq (ι := ι) A = 0 ↔ A = 0 := by
  classical
  constructor
  · intro h
    ext i j
    have hOuter :
        (∀ i' ∈ (Finset.univ : Finset ι),
            (∑ j' : ι, (A i' j') ^ 2) = 0) := by
      have hNonneg :
          ∀ i' ∈ (Finset.univ : Finset ι), 0 ≤ (∑ j' : ι, (A i' j') ^ 2) := by
        intro i' _
        exact Finset.sum_nonneg (by intro j' _; exact sq_nonneg (A i' j'))
      have := (Finset.sum_eq_zero_iff_of_nonneg hNonneg).1 (by simpa [frobSq] using h)
      exact this
    have hInner : (∀ j' ∈ (Finset.univ : Finset ι), (A i j') ^ 2 = 0) := by
      have hNonneg :
          ∀ j' ∈ (Finset.univ : Finset ι), 0 ≤ (A i j') ^ 2 := by
        intro j' _
        exact sq_nonneg (A i j')
      have := (Finset.sum_eq_zero_iff_of_nonneg hNonneg).1 (by
        simpa using hOuter i (by simp))
      exact this
    have hPow : (A i j) ^ 2 = 0 := hInner j (by simp)
    have : A i j * A i j = 0 := by simpa [pow_two] using hPow
    have hz : A i j = 0 := by
      rcases mul_eq_zero.mp this with h0 | h0 <;> exact h0
    simp [hz]
  · intro h
    simp [frobSq, h]

theorem frobSq_pos_of_ne_zero (A : Matrix ι ι ℝ) (hA : A ≠ 0) : 0 < frobSq (ι := ι) A := by
  have h0 : frobSq (ι := ι) A ≠ 0 := by
    intro h
    exact hA ((frobSq_eq_zero_iff (ι := ι) A).1 h)
  exact lt_of_le_of_ne (frobSq_nonneg (ι := ι) A) (Ne.symm h0)

end Frob

end MatrixNorm

end LayerA
end PillarA
