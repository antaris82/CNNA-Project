import Mathlib

namespace REALOQS

namespace PillarA

namespace LayerA

open scoped BigOperators

section CommuteLemmas

variable {R : Type} [Monoid R]

theorem gate_COMMUTE_POW_LEFT {a b : R} (h : Commute a b) (n : Nat) : Commute (a^n) b := by
  simpa using h.pow_left n

theorem gate_COMMUTE_POW_RIGHT {a b : R} (h : Commute a b) (n : Nat) : Commute a (b^n) := by
  simpa using h.pow_right n

end CommuteLemmas

section GeneratorState

structure State (A : Type) where
  eval : A → ℝ

structure Dynamics (A : Type) where
  α : ℝ → A → A
  α0 : ∀ a, α 0 a = a

  α_add : ∀ t s a, α (t+s) a = α t (α s a)

def conserved {A : Type} (dyn : Dynamics A) (ω : State A) (Q : A) : Prop :=
  ∀ t : ℝ, ω.eval (dyn.α t Q) = ω.eval Q

theorem gate_CONSERVED_OF_FIXED {A : Type} (dyn : Dynamics A) (ω : State A) (Q : A)
    (hfix : ∀ t, dyn.α t Q = Q) : conserved dyn ω Q := by
  intro t
  simp [hfix t]

structure NoetherHook {A : Type} (dyn : Dynamics A) where
  IsCharge : A → Prop
  charge_fixed : ∀ Q, IsCharge Q → ∀ t : ℝ, dyn.α t Q = Q

namespace NoetherHook

variable {A : Type} {dyn : Dynamics A}

theorem gate_CHARGE_CONSERVED (H : NoetherHook (dyn := dyn)) (ω : State A) (Q : A)
    (hQ : H.IsCharge Q) : conserved dyn ω Q := by
  refine gate_CONSERVED_OF_FIXED dyn ω Q ?_
  intro t
  exact H.charge_fixed Q hQ t

def mkByFixedness {A : Type} (dyn : Dynamics A) (IsCharge : A → Prop) :
    NoetherHook (dyn := dyn) := by
  refine ⟨(fun Q => IsCharge Q ∧ ∀ t : ℝ, dyn.α t Q = Q), ?_⟩
  intro Q hQ t
  exact hQ.2 t

end NoetherHook

end GeneratorState

section OpenBalance

structure BalanceLaw where
  E : ℝ → ℝ
  Φ : ℝ → ℝ
  D : ℝ → ℝ

  law : Prop
  holds : law

theorem gate_BALANCE_SHAPE (bl : BalanceLaw) : bl.law := by
  exact bl.holds

end OpenBalance

end LayerA

end PillarA

end REALOQS
