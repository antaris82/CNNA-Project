import Mathlib
import REALOQS.PillarA.Core.Approximant
import REALOQS.PillarA.Core.RegionCore

set_option autoImplicit false

namespace PillarA

namespace LayerA

open RegionCore

universe u

structure BoundaryPorts (Cell : Nat → Type u) (L : Nat) [DecidableEq (Cell L)] where
  region : RegionAt Cell L
  ports : Finset (Cell L)
  ports_subset : ports ⊆ region

namespace BoundaryPorts

variable {Cell : Nat → Type u} {L : Nat} [DecidableEq (Cell L)]

@[simp] theorem mem_region_of_mem_ports (bp : BoundaryPorts Cell L) {x : Cell L} :
    x ∈ bp.ports → x ∈ bp.region := by
  intro hx
  exact bp.ports_subset hx

def mkAll (R : RegionAt Cell L) : BoundaryPorts Cell L :=
  ⟨R, R, by intro x hx; exact hx⟩

def refine [Substrate Cell] (bp : BoundaryPorts Cell L) :
    BoundaryPorts Cell (L + 1) := by
  refine ⟨RegionCore.refineAt (Cell := Cell) bp.region,
    Substrate.refineSet (Cell := Cell) bp.ports, ?_⟩
  intro x hx
  have hmono :
      Substrate.refineSet (Cell := Cell) bp.ports ⊆
        Substrate.refineSet (Cell := Cell) bp.region :=
    Substrate.refineSet_mono (Cell := Cell) (S := bp.ports) (T := bp.region) bp.ports_subset
  exact hmono hx

end BoundaryPorts

end LayerA

end PillarA
