import Mathlib
import REALOQS.PillarA.Core.Selection

set_option autoImplicit false
set_option linter.style.commandStart false

namespace PillarA

namespace Update

universe u

structure SeedSpec (Key : Type u) where
  seed : Key → Nat → UInt64

namespace SeedSpec

variable {Key : Type u} (S : SeedSpec Key)

theorem deterministic (k : Key) (n : Nat) :
    S.seed k n = S.seed k n := by
  rfl

def StableUnder (e : Key ≃ Key) : Prop := ∀ k n, S.seed (e k) n = S.seed k n

theorem stable_id : S.StableUnder (Equiv.refl Key) := by
  intro k n
  rfl

theorem stable_comp {e1 e2 : Key ≃ Key}
    (h1 : S.StableUnder e1) (h2 : S.StableUnder e2) :
    S.StableUnder (e1.trans e2) := by
  intro k n
  have h2' : S.seed (e2 (e1 k)) n = S.seed (e1 k) n := h2 (e1 k) n
  have h1' : S.seed (e1 k) n = S.seed k n := h1 k n
  simpa [SeedSpec.StableUnder] using h2'.trans h1'

end SeedSpec

end Update

end PillarA
