import Mathlib

set_option autoImplicit false
open scoped BigOperators

namespace PillarA
namespace Update

noncomputable section

abbrev Conductance (E : Type) := E → ℝ

def updateStep {E : Type} [DecidableEq E]
    (E0 : Finset E) (Δ : E → ℝ) (c : Conductance E) : Conductance E :=
  fun e =>
    if e ∈ E0 then c e else c e * Real.exp (Δ e)

theorem updateStep_fixed {E : Type} [DecidableEq E]
    (E0 : Finset E) (Δ : E → ℝ) (c : Conductance E) (e : E)
    (he : e ∈ E0) :
    updateStep E0 Δ c e = c e := by
  simp [updateStep, he]

theorem updateStep_dynamic {E : Type} [DecidableEq E]
    (E0 : Finset E) (Δ : E → ℝ) (c : Conductance E) (e : E)
    (he : e ∉ E0) :
    updateStep E0 Δ c e = c e * Real.exp (Δ e) := by
  simp [updateStep, he]

theorem updateStep_preserves_nonneg
    {E : Type} [DecidableEq E]
    (E0 : Finset E) (Δ : E → ℝ) (c : Conductance E)
    (hc : ∀ e, 0 ≤ c e) :
    ∀ e, 0 ≤ updateStep E0 Δ c e := by
  intro e
  by_cases he : e ∈ E0
  · simp [updateStep, he, hc]
  · have hexp : 0 ≤ Real.exp (Δ e) := le_of_lt (Real.exp_pos (Δ e))
    simp [updateStep, he, mul_nonneg (hc e) hexp]

end

end Update
end PillarA
