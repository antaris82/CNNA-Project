import Mathlib
import REALOQS.PillarA.OQS.DtN
import REALOQS.PillarA.Update.ApproximationPipeline
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver

set_option autoImplicit false

namespace PillarA
namespace Update

open scoped BigOperators

open PillarA.OQS

def linOpOfMatrix {α : Type} [Fintype α] [DecidableEq α]
    (M : Matrix α α ℝ) : LinOp (α := α) :=
  ⟨fun f => M.mulVec f⟩

structure TailElimDtNSemantics {b : Nat} (A : TwoStageApprox b) where
  V : Type
  [instFintypeV : Fintype V]
  [instDecEqV : DecidableEq V]

  split : OQS.Split V

  L : A.S → Matrix V V ℝ

  inv : ∀ s : A.S, Split.InteriorInv (s := split) (L s)

  boundaryOp : A.S → Matrix split.B split.B ℝ

  boundaryOp_def : ∀ s, boundaryOp s = split.blockBB (L s)

  stage1_boundaryOp_eq_DtN : ∀ s, boundaryOp (A.stage1 s) = split.DtN_of (L s) (inv s)

attribute [instance] TailElimDtNSemantics.instFintypeV TailElimDtNSemantics.instDecEqV

namespace TailElimDtNSemantics

variable {b : Nat} {A : TwoStageApprox b}

def opObserver (Sem : TailElimDtNSemantics A) : OpObserver A.S Sem.split.B :=
  ⟨fun s => linOpOfMatrix (α := Sem.split.B) (Sem.boundaryOp s)⟩

theorem gate_STAGE1_IS_DTN (Sem : TailElimDtNSemantics A) (s : A.S) :
    (Sem.opObserver.op (A.stage1 s)) =
      linOpOfMatrix (α := Sem.split.B) (Sem.split.DtN_of (Sem.L s) (Sem.inv s)) := by
  ext f x
  simpa [TailElimDtNSemantics.opObserver, linOpOfMatrix] using
    congrArg
      (fun M : Matrix Sem.split.B Sem.split.B ℝ => (M.mulVec f) x)
      (Sem.stage1_boundaryOp_eq_DtN s)

end TailElimDtNSemantics

end Update
end PillarA
