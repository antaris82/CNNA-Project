import Mathlib
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.Step

set_option autoImplicit false

namespace PillarA
namespace Update

section Driver

noncomputable section

structure UpdateFromMismatch (α : Type) (E : Type) where
  M : MismatchFunctional (α := α)
  mkΔ : NormalizedOp α → NormalizedOp α → (E → ℝ)

  gate_zero_no_update :
    ∀ (A B : NormalizedOp α),
      M.mismatch A B = 0 → mkΔ A B = (fun _ => 0)

noncomputable def updateStepFromMismatch {α : Type} {E : Type} [DecidableEq E]
    (D : UpdateFromMismatch α E)
    (E0 : Finset E)
    (A B : NormalizedOp α)
    (c : Conductance E) : Conductance E :=
  updateStep E0 (D.mkΔ A B) c

theorem gate_ZERO_MISMATCH_STEP_ID
    {α : Type} {E : Type} [DecidableEq E]
    (D : UpdateFromMismatch α E)
    (E0 : Finset E)
    (A B : NormalizedOp α)
    (h0 : D.M.mismatch A B = 0)
    (c : Conductance E) :
    updateStepFromMismatch (α := α) (E := E) D E0 A B c = c := by
  classical
  have hΔ : D.mkΔ A B = (fun _ => 0) := D.gate_zero_no_update A B h0
  funext e
  by_cases he : e ∈ E0
  · simp [updateStepFromMismatch, updateStep, he]
  · simp [updateStepFromMismatch, updateStep, he, hΔ]

end

end Driver

end Update
end PillarA
