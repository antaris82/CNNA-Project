import Mathlib
import REALOQS.PillarA.Physics.ScaleBreaking
import REALOQS.PillarA.Update.MismatchFunctional
import REALOQS.PillarA.Update.OpObserver

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarA

namespace Physics

open PillarA.Update

noncomputable def breakMeasure_fromMismatch_onTowerD
    {S : Nat → Type} {α : Nat → Type}
    (coarsen : ∀ k, S (k + 1) → S k)
    (tower : ∀ k, S k)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  fun k =>
    let Mk := M k
    let Ak : NormalizedOp (α := α k) :=
      normalizeTrace (α := α k) Mk.P Mk.T eps eps_pos (Obs.op k (tower k))
    let Acoarse : NormalizedOp (α := α k) :=
      normalizeTrace (α := α k) Mk.P Mk.T eps eps_pos (Obs.op k (coarsen k (tower (k + 1))))
    Mk.mismatch Ak Acoarse

noncomputable def breakMeasure_fromMismatchRealD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTowerD (S := S) (α := α) A.coarsen A.real Obs M eps eps_pos

noncomputable def breakMeasure_fromMismatchIdealD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : Nat → ENNReal :=
  breakMeasure_fromMismatch_onTowerD (S := S) (α := α) A.coarsen A.ideal Obs M eps eps_pos

noncomputable def axis_fromMismatchD
    {S : Nat → Type} {α : Nat → Type}
    (A : ScaleBreakingAxisD S)
    (Obs : OpObserverD S α)
    (M : ∀ k, MismatchFunctional (α := α k))
    (eps : ℝ) (eps_pos : eps > 0) : ScaleBreakingAxisD S :=
  { coarsen := A.coarsen
    , ideal := A.ideal
    , real := A.real
    , breakMeasure := breakMeasure_fromMismatchRealD (S := S) (α := α) A Obs M eps eps_pos
    , breakMeasureIdeal := breakMeasure_fromMismatchIdealD (S := S) (α := α) A Obs M eps eps_pos }

end Physics

end PillarA
