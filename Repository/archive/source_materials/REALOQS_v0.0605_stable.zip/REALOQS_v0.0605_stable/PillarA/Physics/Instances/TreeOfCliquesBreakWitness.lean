import Mathlib
import REALOQS.PillarA.Core.Gates
import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.Ideal.TreeOfCliques.Laplacian
import REALOQS.PillarA.Ideal.TreeOfCliques.Level1Facts
import REALOQS.PillarA.Ideal.TreeOfCliques.SmallScales
import REALOQS.PillarA.Ideal.TreeOfCliques.Split

set_option autoImplicit false

namespace PillarA
namespace Physics
namespace Instances
namespace TreeOfCliques

noncomputable section

open scoped BigOperators

namespace ToC

variable {b : Nat}

private lemma rowSum_L1_zero (v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1) :
    (∑ w : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1,
        _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1 v w)
      = 0 := by
  classical
  simpa
      [_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L,
        _root_.PillarA.Ideal.TreeOfCliques.laplacian]
    using
      (_root_.PillarA.LayerA.laplacian_rowSum_zero
        (V := _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1)
        (c := _root_.PillarA.Ideal.TreeOfCliques.conductance (b := b) (k := 1)) v)

theorem adj_boundary1_root (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    _root_.PillarA.Ideal.TreeOfCliques.Adj
        (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x)
        (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
          (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)) := by
  classical
  simp [_root_.PillarA.Ideal.TreeOfCliques.Adj,
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding,
    _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding,
    _root_.PillarA.Ideal.TreeOfCliques.rootI1_val]
  refine Or.inl (Or.inr ?_)
  have hx' :=
    _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
      (b := b) x
  rcases hx' with ⟨d, hx⟩
  refine And.intro ?_ ?_
  · simp [hx]
  · simp [hx]

theorem laplacian_boundary_root_eq_neg_one (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    _root_.PillarA.Ideal.TreeOfCliques.laplacian (b := b) 1
        (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x)
        (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
          (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b))
      = (-1 : ℝ) := by
  classical
  let vx : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x
  let vr : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
      (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
  have hadj : _root_.PillarA.Ideal.TreeOfCliques.Adj vx vr := by
    simpa [vx, vr] using adj_boundary1_root (b := b) x
  have hne : vx ≠ vr := by
    intro h
    have haddr : (x : _root_.PillarA.Ideal.Addr b) = ([] : _root_.PillarA.Ideal.Addr b) := by
      have := congrArg Subtype.val h
      simpa [vx, vr,
        _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding,
        _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding,
        _root_.PillarA.Ideal.TreeOfCliques.rootI1_val] using this
    rcases
      _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
        (b := b) x with ⟨d, hx⟩
    have : ([d] : _root_.PillarA.Ideal.Addr b) = ([] : _root_.PillarA.Ideal.Addr b) := by
      calc
        ([d] : _root_.PillarA.Ideal.Addr b) = (x : _root_.PillarA.Ideal.Addr b) := hx.symm
        _ = ([] : _root_.PillarA.Ideal.Addr b) := haddr
    exact (List.cons_ne_nil d []) this
  simp [vx, vr,
    _root_.PillarA.Ideal.TreeOfCliques.laplacian,
    _root_.PillarA.LayerA.laplacian,
    _root_.PillarA.Ideal.TreeOfCliques.conductance,
    hadj, hne]

theorem laplacian_root_boundary_eq_neg_one (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    _root_.PillarA.Ideal.TreeOfCliques.laplacian (b := b) 1
        (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
          (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b))
        (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x)
      = (-1 : ℝ) := by
  classical
  let vx : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x
  let vr : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
      (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
  have hadj : _root_.PillarA.Ideal.TreeOfCliques.Adj vr vx := by
    have h1 : _root_.PillarA.Ideal.TreeOfCliques.Adj vx vr := by
      simpa [vx, vr] using adj_boundary1_root (b := b) x
    exact (_root_.PillarA.Ideal.TreeOfCliques.Adj_symm (x := vx) (y := vr)).1 h1
  have hne : vr ≠ vx := by
    intro h
    have hxne : vx ≠ vr := by
      intro h'
      have haddr : (x : _root_.PillarA.Ideal.Addr b) = ([] : _root_.PillarA.Ideal.Addr b) := by
        have := congrArg Subtype.val h'
        simpa [vx, vr,
          _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding,
          _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding,
          _root_.PillarA.Ideal.TreeOfCliques.rootI1_val] using this
      rcases
        _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.boundary1_val_eq_singleton
          (b := b) x with ⟨d, hx⟩
      have : ([d] : _root_.PillarA.Ideal.Addr b) = ([] : _root_.PillarA.Ideal.Addr b) := by
        calc
          ([d] : _root_.PillarA.Ideal.Addr b) = (x : _root_.PillarA.Ideal.Addr b) := hx.symm
          _ = ([] : _root_.PillarA.Ideal.Addr b) := haddr
      exact (List.cons_ne_nil d []) this
    exact hxne h.symm
  simp [vx, vr,
    _root_.PillarA.Ideal.TreeOfCliques.laplacian,
    _root_.PillarA.LayerA.laplacian,
    _root_.PillarA.Ideal.TreeOfCliques.conductance,
    hadj, hne]

theorem sum_vertex_k1_split (f : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 → ℝ) :
    (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, f v)
      =
    (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        f (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
      +
    (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
        f (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) := by
  classical
  let e := _root_.PillarA.Ideal.TreeOfCliques.Split.equivVertexSum (b := b) (k := 1)
  have hreindex :
      (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, f v)
        =
      (∑ s : Sum (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
                  (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1),
        f (e.symm s)) := by
    refine
      (Fintype.sum_equiv e (fun v => f v) (fun s => f (e.symm s)) ?_)
    intro v
    simp
  calc
    (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, f v)
        =
      (∑ s : Sum (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
                  (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1),
        f (e.symm s)) := hreindex
    _ =
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        f (e.symm (Sum.inl x)))
      +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
        f (e.symm (Sum.inr i))) := by
      simp [Fintype.sum_sum_type]
    _ =
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        f (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
      +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
        f (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) := by
      simp [e, _root_.PillarA.Ideal.TreeOfCliques.Split.equivVertexSum,
        _root_.PillarA.Ideal.TreeOfCliques.Split.fromSum]

theorem sum_row_LBB_eq_one (x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x y)
      = (1 : ℝ) := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let vx : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x

  have hrowsum : (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, L1 vx v) = 0 := by
    simpa [L1] using rowSum_L1_zero (b := b) vx

  have hsplit :
      (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, L1 vx v)
        =
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y))
        +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) := by
    simpa [L1] using
      (sum_vertex_k1_split (b := b) (f := fun v => L1 vx v))

  have hsum :
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y))
        +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i))
        = 0 :=
    Eq.trans hsplit.symm hrowsum

  have hI :
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i))
        = (-1 : ℝ) := by
    classical
    have huniv :
        (Finset.univ : Finset (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1))
          = {_root_.PillarA.Ideal.TreeOfCliques.rootI1 b} := by
      ext i
      constructor
      · intro _
        simpa [Finset.mem_singleton] using
          (Subsingleton.elim i (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b))
      · intro _
        exact Finset.mem_univ i
    have hsingle :
        (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
            L1 vx
              (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i))
          =
        L1 vx
          (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
            (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)) := by
      change
        (Finset.univ.sum
            (fun i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1 =>
              L1 vx
                (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)))
          = _
      rw [huniv]
      simp
    simpa [hsingle, L1] using (laplacian_boundary_root_eq_neg_one (b := b) x)

  have hB0 :
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y))
        =
      - (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) := by
    have :=
      congrArg
        (fun t : ℝ =>
          t -
            (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
              L1 vx
                (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)))
        hsum
    simpa [add_sub_cancel, zero_sub] using this

  have hB :
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y))
        = (1 : ℝ) := by
    calc
      (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vx
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) y))
          =
          - (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
              L1 vx
                (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) :=
        hB0
      _ = -(-1 : ℝ) := by
        rw [hI]
      _ = (1 : ℝ) := by
        norm_num

  simpa [L1, s1, vx,
    _root_.PillarA.OQS.Split.blockBB,
    _root_.PillarA.OQS.Split.reindex] using hB

theorem sum_all_LBB_eq_b :
    (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockBB
            (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)) x y)
      = (b : ℝ) := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  have hrow :
      (fun x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 =>
          (∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (s1.blockBB L1) x y))
        = fun _ => (1 : ℝ) := by
    funext x
    simpa [L1, s1] using (sum_row_LBB_eq_one (b := b) x)
  have hsum :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (s1.blockBB L1) x y)
        = (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (1 : ℝ)) := by
    exact congrArg (fun g => ∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, g x) hrow
  calc
    (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (s1.blockBB L1) x y)
        = (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (1 : ℝ)) := by
          exact hsum
    _ = (Fintype.card (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) : ℝ) := by
          simp
    _ = (b : ℝ) := by
          exact congrArg (fun n : Nat => (n : ℝ))
            (_root_.PillarA.Ideal.TreeOfCliques.card_boundary1 b)

theorem LII_root_root_eq_b :
    ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))
        (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
        (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
      = (b : ℝ) := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let vr : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1 :=
    _root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1)
      (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)

  have hrowsum : (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, L1 vr v) = 0 := by
    simpa [L1] using rowSum_L1_zero (b := b) vr

  have hsplit :
      (∑ v : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 1, L1 vr v)
        =
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
        +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)) := by
    simpa [L1] using
      (sum_vertex_k1_split (b := b) (f := fun v => L1 vr v))

  have hsum :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
        +
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i))
        = 0 :=
    Eq.trans hsplit.symm hrowsum

  have hB :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
        = -(b : ℝ) := by
    have hfun :
        (fun x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1 =>
            L1 vr
              (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
          = fun _ => (-1 : ℝ) := by
      funext x
      simpa [L1, _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L] using
        (laplacian_root_boundary_eq_neg_one (b := b) x)
    have hsumB :
        (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            L1 vr
              (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
          = (∑ _x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (-1 : ℝ)) := by
      exact
        congrArg
          (fun g =>
            ∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, g x)
          hfun
    calc
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.boundaryEmbedding (b := b) (k := 1) x))
          = (∑ _x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1, (-1 : ℝ)) := by
              exact hsumB
      _ = -(Fintype.card (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) : ℝ) := by
              simp
      _ = -(b : ℝ) := by
              exact congrArg (fun n : Nat => -(n : ℝ))
                (_root_.PillarA.Ideal.TreeOfCliques.card_boundary1 b)

  have hI :
      (∑ i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1,
          L1 vr
            (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i))
        = L1 vr vr := by
    classical
    have huniv :
        (Finset.univ : Finset (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1))
          = {_root_.PillarA.Ideal.TreeOfCliques.rootI1 b} := by
      ext i
      constructor
      · intro _
        simpa [Finset.mem_singleton] using
          (Subsingleton.elim i (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b))
      · intro _
        exact Finset.mem_univ i
    change
      (Finset.univ.sum
          (fun i : _root_.PillarA.Ideal.TreeOfCliques.Interior b 1 =>
            L1 vr
              (_root_.PillarA.Ideal.TreeOfCliques.interiorEmbedding (b := b) (k := 1) i)))
        = _
    rw [huniv]
    simp [vr]

  have hdiag : L1 vr vr = (b : ℝ) := by
    have hsum' : (-(b : ℝ)) + (L1 vr vr) = 0 := by
      have h := hsum
      rw [hB] at h
      rw [hI] at h
      exact h
    have := congrArg (fun t : ℝ => t + (b : ℝ)) hsum'
    simpa [add_assoc, add_left_comm, add_comm] using this

  simpa [L1, s1, vr,
    _root_.PillarA.OQS.Split.blockII,
    _root_.PillarA.OQS.Split.reindex] using hdiag

private lemma half_mul_add_self (a : ℝ) : (1 / 2 : ℝ) * (a + a) = a := by
  linarith

theorem delta_pos_k1 (p : _root_.PillarA.LayerA.Policy b) :
    0 <
      _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
        (p := p)
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (_root_.PillarA.OQS.Split.DtNStabilized.symm
          (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
          ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
            (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))) := by
  classical
  simpa using
    (_root_.PillarA.OQS.Split.DtNStabilized.deltaNum_pos
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (A :=
        _root_.PillarA.OQS.Split.DtNStabilized.symm
          (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
          ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
            (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))))

theorem LII_stab_root_root_eq_b_add_delta (p : _root_.PillarA.LayerA.Policy b) :
    (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1)
        (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
        (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
      =
        (b : ℝ)
        +
          _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
            (p := p)
            (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
            (_root_.PillarA.OQS.Split.DtNStabilized.symm
              (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
              ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
                (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1))) := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let i0 := _root_.PillarA.Ideal.TreeOfCliques.rootI1 b
  let A : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1) ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.symm
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1) (s1.blockII L1)
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1) A

  have hBlock : s1.blockII L1 i0 i0 = (b : ℝ) := by
    simpa [L1, s1, i0] using (LII_root_root_eq_b (b := b))

  have hA : A i0 i0 = (b : ℝ) := by
    have hA' :
        A i0 i0 =
          (2⁻¹ : ℝ) * s1.blockII L1 i0 i0 + (2⁻¹ : ℝ) * s1.blockII L1 i0 i0 := by
      simp [A, i0, _root_.PillarA.OQS.Split.DtNStabilized.symm]
    have hhalf (t : ℝ) : (2⁻¹ : ℝ) * t + (2⁻¹ : ℝ) * t = t := by
      ring
    calc
      A i0 i0 = (2⁻¹ : ℝ) * s1.blockII L1 i0 i0 + (2⁻¹ : ℝ) * s1.blockII L1 i0 i0 := hA'
      _ = s1.blockII L1 i0 i0 := by
        simp [hhalf (s1.blockII L1 i0 i0)]
      _ = (b : ℝ) := hBlock

  have hstab :
      (_root_.PillarA.OQS.Split.DtNStabilized.LII_stabilized (s := s1) (p := p) (L := L1)) i0 i0
        = (b : ℝ) + δ := by
    simp [_root_.PillarA.OQS.Split.DtNStabilized.LII_stabilized,
      _root_.PillarA.OQS.Split.DtNStabilized.stabilize,
      _root_.PillarA.OQS.Split.DtNStabilized.deltaSPD_eq_deltaNum,
      A, δ, i0, hA]

  simpa [L1, s1, A, δ, i0, _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab] using hstab

theorem LII_stab_inv_root_root_eq_inv_b_add_delta (p : _root_.PillarA.LayerA.Policy b) :
    let LII := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1
    let δ : ℝ :=
      _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
        (p := p)
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (_root_.PillarA.OQS.Split.DtNStabilized.symm
          (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
          ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
            (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)))
    (LII⁻¹) (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
          (_root_.PillarA.Ideal.TreeOfCliques.rootI1 b)
      = ((b : ℝ) + δ)⁻¹ := by
  classical
  let LII := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.OQS.Split.DtNStabilized.symm
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1).blockII
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1)))
  let i0 := _root_.PillarA.Ideal.TreeOfCliques.rootI1 b

  have huniv : (Finset.univ : Finset (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1)) = {i0} := by
    ext i
    constructor
    · intro _
      have : i = i0 := Subsingleton.elim i i0
      simp [this]
    · intro _
      exact Finset.mem_univ i

  have hdet : LII.det ≠ 0 := by
    simpa [LII]
      using
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.detGate_proved (b := b) (p := p) 1)

  have invOK : _root_.PillarA.LayerA.TwoSidedInv LII (LII⁻¹) := by
    exact _root_.PillarA.LayerA.gate_DTN_WELLPOSED_canonical
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1) (A := LII) hdet

  have hmul_entry : (LII * LII⁻¹) i0 i0 = 1 := by
    have := congrArg (fun M => M i0 i0) invOK.2
    simpa using this

  have hmul_scalar : LII i0 i0 * (LII⁻¹) i0 i0 = 1 := by
    simpa [Matrix.mul_apply, huniv, i0] using hmul_entry

  have hdiag : LII i0 i0 = (b : ℝ) + δ := by
    simpa [LII, δ, i0] using (LII_stab_root_root_eq_b_add_delta (b := b) (p := p))

  have hδpos : 0 < δ := by
    simpa [δ] using (delta_pos_k1 (b := b) (p := p))

  have hApos : 0 < (b : ℝ) + δ :=
    add_pos_of_nonneg_of_pos (by exact_mod_cast (Nat.zero_le b)) hδpos

  have hAne : (b : ℝ) + δ ≠ 0 := ne_of_gt hApos

  have : (LII⁻¹) i0 i0 = ((b : ℝ) + δ)⁻¹ := by
    have hmul' : ((b : ℝ) + δ) * (LII⁻¹) i0 i0 = 1 := by
      simpa [hdiag] using hmul_scalar
    have := congrArg (fun t => (((b : ℝ) + δ)⁻¹) * t) hmul'
    simpa [mul_assoc, hAne] using this

  simpa [LII, δ] using this

theorem schur_entry_const_k1
    (p : _root_.PillarA.LayerA.Policy b)
    (x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) :
    let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
    let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
    let δ : ℝ :=
      _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
        (p := p)
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (_root_.PillarA.OQS.Split.DtNStabilized.symm
          (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
          (s1.blockII L1))
    ((s1.blockBI L1) *
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1)⁻¹ *
        (s1.blockIB L1)) x y
      = ((b : ℝ) + δ)⁻¹ := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum
      (p := p)
      (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
      (_root_.PillarA.OQS.Split.DtNStabilized.symm
        (ι := _root_.PillarA.Ideal.TreeOfCliques.Interior b 1)
        (s1.blockII L1))
  let i0 := _root_.PillarA.Ideal.TreeOfCliques.rootI1 b

  have huniv : (Finset.univ : Finset (_root_.PillarA.Ideal.TreeOfCliques.Interior b 1)) = {i0} := by
    ext i
    constructor
    · intro _
      have : i = i0 := Subsingleton.elim i i0
      simp [this]
    · intro _
      exact Finset.mem_univ i

  have hBI : s1.blockBI L1 x i0 = (-1 : ℝ) := by
    simpa [L1, _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L, s1, i0,
      _root_.PillarA.OQS.Split.blockBI, _root_.PillarA.OQS.Split.reindex] using
      (laplacian_boundary_root_eq_neg_one (b := b) x)

  have hIB : s1.blockIB L1 i0 y = (-1 : ℝ) := by
    simpa [L1, _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L, s1, i0,
      _root_.PillarA.OQS.Split.blockIB, _root_.PillarA.OQS.Split.reindex] using
      (laplacian_root_boundary_eq_neg_one (b := b) y)

  have hInv :
      ((_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab (b := b) (p := p) 1)⁻¹) i0 i0
        = ((b : ℝ) + δ)⁻¹ := by
    simpa [i0, δ] using
      (LII_stab_inv_root_root_eq_inv_b_add_delta (b := b) (p := p))

  simp [L1, s1, δ, i0, Matrix.mul_apply, huniv, hBI, hIB, hInv]

theorem coarsen0_real1_entry_eq_sum (p : _root_.PillarA.LayerA.Policy b) :
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 0
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized (b := b) (p := p) 1)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b)
      =
    (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized (b := b) (p := p) 1)
            x y) := by
  classical
  simp [_root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat,
    _root_.PillarA.Ideal.TreeOfCliques.Level1Facts.fiber_rootB0_eq_univ]

theorem sum_all_real1_pos
    (p : _root_.PillarA.LayerA.Policy b) (hb : 0 < b) :
    0 <
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
              (b := b) (p := p) 1) x y) := by
  classical
  let L1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 1
  let s1 := _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 1
  let δ : ℝ :=
    _root_.PillarA.OQS.Split.DtNStabilized.deltaNum p
      (_root_.PillarA.OQS.Split.DtNStabilized.symm (s1.blockII L1))
  let Schur :
      Matrix (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1)
        (_root_.PillarA.Ideal.TreeOfCliques.Boundary b 1) ℝ :=
    s1.blockBI L1 *
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.LII_stab p 1)⁻¹ *
      s1.blockIB L1

  have hbR : 0 < (b : ℝ) := by exact_mod_cast hb
  have hδpos : 0 < δ := by
    simpa [δ] using (delta_pos_k1 (b := b) (p := p))
  have hbδpos : 0 < (b : ℝ) + δ := add_pos hbR hδpos
  have hbδne : (b : ℝ) + δ ≠ 0 := ne_of_gt hbδpos

  have hSchurEntry :
      ∀ x y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        Schur x y = ((b : ℝ) + δ)⁻¹ := by
    intro x y
    simpa [Schur, L1, s1, δ] using
      (schur_entry_const_k1 (b := b) (p := p) x y)

  have hcells :
      (_root_.PillarA.Ideal.cellsAtLevel b 1).card = b := by
    simpa using (_root_.PillarA.Ideal.card_cellsAtLevel b 1)

  have hcellsR :
      (( _root_.PillarA.Ideal.cellsAtLevel b 1).card : ℝ) = (b : ℝ) := by
    exact_mod_cast hcells

  have hsumSchur :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          Schur x y)
        = (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹ := by
    have h' :
        (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            Schur x y)
          =
          (( _root_.PillarA.Ideal.cellsAtLevel b 1).card : ℝ) *
            ((( _root_.PillarA.Ideal.cellsAtLevel b 1).card : ℝ) *
              ((b : ℝ) + δ)⁻¹) := by
        simp [hSchurEntry, Finset.sum_const, nsmul_eq_mul]
    have h'' :
        (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            Schur x y)
          = (b : ℝ) * ((b : ℝ) * ((b : ℝ) + δ)⁻¹) := by
      simpa [hcellsR] using h'
    simpa [mul_assoc] using h''

  have hsumDtN :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
              (b := b) (p := p) 1) x y)
        =
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          s1.blockBB L1 x y) -
        (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            Schur x y) := by
    simp [ _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized,
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
      _root_.PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
      _root_.PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
      _root_.PillarA.OQS.Split.DtNStabilized.interiorInvStabilized_of_det,
      _root_.PillarA.OQS.Split.DtNStabilized.LII_stabilized,
      _root_.PillarA.LayerA.DtN,
      Schur, L1, s1,
      Matrix.sub_apply, Finset.sum_sub_distrib]

  have hsumLBB :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          s1.blockBB L1 x y) = (b : ℝ) := by
    simpa [L1, s1] using (sum_all_LBB_eq_b (b := b))

  have hsumSchur_attach :
      (∑ x ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
        ∑ y ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
          Schur x y)
        = (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹ := by
    simpa using hsumSchur

  have hsumLBB_attach :
      (∑ x ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
        ∑ y ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
          s1.blockBB L1 x y) = (b : ℝ) := by
    simpa using hsumLBB

  have hsumEq :
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
              (b := b) (p := p) 1) x y)
        = (b : ℝ) - (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹ := by
    calc
      (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
        ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
              (b := b) (p := p) 1) x y)
          =
        (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
          ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            s1.blockBB L1 x y) -
          (∑ x : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
            ∑ y : _root_.PillarA.Ideal.TreeOfCliques.Boundary b 1,
              Schur x y) := by
          exact hsumDtN
      _ = (b : ℝ) - (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹ := by
          simp [hsumLBB_attach, hsumSchur_attach]

  have hsumEq_attach :
      (∑ x ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
        ∑ y ∈ (_root_.PillarA.Ideal.cellsAtLevel b 1).attach,
          (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
              (b := b) (p := p) 1) x y)
        = (b : ℝ) - (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹ := by
    simpa using hsumEq

  have hrewrite :
      (b : ℝ) - (b : ℝ) * (b : ℝ) * ((b : ℝ) + δ)⁻¹
        = (b : ℝ) * δ * ((b : ℝ) + δ)⁻¹ := by
    field_simp [hbδne]
    ring_nf

  have hinvpos : 0 < ((b : ℝ) + δ)⁻¹ := inv_pos.2 hbδpos
  have hbδ : 0 < (b : ℝ) * δ := mul_pos hbR hδpos
  have hpos : 0 < (b : ℝ) * δ * ((b : ℝ) + δ)⁻¹ := by
    have : 0 < ((b : ℝ) * δ) * ((b : ℝ) + δ)⁻¹ := mul_pos hbδ hinvpos
    simpa [mul_assoc] using this

  simpa [hsumEq_attach, hrewrite] using hpos

theorem coarsen0_real1_pos
    (p : _root_.PillarA.LayerA.Policy b) (hb : 0 < b) :
    0 <
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 0
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized (b := b) (p := p) 1)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b) := by
  have hsum := sum_all_real1_pos (b := b) (p := p) hb
  simpa [coarsen0_real1_entry_eq_sum (b := b) (p := p)] using hsum

theorem coarsen0_real1_ne_zero
    (p : _root_.PillarA.LayerA.Policy b) (hb : 0 < b) :
    _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat b 0
        (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized (b := b) (p := p) 1)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b)
        (_root_.PillarA.Ideal.TreeOfCliques.rootB0 b) ≠ 0 :=
  ne_of_gt (coarsen0_real1_pos (b := b) (p := p) hb)

private lemma nil_mem_cellsUpTo0 (b : Nat) :
    ([] : _root_.PillarA.Ideal.Addr b) ∈ _root_.PillarA.Ideal.cellsUpTo b 0 := by
  have h0 :
      ([] : _root_.PillarA.Ideal.Addr b) ∈ _root_.PillarA.Ideal.cellsAtLevel b 0 := by
    simpa using
      (_root_.PillarA.Ideal.mem_cellsAtLevel_iff_length (b := b) (k := 0)
          ([] : _root_.PillarA.Ideal.Addr b)).2 rfl
  simpa [_root_.PillarA.Ideal.cellsUpTo] using h0

private def rootV0 (b : Nat) : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 0 :=
  ⟨[], nil_mem_cellsUpTo0 (b := b)⟩

instance instUniqueVertex0 (b : Nat) : Unique (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0) where
  default := rootV0 b
  uniq v := by
    apply Subtype.ext
    have hle : v.1.length ≤ 0 := by
      have hdepth : _root_.PillarA.Ideal.TreeOfCliques.Vertex.depth v ≤ 0 :=
        _root_.PillarA.Ideal.TreeOfCliques.Vertex.depth_le (v := v)
      simpa [_root_.PillarA.Ideal.TreeOfCliques.Vertex.depth,
        _root_.PillarA.Ideal.TreeOfCliques.Vertex.addr] using hdepth
    have hlen : v.1.length = 0 := Nat.eq_zero_of_le_zero hle
    exact (List.length_eq_zero_iff).1 hlen

theorem laplacian_k0_eq_zero (b : Nat) :
    _root_.PillarA.Ideal.TreeOfCliques.laplacian (b := b) 0 = 0 := by
  classical
  ext i j
  have hij : i = j := Subsingleton.elim i j
  subst hij
  have hi : i = (default : _root_.PillarA.Ideal.TreeOfCliques.Vertex b 0) := Unique.eq_default i
  simp [_root_.PillarA.Ideal.TreeOfCliques.laplacian,
    _root_.PillarA.LayerA.laplacian,
    _root_.PillarA.LayerA.degree,
    hi]

theorem real0_eq_zero (p : _root_.PillarA.LayerA.Policy b) :
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized (b := b) (p := p) 0 = 0 := by
  classical
  have hL0 :
      _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L (b := b) 0 = 0 := by
    simpa [_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.L] using (laplacian_k0_eq_zero (b := b))

  have hBB :
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 0).blockBB
          (0 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0)
                      (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0) ℝ)
        = 0 := by
    ext i j
    simp [_root_.PillarA.OQS.Split.blockBB, _root_.PillarA.OQS.Split.reindex]
  have hBI :
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 0).blockBI
          (0 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0)
                      (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0) ℝ)
        = 0 := by
    ext i j
    simp [_root_.PillarA.OQS.Split.blockBI, _root_.PillarA.OQS.Split.reindex]
  have hIB :
      (_root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.s (b := b) 0).blockIB
          (0 : Matrix (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0)
                      (_root_.PillarA.Ideal.TreeOfCliques.Vertex b 0) ℝ)
        = 0 := by
    ext i j
    simp [_root_.PillarA.OQS.Split.blockIB, _root_.PillarA.OQS.Split.reindex]

  ext x y
  simp [
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized,
    _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized_of_det,
    _root_.PillarA.OQS.Split.DtNStabilized.dtn_stabilized_of_det,
    _root_.PillarA.OQS.Split.DtNStabilized.DtN_stabilized_of,
    _root_.PillarA.LayerA.DtN,
    hL0, hBB, hBI, hIB]

end ToC

end

end TreeOfCliques
end Instances
end Physics
end PillarA
