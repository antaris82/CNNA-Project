import Mathlib
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesApprox
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesDtNSemantics
import REALOQS.PillarA.Physics.ScaleBreakingMismatch
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff

set_option autoImplicit false

namespace PillarA
namespace Physics

noncomputable section

open PillarA.Update

namespace Instances
namespace TreeOfCliques

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev A : PillarA.Update.TwoStageApprox b :=
  PillarA.Update.Instances.TreeOfCliquesApprox.mk (b := b) p

abbrev Sem : PillarA.Update.TailElimDtNSemantics (A := (A (p := p))) :=
  PillarA.Update.Instances.TreeOfCliquesDtNSemantics.mk (b := b) p

noncomputable def mismatchFunctional
    [Fintype (Sem (p := p)).split.B] [DecidableEq (Sem (p := p)).split.B] :
    MismatchFunctional (α := (Sem (p := p)).split.B) :=
  MismatchFunctional.NormDiff.mkId (α := (Sem (p := p)).split.B)

noncomputable def scaleAxisTreeOfCliquesDtN
    [Fintype (Sem (p := p)).split.B] [DecidableEq (Sem (p := p)).split.B]
    (SB : ScaleBreakingAxis ((A (p := p)).S))
    (eps : ℝ) (eps_pos : 0 < eps) :
    ScaleBreakingAxis ((A (p := p)).S) :=
  axis_fromMismatch
    (A := SB)
    (Obs := (Sem (p := p)).opObserver)
    (M := mismatchFunctional (p := p))
    (eps := eps)
    (eps_pos := eps_pos)

end TreeOfCliques
end Instances

end
end Physics
end PillarA
