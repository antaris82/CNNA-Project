import Mathlib
import REALOQS.PillarA.Ideal.TreeOfCliques.CoarsenBoundary
import REALOQS.PillarA.Ideal.TreeOfCliques.DtNStabilized
import REALOQS.PillarA.Physics.ScaleBreakingMismatchD
import REALOQS.PillarA.Update.MismatchFunctional.NormDiff
import REALOQS.PillarA.Update.TailEliminationDtN

set_option autoImplicit false

namespace PillarA
namespace Physics
namespace Instances
namespace TreeOfCliques

noncomputable section

open _root_.PillarA
open _root_.PillarA.Update
open _root_.PillarA.Physics

namespace ToC

variable {b : Nat}

abbrev α (b : Nat) : Nat → Type := fun k => _root_.PillarA.Ideal.TreeOfCliques.Boundary b k

abbrev S (b : Nat) : Nat → Type := fun k => Matrix (α b k) (α b k) ℝ

noncomputable def Obs (b : Nat) : OpObserverD (S b) (α b) := by
  classical
  refine { op := ?_ }
  intro k M
  exact _root_.PillarA.Update.linOpOfMatrix (α := α b k) M

noncomputable def M (b : Nat) : ∀ k, MismatchFunctional (α := α b k) := by
  classical
  intro k
  exact _root_.PillarA.Update.MismatchFunctional.NormDiff.mkId (α := α b k)

def axis0 (b : Nat) (p : _root_.PillarA.LayerA.Policy b) :
    ScaleBreakingAxisD (S b) :=
  { coarsen := fun k =>
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.coarsenMat (b := b) (k := k)
    , ideal := fun k =>
      _root_.PillarA.Ideal.TreeOfCliques.CoarsenBoundary.idealTower (b := b) k
    , real := fun k =>
        _root_.PillarA.Ideal.TreeOfCliques.DtNStabilized.dtn_stabilized
          (b := b) (p := p) (k := k)
    , breakMeasure := fun _ => 0
    , breakMeasureIdeal := fun _ => 0 }

noncomputable def axis_canonicalD
    (p : _root_.PillarA.LayerA.Policy b) :
    ScaleBreakingAxisD (S b) :=
  axis_fromMismatchD
    (S := S b) (α := α b)
    (A := axis0 (b := b) (p := p))
    (Obs := Obs b)
    (M := M b)
    (eps := p.eps)
    (eps_pos := p.eps_pos)

end ToC

end

end TreeOfCliques
end Instances
end Physics
end PillarA
