import REALOQS.PillarA.Ideal.Adapter.SubstrateInstance
import REALOQS.PillarA.Ideal.TreeOfCliques.Split
import REALOQS.PillarA.OQS.DtN
import REALOQS.PillarA.Update.ApproximationPipeline

set_option autoImplicit false

namespace PillarA
namespace Update
namespace Instances

open scoped BigOperators

noncomputable section

open PillarA.LayerA
open PillarA.OQS

namespace TreeOfCliquesApprox

variable {b : Nat} (p : PillarA.LayerA.Policy b)

abbrev k : Nat := p.L_max
abbrev V : Type := PillarA.Ideal.TreeOfCliques.Vertex b (k := k p)
abbrev B : Type := PillarA.Ideal.TreeOfCliques.Boundary b (k := k p)
abbrev I : Type := PillarA.Ideal.TreeOfCliques.Interior b (k := k p)

abbrev sSplit : PillarA.OQS.Split (V := V (p := p)) :=
  PillarA.Ideal.TreeOfCliques.split (b := b) (k := k p)

structure ReducedOpState where
  LBB : Matrix (B (p := p)) (B (p := p)) ℝ
  LBI : Matrix (B (p := p)) (I (p := p)) ℝ
  LIB : Matrix (I (p := p)) (B (p := p)) ℝ
  LII : Matrix (I (p := p)) (I (p := p)) ℝ
  inv : Matrix (I (p := p)) (I (p := p)) ℝ
  invOK : PillarA.LayerA.TwoSidedInv LII inv

attribute [simp] ReducedOpState.invOK

@[ext] lemma ReducedOpState.ext
    {st st' : ReducedOpState (p := p)}
    (hBB : st.LBB = st'.LBB)
    (hBI : st.LBI = st'.LBI)
    (hIB : st.LIB = st'.LIB)
    (hII : st.LII = st'.LII)
    (hInv : st.inv = st'.inv) : st = st' := by
  cases st with
  | mk LBB LBI LIB LII inv invOK =>
    cases st' with
    | mk LBB' LBI' LIB' LII' inv' invOK' =>
      cases hBB; cases hBI; cases hIB; cases hII; cases hInv
      have hOK : invOK = invOK' := by
        apply Subsingleton.elim
      cases hOK
      rfl

def sumMatrix (st : ReducedOpState (p := p)) :
    Matrix (Sum (B (p := p)) (I (p := p))) (Sum (B (p := p)) (I (p := p))) ℝ :=
  fun x y =>
    match x, y with
    | Sum.inl b1, Sum.inl b2 => st.LBB b1 b2
    | Sum.inl b1, Sum.inr i2 => st.LBI b1 i2
    | Sum.inr i1, Sum.inl b2 => st.LIB i1 b2
    | Sum.inr i1, Sum.inr i2 => st.LII i1 i2

def fullMatrix (st : ReducedOpState (p := p)) : Matrix (V (p := p)) (V (p := p)) ℝ :=
  Matrix.reindex (sSplit (p := p)).e.symm (sSplit (p := p)).e.symm (sumMatrix (p := p) st)

@[simp] lemma blockBB_fullMatrix (st : ReducedOpState (p := p)) :
    (sSplit (p := p)).blockBB (fullMatrix (p := p) st) = st.LBB := by
  classical
  ext i j
  simp [PillarA.OQS.Split.blockBB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockII_fullMatrix (st : ReducedOpState (p := p)) :
    (sSplit (p := p)).blockII (fullMatrix (p := p) st) = st.LII := by
  classical
  ext i j
  simp [PillarA.OQS.Split.blockII, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockBI_fullMatrix (st : ReducedOpState (p := p)) :
    (sSplit (p := p)).blockBI (fullMatrix (p := p) st) = st.LBI := by
  classical
  ext i j
  simp [PillarA.OQS.Split.blockBI, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

@[simp] lemma blockIB_fullMatrix (st : ReducedOpState (p := p)) :
    (sSplit (p := p)).blockIB (fullMatrix (p := p) st) = st.LIB := by
  classical
  ext i j
  simp [PillarA.OQS.Split.blockIB, PillarA.OQS.Split.reindex, fullMatrix, sumMatrix, Matrix.reindex]

def interiorInv (st : ReducedOpState (p := p)) :
    PillarA.OQS.Split.InteriorInv (s := sSplit (p := p)) (fullMatrix (p := p) st) := by
  classical
  refine ⟨st.inv, ?_⟩
  simpa [blockII_fullMatrix (p := p) st] using st.invOK

@[simp] lemma interiorInv_inv (st : ReducedOpState (p := p)) :
    (interiorInv (p := p) st).inv = st.inv := by
  rfl

def maskBB (R : Finset (B (p := p))) (M : Matrix (B (p := p)) (B (p := p)) ℝ) :
    Matrix (B (p := p)) (B (p := p)) ℝ :=
  fun i j => if (i ∈ R ∧ j ∈ R) then M i j else 0

def maskBI (R : Finset (B (p := p))) (M : Matrix (B (p := p)) (I (p := p)) ℝ) :
    Matrix (B (p := p)) (I (p := p)) ℝ :=
  fun b i => if b ∈ R then M b i else 0

def maskIB (R : Finset (B (p := p))) (M : Matrix (I (p := p)) (B (p := p)) ℝ) :
    Matrix (I (p := p)) (B (p := p)) ℝ :=
  fun i b => if b ∈ R then M i b else 0

def select (m : SubsystemMode (PillarA.Ideal.IdealCell b (k p)))
    (st : ReducedOpState (p := p)) : ReducedOpState (p := p) := by
  classical
  cases m with
  | allCells =>
      exact st
  | region R =>
      refine {
        LBB := maskBB (p := p) (R := R) st.LBB
        LBI := maskBI (p := p) (R := R) st.LBI
        LIB := maskIB (p := p) (R := R) st.LIB
        LII := st.LII
        inv := st.inv
        invOK := st.invOK }

lemma dtn_fullMatrix_of_cross_zero (st : ReducedOpState (p := p))
    (hBI : st.LBI = 0) (hIB : st.LIB = 0) :
    (sSplit (p := p)).DtN_of (L := fullMatrix (p := p) st)
        (w := interiorInv (p := p) st) = st.LBB := by
  classical
  simp [PillarA.OQS.Split.DtN_of, PillarA.LayerA.DtN, hBI, hIB]

def reduce (st : ReducedOpState (p := p)) : ReducedOpState (p := p) :=
  { LBB := (sSplit (p := p)).DtN_of (L := fullMatrix (p := p) st)
            (w := interiorInv (p := p) st)
    LBI := 0
    LIB := 0
    LII := st.LII
    inv := st.inv
    invOK := st.invOK }

lemma dtn_fullMatrix_of_reduced (st : ReducedOpState (p := p)) :
    (sSplit (p := p)).DtN_of (L := fullMatrix (p := p) (reduce (p := p) st))
        (w := interiorInv (p := p) (reduce (p := p) st))
      = (reduce (p := p) st).LBB := by
  classical
  apply dtn_fullMatrix_of_cross_zero (p := p) (st := reduce (p := p) st) <;> rfl

lemma reduce_idem (st : ReducedOpState (p := p)) :
    reduce (p := p) (reduce (p := p) st) = reduce (p := p) st := by
  classical
  apply ReducedOpState.ext (p := p)
  · simpa [reduce] using (dtn_fullMatrix_of_reduced (p := p) st)
  · simp [reduce]
  · simp [reduce]
  · simp [reduce]
  · simp [reduce]

def mk (p : PillarA.LayerA.Policy b) : PillarA.Update.TwoStageApprox.{0} b := by
  classical
  refine
    { policy := p
      Cell := (PillarA.Ideal.IdealCell b : Nat → Type)
      S := ReducedOpState (p := p)
      truncateTail := id
      integrateTail := fun s => reduce (p := p) s
      select := fun m s => select (p := p) m s
      truncate_idem := by intro s; rfl
      integrate_idem := by intro s; simpa using (reduce_idem (p := p) s)
      stage1_idem := by
        intro s
        simpa [TwoStageApprox.stage1] using (reduce_idem (p := p) s) }

end TreeOfCliquesApprox

end

end Instances
end Update
end PillarA
