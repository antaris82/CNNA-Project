import Mathlib
import REALOQS.PillarA.Ideal.Foliation
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarA.Kinematics.Worldline

set_option linter.style.longLine false

set_option autoImplicit false

namespace PillarA
namespace Ideal

open PillarA.Kinematics

section AddrPaths

variable {b : Nat}

def τ (b : Nat) : Addr b → Nat := fun a => a.length

def Sigma (b : Nat) (n : Nat) : Set (Addr b) := {a | a ∈ cellsAtLevel b n}

notation:50 a " ⪯ " x => a <+: x

def AddrStep (x y : Addr b) : Prop := ∃ d : Fin b, y = child x d

def AddrSpacetime (b : Nat) : PillarA.Kinematics.DiscreteSpacetime (Addr b) where
  τ := τ b
  step := AddrStep (b := b)
  step_tau := by
    intro x y h
    rcases h with ⟨d, rfl⟩
    simp [child, τ, List.length_append]

theorem gate_addrSpacetime_mem_slice_iff (n : Nat) (a : Addr b) :
    a ∈ (AddrSpacetime b).Sigma n ↔ a ∈ Sigma b n := by
  change ((AddrSpacetime b).τ a = n) ↔ a ∈ cellsAtLevel b n
  simpa [PillarA.Kinematics.DiscreteSpacetime.Sigma, AddrSpacetime, Sigma, τ] using
    (mem_cellsAtLevel_iff_length b n a).symm

abbrev AddrWorldline (b : Nat) := Worldline (Addr b)

abbrev AddrWorldTube (b : Nat) := WorldTube (Addr b)

def IsFoliationAdapted (γ : AddrWorldline b) : Prop := ∀ n, τ (b := b) (γ n) = n

def IsCausalChain (γ : AddrWorldline b) : Prop := ∀ n, (γ n) ⪯ (γ (n+1))

def IsFoliationAdaptedTube (W : AddrWorldTube b) : Prop := ∀ n x, x ∈ W n → τ (b := b) x = n

def IsCausalTube (W : AddrWorldTube b) : Prop := ∀ n x, x ∈ W n → ∃ y, y ∈ W (n+1) ∧ x ⪯ y

theorem gate_adaptedTube_mem_sigma (W : AddrWorldTube b) (h : IsFoliationAdaptedTube (b := b) W)
    (n : Nat) (x : Addr b) (hx : x ∈ W n) : x ∈ Sigma b n := by
  have hxlen : x.length = n := by
    simpa [IsFoliationAdaptedTube, τ] using h n x hx
  simpa [Sigma] using (mem_cellsAtLevel_iff_length b n x).2 hxlen

theorem gate_adapted_mem_sigma (γ : AddrWorldline b) (h : IsFoliationAdapted (b := b) γ) (n : Nat) :
    γ n ∈ Sigma b n := by
  have hxlen : (γ n).length = n := by
    simpa [IsFoliationAdapted, τ] using h n
  simpa [Sigma] using (mem_cellsAtLevel_iff_length b n (γ n)).2 hxlen

theorem gate_causal_tau_mono (γ : AddrWorldline b) (h : IsCausalChain (b := b) γ) :
    ∀ n, τ (b := b) (γ n) ≤ τ (b := b) (γ (n+1)) := by
  intro n
  rcases h n with ⟨t, ht⟩
  have hlen' : (γ n).length + t.length = (γ (n+1)).length := by
    simpa [List.length_append] using congrArg List.length ht
  have hlen : (γ (n+1)).length = (γ n).length + t.length := hlen'.symm
  have : (γ n).length ≤ (γ (n+1)).length := by
    rw [hlen]
    exact Nat.le_add_right (γ n).length t.length
  simp [τ]
  exact this

theorem gate_precedes_tau_le {a x : Addr b} (h : a ⪯ x) : τ (b := b) a ≤ τ (b := b) x := by
  rcases h with ⟨t, ht⟩
  have hlen' : a.length + t.length = x.length := by
    simpa [List.length_append] using congrArg List.length ht
  have hlen : x.length = a.length + t.length := hlen'.symm
  have : a.length ≤ x.length := by
    rw [hlen]
    exact Nat.le_add_right a.length t.length
  simp [τ]
  exact this

theorem gate_precedes_len_succ_implies_child {a x : Addr b}
    (hpre : a ⪯ x) (hlen : x.length = a.length + 1) :
    ∃ d : Fin b, x = child a d := by
  rcases hpre with ⟨t, rfl⟩
  have htlen : t.length = 1 := by
    have : a.length + t.length = a.length + 1 := by
      simpa [List.length_append] using hlen
    exact Nat.add_left_cancel this
  cases t with
  | nil =>
      cases htlen
  | cons d t' =>
      have ht'len : t'.length = 0 := by
        have : Nat.succ t'.length = 1 := by
          simpa using htlen
        have : Nat.succ t'.length = Nat.succ 0 := by
          simpa using this
        exact Nat.succ_inj.mp this
      have ht' : t' = [] := by
        exact (List.length_eq_zero_iff).1 ht'len
      subst ht'
      refine ⟨d, ?_⟩
      simp [child]

def toSTWorldline (γ : AddrWorldline b)
    (hadapt : IsFoliationAdapted (b := b) γ)
    (hcausal : IsCausalChain (b := b) γ) :
    (AddrSpacetime b).Worldline := by
  refine
    { x := γ
      step_ok := ?_ }
  intro n
  have hpre : (γ n) ⪯ (γ (n+1)) := hcausal n

  have hx : (γ (n+1)).length = n + 1 := by
    simpa [IsFoliationAdapted, τ] using hadapt (n+1)
  have hy : (γ n).length = n := by
    simpa [IsFoliationAdapted, τ] using hadapt n

  have hlen : (γ (n+1)).length = (γ n).length + 1 := by
    calc
      (γ (n+1)).length = n + 1 := hx
      _ = (γ n).length + 1 := by
        simp [hy]

  rcases
      gate_precedes_len_succ_implies_child (b := b) (a := γ n) (x := γ (n + 1)) hpre hlen
    with ⟨d, hd⟩
  exact ⟨d, hd⟩

end AddrPaths

end Ideal
end PillarA
