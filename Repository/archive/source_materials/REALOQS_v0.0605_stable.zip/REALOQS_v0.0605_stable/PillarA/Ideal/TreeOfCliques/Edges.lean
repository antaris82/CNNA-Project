import REALOQS.PillarA.Ideal.TreeOfCliques.Vertex

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

def parentRel {b : Nat} (p c : Addr b) : Prop :=
  p.length + 1 = c.length ∧ p = c.dropLast

def parentEdge {b : Nat} (a₁ a₂ : Addr b) : Prop :=
  parentRel a₁ a₂ ∨ parentRel a₂ a₁

def siblingEdge {b : Nat} (a₁ a₂ : Addr b) : Prop :=
  a₁ ≠ a₂ ∧ a₁.length = a₂.length ∧ a₁.dropLast = a₂.dropLast

def adjAddr {b : Nat} (a₁ a₂ : Addr b) : Prop :=
  parentEdge a₁ a₂ ∨ siblingEdge a₁ a₂

theorem parentEdge_symm {b : Nat} (a₁ a₂ : Addr b) :
    parentEdge a₁ a₂ ↔ parentEdge a₂ a₁ := by
  simp [parentEdge, Or.comm]

theorem siblingEdge_symm {b : Nat} (a₁ a₂ : Addr b) :
    siblingEdge a₁ a₂ ↔ siblingEdge a₂ a₁ := by
  constructor
  · intro h
    rcases h with ⟨hne, hlen, hdrop⟩
    exact ⟨Ne.symm hne, hlen.symm, hdrop.symm⟩
  · intro h
    rcases h with ⟨hne, hlen, hdrop⟩
    exact ⟨Ne.symm hne, hlen.symm, hdrop.symm⟩

theorem adjAddr_symm {b : Nat} (a₁ a₂ : Addr b) :
    adjAddr a₁ a₂ ↔ adjAddr a₂ a₁ := by
  constructor
  · intro h
    cases h with
    | inl hp =>
        exact Or.inl ((parentEdge_symm (b:=b) a₁ a₂).mp hp)
    | inr hs =>
        exact Or.inr ((siblingEdge_symm (b:=b) a₁ a₂).mp hs)
  · intro h
    cases h with
    | inl hp =>
        exact Or.inl ((parentEdge_symm (b:=b) a₂ a₁).mp hp)
    | inr hs =>
        exact Or.inr ((siblingEdge_symm (b:=b) a₂ a₁).mp hs)

def Adj {b k : Nat} (x y : Vertex b k) : Prop :=
  adjAddr x.1 y.1

theorem Adj_symm {b k : Nat} (x y : Vertex b k) : Adj x y ↔ Adj y x := by
  simpa [Adj] using (adjAddr_symm (b:=b) x.1 y.1)

noncomputable def conductance {b k : Nat} (x y : Vertex b k) : ℝ := by
  classical
  exact if Adj x y then 1 else 0

theorem conductance_symm {b k : Nat} (x y : Vertex b k) :
    conductance x y = conductance y x := by
  classical
  by_cases h : Adj x y
  · have : Adj y x := (Adj_symm (x:=x) (y:=y)).1 h
    simp [conductance, h, this]
  · have : ¬ Adj y x := by
      intro hyx
      exact h ((Adj_symm (x:=x) (y:=y)).2 hyx)
    simp [conductance, h, this]

theorem conductance_nonneg {b k : Nat} (x y : Vertex b k) :
    0 ≤ conductance x y := by
  classical
  by_cases h : Adj x y <;> simp [conductance, h]

end TreeOfCliques
end Ideal
end PillarA
