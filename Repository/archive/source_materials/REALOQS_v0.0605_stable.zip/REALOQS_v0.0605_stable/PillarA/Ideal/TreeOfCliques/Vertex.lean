import REALOQS.PillarA.Ideal.Substrate

set_option autoImplicit false

namespace PillarA
namespace Ideal
namespace TreeOfCliques

abbrev Vertex (b k : Nat) : Type := ↥(cellsUpTo b k)

namespace Vertex

def addr {b k : Nat} (v : Vertex b k) : Addr b := v.1

def depth {b k : Nat} (v : Vertex b k) : Nat := v.addr.length

theorem mem_cellsUpTo_length_le (b k : Nat) (a : Addr b) :
    a ∈ cellsUpTo b k → a.length ≤ k := by
  intro ha
  induction k with
  | zero =>
      have hlen : a.length = 0 := by
        have ha0 : a ∈ cellsAtLevel b 0 := by
          have ha' := ha
          simp [cellsUpTo] at ha'
          exact ha'
        exact (mem_cellsAtLevel_iff_length b 0 a).1 ha0
      simp [hlen]
  | succ k ih =>
      have ha' : a ∈ cellsUpTo b k ∨ a ∈ cellsAtLevel b (k + 1) := by
        have ha'' := ha
        simp [cellsUpTo] at ha''
        exact ha''
      cases ha' with
      | inl hprev =>
          exact Nat.le_trans (ih hprev) (Nat.le_succ k)
      | inr hlast =>
          have hlen : a.length = k + 1 := (mem_cellsAtLevel_iff_length b (k + 1) a).1 hlast
          exact le_of_eq hlen

theorem depth_le {b k : Nat} (v : Vertex b k) : v.depth ≤ k :=
  mem_cellsUpTo_length_le b k v.1 v.2

def castSucc {b k : Nat} : Vertex b k → Vertex b (k + 1) := by
  intro v
  refine ⟨v.1, ?_⟩
  simp [cellsUpTo, v.2]

theorem cellsUpTo_subset_succ (b k : Nat) : cellsUpTo b k ⊆ cellsUpTo b (k + 1) := by
  intro a ha
  simp [cellsUpTo, ha]

end Vertex

end TreeOfCliques
end Ideal
end PillarA
