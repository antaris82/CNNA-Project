# C* Foundation Policy (C0 closure)

Goal: keep the repo on a single analytic C*-foundation.

## Canonical foundation

The only approved analytic C*-path is the Mathlib-based layer used in Pillar B:

- `REALOQS.PillarB.AQFT.CStarNorm`
- `AQFT.NonUnitalCStarAlgebraBundle`
- `AQFT.CStarAlgebraBundle`
- `AQFT.starAlgebraOfCStar`

REALOQS may add light wrappers and bridges on top of these, but must not
re-introduce a parallel project-local placeholder class for the analytic C*
role.

## Forbidden regression patterns

The following names are treated as banned placeholder/surrogate markers:

- `IsCStarOverComplex`
- `MyCStar`
- `AbstractCStar`
- `FakeCStar`
- imports of `REALOQS.PillarA.Core.Derived.GNS_CStar`

A C*-marked placeholder carrying only `trivial : True` is also considered a
regression.

## Checks

### Lean gate

`BuildAll` imports:

- `REALOQS.Meta.PillarB_PhaseC0_CStarFoundation`

This locks in the positive Mathlib-based foundation.

### External audit

Run from a repository root that contains the `REALOQS/` directory:

```bash
python3 REALOQS/tools/check_cstar_foundation.py
```

The script exits non-zero if banned placeholder markers reappear.

## Recommended local closure sequence

```bash
python3 REALOQS/tools/check_cstar_foundation.py
lake build
lake build REALOQS.BuildAll
```
