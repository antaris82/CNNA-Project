import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullDynamics

set_option autoImplicit false

namespace PillarB
namespace AQFT

inductive TimeOrientation
  | plus
  | minus

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryMatrixDyn
    (σ : TimeOrientation)
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    StarAlgDynamics (SA := Derived.matrixStarAlgebraCStar Ω) :=
  match σ with
  | .plus => Derived.fullBoundaryDynPlus (Ω := Ω) L hL
  | .minus => Derived.fullBoundaryDynMinus (Ω := Ω) L hL

@[simp] theorem boundaryMatrixDyn_plus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryMatrixDyn (Ω := Ω) TimeOrientation.plus L hL =
      Derived.fullBoundaryDynPlus (Ω := Ω) L hL := rfl

@[simp] theorem boundaryMatrixDyn_minus
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryMatrixDyn (Ω := Ω) TimeOrientation.minus L hL =
      Derived.fullBoundaryDynMinus (Ω := Ω) L hL := rfl

end

end AQFT
end PillarB
