import Mathlib.Algebra.Star.StarAlgHom
import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Analysis.CStarAlgebra.Classes
import Mathlib.Analysis.CStarAlgebra.Hom
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u v

structure NonUnitalCStarAlgebraBundle where
  Carrier : Type u
  inst : NonUnitalCStarAlgebra Carrier

attribute [instance] NonUnitalCStarAlgebraBundle.inst

structure CStarAlgebraBundle where
  Carrier : Type u
  inst : CStarAlgebra Carrier

attribute [instance] CStarAlgebraBundle.inst

namespace NonUnitalCStarAlgebraBundle

def ofType (A : Type u) [NonUnitalCStarAlgebra A] : NonUnitalCStarAlgebraBundle where
  Carrier := A
  inst := inferInstance

@[simp] theorem carrier_ofType (A : Type u) [NonUnitalCStarAlgebra A] :
    (ofType A).Carrier = A := rfl

end NonUnitalCStarAlgebraBundle

namespace CStarAlgebraBundle

def ofType (A : Type u) [CStarAlgebra A] : CStarAlgebraBundle where
  Carrier := A
  inst := inferInstance

@[simp] theorem carrier_ofType (A : Type u) [CStarAlgebra A] :
    (ofType A).Carrier = A := rfl

def toNonUnital (A : CStarAlgebraBundle) : NonUnitalCStarAlgebraBundle where
  Carrier := A.Carrier
  inst := by

    infer_instance

end CStarAlgebraBundle

abbrev NonUnitalStarHom
    (A : NonUnitalCStarAlgebraBundle.{u})
    (B : NonUnitalCStarAlgebraBundle.{v}) :=
  A.Carrier →⋆ₙₐ[ℂ] B.Carrier

abbrev StarHom (A : CStarAlgebraBundle.{u}) (B : CStarAlgebraBundle.{v}) :=
  A.Carrier →⋆ₐ[ℂ] B.Carrier

namespace NonUnitalStarHom

def id (A : NonUnitalCStarAlgebraBundle) : NonUnitalStarHom A A :=
  _root_.NonUnitalStarAlgHom.id ℂ A.Carrier

def comp {A B C : NonUnitalCStarAlgebraBundle}
    (g : NonUnitalStarHom B C) (f : NonUnitalStarHom A B) :
    NonUnitalStarHom A C :=
  _root_.NonUnitalStarAlgHom.comp g f

@[simp] theorem id_apply (A : NonUnitalCStarAlgebraBundle) (x : A.Carrier) : id A x = x := by
  simp [id]

@[simp] theorem comp_apply {A B C : NonUnitalCStarAlgebraBundle}
    (g : NonUnitalStarHom B C) (f : NonUnitalStarHom A B)
    (x : A.Carrier) : comp g f x = g (f x) := by
  simp [comp]

end NonUnitalStarHom

namespace StarHom

def id (A : CStarAlgebraBundle) : StarHom A A :=
  _root_.StarAlgHom.id ℂ A.Carrier

def comp {A B C : CStarAlgebraBundle} (g : StarHom B C) (f : StarHom A B) : StarHom A C :=
  _root_.StarAlgHom.comp g f

@[simp] theorem id_apply (A : CStarAlgebraBundle) (x : A.Carrier) : id A x = x := by
  simp [id]

@[simp] theorem comp_apply {A B C : CStarAlgebraBundle}
    (g : StarHom B C) (f : StarHom A B) (x : A.Carrier) : comp g f x = g (f x) := by
  simp [comp]

end StarHom

def starAlgebraOfCStar (A : Type u) [CStarAlgebra A] : StarAlgebra A :=
  { zero := 0
    one := 1
    add := (· + ·)
    mul := (· * ·)
    neg := Neg.neg
    star := star
    add_assoc := by intro x y z; simp [add_assoc]
    add_comm := by intro x y; simp [add_comm]
    add_zero := by intro x; simp
    zero_add := by intro x; simp
    add_left_neg := by intro x; simp
    mul_assoc := by intro x y z; simp [mul_assoc]
    one_mul := by intro x; simp
    mul_one := by intro x; simp
    left_distrib := by intro x y z; simp [mul_add]
    right_distrib := by intro x y z; simp [add_mul]
    zero_mul := by intro x; simp
    mul_zero := by intro x; simp
    star_involutive := by intro x; simp
    star_add := by intro x y; simp
    star_mul := by intro x y; simp
    star_one := by simp
    star_zero := by simp }

@[simp] theorem starAlgebraOfCStar_zero (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).zero = (0 : A) := rfl

@[simp] theorem starAlgebraOfCStar_one (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).one = (1 : A) := rfl

@[simp] theorem starAlgebraOfCStar_add (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).add = ((· + ·) : A → A → A) := rfl

@[simp] theorem starAlgebraOfCStar_mul (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).mul = ((· * ·) : A → A → A) := rfl

@[simp] theorem starAlgebraOfCStar_neg (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).neg = (Neg.neg : A → A) := rfl

@[simp] theorem starAlgebraOfCStar_star (A : Type u) [CStarAlgebra A] :
    (starAlgebraOfCStar A).star = (star : A → A) := rfl

def starAlgHomOfStarAlgHom {A : Type u} {B : Type v} [CStarAlgebra A] [CStarAlgebra B]
    (f : A →⋆ₐ[ℂ] B) :
    StarAlgHom (starAlgebraOfCStar A) (starAlgebraOfCStar B) :=
  { toFun := fun x => f x
    isHom :=
      { map_zero := by
          simp [starAlgebraOfCStar]
        map_one := by
          simp [starAlgebraOfCStar]
        map_add := by
          intro x y
          simp [starAlgebraOfCStar]
        map_mul := by
          intro x y
          simp [starAlgebraOfCStar]
        map_neg := by
          intro x
          simp [starAlgebraOfCStar]
        map_star := by
          intro x
          simpa [starAlgebraOfCStar] using (map_star f x) } }

@[simp] theorem starAlgHomOfStarAlgHom_apply {A : Type u} {B : Type v}
    [CStarAlgebra A] [CStarAlgebra B] (f : A →⋆ₐ[ℂ] B) (x : A) :
    starAlgHomOfStarAlgHom f x = f x := rfl

end AQFT
end PillarB
