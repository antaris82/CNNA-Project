import REALOQS.PillarA.Core.BInterfaces.StateNet
import REALOQS.PillarB.AQFT.LocalNet
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

namespace LocalStarAlgebraNet

variable {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω))

def toStateNet : PillarA.LayerA.StateNet (Ω := Ω) where
  RN := N.LAN.RN
  State := fun r => StateOn (N.LAN.Alg r)
  restrict := by
    intro a b hab ρ
    exact StateOn.restrict (SA := N.SA a) (SB := N.SA b) (N.inclHom hab) ρ
  restrict_id := by
    intro a ρ
    have hid :
        N.inclHom (a := a) (b := a) (le_rfl) = StarAlgHom.id (N.SA a) :=
      N.inclHom_id a

    simpa [hid] using (StateOn.restrict_id (SA := N.SA a) (ψ := ρ))
  restrict_comp := by
    intro a b c hab hbc ρ

    have h :=
      (StateOn.restrict_comp (SA := N.SA a) (SB := N.SA b) (SC := N.SA c)
        (g := N.inclHom (a := b) (b := c) hbc)
        (f := N.inclHom (a := a) (b := b) hab) (ψ := ρ)).symm

    have hhom :=
      N.inclHom_comp (a := a) (b := b) (c := c) hab hbc
    simpa [hhom] using h

end LocalStarAlgebraNet

end AQFT
end PillarB
