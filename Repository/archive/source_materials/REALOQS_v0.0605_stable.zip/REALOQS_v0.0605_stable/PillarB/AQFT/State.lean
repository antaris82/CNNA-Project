import Mathlib.Data.Complex.Basic
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u v

structure StateOn (A : Type u) where
  toFun : A → Complex

instance {A : Type u} : CoeFun (StateOn A) (fun _ => A → Complex) :=
  ⟨StateOn.toFun⟩

namespace StateOn

variable {A : Type u}

theorem ext {φ ψ : StateOn A} (h : ∀ x : A, φ x = ψ x) : φ = ψ := by
  cases φ with
  | mk f =>
    cases ψ with
    | mk g =>
      have : f = g := funext h
      cases this
      rfl

end StateOn

def IsNormalized {A : Type u} (SA : StarAlgebra A) (φ : StateOn A) : Prop :=
  φ SA.one = (1 : Complex)

def IsRealNonneg (z : Complex) : Prop :=
  z.im = 0 ∧ 0 ≤ z.re

def IsPositive {A : Type u} (SA : StarAlgebra A) (φ : StateOn A) : Prop :=
  ∀ a : A, IsRealNonneg (φ (SA.mul (SA.star a) a))

namespace StateOn

universe w

variable {A : Type u} {B : Type v}
variable {SA : StarAlgebra A} {SB : StarAlgebra B}

def restrict (f : StarAlgHom SA SB) (ψ : StateOn B) : StateOn A :=
  { toFun := fun a => ψ (f a) }

@[simp] theorem restrict_apply (f : StarAlgHom SA SB) (ψ : StateOn B) (a : A) :
    (restrict (SA := SA) (SB := SB) f ψ) a = ψ (f a) := rfl

theorem restrict_id (ψ : StateOn A) :
    restrict (SA := SA) (SB := SA) (StarAlgHom.id SA) ψ = ψ := by
  apply StateOn.ext
  intro a
  rfl

theorem restrict_comp {C : Type w} {SC : StarAlgebra C}
    (g : StarAlgHom SB SC) (f : StarAlgHom SA SB) (ψ : StateOn C) :
    restrict (SA := SA) (SB := SC) (StarAlgHom.comp g f) ψ =
      restrict (SA := SA) (SB := SB) f (restrict (SA := SB) (SB := SC) g ψ) := by
  apply StateOn.ext
  intro a
  rfl

theorem restrict_preserves_normalized (f : StarAlgHom SA SB) {ψ : StateOn B} :
    IsNormalized SB ψ → IsNormalized SA (restrict (SA := SA) (SB := SB) f ψ) := by
  intro h

  simpa [IsNormalized, StateOn.restrict, StarAlgHom.map_one f] using h

theorem restrict_preserves_positive (f : StarAlgHom SA SB) {ψ : StateOn B} :
    IsPositive SB ψ → IsPositive SA (restrict (SA := SA) (SB := SB) f ψ) := by
  intro hpos a

  have h := hpos (f a)

  simpa [IsPositive, IsRealNonneg, StateOn.restrict,
    StarAlgHom.map_mul f, StarAlgHom.map_star f] using h

end StateOn

end AQFT
end PillarB
