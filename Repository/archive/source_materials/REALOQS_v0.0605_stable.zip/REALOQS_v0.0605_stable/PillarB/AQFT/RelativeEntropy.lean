import Mathlib.Data.Real.Basic
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

variable {A : Type u} {SA : StarAlgebra A}

structure RelativeEntropy (SA : StarAlgebra A) where

  S : StateOn A → StateOn A → ℝ

  nonneg : ∀ φ ψ : StateOn A, 0 ≤ S φ ψ

  self_eq_zero : ∀ φ : StateOn A, S φ φ = 0

  isAraki : Prop

  dataProcessing : Prop

namespace RelativeEntropy

variable (H : RelativeEntropy (SA := SA))

@[simp] theorem self (φ : StateOn A) : H.S φ φ = 0 := H.self_eq_zero φ

theorem eq_zero_of_eq {φ ψ : StateOn A} (h : φ = ψ) : H.S φ ψ = 0 := by
  cases h
  simp

theorem nonneg' (φ ψ : StateOn A) : 0 ≤ H.S φ ψ := H.nonneg φ ψ

end RelativeEntropy

end AQFT
end PillarB
