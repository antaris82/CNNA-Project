import REALOQS.PillarA.Core.RegionNet
import REALOQS.PillarB.AQFT.StarAlgebra

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace HaagKastler

universe u v

section Commute

variable {A : Type u} (SA : StarAlgebra A)

def Commute (x y : A) : Prop :=
  SA.mul x y = SA.mul y x

theorem commute_symm {x y : A} : Commute SA x y → Commute SA y x := by
  intro h
  dsimp [Commute] at *
  simp [h]

end Commute

section Iso

variable {A : Type u} {B : Type v}
variable (SA : StarAlgebra A) (SB : StarAlgebra B)

structure StarAlgIso where
  hom : StarAlgHom SA SB
  inv : StarAlgHom SB SA
  left_inv : ∀ x : A, inv (hom x) = x
  right_inv : ∀ y : B, hom (inv y) = y

namespace StarAlgIso

variable {SA : StarAlgebra A} {SB : StarAlgebra B}

theorem hom_injective (e : StarAlgIso (SA := SA) (SB := SB)) : Function.Injective e.hom := by
  intro x y h
  have := congrArg e.inv h
  simpa [e.left_inv] using this

theorem hom_surjective (e : StarAlgIso (SA := SA) (SB := SB)) : Function.Surjective e.hom := by
  intro y
  refine ⟨e.inv y, ?_⟩
  exact e.right_inv y

end StarAlgIso

end Iso

section Subalgebra

variable {A : Type u} (SA : StarAlgebra A)

structure StarSubalgebra where
  carrier : Set A
  zero_mem : SA.zero ∈ carrier
  one_mem : SA.one ∈ carrier
  add_mem : ∀ {x y : A}, x ∈ carrier → y ∈ carrier → SA.add x y ∈ carrier
  mul_mem : ∀ {x y : A}, x ∈ carrier → y ∈ carrier → SA.mul x y ∈ carrier
  neg_mem : ∀ {x : A}, x ∈ carrier → SA.neg x ∈ carrier
  star_mem : ∀ {x : A}, x ∈ carrier → SA.star x ∈ carrier

def GeneratedBy (S : Set A) (x : A) : Prop :=
  ∀ U : StarSubalgebra SA, (S ⊆ U.carrier) → x ∈ U.carrier

def IsGeneratedBy (S : Set A) : Prop :=
  ∀ x : A, GeneratedBy (SA := SA) S x

theorem GeneratedBy.mono {S T : Set A} {x : A}
    (hST : S ⊆ T) (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) T x := by
  intro U hT
  apply hx U
  intro y hy
  exact hT (hST hy)

theorem IsGeneratedBy.mono {S T : Set A}
    (hST : S ⊆ T) (hS : IsGeneratedBy (SA := SA) S) :
    IsGeneratedBy (SA := SA) T := by
  intro x
  exact GeneratedBy.mono (SA := SA) hST (hS x)

theorem generatedBy_of_mem {S : Set A} {x : A} (hx : x ∈ S) :
    GeneratedBy (SA := SA) S x := by
  intro U hS
  exact hS hx

theorem GeneratedBy.zero (S : Set A) :
    GeneratedBy (SA := SA) S SA.zero := by
  intro U _hS
  exact U.zero_mem

theorem GeneratedBy.one (S : Set A) :
    GeneratedBy (SA := SA) S SA.one := by
  intro U _hS
  exact U.one_mem

theorem GeneratedBy.add {S : Set A} {x y : A}
    (hx : GeneratedBy (SA := SA) S x)
    (hy : GeneratedBy (SA := SA) S y) :
    GeneratedBy (SA := SA) S (SA.add x y) := by
  intro U hS
  exact U.add_mem (hx U hS) (hy U hS)

theorem GeneratedBy.mul {S : Set A} {x y : A}
    (hx : GeneratedBy (SA := SA) S x)
    (hy : GeneratedBy (SA := SA) S y) :
    GeneratedBy (SA := SA) S (SA.mul x y) := by
  intro U hS
  exact U.mul_mem (hx U hS) (hy U hS)

theorem GeneratedBy.neg {S : Set A} {x : A}
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (SA.neg x) := by
  intro U hS
  exact U.neg_mem (hx U hS)

theorem GeneratedBy.star {S : Set A} {x : A}
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (SA.star x) := by
  intro U hS
  exact U.star_mem (hx U hS)

def StarSubalgebra.preimage {B : Type v}
    {SB : StarAlgebra B} (U : StarSubalgebra SB) (f : StarAlgHom SA SB) :
    StarSubalgebra SA where
  carrier := { x | f x ∈ U.carrier }
  zero_mem := by
    simpa [StarAlgHom.map_zero] using U.zero_mem
  one_mem := by
    simpa [StarAlgHom.map_one] using U.one_mem
  add_mem := by
    intro x y hx hy
    simpa [StarAlgHom.map_add] using U.add_mem hx hy
  mul_mem := by
    intro x y hx hy
    simpa [StarAlgHom.map_mul] using U.mul_mem hx hy
  neg_mem := by
    intro x hx
    simpa [StarAlgHom.map_neg] using U.neg_mem hx
  star_mem := by
    intro x hx
    simpa [StarAlgHom.map_star] using U.star_mem hx

theorem GeneratedBy.map {B : Type v} {SB : StarAlgebra B}
    {S : Set A} {T : Set B} {x : A}
    (f : StarAlgHom SA SB)
    (hST : ∀ y : A, y ∈ S → f y ∈ T)
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SB) T (f x) := by
  intro U hT
  let V : StarSubalgebra SA := StarSubalgebra.preimage (SA := SA) U f
  have hSV : S ⊆ V.carrier := by
    intro y hy
    exact hT (hST y hy)
  exact hx V hSV

theorem GeneratedBy.preserved {S : Set A} {x : A}
    (f : StarAlgHom SA SA)
    (hS : ∀ y : A, y ∈ S → GeneratedBy (SA := SA) S (f y))
    (hx : GeneratedBy (SA := SA) S x) :
    GeneratedBy (SA := SA) S (f x) := by
  intro U hU
  let V : StarSubalgebra SA := StarSubalgebra.preimage (SA := SA) U f
  have hPre : S ⊆ V.carrier := by
    intro y hy
    exact hS y hy U hU
  exact hx V hPre

end Subalgebra

namespace Region

universe w

variable {Ω : Type w} (RN : PillarA.LayerA.RegionNet Ω)

structure CausalDisjoint where
  disj : RN.Region → RN.Region → Prop
  symm : ∀ {a b : RN.Region}, disj a b → disj b a
  mono_left : ∀ {a a' b : RN.Region}, a' ≤ a → disj a b → disj a' b
  mono_right : ∀ {a b b' : RN.Region}, b' ≤ b → disj a b → disj a b'

namespace CausalDisjoint

variable {RN : PillarA.LayerA.RegionNet Ω}

theorem symm' (D : CausalDisjoint (RN := RN)) {a b : RN.Region} (h : D.disj a b) : D.disj b a :=
  D.symm h

end CausalDisjoint

def carrierDisjoint : CausalDisjoint (RN := RN) where

  disj a b := Disjoint (RN.carrier a) (RN.carrier b)
  symm := by
    intro a b h
    exact h.symm
  mono_left := by
    intro a a' b haa' hdisj

    have hmono : RN.carrier a' ≤ RN.carrier a := RN.carrier_mono' (a := a') (b := a) haa'
    exact hdisj.mono_left hmono
  mono_right := by
    intro a b b' hbb' hdisj
    have hmono : RN.carrier b' ≤ RN.carrier b := RN.carrier_mono' (a := b') (b := b) hbb'
    exact hdisj.mono_right hmono

end Region

end HaagKastler
end AQFT
end PillarB
