import Mathlib
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixPhases
import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryDynMap (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) : Mat Ω :=
  fun i j => phaseMinusR L t i * A i j * phasePlusR L t j

abbrev boundaryDynMapDiag (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) : Mat Ω :=
  boundaryDynMap (Ω := Ω) L t A

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) (i j : Ω) :
    boundaryDynMap (Ω := Ω) L t A i j = phaseMinusR L t i * A i j * phasePlusR L t j := rfl

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_zero (L : Matrix Ω Ω ℝ) (t : ℝ) :
    boundaryDynMap (Ω := Ω) L t (0 : Mat Ω) = 0 := by
  ext i j
  simp [boundaryDynMap]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_add (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω) :
    boundaryDynMap (Ω := Ω) L t (A + B) =
      boundaryDynMap (Ω := Ω) L t A + boundaryDynMap (Ω := Ω) L t B := by
  ext i j
  simp [boundaryDynMap, mul_add, add_mul]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_neg (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    boundaryDynMap (Ω := Ω) L t (-A) = -boundaryDynMap (Ω := Ω) L t A := by
  ext i j
  simp [boundaryDynMap, mul_assoc]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_zero_time (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    boundaryDynMap (Ω := Ω) L 0 A = A := by
  ext i j
  simp [boundaryDynMap]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_diag
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) (i : Ω) :
    boundaryDynMap (Ω := Ω) L t A i i = A i i := by
  calc
    boundaryDynMap (Ω := Ω) L t A i i
        = phaseMinusR L t i * A i i * phasePlusR L t i := by
            simp [boundaryDynMap]
    _ = A i i * (phaseMinusR L t i * phasePlusR L t i) := by
          ac_rfl
    _ = A i i * 1 := by
          rw [phaseMinus_mul_phasePlus (L := L) t i]
    _ = A i i := by simp

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryDynMap_comp_time
    (L : Matrix Ω Ω ℝ) (s t : ℝ) (A : Mat Ω) :
    boundaryDynMap (Ω := Ω) L (s + t) A =
      boundaryDynMap (Ω := Ω) L s (boundaryDynMap (Ω := Ω) L t A) := by
  ext i j
  simp [boundaryDynMap, mul_assoc, mul_left_comm, mul_comm]

omit [Fintype Ω] in
@[simp] theorem boundaryDynMap_one (L : Matrix Ω Ω ℝ) (t : ℝ) :
    boundaryDynMap (Ω := Ω) L t (1 : Mat Ω) = 1 := by
  ext i j
  by_cases h : i = j
  · subst h
    rw [boundaryDynMap_diag (L := L) (t := t) (A := (1 : Mat Ω)) i]
  · simp [boundaryDynMap, h]

@[simp] theorem boundaryDynMap_mul
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A B : Mat Ω) :
    boundaryDynMap (Ω := Ω) L t ((matrixStarAlgebra Ω).mul A B) =
      (matrixStarAlgebra Ω).mul
        (boundaryDynMap (Ω := Ω) L t A)
        (boundaryDynMap (Ω := Ω) L t B) := by
  ext i j
  calc
    boundaryDynMap (Ω := Ω) L t ((matrixStarAlgebra Ω).mul A B) i j
        = phaseMinusR L t i * (∑ k, A i k * B k j) * phasePlusR L t j := by
            simp [boundaryDynMap, matrixStarAlgebra, Matrix.mul_apply]
    _ = ∑ k, phaseMinusR L t i * (A i k * B k j) * phasePlusR L t j := by
          rw [Finset.mul_sum, Finset.sum_mul]
    _ = ∑ k,
          ((phaseMinusR L t i * A i k * phasePlusR L t k) *
            (phaseMinusR L t k * B k j * phasePlusR L t j)) := by
          apply Finset.sum_congr rfl
          intro k hk
          calc
            phaseMinusR L t i * (A i k * B k j) * phasePlusR L t j
                = phaseMinusR L t i * A i k * B k j * phasePlusR L t j := by
                    simp [mul_assoc]
            _ = phaseMinusR L t i * A i k * ((1 : Complex) * B k j) * phasePlusR L t j := by
                    simp [mul_assoc]
            _ = phaseMinusR L t i * A i k * ((phasePlusR L t k * phaseMinusR L t k) * B k j) *
                  phasePlusR L t j := by
                    rw [phasePlus_mul_phaseMinus (L := L) t k]
            _ = ((phaseMinusR L t i * A i k * phasePlusR L t k) *
                  (phaseMinusR L t k * B k j * phasePlusR L t j)) := by
                    ac_rfl
    _ = (matrixStarAlgebra Ω).mul
          (boundaryDynMap (Ω := Ω) L t A)
          (boundaryDynMap (Ω := Ω) L t B) i j := by
          simp [boundaryDynMap, matrixStarAlgebra, Matrix.mul_apply, mul_assoc]

@[simp] theorem boundaryDynMap_star
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    boundaryDynMap (Ω := Ω) L t ((matrixStarAlgebra Ω).star A) =
      (matrixStarAlgebra Ω).star (boundaryDynMap (Ω := Ω) L t A) := by
  ext i j
  simp [boundaryDynMap, matrixStarAlgebra, mul_assoc, mul_left_comm, mul_comm]

def boundaryDynHom (L : Matrix Ω Ω ℝ) (t : ℝ) :
    StarAlgHom (matrixStarAlgebra Ω) (matrixStarAlgebra Ω) :=
  { toFun := boundaryDynMap (Ω := Ω) L t
    isHom :=
      { map_zero := boundaryDynMap_zero (Ω := Ω) L t
        map_one := boundaryDynMap_one (Ω := Ω) L t
        map_add := boundaryDynMap_add (Ω := Ω) L t
        map_mul := boundaryDynMap_mul (Ω := Ω) L t
        map_neg := boundaryDynMap_neg (Ω := Ω) L t
        map_star := boundaryDynMap_star (Ω := Ω) L t } }

@[simp] theorem boundaryDynHom_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    boundaryDynHom (Ω := Ω) L t A = boundaryDynMap (Ω := Ω) L t A := rfl

def boundaryDyn (L : Matrix Ω Ω ℝ) :
    StarAlgDynamics (SA := matrixStarAlgebra Ω) :=
  { α := boundaryDynHom (Ω := Ω) L
    map_zero := by
      apply StarAlgHom.ext
      intro A
      exact boundaryDynMap_zero_time (Ω := Ω) L A
    map_add := by
      intro s t
      apply StarAlgHom.ext
      intro A
      change boundaryDynMap (Ω := Ω) L (s + t) A =
        boundaryDynMap (Ω := Ω) L s (boundaryDynMap (Ω := Ω) L t A)
      exact boundaryDynMap_comp_time (Ω := Ω) L s t A }

abbrev boundaryDynDiag (L : Matrix Ω Ω ℝ) :
    StarAlgDynamics (SA := matrixStarAlgebra Ω) :=
  boundaryDyn (Ω := Ω) L

@[simp] theorem boundaryDyn_alpha_apply
    (L : Matrix Ω Ω ℝ) (t : ℝ) (A : Mat Ω) :
    (boundaryDyn (Ω := Ω) L).α t A = boundaryDynMap (Ω := Ω) L t A := rfl

end
end Derived
end AQFT
end PillarB
