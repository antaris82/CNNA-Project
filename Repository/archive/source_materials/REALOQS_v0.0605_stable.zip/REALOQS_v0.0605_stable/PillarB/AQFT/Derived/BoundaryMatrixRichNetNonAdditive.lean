import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixNontriviality
import REALOQS.PillarB.Gates.HaagKastler.Additivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler

variable {Ω : Type u}

def pairRegion [DecidableEq Ω] (i j : Ω) : BoundaryRegion Ω :=
  ({i} : Finset Ω) ⊔ ({j} : Finset Ω)

@[simp] theorem mem_pairRegion [DecidableEq Ω] {i j k : Ω} :
    k ∈ pairRegion (Ω := Ω) i j ↔ k = i ∨ k = j := by
  constructor
  · intro hk
    simp [pairRegion] at hk
    rcases hk with hk | hk
    · exact Or.inr hk
    · exact Or.inl hk
  · intro hk
    rcases hk with hk | hk
    · simp [pairRegion, hk]
    · simp [pairRegion, hk]

@[simp] theorem left_mem_pairRegion [DecidableEq Ω] (i j : Ω) :
    i ∈ pairRegion (Ω := Ω) i j := by
  simp [pairRegion]

@[simp] theorem right_mem_pairRegion [DecidableEq Ω] (i j : Ω) :
    j ∈ pairRegion (Ω := Ω) i j := by
  simp [pairRegion]

@[simp] theorem singleton_le_pairRegion_left [DecidableEq Ω] (i j : Ω) :
    ({i} : Finset Ω) ≤ pairRegion (Ω := Ω) i j := by
  intro k hk
  simp [pairRegion, hk]

@[simp] theorem singleton_le_pairRegion_right [DecidableEq Ω] (i j : Ω) :
    ({j} : Finset Ω) ≤ pairRegion (Ω := Ω) i j := by
  intro k hk
  have hk' : k = j := by simpa using hk
  exact (mem_pairRegion (Ω := Ω) (i := i) (j := j) (k := k)).2 (Or.inr hk')

theorem regionLocalized_apply_eq_zero_of_or_not_mem [DecidableEq Ω]
    {r : BoundaryRegion Ω} {A : BoundaryMat Ω} (hA : RegionLocalized r A)
    {x y : Ω} (hxy : x ≠ y) (hout : x ∉ r ∨ y ∉ r) :
    A x y = 0 := by
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r) (A := A)).1 hA with
    ⟨scalar, perturb, hperturb, hAeq⟩
  have hperturb0 : perturb x y = 0 := hperturb x y hout
  rw [hAeq]
  simp [hxy, hperturb0]

theorem boundaryMatrixUnit_supportedOn_pairRegion [DecidableEq Ω] (i j : Ω) :
    SupportedOn (pairRegion (Ω := Ω) i j) (boundaryMatrixUnit (Ω := Ω) i j) := by
  intro x y hxy
  by_cases hx : x = i
  · by_cases hy : y = j
    · subst hx; subst hy
      exfalso
      simp [pairRegion] at hxy
    · simp [boundaryMatrixUnit, hx, hy]
  · simp [boundaryMatrixUnit, hx]

theorem boundaryMatrixUnit_regionLocalized_pairRegion [DecidableEq Ω] (i j : Ω) :
    RegionLocalized (pairRegion (Ω := Ω) i j)
      (boundaryMatrixUnit (Ω := Ω) i j) := by
  simpa using
    regionLocalized_of_decomposition (r := pairRegion (Ω := Ω) i j) (0 : Complex)
      (boundaryMatrixUnit (Ω := Ω) i j)
      (boundaryMatrixUnit_supportedOn_pairRegion (Ω := Ω) i j)

def pairOffDiagWitness [DecidableEq Ω] (i j : Ω) :
    RegionBlockMat Ω (pairRegion (Ω := Ω) i j) :=
  ⟨boundaryMatrixUnit (Ω := Ω) i j,
    boundaryMatrixUnit_regionLocalized_pairRegion (Ω := Ω) i j⟩

@[simp] theorem pairOffDiagWitness_toMatrix [DecidableEq Ω] (i j : Ω) :
    RegionBlockMat.toMatrix (pairOffDiagWitness (Ω := Ω) i j) =
      boundaryMatrixUnit (Ω := Ω) i j := rfl

def pairOffDiagZero [DecidableEq Ω] (i j : Ω)
    (A : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)) : Prop :=
  RegionBlockMat.toMatrix A i j = 0 ∧ RegionBlockMat.toMatrix A j i = 0

@[simp] theorem pairOffDiagZero_zero [Fintype Ω] [DecidableEq Ω] (i j : Ω) :
    pairOffDiagZero (Ω := Ω) i j
      (regionBlockZero (Ω := Ω) (pairRegion (Ω := Ω) i j)) := by
  constructor
  · change (0 : BoundaryMat Ω) i j = 0
    simp
  · change (0 : BoundaryMat Ω) j i = 0
    simp

@[simp] theorem pairOffDiagZero_one [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j) :
    pairOffDiagZero (Ω := Ω) i j
      (regionBlockOne (Ω := Ω) (pairRegion (Ω := Ω) i j)) := by
  constructor
  · change (1 : BoundaryMat Ω) i j = 0
    simp [hij]
  · change (1 : BoundaryMat Ω) j i = 0
    simp [Ne.symm hij]

@[simp] theorem pairOffDiagZero_add [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    {A B : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A)
    (hB : pairOffDiagZero (Ω := Ω) i j B) :
    pairOffDiagZero (Ω := Ω) i j (regionBlockAdd A B) := by
  rcases hA with ⟨hAij, hAji⟩
  rcases hB with ⟨hBij, hBji⟩
  constructor
  · rw [regionBlockAdd_toMatrix]
    change A.toMatrix i j + B.toMatrix i j = 0
    rw [hAij, hBij]
    simp
  · rw [regionBlockAdd_toMatrix]
    change A.toMatrix j i + B.toMatrix j i = 0
    rw [hAji, hBji]
    simp

@[simp] theorem pairOffDiagZero_neg [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    {A : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A) :
    pairOffDiagZero (Ω := Ω) i j (regionBlockNeg A) := by
  rcases hA with ⟨hAij, hAji⟩
  constructor
  · rw [regionBlockNeg_toMatrix]
    change -A.toMatrix i j = 0
    rw [hAij]
    simp
  · rw [regionBlockNeg_toMatrix]
    change -A.toMatrix j i = 0
    rw [hAji]
    simp

@[simp] theorem pairOffDiagZero_star [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    {A : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A) :
    pairOffDiagZero (Ω := Ω) i j (regionBlockStar A) := by
  rcases hA with ⟨hAij, hAji⟩
  constructor
  · rw [regionBlockStar_toMatrix, Matrix.conjTranspose_apply]
    rw [hAji]
    simp
  · rw [regionBlockStar_toMatrix, Matrix.conjTranspose_apply]
    rw [hAij]
    simp

theorem pairOffDiagZero_mul_ij [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    (hij : i ≠ j)
    {A B : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A)
    (hB : pairOffDiagZero (Ω := Ω) i j B) :
    RegionBlockMat.toMatrix (regionBlockMul A B) i j = 0 := by
  rcases hA with ⟨hAij, _hAji⟩
  rcases hB with ⟨hBij, _hBji⟩
  rw [regionBlockMul_toMatrix, Matrix.mul_apply]
  apply Finset.sum_eq_zero
  intro k hk
  by_cases hki : k = i
  · subst hki
    rw [hBij, mul_zero]
  · by_cases hkj : k = j
    · subst hkj
      rw [hAij, zero_mul]
    · have hkout : k ∉ pairRegion (Ω := Ω) i j := by
        simp [pairRegion, hki, hkj]
      have hAik : RegionBlockMat.toMatrix A i k = 0 := by
        refine regionLocalized_apply_eq_zero_of_or_not_mem
          (r := pairRegion (Ω := Ω) i j) (A := RegionBlockMat.toMatrix A) A.2 ?_ ?_
        · exact Ne.symm hki
        · exact Or.inr hkout
      have hBkj : RegionBlockMat.toMatrix B k j = 0 := by
        refine regionLocalized_apply_eq_zero_of_or_not_mem
          (r := pairRegion (Ω := Ω) i j) (A := RegionBlockMat.toMatrix B) B.2 ?_ ?_
        · exact hkj
        · exact Or.inl hkout
      rw [hAik, zero_mul]

theorem pairOffDiagZero_mul_ji [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    (hij : i ≠ j)
    {A B : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A)
    (hB : pairOffDiagZero (Ω := Ω) i j B) :
    RegionBlockMat.toMatrix (regionBlockMul A B) j i = 0 := by
  rcases hA with ⟨_hAij, hAji⟩
  rcases hB with ⟨_hBij, hBji⟩
  rw [regionBlockMul_toMatrix, Matrix.mul_apply]
  apply Finset.sum_eq_zero
  intro k hk
  by_cases hkj : k = j
  · subst hkj
    rw [hBji, mul_zero]
  · by_cases hki : k = i
    · subst hki
      rw [hAji, zero_mul]
    · have hkout : k ∉ pairRegion (Ω := Ω) i j := by
        simp [pairRegion, hki, hkj]
      have hAjk : RegionBlockMat.toMatrix A j k = 0 := by
        refine regionLocalized_apply_eq_zero_of_or_not_mem
          (r := pairRegion (Ω := Ω) i j) (A := RegionBlockMat.toMatrix A) A.2 ?_ ?_
        · exact Ne.symm hkj
        · exact Or.inr hkout
      have hBki : RegionBlockMat.toMatrix B k i = 0 := by
        refine regionLocalized_apply_eq_zero_of_or_not_mem
          (r := pairRegion (Ω := Ω) i j) (A := RegionBlockMat.toMatrix B) B.2 ?_ ?_
        · exact hki
        · exact Or.inl hkout
      rw [hAjk, zero_mul]

@[simp] theorem pairOffDiagZero_mul [Fintype Ω] [DecidableEq Ω] {i j : Ω}
    (hij : i ≠ j)
    {A B : RegionBlockMat Ω (pairRegion (Ω := Ω) i j)}
    (hA : pairOffDiagZero (Ω := Ω) i j A)
    (hB : pairOffDiagZero (Ω := Ω) i j B) :
    pairOffDiagZero (Ω := Ω) i j (regionBlockMul A B) := by
  constructor
  · exact pairOffDiagZero_mul_ij (Ω := Ω) hij hA hB
  · exact pairOffDiagZero_mul_ji (Ω := Ω) hij hA hB

def pairOffDiagZeroSubalgebra [Fintype Ω] [DecidableEq Ω]
    (i j : Ω) (hij : i ≠ j) :
    StarSubalgebra (regionBlockStarAlgebra (Ω := Ω) (pairRegion (Ω := Ω) i j)) where
  carrier := { A | pairOffDiagZero (Ω := Ω) i j A }
  zero_mem := by
    change pairOffDiagZero (Ω := Ω) i j
      (regionBlockZero (Ω := Ω) (pairRegion (Ω := Ω) i j))
    exact pairOffDiagZero_zero (Ω := Ω) i j
  one_mem := by
    change pairOffDiagZero (Ω := Ω) i j
      (regionBlockOne (Ω := Ω) (pairRegion (Ω := Ω) i j))
    exact pairOffDiagZero_one (Ω := Ω) (i := i) (j := j) hij
  add_mem := by
    intro A B hA hB
    change pairOffDiagZero (Ω := Ω) i j (regionBlockAdd A B)
    exact pairOffDiagZero_add (Ω := Ω) hA hB
  mul_mem := by
    intro A B hA hB
    change pairOffDiagZero (Ω := Ω) i j (regionBlockMul A B)
    exact pairOffDiagZero_mul (Ω := Ω) hij hA hB
  neg_mem := by
    intro A hA
    change pairOffDiagZero (Ω := Ω) i j (regionBlockNeg A)
    exact pairOffDiagZero_neg (Ω := Ω) hA
  star_mem := by
    intro A hA
    change pairOffDiagZero (Ω := Ω) i j (regionBlockStar A)
    exact pairOffDiagZero_star (Ω := Ω) hA

theorem pairOffDiagZero_of_incl_singleton_left [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j)
    (A : RegionBlockMat Ω ({i} : Finset Ω)) :
    pairOffDiagZero (Ω := Ω) i j
      (regionBlockIncl (Ω := Ω) (singleton_le_pairRegion_left (Ω := Ω) i j) A) := by
  constructor
  · have hAij : RegionBlockMat.toMatrix A i j = 0 := by
      refine regionLocalized_apply_eq_zero_of_or_not_mem
        (r := ({i} : Finset Ω)) (A := RegionBlockMat.toMatrix A) A.2 hij ?_
      exact Or.inr (by
        intro h
        have : j = i := by simpa using h
        exact hij this.symm)
    rw [regionBlockIncl_toMatrix]
    exact hAij
  · have hAji : RegionBlockMat.toMatrix A j i = 0 := by
      refine regionLocalized_apply_eq_zero_of_or_not_mem
        (r := ({i} : Finset Ω)) (A := RegionBlockMat.toMatrix A) A.2 (Ne.symm hij) ?_
      exact Or.inl (by
        intro h
        have : j = i := by simpa using h
        exact hij this.symm)
    rw [regionBlockIncl_toMatrix]
    exact hAji

theorem pairOffDiagZero_of_incl_singleton_right [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j)
    (A : RegionBlockMat Ω ({j} : Finset Ω)) :
    pairOffDiagZero (Ω := Ω) i j
      (regionBlockIncl (Ω := Ω) (singleton_le_pairRegion_right (Ω := Ω) i j) A) := by
  constructor
  · have hAij : RegionBlockMat.toMatrix A i j = 0 := by
      refine regionLocalized_apply_eq_zero_of_or_not_mem
        (r := ({j} : Finset Ω)) (A := RegionBlockMat.toMatrix A) A.2 hij ?_
      exact Or.inl (by
        intro h
        have : i = j := by simpa using h
        exact hij this)
    rw [regionBlockIncl_toMatrix]
    exact hAij
  · have hAji : RegionBlockMat.toMatrix A j i = 0 := by
      refine regionLocalized_apply_eq_zero_of_or_not_mem
        (r := ({j} : Finset Ω)) (A := RegionBlockMat.toMatrix A) A.2 (Ne.symm hij) ?_
      exact Or.inr (by
        intro h
        have : i = j := by simpa using h
        exact hij this)
    rw [regionBlockIncl_toMatrix]
    exact hAji

theorem pairOffDiagWitness_not_mem_zeroSubalgebra [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j) :
    pairOffDiagWitness (Ω := Ω) i j ∉
      (pairOffDiagZeroSubalgebra (Ω := Ω) i j hij).carrier := by
  intro hx
  have hxij : RegionBlockMat.toMatrix (pairOffDiagWitness (Ω := Ω) i j) i j = 0 := hx.1
  have h10 : (1 : Complex) = 0 := by
    rw [pairOffDiagWitness_toMatrix, boundaryMatrixUnit_apply_self] at hxij
    exact hxij
  norm_num at h10

theorem pairOffDiagWitness_not_generated_from_singletons [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j) :
    ¬ GeneratedBy
      (SA := (boundaryMatrixRichNet (Ω := Ω)).SA (pairRegion (Ω := Ω) i j))
      (additivityGenSet (N := boundaryMatrixRichNet (Ω := Ω))
        ({i} : Finset Ω) ({j} : Finset Ω))
      (pairOffDiagWitness (Ω := Ω) i j) := by
  intro hgen
  let U := pairOffDiagZeroSubalgebra (Ω := Ω) i j hij
  have hsubset :
      additivityGenSet (N := boundaryMatrixRichNet (Ω := Ω))
        ({i} : Finset Ω) ({j} : Finset Ω) ⊆ U.carrier := by
    intro x hx
    rcases hx with hx | hx
    · rcases hx with ⟨A, rfl⟩
      simpa [U, additivityImgLeft, boundaryMatrixRichNet_eq_boundaryMatrixLocalNet] using
        pairOffDiagZero_of_incl_singleton_left (Ω := Ω) hij A
    · rcases hx with ⟨A, rfl⟩
      simpa [U, additivityImgRight, boundaryMatrixRichNet_eq_boundaryMatrixLocalNet] using
        pairOffDiagZero_of_incl_singleton_right (Ω := Ω) hij A
  have hxmem : pairOffDiagWitness (Ω := Ω) i j ∈ U.carrier := hgen U hsubset
  exact pairOffDiagWitness_not_mem_zeroSubalgebra (Ω := Ω) hij hxmem

theorem boundaryMatrixRichNet_not_additive_at_pair [Fintype Ω] [DecidableEq Ω]
    {i j : Ω} (hij : i ≠ j) :
    ¬ Additivity (N := boundaryMatrixRichNet (Ω := Ω)) := by
  intro hAdd
  exact pairOffDiagWitness_not_generated_from_singletons (Ω := Ω) hij
    (hAdd ({i} : Finset Ω) ({j} : Finset Ω) (pairOffDiagWitness (Ω := Ω) i j))

theorem boundaryMatrixRichNet_not_additive_of_exists_ne [Fintype Ω] [DecidableEq Ω]
    (hpair : ∃ i j : Ω, i ≠ j) :
    ¬ Additivity (N := boundaryMatrixRichNet (Ω := Ω)) := by
  rcases hpair with ⟨i, j, hij⟩
  exact boundaryMatrixRichNet_not_additive_at_pair (Ω := Ω) hij

end
end Derived
end AQFT
end PillarB
