import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

abbrev BoundaryRegion (Ω : Type u) := Finset Ω
abbrev BoundaryMat (Ω : Type u) := Mat Ω

def SupportedOn {Ω : Type u} [DecidableEq Ω]
    (r : BoundaryRegion Ω) (U : BoundaryMat Ω) : Prop :=
  ∀ i j : Ω, i ∉ r ∨ j ∉ r → U i j = 0

def RegionLocalized {Ω : Type u} [DecidableEq Ω]
    (r : BoundaryRegion Ω) (A : BoundaryMat Ω) : Prop :=
  ∃ scalar : Complex, SupportedOn r (A - scalar • (1 : BoundaryMat Ω))

abbrev RegionBlockMat (Ω : Type u) [DecidableEq Ω] (r : BoundaryRegion Ω) :=
  { A : BoundaryMat Ω // RegionLocalized r A }

namespace RegionBlockMat

variable {Ω : Type u} [DecidableEq Ω] {r : BoundaryRegion Ω}

def toMatrix (A : RegionBlockMat Ω r) : BoundaryMat Ω :=
  A.1

@[simp] theorem toMatrix_mk (A : BoundaryMat Ω) (hA : RegionLocalized r A) :
    toMatrix (⟨A, hA⟩ : RegionBlockMat Ω r) = A := rfl

@[simp] theorem toMatrix_apply (A : RegionBlockMat Ω r) (i j : Ω) :
    RegionBlockMat.toMatrix A i j = A.1 i j := rfl

@[ext] theorem ext {A B : RegionBlockMat Ω r}
    (h : RegionBlockMat.toMatrix A = RegionBlockMat.toMatrix B) : A = B := by
  exact Subtype.ext h

end RegionBlockMat

section SupportLemmas

variable {Ω : Type u} [DecidableEq Ω]

@[simp] theorem supportedOn_zero (r : BoundaryRegion Ω) :
    SupportedOn r (0 : BoundaryMat Ω) := by
  intro i j hij
  simp

@[simp] theorem supportedOn_add {r : BoundaryRegion Ω}
    {U V : BoundaryMat Ω} (hU : SupportedOn r U) (hV : SupportedOn r V) :
    SupportedOn r (U + V) := by
  intro i j hij
  simp [Matrix.add_apply, hU i j hij, hV i j hij]

@[simp] theorem supportedOn_neg {r : BoundaryRegion Ω}
    {U : BoundaryMat Ω} (hU : SupportedOn r U) :
    SupportedOn r (-U) := by
  intro i j hij
  simp [Matrix.neg_apply, hU i j hij]

@[simp] theorem supportedOn_smul {r : BoundaryRegion Ω}
    (c : Complex) {U : BoundaryMat Ω} (hU : SupportedOn r U) :
    SupportedOn r (c • U) := by
  intro i j hij
  simp [Matrix.smul_apply, hU i j hij]

@[simp] theorem supportedOn_star {r : BoundaryRegion Ω}
    {U : BoundaryMat Ω} (hU : SupportedOn r U) :
    SupportedOn r (Matrix.conjTranspose U) := by
  intro i j hij
  rw [Matrix.conjTranspose_apply]
  have hji : j ∉ r ∨ i ∉ r := hij.elim Or.inr Or.inl
  simpa using hU j i hji

@[simp] theorem supportedOn_mono {r s : BoundaryRegion Ω} (hrs : r ≤ s)
    {U : BoundaryMat Ω} (hU : SupportedOn r U) :
    SupportedOn s U := by
  intro i j hij
  apply hU i j
  cases hij with
  | inl hi =>
      exact Or.inl (fun hir => hi (hrs hir))
  | inr hj =>
      exact Or.inr (fun hjr => hj (hrs hjr))

end SupportLemmas

section FintypeSupportLemmas

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

@[simp] theorem supportedOn_mul {r : BoundaryRegion Ω}
    {U V : BoundaryMat Ω} (hU : SupportedOn r U) (hV : SupportedOn r V) :
    SupportedOn r (U * V) := by
  intro i j hij
  rw [Matrix.mul_apply]
  cases hij with
  | inl hi =>
      apply Finset.sum_eq_zero
      intro k hk
      have hzero : U i k = 0 := hU i k (Or.inl hi)
      simp [hzero]
  | inr hj =>
      apply Finset.sum_eq_zero
      intro k hk
      have hzero : V k j = 0 := hV k j (Or.inr hj)
      simp [hzero]

@[simp] theorem supportedOn_univ (U : BoundaryMat Ω) :
    SupportedOn (Finset.univ : Finset Ω) U := by
  intro i j hij
  cases hij with
  | inl hi => simp at hi
  | inr hj => simp at hj

end FintypeSupportLemmas

section RegionLocalizedBasicLemmas

variable {Ω : Type u} [DecidableEq Ω]

theorem regionLocalized_iff_exists_scalar_perturb {r : BoundaryRegion Ω}
    {A : BoundaryMat Ω} :
    RegionLocalized r A ↔
      ∃ scalar : Complex, ∃ perturb : BoundaryMat Ω,
        SupportedOn r perturb ∧ A = scalar • (1 : BoundaryMat Ω) + perturb := by
  constructor
  · rintro ⟨scalar, hsupp⟩
    refine ⟨scalar, A - scalar • (1 : BoundaryMat Ω), hsupp, ?_⟩
    ext i j
    simp [sub_eq_add_neg, add_left_comm]
  · rintro ⟨scalar, perturb, hsupp, hA⟩
    refine ⟨scalar, ?_⟩
    rw [hA]
    simpa [sub_eq_add_neg, add_left_comm] using hsupp

theorem regionLocalized_of_decomposition {r : BoundaryRegion Ω}
    (scalar : Complex) (perturb : BoundaryMat Ω) (hsupp : SupportedOn r perturb) :
    RegionLocalized r (scalar • (1 : BoundaryMat Ω) + perturb) := by
  exact (regionLocalized_iff_exists_scalar_perturb (r := r)).2
    ⟨scalar, perturb, hsupp, rfl⟩

@[simp] theorem regionLocalized_zero (r : BoundaryRegion Ω) :
    RegionLocalized r (0 : BoundaryMat Ω) := by
  simpa using regionLocalized_of_decomposition (r := r) (0 : Complex)
    (0 : BoundaryMat Ω) (supportedOn_zero r)

@[simp] theorem regionLocalized_one (r : BoundaryRegion Ω) :
    RegionLocalized r (1 : BoundaryMat Ω) := by
  simpa using regionLocalized_of_decomposition (r := r) (1 : Complex)
    (0 : BoundaryMat Ω) (supportedOn_zero r)

@[simp] theorem regionLocalized_add {r : BoundaryRegion Ω}
    {A B : BoundaryMat Ω} (hA : RegionLocalized r A) (hB : RegionLocalized r B) :
    RegionLocalized r (A + B) := by
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hA with
    ⟨a, P, hP, rfl⟩
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hB with
    ⟨b, Q, hQ, rfl⟩
  simpa [add_smul, add_assoc, add_left_comm, add_comm] using
    regionLocalized_of_decomposition (r := r) (a + b) (P + Q)
      (supportedOn_add hP hQ)

@[simp] theorem regionLocalized_neg {r : BoundaryRegion Ω}
    {A : BoundaryMat Ω} (hA : RegionLocalized r A) :
    RegionLocalized r (-A) := by
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hA with
    ⟨a, P, hP, rfl⟩
  simpa [add_assoc, add_left_comm, add_comm] using
    regionLocalized_of_decomposition (r := r) (-a) (-P)
      (supportedOn_neg hP)

@[simp] theorem regionLocalized_star {r : BoundaryRegion Ω}
    {A : BoundaryMat Ω} (hA : RegionLocalized r A) :
    RegionLocalized r (Matrix.conjTranspose A) := by
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hA with
    ⟨a, P, hP, rfl⟩
  simpa [Matrix.conjTranspose_add, Matrix.conjTranspose_smul,
      star_eq_conjTranspose] using
    regionLocalized_of_decomposition (r := r) (star a) (Matrix.conjTranspose P)
      (supportedOn_star hP)

@[simp] theorem regionLocalized_mono {r s : BoundaryRegion Ω} (hrs : r ≤ s)
    {A : BoundaryMat Ω} (hA : RegionLocalized r A) :
    RegionLocalized s A := by
  rcases hA with ⟨scalar, hsupp⟩
  exact ⟨scalar, supportedOn_mono hrs hsupp⟩

end RegionLocalizedBasicLemmas

section RegionLocalizedFintypeLemmas

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

@[simp] theorem regionLocalized_mul {r : BoundaryRegion Ω}
    {A B : BoundaryMat Ω} (hA : RegionLocalized r A) (hB : RegionLocalized r B) :
    RegionLocalized r (A * B) := by
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hA with
    ⟨a, P, hP, rfl⟩
  rcases (regionLocalized_iff_exists_scalar_perturb (r := r)).1 hB with
    ⟨b, Q, hQ, rfl⟩
  simpa [mul_add, add_mul, add_smul, smul_add, mul_assoc,
      add_assoc, add_left_comm, add_comm, smul_mul_assoc, mul_smul_comm, smul_smul] using
    regionLocalized_of_decomposition (r := r) (b * a)
      (a • Q + b • P + P * Q)
      (supportedOn_add
        (supportedOn_add (supportedOn_smul a hQ) (supportedOn_smul b hP))
        (supportedOn_mul hP hQ))

@[simp] theorem regionLocalized_univ (A : BoundaryMat Ω) :
    RegionLocalized (Finset.univ : Finset Ω) A := by
  refine ⟨0, ?_⟩
  simp [supportedOn_univ]

end RegionLocalizedFintypeLemmas

section RegionBlockDecomposition

variable {Ω : Type u} [DecidableEq Ω]

theorem exists_scalar_supported_perturb {r : BoundaryRegion Ω}
    (A : RegionBlockMat Ω r) :
    ∃ scalar : Complex, ∃ perturb : BoundaryMat Ω,
      SupportedOn r perturb ∧
        RegionBlockMat.toMatrix A = scalar • (1 : BoundaryMat Ω) + perturb :=
  (regionLocalized_iff_exists_scalar_perturb (r := r)).1 A.2

end RegionBlockDecomposition

section RegionBlockBasicOps

variable {Ω : Type u} [DecidableEq Ω]

def regionBlockZero (r : BoundaryRegion Ω) : RegionBlockMat Ω r :=
  ⟨0, regionLocalized_zero r⟩

def regionBlockOne (r : BoundaryRegion Ω) : RegionBlockMat Ω r :=
  ⟨1, regionLocalized_one r⟩

def regionBlockAdd {r : BoundaryRegion Ω}
    (A B : RegionBlockMat Ω r) : RegionBlockMat Ω r :=
  ⟨A.1 + B.1, regionLocalized_add A.2 B.2⟩

def regionBlockNeg {r : BoundaryRegion Ω}
    (A : RegionBlockMat Ω r) : RegionBlockMat Ω r :=
  ⟨-A.1, regionLocalized_neg A.2⟩

def regionBlockStar {r : BoundaryRegion Ω}
    (A : RegionBlockMat Ω r) : RegionBlockMat Ω r :=
  ⟨Matrix.conjTranspose A.1, regionLocalized_star A.2⟩

@[simp] theorem regionBlockZero_toMatrix (r : BoundaryRegion Ω) :
    RegionBlockMat.toMatrix (regionBlockZero (Ω := Ω) r) = 0 := rfl

@[simp] theorem regionBlockOne_toMatrix (r : BoundaryRegion Ω) :
    RegionBlockMat.toMatrix (regionBlockOne (Ω := Ω) r) = 1 := rfl

@[simp] theorem regionBlockAdd_toMatrix {r : BoundaryRegion Ω}
    (A B : RegionBlockMat Ω r) :
    RegionBlockMat.toMatrix (regionBlockAdd A B) =
      RegionBlockMat.toMatrix A + RegionBlockMat.toMatrix B := rfl

@[simp] theorem regionBlockNeg_toMatrix {r : BoundaryRegion Ω}
    (A : RegionBlockMat Ω r) :
    RegionBlockMat.toMatrix (regionBlockNeg A) = -RegionBlockMat.toMatrix A := rfl

@[simp] theorem regionBlockStar_toMatrix {r : BoundaryRegion Ω}
    (A : RegionBlockMat Ω r) :
    RegionBlockMat.toMatrix (regionBlockStar A) =
      Matrix.conjTranspose (RegionBlockMat.toMatrix A) := rfl

def regionBlockIncl {r s : BoundaryRegion Ω} (hrs : r ≤ s)
    (A : RegionBlockMat Ω r) : RegionBlockMat Ω s :=
  ⟨A.1, regionLocalized_mono hrs A.2⟩

@[simp] theorem regionBlockIncl_toMatrix {r s : BoundaryRegion Ω} (hrs : r ≤ s)
    (A : RegionBlockMat Ω r) :
    RegionBlockMat.toMatrix (regionBlockIncl (Ω := Ω) hrs A) =
      RegionBlockMat.toMatrix A := rfl

end RegionBlockBasicOps

section RegionBlockFintypeOps

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def matrixToTopRegion (A : BoundaryMat Ω) :
    RegionBlockMat Ω (Finset.univ : Finset Ω) :=
  ⟨A, regionLocalized_univ A⟩

@[simp] theorem matrixToTopRegion_toMatrix (A : BoundaryMat Ω) :
    RegionBlockMat.toMatrix (matrixToTopRegion (Ω := Ω) A) = A := rfl

def regionBlockMul {r : BoundaryRegion Ω}
    (A B : RegionBlockMat Ω r) : RegionBlockMat Ω r :=
  ⟨A.1 * B.1, regionLocalized_mul A.2 B.2⟩

@[simp] theorem regionBlockMul_toMatrix {r : BoundaryRegion Ω}
    (A B : RegionBlockMat Ω r) :
    RegionBlockMat.toMatrix (regionBlockMul A B) =
      RegionBlockMat.toMatrix A * RegionBlockMat.toMatrix B := rfl

def regionBlockStarAlgebra (r : BoundaryRegion Ω) : StarAlgebra (RegionBlockMat Ω r) :=
  { zero := regionBlockZero (Ω := Ω) r
    one := regionBlockOne (Ω := Ω) r
    add := regionBlockAdd
    mul := regionBlockMul
    neg := regionBlockNeg
    star := regionBlockStar
    add_assoc := by
      intro A B C
      apply RegionBlockMat.ext
      simp [regionBlockAdd, add_assoc]
    add_comm := by
      intro A B
      apply RegionBlockMat.ext
      simp [regionBlockAdd, add_comm]
    add_zero := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockAdd, regionBlockZero]
    zero_add := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockAdd, regionBlockZero]
    add_left_neg := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockAdd, regionBlockNeg, regionBlockZero]
    mul_assoc := by
      intro A B C
      apply RegionBlockMat.ext
      simp [regionBlockMul, mul_assoc]
    one_mul := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockOne]
    mul_one := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockOne]
    left_distrib := by
      intro A B C
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockAdd, left_distrib]
    right_distrib := by
      intro A B C
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockAdd, right_distrib]
    zero_mul := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockZero]
    mul_zero := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockMul, regionBlockZero]
    star_involutive := by
      intro A
      apply RegionBlockMat.ext
      simp [regionBlockStar]
    star_add := by
      intro A B
      apply RegionBlockMat.ext
      simp [regionBlockStar, regionBlockAdd, Matrix.conjTranspose_add]
    star_mul := by
      intro A B
      apply RegionBlockMat.ext
      simp [regionBlockStar, regionBlockMul, Matrix.conjTranspose_mul]
    star_one := by
      apply RegionBlockMat.ext
      simp [regionBlockStar, regionBlockOne]
    star_zero := by
      apply RegionBlockMat.ext
      simp [regionBlockStar, regionBlockZero] }

def boundaryMatrixLocalAlgebraNet :
    PillarA.LayerA.LocalAlgebraNet (Ω := Ω) where
  RN := PillarA.LayerA.FinsetRegionNet Ω
  Alg := fun r => RegionBlockMat Ω r
  incl := by
    intro a b hab
    exact regionBlockIncl (Ω := Ω) hab
  incl_id := by
    intro a A
    apply RegionBlockMat.ext
    rfl
  incl_comp := by
    intro a b c hab hbc A
    apply RegionBlockMat.ext
    rfl

def boundaryMatrixLocalNet :
    PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω) where
  LAN := boundaryMatrixLocalAlgebraNet (Ω := Ω)
  SA := fun r => regionBlockStarAlgebra (Ω := Ω) r
  incl_isHom := by
    intro a b hab
    refine
      { map_zero := by
          apply RegionBlockMat.ext
          rfl
        map_one := by
          apply RegionBlockMat.ext
          rfl
        map_add := by
          intro A B
          apply RegionBlockMat.ext
          rfl
        map_mul := by
          intro A B
          apply RegionBlockMat.ext
          rfl
        map_neg := by
          intro A
          apply RegionBlockMat.ext
          rfl
        map_star := by
          intro A
          apply RegionBlockMat.ext
          rfl }

abbrev boundaryMatrixRichNet :
    PillarB.AQFT.LocalStarAlgebraNet (Ω := Ω) :=
  boundaryMatrixLocalNet (Ω := Ω)

@[simp] theorem boundaryMatrixRichNet_eq_boundaryMatrixLocalNet :
    boundaryMatrixRichNet (Ω := Ω) = boundaryMatrixLocalNet (Ω := Ω) := rfl

@[simp] theorem boundaryMatrixLocalNet_incl_toMatrix
    {a b : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg a) :
    RegionBlockMat.toMatrix ((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl hab A :
      (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg b) = RegionBlockMat.toMatrix A := by
  rfl

def boundaryMatrixRegionToMatrixHom
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    StarAlgHom ((boundaryMatrixLocalNet (Ω := Ω)).SA r) (matrixStarAlgebraCStar Ω) :=
  { toFun := fun A => RegionBlockMat.toMatrix A
    isHom :=
      { map_zero := by
          rfl
        map_one := by
          rfl
        map_add := by
          intro A B
          rfl
        map_mul := by
          intro A B
          rfl
        map_neg := by
          intro A
          rfl
        map_star := by
          intro A
          rfl } }

@[simp] theorem boundaryMatrixRegionToMatrix_natural
    {a b : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region} (hab : a ≤ b)
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg a) :
    boundaryMatrixRegionToMatrixHom (Ω := Ω) b
        ((boundaryMatrixLocalNet (Ω := Ω)).LAN.incl hab A) =
      boundaryMatrixRegionToMatrixHom (Ω := Ω) a A := by
  rfl

theorem boundaryMatrixRegionToMatrix_injective
    (r : (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.Region) :
    Function.Injective (boundaryMatrixRegionToMatrixHom (Ω := Ω) r) := by
  intro A B h
  exact RegionBlockMat.ext h

def boundaryMatrixTopToMatrixHom :
    StarAlgHom
      ((boundaryMatrixLocalNet (Ω := Ω)).SA
        ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top))
      (matrixStarAlgebraCStar Ω) :=
  boundaryMatrixRegionToMatrixHom (Ω := Ω)
    ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top)

@[simp] theorem boundaryMatrixTopToMatrixHom_apply
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top))) :
    boundaryMatrixTopToMatrixHom (Ω := Ω) A = RegionBlockMat.toMatrix A := rfl

def matrixToBoundaryMatrixTopHom :
    StarAlgHom
      (matrixStarAlgebraCStar Ω)
      ((boundaryMatrixLocalNet (Ω := Ω)).SA
        ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top)) :=
  { toFun := matrixToTopRegion (Ω := Ω)
    isHom :=
      { map_zero := by
          apply RegionBlockMat.ext
          rfl
        map_one := by
          apply RegionBlockMat.ext
          rfl
        map_add := by
          intro A B
          apply RegionBlockMat.ext
          rfl
        map_mul := by
          intro A B
          apply RegionBlockMat.ext
          rfl
        map_neg := by
          intro A
          apply RegionBlockMat.ext
          rfl
        map_star := by
          intro A
          apply RegionBlockMat.ext
          rfl } }

@[simp] theorem matrixToBoundaryMatrixTopHom_apply (A : BoundaryMat Ω) :
    matrixToBoundaryMatrixTopHom (Ω := Ω) A = matrixToTopRegion (Ω := Ω) A := rfl

def boundaryMatrixTopIsoMatrix :
    HaagKastler.StarAlgIso
      (SA := ((boundaryMatrixLocalNet (Ω := Ω)).SA
        ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top)))
      (SB := matrixStarAlgebraCStar Ω) where
  hom := boundaryMatrixTopToMatrixHom (Ω := Ω)
  inv := matrixToBoundaryMatrixTopHom (Ω := Ω)
  left_inv := by
    intro A
    apply RegionBlockMat.ext
    rfl
  right_inv := by
    intro A
    rfl

@[simp] theorem boundaryMatrixTopToMatrixHom_leftInverse
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top))) :
    matrixToBoundaryMatrixTopHom (Ω := Ω)
        (boundaryMatrixTopToMatrixHom (Ω := Ω) A) = A :=
  (boundaryMatrixTopIsoMatrix (Ω := Ω)).left_inv A

@[simp] theorem boundaryMatrixTopToMatrixHom_rightInverse (A : BoundaryMat Ω) :
    boundaryMatrixTopToMatrixHom (Ω := Ω)
        (matrixToBoundaryMatrixTopHom (Ω := Ω) A) = A :=
  (boundaryMatrixTopIsoMatrix (Ω := Ω)).right_inv A

theorem boundaryMatrixTopToMatrixHom_injective :
    Function.Injective (boundaryMatrixTopToMatrixHom (Ω := Ω)) :=
  HaagKastler.StarAlgIso.hom_injective (boundaryMatrixTopIsoMatrix (Ω := Ω))

theorem boundaryMatrixTopToMatrixHom_surjective :
    Function.Surjective (boundaryMatrixTopToMatrixHom (Ω := Ω)) :=
  HaagKastler.StarAlgIso.hom_surjective (boundaryMatrixTopIsoMatrix (Ω := Ω))

theorem boundaryMatrixTopToMatrixHom_bijective :
    Function.Bijective (boundaryMatrixTopToMatrixHom (Ω := Ω)) :=
  ⟨boundaryMatrixTopToMatrixHom_injective (Ω := Ω),
    boundaryMatrixTopToMatrixHom_surjective (Ω := Ω)⟩

@[simp] theorem boundaryMatrixTopIsoMatrix_hom_apply
    (A : ((boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg
      ((boundaryMatrixLocalNet (Ω := Ω)).LAN.RN.top))) :
    (boundaryMatrixTopIsoMatrix (Ω := Ω)).hom A = RegionBlockMat.toMatrix A := rfl

@[simp] theorem boundaryMatrixTopIsoMatrix_inv_apply (A : BoundaryMat Ω) :
    (boundaryMatrixTopIsoMatrix (Ω := Ω)).inv A = matrixToTopRegion (Ω := Ω) A := rfl

def boundaryMatrixTrivialDisjoint :
    HaagKastler.Region.CausalDisjoint (RN := (boundaryMatrixLocalNet (Ω := Ω)).LAN.RN) where
  disj := fun _ _ => False
  symm := by
    intro a b h
    cases h
  mono_left := by
    intro a a' b haa' h
    cases h
  mono_right := by
    intro a b b' hbb' h
    cases h

end RegionBlockFintypeOps

end

end Derived
end AQFT
end PillarB
