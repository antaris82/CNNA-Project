import REALOQS.PillarA.Core.DirichletLaplacian
import REALOQS.PillarB.AQFT.Derived.GibbsStateOnConfig

set_option linter.style.longLine false
set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

noncomputable section

def quadFormU (Λ : Matrix Ω Ω ℝ) (f : Ω → ℝ) : ℝ :=
  ∑ i, f i * (Λ.mulVec f) i

structure MatterTemplate where

  d : Nat

  d_pos : 0 < d

  β : ℝ

  φ : Fin d → ℝ

namespace MatterTemplate

def zero (T : MatterTemplate) : Fin T.d :=
  ⟨0, T.d_pos⟩

end MatterTemplate

def cfgDefault (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) :=
  fun _ => T.zero

omit [DecidableEq Ω] in
theorem cfg_nonempty (T : MatterTemplate) :
    Nonempty (Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω)) :=
  ⟨cfgDefault (Ω := Ω) T⟩

def realVecOfCfg (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → Ω → ℝ :=
  fun σ i =>
    T.φ (σ ⟨i, by simp⟩)

def energyFromBoundaryOp (L : Matrix Ω Ω ℝ) (T : MatterTemplate) :
    Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → ℝ :=
  fun σ =>
    quadFormU (Ω := Ω) L (realVecOfCfg (Ω := Ω) T σ)

def gibbsTopState_fromBoundaryOp (L : Matrix Ω Ω ℝ) (T : MatterTemplate) :
    StateOn (Alg (Ω := Ω) T.d (Finset.univ : Finset Ω)) := by
  classical
  let E : Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω) → ℝ :=
    energyFromBoundaryOp (Ω := Ω) L T
  have hcfg : Nonempty (Cfg (Ω := Ω) T.d (Finset.univ : Finset Ω)) :=
    cfg_nonempty (Ω := Ω) T
  exact gibbsTopState (Ω := Ω) T.d T.β E (hcfg := hcfg)

end

end Derived
end AQFT
end PillarB
