import Mathlib
import Mathlib.Analysis.Normed.Algebra.Exponential
import Mathlib.Analysis.Normed.Algebra.MatrixExponential
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar

set_option autoImplicit false

open scoped Matrix.Norms.L2Operator

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

noncomputable def fullHamiltonian (L : Matrix Ω Ω ℝ) : Mat Ω :=
  fun i j => (L i j : ℂ)

omit [Fintype Ω] [DecidableEq Ω] in
theorem fullHamiltonian_apply (L : Matrix Ω Ω ℝ) (i j : Ω) :
    fullHamiltonian (Ω := Ω) L i j = (L i j : ℂ) := rfl

attribute [simp] fullHamiltonian_apply

noncomputable def hamExp (L : Matrix Ω Ω ℝ) (z : ℂ) : Mat Ω :=
  NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (z • fullHamiltonian (Ω := Ω) L)

noncomputable def unitaryFromLPlus (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (Complex.I * (t : ℂ))

noncomputable def unitaryFromLMinus (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-Complex.I * (t : ℂ))

noncomputable abbrev unitaryFromL (L : Matrix Ω Ω ℝ) (t : ℝ) : Mat Ω :=
  unitaryFromLPlus (Ω := Ω) L t

@[simp] theorem hamExp_zero (L : Matrix Ω Ω ℝ) :
    hamExp (Ω := Ω) L 0 = (1 : Mat Ω) := by
  simp [hamExp]

theorem hamExp_commute_arg (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    Commute (z • fullHamiltonian (Ω := Ω) L) (w • fullHamiltonian (Ω := Ω) L) := by
  simpa using ((Commute.refl (fullHamiltonian (Ω := Ω) L)).smul_left z).smul_right w

theorem hamExp_add (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    hamExp (Ω := Ω) L (z + w) =
      hamExp (Ω := Ω) L z * hamExp (Ω := Ω) L w := by
  have hcomm := hamExp_commute_arg (Ω := Ω) L z w
  simpa [hamExp, add_smul] using
    (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)

theorem hamExp_commute (L : Matrix Ω Ω ℝ) (z w : ℂ) :
    Commute (hamExp (Ω := Ω) L z) (hamExp (Ω := Ω) L w) := by
  calc
    hamExp (Ω := Ω) L z * hamExp (Ω := Ω) L w
        = hamExp (Ω := Ω) L (z + w) := by
            symm
            exact hamExp_add (Ω := Ω) L z w
    _ = hamExp (Ω := Ω) L (w + z) := by rw [add_comm]
    _ = hamExp (Ω := Ω) L w * hamExp (Ω := Ω) L z := by
            exact hamExp_add (Ω := Ω) L w z

@[simp] theorem unitaryFromL_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromL (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromL, unitaryFromLPlus]
  simp [hamExp_zero]

@[simp] theorem unitaryFromLPlus_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromLPlus (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromLPlus]
  simp [hamExp_zero]

@[simp] theorem unitaryFromLMinus_zero (L : Matrix Ω Ω ℝ) :
    unitaryFromLMinus (Ω := Ω) L 0 = (1 : Mat Ω) := by
  rw [unitaryFromLMinus]
  simp [hamExp_zero]

theorem unitaryFromL_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromL (Ω := Ω) L (s + t) =
      unitaryFromL (Ω := Ω) L s * unitaryFromL (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (Complex.I * (t : ℂ))
  rw [show Complex.I * (((s + t : ℝ) : ℂ)) =
      Complex.I * (s : ℂ) + Complex.I * (t : ℂ) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (Complex.I * (s : ℂ)) (Complex.I * (t : ℂ))

theorem unitaryFromLPlus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromLPlus (Ω := Ω) L (s + t) =
      unitaryFromLPlus (Ω := Ω) L s * unitaryFromLPlus (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (Complex.I * (t : ℂ))
  rw [show Complex.I * (((s + t : ℝ) : ℂ)) =
      Complex.I * (s : ℂ) + Complex.I * (t : ℂ) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (Complex.I * (s : ℂ)) (Complex.I * (t : ℂ))

theorem unitaryFromLMinus_add (L : Matrix Ω Ω ℝ) (s t : ℝ) :
    unitaryFromLMinus (Ω := Ω) L (s + t) =
      unitaryFromLMinus (Ω := Ω) L s * unitaryFromLMinus (Ω := Ω) L t := by
  change
      hamExp (Ω := Ω) L (-Complex.I * (((s + t : ℝ) : ℂ))) =
        hamExp (Ω := Ω) L (-Complex.I * (s : ℂ)) *
          hamExp (Ω := Ω) L (-Complex.I * (t : ℂ))
  rw [show -Complex.I * (((s + t : ℝ) : ℂ)) =
      (-Complex.I * (s : ℂ)) + (-Complex.I * (t : ℂ)) by
    simp [mul_add]]
  exact hamExp_add (Ω := Ω) L (-Complex.I * (s : ℂ)) (-Complex.I * (t : ℂ))

theorem unitaryFromLMinus_eq_unitaryFromLPlus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLMinus (Ω := Ω) L t =
      unitaryFromLPlus (Ω := Ω) L (-t) := by
  simp [unitaryFromLMinus, unitaryFromLPlus, mul_comm]

theorem unitaryFromLPlus_eq_unitaryFromLMinus_neg
    (L : Matrix Ω Ω ℝ) (t : ℝ) :
    unitaryFromLPlus (Ω := Ω) L t =
      unitaryFromLMinus (Ω := Ω) L (-t) := by
  exact Eq.symm <| by
    simpa [neg_neg] using
      (unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L (-t))

omit [Fintype Ω] [DecidableEq Ω] in

theorem fullHamiltonian_isHermitian_of_transpose_eq
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    Matrix.IsHermitian (fullHamiltonian (Ω := Ω) L) := by
  classical
  dsimp [Matrix.IsHermitian, fullHamiltonian]
  ext i j
  have hij : L j i = L i j := by
    have h := congrArg (fun M : Matrix Ω Ω ℝ => M i j) hL
    simpa [Matrix.transpose_apply] using h

  simp [Matrix.conjTranspose_apply, hij]

theorem hamExp_conjTranspose
    (L : Matrix Ω Ω ℝ) (z : ℂ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (hamExp (Ω := Ω) L z) = hamExp (Ω := Ω) L (star z) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := z • H
  have hA : Matrix.conjTranspose A = (star z) • H := by
    simp [A, Matrix.conjTranspose_smul, hH]

  simpa [hamExp, A, hA] using
    (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm

theorem conjTranspose_unitaryFromLPlus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) =
      unitaryFromLMinus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (hamExp_conjTranspose (Ω := Ω) L (Complex.I * (t : ℂ)) hL)

theorem conjTranspose_unitaryFromLMinus
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) =
      unitaryFromLPlus (Ω := Ω) L t := by
  simpa [unitaryFromLPlus, unitaryFromLMinus, star_mul, mul_comm] using
    (hamExp_conjTranspose (Ω := Ω) L (-Complex.I * (t : ℂ)) hL)

theorem unitaryFromL_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) *
        unitaryFromL (Ω := Ω) L t = (1 : Mat Ω) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := (Complex.I * (t : ℂ)) • H
  have hA_conj : Matrix.conjTranspose A = (-A) := by

    calc
      Matrix.conjTranspose A
          = (star (Complex.I * (t : ℂ))) • Matrix.conjTranspose H := by
              simp [A, Matrix.conjTranspose_smul]
      _ = (-(Complex.I * (t : ℂ))) • H := by
              simp [hH, star_mul, mul_comm]
      _ = -A := by
              simp [A, neg_smul]
  have hU :
      unitaryFromL (Ω := Ω) L t =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A := by
    rw [unitaryFromL, unitaryFromLPlus, hamExp]
  have hExp_conj :
      Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A) := by

    simpa [hA_conj] using
      (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm
  have hcomm : Commute (-A) A := (Commute.refl A).neg_left
  calc
    Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) * unitaryFromL (Ω := Ω) L t
        = Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hU]
    _ = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A)) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hExp_conj]
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) ((-A) + A) := by

              symm
              simpa using
                (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)
    _ = (1 : Mat Ω) := by
              simp [NormedSpace.exp_zero]

theorem unitaryFromLPlus_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) *
        unitaryFromLPlus (Ω := Ω) L t = (1 : Mat Ω) := by
  simpa [unitaryFromL] using unitaryFromL_conjTranspose_mul_self (Ω := Ω) L t hL

theorem unitaryFromL_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromL (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t) = (1 : Mat Ω) := by
  classical
  let H : Mat Ω := fullHamiltonian (Ω := Ω) L
  have hH : Matrix.conjTranspose H = H :=
    (fullHamiltonian_isHermitian_of_transpose_eq (Ω := Ω) L hL)
  let A : Mat Ω := (Complex.I * (t : ℂ)) • H
  have hA_conj : Matrix.conjTranspose A = (-A) := by
    calc
      Matrix.conjTranspose A
          = (star (Complex.I * (t : ℂ))) • Matrix.conjTranspose H := by
              simp [A, Matrix.conjTranspose_smul]
      _ = (-(Complex.I * (t : ℂ))) • H := by
              simp [hH, star_mul, mul_comm]
      _ = -A := by
              simp [A, neg_smul]
  have hU :
      unitaryFromL (Ω := Ω) L t =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A := by
    rw [unitaryFromL, unitaryFromLPlus, hamExp]
  have hExp_conj :
      Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) =
        NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A) := by
    simpa [hA_conj] using
      (Matrix.exp_conjTranspose (𝕂 := ℂ) (A := A)).symm
  have hcomm : Commute A (-A) := (Commute.refl A).neg_right
  calc
    unitaryFromL (Ω := Ω) L t * Matrix.conjTranspose (unitaryFromL (Ω := Ω) L t)
        = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            Matrix.conjTranspose (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) := by
              simp [hU]
    _ = (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) A) *
            (NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (-A)) := by
              simp [hExp_conj]
    _ = NormedSpace.exp (𝕂 := ℂ) (𝔸 := Mat Ω) (A + (-A)) := by
              symm
              simpa using
                (NormedSpace.exp_add_of_commute (𝕂 := ℂ) (𝔸 := Mat Ω) hcomm)
    _ = (1 : Mat Ω) := by
              simp [NormedSpace.exp_zero]

theorem unitaryFromLPlus_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromLPlus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L t) = (1 : Mat Ω) := by
  simpa [unitaryFromL] using unitaryFromL_mul_conjTranspose_self (Ω := Ω) L t hL

theorem unitaryFromLMinus_conjTranspose_mul_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) *
        unitaryFromLMinus (Ω := Ω) L t = (1 : Mat Ω) := by
  calc
    Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) *
        unitaryFromLMinus (Ω := Ω) L t
        = Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L (-t)) *
            unitaryFromLPlus (Ω := Ω) L (-t) := by
              rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
    _ = (1 : Mat Ω) := by
          simpa using unitaryFromLPlus_conjTranspose_mul_self (Ω := Ω) L (-t) hL

theorem unitaryFromLMinus_mul_conjTranspose_self
    (L : Matrix Ω Ω ℝ) (t : ℝ) (hL : Matrix.transpose L = L) :
    unitaryFromLMinus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t) = (1 : Mat Ω) := by
  calc
    unitaryFromLMinus (Ω := Ω) L t *
        Matrix.conjTranspose (unitaryFromLMinus (Ω := Ω) L t)
        = unitaryFromLPlus (Ω := Ω) L (-t) *
            Matrix.conjTranspose (unitaryFromLPlus (Ω := Ω) L (-t)) := by
              rw [unitaryFromLMinus_eq_unitaryFromLPlus_neg (Ω := Ω) L t]
    _ = (1 : Mat Ω) := by
          simpa using unitaryFromLPlus_mul_conjTranspose_self (Ω := Ω) L (-t) hL

end

end Derived
end AQFT
end PillarB
