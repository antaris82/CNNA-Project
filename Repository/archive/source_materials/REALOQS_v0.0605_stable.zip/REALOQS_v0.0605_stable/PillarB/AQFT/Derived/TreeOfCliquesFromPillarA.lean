import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveProperties
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveStateNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveSubnet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGNS
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixModular
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixObservableBasis
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixQuasiLocalClosure
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.Derived.EnergyFromBoundaryOp

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived
namespace TreeOfCliquesFromPillarA

noncomputable section

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
open PillarB.AQFT.Derived
open PillarB.AQFT.QuasiLocal

variable {b : Nat}

namespace ToC

variable (p : _root_.PillarA.LayerA.Policy b)

abbrev Ω : Type :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.Ω (b := b) p

instance : Fintype (Ω (b := b) (p := p)) := by
  infer_instance

instance : DecidableEq (Ω (b := b) (p := p)) := by
  classical
  infer_instance

abbrev L : Matrix (Ω (b := b) (p := p)) (Ω (b := b) (p := p)) ℝ :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L (b := b) p

@[simp] lemma L_def :
    L (b := b) (p := p) =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L (b := b) p := rfl

noncomputable def T : MatterTemplate :=
  { d := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA (b := b) p
    d_pos := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA_pos (b := b) p
    β := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA (b := b) p
    φ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.phiFromA (b := b) p }

@[simp] theorem T_d :
    (T (b := b) (p := p)).d =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.dFromA (b := b) p := rfl

@[simp] theorem T_phi :
    (T (b := b) (p := p)).φ =
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.phiFromA (b := b) p := rfl

noncomputable abbrev N_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixLocalNet (Ω := Ω (b := b) (p := p))

noncomputable abbrev N_rich_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  N_ToC (b := b) (p := p)

noncomputable abbrev B_ToC :
    _root_.PillarB.AQFT.Gates.HaagKastler.RegionBasis
      (N := N_rich_ToC (b := b) (p := p)) :=
  boundaryObservableBasisFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

noncomputable def basisFamily_ToC : Finset (BoundaryRegion (Ω (b := b) (p := p))) :=
  boundaryObservableBasisFamilyFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

noncomputable abbrev N_add_ToC : LocalStarAlgebraNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixAdditiveNetFromL
    (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p))

noncomputable abbrev observableInclRich_ToC
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    StarAlgHom
      ((N_add_ToC (b := b) (p := p)).SA r)
      ((N_rich_ToC (b := b) (p := p)).SA r) :=
  boundaryMatrixAdditiveInclRichHom
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    r

noncomputable abbrev B_add_ToC :
    _root_.PillarB.AQFT.Gates.HaagKastler.RegionBasis
      (N := N_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveBasis
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

theorem isotony_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.Isotony
      (N := N_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveIsotony
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

theorem locality_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.Locality
      (N := N_add_ToC (b := b) (p := p))
      (D := boundaryMatrixAdditiveCarrierDisjoint
        (Ω := Ω (b := b) (p := p))
        (B := B_ToC (b := b) (p := p))) :=
  boundaryMatrixAdditiveLocality
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

theorem additivity_basis_ToC_add :
    _root_.PillarB.AQFT.Gates.HaagKastler.AdditivityOnBasis
      (N := N_add_ToC (b := b) (p := p))
      (B_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveAdditivityOnBasis
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

@[simp] theorem B_ToC_basic_ball (i : Ω (b := b) (p := p)) :
    (B_ToC (b := b) (p := p)).basic
      (boundaryBallFromL (Ω := Ω (b := b) (p := p)) (L := L (b := b) (p := p)) i) := by
  change (boundaryObservableBasisFromL
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))).basic
        (boundaryBallFromL (Ω := Ω (b := b) (p := p))
          (L := L (b := b) (p := p)) i)
  exact boundaryObservableBasisFromL_basic_ball
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p)) i

theorem basisFamily_ToC_covers_top :
    _root_.PillarB.AQFT.Gates.HaagKastler.BasisCover
      (N := N_rich_ToC (b := b) (p := p))
      (basisFamily_ToC (b := b) (p := p))
      ((N_rich_ToC (b := b) (p := p)).LAN.RN.top) := by
  change _root_.PillarB.AQFT.Gates.HaagKastler.BasisCover
      (N := boundaryMatrixRichNet (Ω := Ω (b := b) (p := p)))
      (boundaryObservableBasisFamilyFromL
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p)))
      ((boundaryMatrixRichNet (Ω := Ω (b := b) (p := p))).LAN.RN.top)
  exact boundaryObservableBasisFamilyFromL_covers_top
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))

section StrictMatrixState

variable [Fact (0 < b)]

noncomputable def ρTopStrong : CStarStateOn (Mat (Ω (b := b) (p := p))) :=
  boundaryDensityStateAtBeta
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

theorem ρTopStrong_apply (A : Mat (Ω (b := b) (p := p))) :
    ρTopStrong (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        A := by
  exact boundaryDensityStateAtBeta_apply
    (Ω := Ω (b := b) (p := p))
    (L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

noncomputable abbrev SN_ToC :
    PillarA.LayerA.StateNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixStateNet (Ω := Ω (b := b) (p := p))

abbrev topRegion : (N_ToC (b := b) (p := p)).LAN.RN.Region :=
  boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p))

noncomputable abbrev ρTop :
    StateOn
      ((N_ToC (b := b) (p := p)).LAN.Alg
        (topRegion (b := b) (p := p))) :=
  boundaryMatrixTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev ρRegionStrong
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixRegionStrong
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

noncomputable abbrev ρRegion
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixRegion
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

@[simp] theorem ρTop_apply
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg
      (topRegion (b := b) (p := p)))) :
    ρTop (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixTop_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

@[simp] theorem ρRegionStrong_apply
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρRegionStrong (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixRegionStrong_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

@[simp] theorem ρRegion_apply
    (r : (N_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρRegion (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A) := by
  exact boundaryMatrixRegion_apply
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

@[simp] theorem ρRegion_top :
    ρRegion (b := b) (p := p) (topRegion (b := b) (p := p)) =
      ρTop (b := b) (p := p) := by
  exact boundaryMatrixRegion_top
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev cone_FromA :
    PillarA.LayerA.GlobalStateCone (SN := SN_ToC (b := b) (p := p)) :=
  boundaryMatrixStateConeFromStrongTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev Φ_FromA :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω (b := b) (p := p))
        (N := N_ToC (b := b) (p := p))) :=
  boundaryMatrixQuasiLocalStateFromStrongTop
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

theorem restrictToRegion_univ_Φ_FromA :
    QuasiLocal.restrictToRegion (Ω := Ω (b := b) (p := p))
        (N := N_ToC (b := b) (p := p))
        (Φ_FromA (b := b) (p := p))
        (Finset.univ : Finset (Ω (b := b) (p := p))) =
      ρRegion (b := b) (p := p)
        (Finset.univ : Finset (Ω (b := b) (p := p))) := by
  change QuasiLocal.restrictToRegion
      (Ω := Ω (b := b) (p := p))
      (N := N_ToC (b := b) (p := p))
      (boundaryMatrixQuasiLocalStateFromStrongTop
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p))
      (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p))) =
    boundaryMatrixRegion
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))
      ((T (b := b) (p := p)).β)
      (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
      (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p)))
  exact boundaryMatrixQuasiLocalStateFromStrongTop_restrict
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    (boundaryMatrixTopRegion (Ω := Ω (b := b) (p := p)))

noncomputable abbrev SN_add_ToC :
    PillarA.LayerA.StateNet (Ω := Ω (b := b) (p := p)) :=
  boundaryMatrixAdditiveStateNet
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))

noncomputable abbrev ρAdd_top :
    StateOn
      ((N_add_ToC (b := b) (p := p)).LAN.Alg
        ((N_add_ToC (b := b) (p := p)).LAN.RN.top)) :=
  boundaryMatrixAdditiveTopFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev ρAdd_region
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    StateOn ((N_add_ToC (b := b) (p := p)).LAN.Alg r) :=
  boundaryMatrixAdditiveRegionFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

@[simp] theorem ρAdd_top_apply
    (A : ((N_add_ToC (b := b) (p := p)).LAN.Alg
      ((N_add_ToC (b := b) (p := p)).LAN.RN.top))) :
    ρAdd_top (b := b) (p := p) A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A.1) := by
  exact boundaryMatrixAdditiveTopFromRich_apply
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    A

@[simp] theorem ρAdd_region_apply
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region)
    (A : ((N_add_ToC (b := b) (p := p)).LAN.Alg r)) :
    ρAdd_region (b := b) (p := p) r A =
      boundaryDensityStateMatAtBeta
        (Ω := Ω (b := b) (p := p))
        (L (b := b) (p := p))
        ((T (b := b) (p := p)).β)
        (RegionBlockMat.toMatrix A.1) := by
  exact boundaryMatrixAdditiveRegionFromRich_apply
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r A

theorem ρAdd_region_eq_restrict_top
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    (SN_add_ToC (b := b) (p := p)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (N_add_ToC (b := b) (p := p)).LAN.RN) r)
        (ρAdd_top (b := b) (p := p)) =
      ρAdd_region (b := b) (p := p) r := by
  exact boundaryMatrixAdditiveRegionFromRich_eq_restrict_top
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

noncomputable abbrev cone_add_FromA :
    PillarA.LayerA.GlobalStateCone (SN := SN_add_ToC (b := b) (p := p)) :=
  boundaryMatrixAdditiveStateConeFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev Φ_add_FromA :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))) :=
  boundaryMatrixAdditiveQuasiLocalStateFromRich
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    ((T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

theorem restrictToRegion_Φ_add_FromA
    (r : (N_add_ToC (b := b) (p := p)).LAN.RN.Region) :
    QuasiLocal.restrictToRegion
        (Ω := Ω (b := b) (p := p))
        (N := N_add_ToC (b := b) (p := p))
        (Φ_add_FromA (b := b) (p := p))
        r =
      ρAdd_region (b := b) (p := p) r := by
  exact boundaryMatrixAdditiveQuasiLocalStateFromRich_restrict
    (Ω := Ω (b := b) (p := p))
    (B := B_ToC (b := b) (p := p))
    (L := L (b := b) (p := p))
    (((T (b := b) (p := p)).β))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)
    r

noncomputable abbrev Ainf_FromA : Type :=
  QuasiLocal.Carrier
    (Ω := Ω (b := b) (p := p))
    (N := N_ToC (b := b) (p := p))

noncomputable abbrev quasiLocalClosureIsoMatrix_FromA :
    HaagKastler.StarAlgIso
      (SA := boundaryMatrixQuasiLocalSA (Ω := Ω (b := b) (p := p)))
      (SB := matrixStarAlgebraCStar (Ω (b := b) (p := p))) :=
  boundaryMatrixQuasiLocalIsoMatrix (Ω := Ω (b := b) (p := p))

noncomputable abbrev gnsDatum_top_ToC :
    GNSDatum
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p)))
      (ω := ρTop (b := b) (p := p)) :=
  boundaryMatrixTopGNSDatum
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev dyn_top_ToC :
    StarAlgDynamics
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p))) :=
  boundaryMatrixTopDynMinus
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev kmsDatum_top_ToC :
    KMSState
      (SA := (N_ToC (b := b) (p := p)).SA (topRegion (b := b) (p := p))) :=
  boundaryMatrixTopKMSMinusAtBeta
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
    (hL := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

noncomputable abbrev modularDatum_top_ToC :
    BoundaryMatrixModularDatum
      (Ω := Ω (b := b) (p := p))
      (L := L (b := b) (p := p))
      (β := (T (b := b) (p := p)).β)
      (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) :=
  boundaryMatrixTopModularDatum
    (Ω := Ω (b := b) (p := p))
    (L := L (b := b) (p := p))
    (β := (T (b := b) (p := p)).β)
    (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
    (hL := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p)

@[simp] theorem gnsDatum_top_ToC_eq_boundaryMatrixTopGNSDatum :
    gnsDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopGNSDatum
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

omit [Fact (0 < b)] in
@[simp] theorem dyn_top_ToC_eq_boundaryMatrixTopDynMinus :
    dyn_top_ToC (b := b) (p := p) =
      boundaryMatrixTopDynMinus
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (_root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem kmsDatum_top_ToC_eq_boundaryMatrixTopKMSMinusAtBeta :
    kmsDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopKMSMinusAtBeta
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_eq_boundaryMatrixTopModularDatum :
    modularDatum_top_ToC (b := b) (p := p) =
      boundaryMatrixTopModularDatum
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_matrixKMS :
    (modularDatum_top_ToC (b := b) (p := p)).matrixKMS =
      boundaryFullKMSMinusAtBeta
        (Ω := Ω (b := b) (p := p))
        (L := L (b := b) (p := p))
        (β := (T (b := b) (p := p)).β)
        (hβ := _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.betaFromA_pos (b := b) p)
        (hL :=
          _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.L_transpose_eq (b := b) p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_topKMS :
    (modularDatum_top_ToC (b := b) (p := p)).topKMS = kmsDatum_top_ToC (b := b) (p := p) := by
  rfl

@[simp] theorem modularDatum_top_ToC_gns :
    (modularDatum_top_ToC (b := b) (p := p)).gns = gnsDatum_top_ToC (b := b) (p := p) := by
  rfl

theorem state_top_ToC_from_cyclic
    (A : (N_ToC (b := b) (p := p)).LAN.Alg (topRegion (b := b) (p := p))) :
    ρTop (b := b) (p := p) A =
      (gnsDatum_top_ToC (b := b) (p := p)).sesq
        (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec
        ((gnsDatum_top_ToC (b := b) (p := p)).pi A
          (gnsDatum_top_ToC (b := b) (p := p)).cyclicVec) := by
  change ρTop (b := b) (p := p) A =
      (modularDatum_top_ToC (b := b) (p := p)).gns.sesq
        (modularDatum_top_ToC (b := b) (p := p)).gns.cyclicVec
        ((modularDatum_top_ToC (b := b) (p := p)).gns.pi A
          ((modularDatum_top_ToC (b := b) (p := p)).gns.cyclicVec))
  exact (modularDatum_top_ToC (b := b) (p := p)).state_from_cyclic A

end StrictMatrixState

end ToC

end

end TreeOfCliquesFromPillarA
end Derived
end AQFT
end PillarB
