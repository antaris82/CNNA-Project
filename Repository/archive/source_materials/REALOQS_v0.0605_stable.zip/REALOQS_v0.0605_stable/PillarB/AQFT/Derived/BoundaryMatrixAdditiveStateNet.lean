import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAdditiveProperties
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.QuasiLocal.StateLift

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

open PillarB.AQFT.HaagKastler
open PillarB.AQFT.Gates.HaagKastler
open PillarB.AQFT.QuasiLocal

universe u

section BoundaryMatrixAdditiveStateNet

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

variable (B : RegionBasis (N := RichBoundaryNet (Ω := Ω)))

abbrev boundaryMatrixAdditiveStateNet : PillarA.LayerA.StateNet (Ω := Ω) :=
  LocalStarAlgebraNet.toStateNet (Ω := Ω) (AdditiveBoundaryNet (Ω := Ω) B)

abbrev boundaryMatrixAdditiveTopRegion :
    (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region :=
  (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.top

section LocalStatesFromRich

variable [Nonempty Ω]
variable (L : Matrix Ω Ω ℝ) (β : ℝ)
variable (hL : Matrix.transpose L = L)

def boundaryMatrixAdditiveRegionStrongFromRich
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    StateOn ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r) :=
  StateOn.restrict
    (SA := (AdditiveBoundaryNet (Ω := Ω) B).SA r)
    (SB := (RichBoundaryNet (Ω := Ω)).SA r)
    (boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r)
    (boundaryMatrixRegionStrong (Ω := Ω) L β hL r)

abbrev boundaryMatrixAdditiveRegionFromRich
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    StateOn ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r) :=
  boundaryMatrixAdditiveRegionStrongFromRich (Ω := Ω) (B := B) L β hL r

abbrev boundaryMatrixAdditiveTopFromRich :
    StateOn
      ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg
        (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B))) :=
  boundaryMatrixAdditiveRegionStrongFromRich
    (Ω := Ω) (B := B) L β hL
    (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B))

@[simp] theorem boundaryMatrixAdditiveRegionStrongFromRich_apply
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region)
    (A : ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r)) :
    (boundaryMatrixAdditiveRegionStrongFromRich
      (Ω := Ω) (B := B) L β hL r) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β
        (RegionBlockMat.toMatrix A.1) := by
  rw [boundaryMatrixAdditiveRegionStrongFromRich, StateOn.restrict_apply]
  exact boundaryMatrixRegionStrong_apply (Ω := Ω) L β hL r A.1

@[simp] theorem boundaryMatrixAdditiveRegionFromRich_apply
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region)
    (A : ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg r)) :
    (boundaryMatrixAdditiveRegionFromRich
      (Ω := Ω) (B := B) L β hL r) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β
        (RegionBlockMat.toMatrix A.1) :=
  boundaryMatrixAdditiveRegionStrongFromRich_apply
    (Ω := Ω) (B := B) L β hL r A

@[simp] theorem boundaryMatrixAdditiveTopFromRich_apply
    (A : ((AdditiveBoundaryNet (Ω := Ω) B).LAN.Alg
      (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B)))) :
    (boundaryMatrixAdditiveTopFromRich
      (Ω := Ω) (B := B) L β hL) A =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β
        (RegionBlockMat.toMatrix A.1) :=
  boundaryMatrixAdditiveRegionStrongFromRich_apply
    (Ω := Ω) (B := B) L β hL
    (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B)) A

@[simp] theorem boundaryMatrixAdditiveTopFromRich_eq_region_top :
    boundaryMatrixAdditiveTopFromRich (Ω := Ω) (B := B) L β hL =
      boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL
        (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B)) := by
  rfl

@[simp] theorem boundaryMatrixAdditiveRegionFromRich_eq_regionStrong
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r =
      boundaryMatrixAdditiveRegionStrongFromRich
        (Ω := Ω) (B := B) L β hL r := by
  rfl

theorem boundaryMatrixAdditiveRegionStrongFromRich_compat
    {a b : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region} (hab : a ≤ b) :
    (boundaryMatrixAdditiveStateNet (Ω := Ω) (B := B)).restrict hab
      (boundaryMatrixAdditiveRegionStrongFromRich
        (Ω := Ω) (B := B) L β hL b) =
      boundaryMatrixAdditiveRegionStrongFromRich
        (Ω := Ω) (B := B) L β hL a := by
  apply StateOn.ext
  intro A
  rw [LocalStarAlgebraNet.toStateNet_restrict_toFun]
  rw [boundaryMatrixAdditiveRegionStrongFromRich_apply
    (Ω := Ω) (B := B) L β hL b
    (((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl hab A))]
  rw [boundaryMatrixAdditiveRegionStrongFromRich_apply
    (Ω := Ω) (B := B) L β hL a A]
  have hmat :
      RegionBlockMat.toMatrix
          ((((AdditiveBoundaryNet (Ω := Ω) B).LAN.incl hab A)).1) =
        RegionBlockMat.toMatrix A.1 := by
    change RegionBlockMat.toMatrix
        (((RichBoundaryNet (Ω := Ω)).LAN.incl hab A.1) :
          (RichBoundaryNet (Ω := Ω)).LAN.Alg b) =
      RegionBlockMat.toMatrix A.1
    exact boundaryMatrixRegionToMatrix_natural (Ω := Ω) hab A.1
  rw [hmat]

theorem boundaryMatrixAdditiveRegionFromRich_eq_restrict_top
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    (boundaryMatrixAdditiveStateNet (Ω := Ω) (B := B)).restrict
        (_root_.PillarA.LayerA.RegionNet.le_top'
          (RN := (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN) r)
        (boundaryMatrixAdditiveTopFromRich
          (Ω := Ω) (B := B) L β hL) =
      boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r := by
  change (boundaryMatrixAdditiveStateNet (Ω := Ω) (B := B)).restrict
      (_root_.PillarA.LayerA.RegionNet.le_top'
        (RN := (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN) r)
      (boundaryMatrixAdditiveRegionStrongFromRich
        (Ω := Ω) (B := B) L β hL
        (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B))) =
    boundaryMatrixAdditiveRegionStrongFromRich
      (Ω := Ω) (B := B) L β hL r
  exact boundaryMatrixAdditiveRegionStrongFromRich_compat
    (Ω := Ω) (B := B) L β hL
    (_root_.PillarA.LayerA.RegionNet.le_top'
      (RN := (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN) r)

@[simp] theorem boundaryMatrixAdditiveRegionFromRich_top :
    boundaryMatrixAdditiveRegionFromRich
      (Ω := Ω) (B := B) L β hL
      (boundaryMatrixAdditiveTopRegion (Ω := Ω) (B := B)) =
      boundaryMatrixAdditiveTopFromRich (Ω := Ω) (B := B) L β hL := by
  rfl

def boundaryMatrixAdditiveStateConeFromRich :
    PillarA.LayerA.GlobalStateCone
      (SN := boundaryMatrixAdditiveStateNet (Ω := Ω) (B := B)) where
  ω := boundaryMatrixAdditiveRegionFromRich (Ω := Ω) (B := B) L β hL
  compat := by
    intro a b hab
    exact boundaryMatrixAdditiveRegionStrongFromRich_compat
      (Ω := Ω) (B := B) L β hL hab

@[simp] theorem boundaryMatrixAdditiveStateConeFromRich_ω
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    (boundaryMatrixAdditiveStateConeFromRich
      (Ω := Ω) (B := B) L β hL).ω r =
      boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r := by
  rfl

def boundaryMatrixAdditiveQuasiLocalStateFromRich :
    StateOn
      (QuasiLocal.Carrier
        (Ω := Ω)
        (N := AdditiveBoundaryNet (Ω := Ω) B)) :=
  QuasiLocal.stateLift
    (Ω := Ω)
    (N := AdditiveBoundaryNet (Ω := Ω) B)
    (boundaryMatrixAdditiveStateConeFromRich
      (Ω := Ω) (B := B) L β hL)

@[simp] theorem boundaryMatrixAdditiveQuasiLocalStateFromRich_restrict
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    QuasiLocal.restrictToRegion
        (Ω := Ω)
        (N := AdditiveBoundaryNet (Ω := Ω) B)
        (boundaryMatrixAdditiveQuasiLocalStateFromRich
          (Ω := Ω) (B := B) L β hL)
        r =
      boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r := by
  simpa [boundaryMatrixAdditiveQuasiLocalStateFromRich] using
    (QuasiLocal.gate_restrictToRegion_stateLift
      (Ω := Ω)
      (N := AdditiveBoundaryNet (Ω := Ω) B)
      (C := boundaryMatrixAdditiveStateConeFromRich
        (Ω := Ω) (B := B) L β hL)
      (r := r))

theorem boundaryMatrixAdditiveRegionFromRich_normalized
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    IsNormalized ((AdditiveBoundaryNet (Ω := Ω) B).SA r)
      (boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r) := by
  apply StateOn.restrict_preserves_normalized
    (SA := (AdditiveBoundaryNet (Ω := Ω) B).SA r)
    (SB := (RichBoundaryNet (Ω := Ω)).SA r)
    (f := boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r)
  simpa using
    (boundaryMatrixRegion_normalized
      (Ω := Ω) (L := L) (β := β) (hL := hL) (r := r))

theorem boundaryMatrixAdditiveRegionFromRich_positive
    (r : (AdditiveBoundaryNet (Ω := Ω) B).LAN.RN.Region) :
    IsPositive ((AdditiveBoundaryNet (Ω := Ω) B).SA r)
      (boundaryMatrixAdditiveRegionFromRich
        (Ω := Ω) (B := B) L β hL r) := by
  apply StateOn.restrict_preserves_positive
    (SA := (AdditiveBoundaryNet (Ω := Ω) B).SA r)
    (SB := (RichBoundaryNet (Ω := Ω)).SA r)
    (f := boundaryMatrixAdditiveInclRichHom (Ω := Ω) (B := B) r)
  simpa using
    (boundaryMatrixRegion_positive
      (Ω := Ω) (L := L) (β := β) (hL := hL) (r := r))

end LocalStatesFromRich

end BoundaryMatrixAdditiveStateNet

end

end Derived
end AQFT
end PillarB
