import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Data.Complex.Basic
import Mathlib.Data.Real.Basic
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

universe u

variable {X : Type u} [Fintype X]

noncomputable section

def Z (w : X → ℝ) : ℝ := by
  classical
  exact (Finset.univ : Finset X).sum (fun x => w x)

def μ (w : X → ℝ) (_hZ : Z (X := X) w ≠ 0) : X → ℝ :=
  fun x => w x / Z (X := X) w

def expect (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) (f : X → Complex) : Complex :=
  by
    classical
    exact (Finset.univ : Finset X).sum
      (fun x => ((μ (X := X) w hZ x : ℝ) : Complex) * f x)

def expectationState (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) : StateOn (X → Complex) :=
  { toFun := expect (X := X) w hZ }

@[simp] theorem expectationState_apply (w : X → ℝ) (hZ : Z (X := X) w ≠ 0) (f : X → Complex) :
    (expectationState (X := X) w hZ) f = expect (X := X) w hZ f := rfl

end

end Derived
end AQFT
end PillarB
