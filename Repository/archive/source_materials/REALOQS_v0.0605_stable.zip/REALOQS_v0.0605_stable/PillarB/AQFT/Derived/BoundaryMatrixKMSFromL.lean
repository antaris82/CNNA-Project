import Mathlib
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDynamicsFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGibbsState
import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryKMSKernelTerm
    (L : Matrix Ω Ω ℝ) (β : ℝ) (a b : Mat Ω) (i j : Ω) (z : Complex) : Complex :=
  ((((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * a i j) * b j i) *
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) * z)

def boundaryKMSKernel
    (L : Matrix Ω Ω ℝ) (β : ℝ) (a b : Mat Ω) (z : Complex) : Complex :=
  ∑ i, ∑ j, boundaryKMSKernelTerm (Ω := Ω) L β a b i j z

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryKMSExp_real
    (L : Matrix Ω Ω ℝ) (t : ℝ) (i j : Ω) :
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex)) =
      phaseMinusR L t i * phasePlusR L t j := by
  have harg :
      (Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex) =
        - phaseArg L t i + phaseArg L t j := by
    calc
      (Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex)
          = Complex.I *
              ((((L j j : ℝ) : Complex) - (((L i i : ℝ) : Complex))) *
                (t : Complex)) := by
              simp [mul_assoc]
      _ = Complex.I *
            ((((L j j : ℝ) : Complex) * (t : Complex)) -
              ((((L i i : ℝ) : Complex)) * (t : Complex))) := by
              rw [sub_mul]
      _ = Complex.I * ((((t * L j j : ℝ) : Complex)) - (((t * L i i : ℝ) : Complex))) := by
              congr 1
              simp [mul_comm]
      _ = Complex.I * ((t * L j j : ℝ) : Complex) - Complex.I * ((t * L i i : ℝ) : Complex) := by
              rw [mul_sub]
      _ = - phaseArg L t i + phaseArg L t j := by
              simp [phaseArg, sub_eq_add_neg, add_comm]
  calc
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex))
        = Complex.exp (- phaseArg L t i + phaseArg L t j) := by rw [harg]
    _ = Complex.exp (- phaseArg L t i) * Complex.exp (phaseArg L t j) := by
          rw [Complex.exp_add]
    _ = phaseMinusR L t i * phasePlusR L t j := by
          simp [phaseMinusR, phasePlusR]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryKMSExp_imag_shift
    (L : Matrix Ω Ω ℝ) (β : ℝ) (i j : Ω) :
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
      (Complex.I * (β : Complex))) =
      Complex.exp (((β * L i i : ℝ) : Complex)) *
        Complex.exp (-((β * L j j : ℝ) : Complex)) := by
  have hmulI :
      (Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (Complex.I * (β : Complex)) =
        -((((L j j - L i i : ℝ)) : Complex) * (β : Complex)) := by
    calc
      (Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (Complex.I * (β : Complex))
          = (Complex.I * Complex.I) * ((((L j j - L i i : ℝ)) : Complex) * (β : Complex)) := by
              ac_rfl
      _ = (-1 : Complex) * ((((L j j - L i i : ℝ)) : Complex) * (β : Complex)) := by
            simp
      _ = -((((L j j - L i i : ℝ)) : Complex) * (β : Complex)) := by
            simp
  have hsubR : -((L j j - L i i) * β) = β * L i i + -(β * L j j) := by
    ring
  have hsub :
      -((((L j j - L i i : ℝ)) : Complex) * (β : Complex)) =
        (((β * L i i : ℝ) : Complex)) + (-((β * L j j : ℝ) : Complex)) := by
    exact_mod_cast hsubR
  calc
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
          (Complex.I * (β : Complex)))
        = Complex.exp ((((β * L i i : ℝ) : Complex)) + (-((β * L j j : ℝ) : Complex))) := by
            rw [hmulI, hsub]
    _ = Complex.exp (((β * L i i : ℝ) : Complex)) *
          Complex.exp (-((β * L j j : ℝ) : Complex)) := by
            rw [Complex.exp_add]

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryKMSExp_top
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (i j : Ω) :
    Complex.exp ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
      ((t : Complex) + Complex.I * (β : Complex))) =
      (phaseMinusR L t i * phasePlusR L t j) *
        (Complex.exp (((β * L i i : ℝ) : Complex)) *
          Complex.exp (-((β * L j j : ℝ) : Complex))) := by
  calc
    Complex.exp
        ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
          ((t : Complex) + Complex.I * (β : Complex)))
        = Complex.exp
            ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex) +
              (Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
                (Complex.I * (β : Complex))) := by
              rw [mul_add]
    _ = Complex.exp
            ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) * (t : Complex)) *
          Complex.exp
            ((Complex.I * (((L j j - L i i : ℝ)) : Complex)) *
              (Complex.I * (β : Complex))) := by
              rw [Complex.exp_add]
    _ = (phaseMinusR L t i * phasePlusR L t j) *
          (Complex.exp (((β * L i i : ℝ) : Complex)) *
            Complex.exp (-((β * L j j : ℝ) : Complex))) := by
          rw [boundaryKMSExp_real, boundaryKMSExp_imag_shift]

omit [Fintype Ω] [DecidableEq Ω] in
theorem boundaryKMSKernelTerm_differentiable
    (L : Matrix Ω Ω ℝ) (β : ℝ) (a b : Mat Ω) (i j : Ω) :
    Differentiable Complex (boundaryKMSKernelTerm (Ω := Ω) L β a b i j) := by
  unfold boundaryKMSKernelTerm
  fun_prop

omit [DecidableEq Ω] in
theorem boundaryKMSKernel_differentiable
    (L : Matrix Ω Ω ℝ) (β : ℝ) (a b : Mat Ω) :
    Differentiable Complex (boundaryKMSKernel (Ω := Ω) L β a b) := by
  classical
  unfold boundaryKMSKernel boundaryKMSKernelTerm
  fun_prop

theorem boundaryKMSKernel_real
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (a b : Mat Ω) :
    boundaryKMSKernel (Ω := Ω) L β a b (t : Complex) =
      boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul ((boundaryDyn (Ω := Ω) L).α t a) b) := by
  rw [boundaryDyn_alpha_apply, boundaryGibbsDiagStateMat_mul_boundaryDyn_expand]
  unfold boundaryKMSKernel
  apply Finset.sum_congr rfl
  intro i hi
  calc
    ∑ j, boundaryKMSKernelTerm (Ω := Ω) L β a b i j (t : Complex)
        = ∑ j,
            ((((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * a i j) * b j i) *
              (phaseMinusR L t i * phasePlusR L t j) := by
              apply Finset.sum_congr rfl
              intro j hj
              rw [boundaryKMSKernelTerm, boundaryKMSExp_real]
    _ = ∑ j,
          (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
            ((phaseMinusR L t i * a i j * phasePlusR L t j) * b j i)) := by
              apply Finset.sum_congr rfl
              intro j hj
              ac_rfl
    _ = (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
          ∑ j, (phaseMinusR L t i * a i j * phasePlusR L t j) * b j i) := by
            rw [Finset.mul_sum]

theorem boundaryKMSKernel_top
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (a b : Mat Ω) :
    boundaryKMSKernel (Ω := Ω) L β a b ((t : Complex) + Complex.I * (β : Complex)) =
      boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul b ((boundaryDyn (Ω := Ω) L).α t a)) := by
  rw [boundaryDyn_alpha_apply, boundaryGibbsDiagStateMat_mul_dyn_right_expand_kernel_order]
  unfold boundaryKMSKernel
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  calc
    boundaryKMSKernelTerm (Ω := Ω) L β a b i j ((t : Complex) + Complex.I * (β : Complex))
        = ((((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
              Complex.exp (((β * L i i : ℝ) : Complex)) *
              Complex.exp (-((β * L j j : ℝ) : Complex))) *
            (b j i * (phaseMinusR L t i * a i j * phasePlusR L t j))) := by
              rw [boundaryKMSKernelTerm, boundaryKMSExp_top]
              ac_rfl
    _ = ((((boundaryGibbsWeight (Ω := Ω) L β j : ℝ) : Complex)) *
            (b j i * (phaseMinusR L t i * a i j * phasePlusR L t j))) := by
              rw [boundaryGibbsWeight_shift (Ω := Ω) L β i j]
    _ = (((boundaryGibbsWeight (Ω := Ω) L β j : ℝ) : Complex) *
          (b j i * (phaseMinusR L t i * a i j * phasePlusR L t j))) := by
            rfl

theorem invariant_boundaryGibbsDiagStateMat (L : Matrix Ω Ω ℝ) (β : ℝ) :
    IsInvariant (SA := matrixStarAlgebra Ω)
      (boundaryDyn (Ω := Ω) L) (boundaryGibbsDiagStateMat (Ω := Ω) L β) := by
  intro t A
  rw [boundaryDyn_alpha_apply]
  exact boundaryGibbsDiagStateMat_invariant (Ω := Ω) L β t A

theorem kmsStrip_boundaryGibbsDiagStateMat (L : Matrix Ω Ω ℝ) (β : ℝ) :
    KMSStrip (SA := matrixStarAlgebra Ω)
      (boundaryDyn (Ω := Ω) L) β (boundaryGibbsDiagStateMat (Ω := Ω) L β) := by
  intro a b
  refine ⟨boundaryKMSKernel (Ω := Ω) L β a b, ?_, ?_, ?_, ?_⟩
  · exact (boundaryKMSKernel_differentiable (Ω := Ω) L β a b).differentiableOn
  · exact (boundaryKMSKernel_differentiable (Ω := Ω) L β a b).continuous.continuousOn
  · intro t
    exact boundaryKMSKernel_real (Ω := Ω) L β t a b
  · intro t
    exact boundaryKMSKernel_top (Ω := Ω) L β t a b

def boundaryMatrixKMS (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β) :
    KMSState (SA := matrixStarAlgebra Ω) :=
  { β := β
    dyn := boundaryDyn (Ω := Ω) L
    state := boundaryGibbsDiagStateMat (Ω := Ω) L β
    isKMS :=
      { beta_pos := hβ
        invariant := invariant_boundaryGibbsDiagStateMat (Ω := Ω) L β
        kmsStrip := kmsStrip_boundaryGibbsDiagStateMat (Ω := Ω) L β } }

abbrev boundaryMatrixDiagKMS (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β) :
    KMSState (SA := matrixStarAlgebra Ω) :=
  boundaryMatrixKMS (Ω := Ω) L β hβ

@[simp] theorem boundaryMatrixKMS_state (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β) :
    (boundaryMatrixKMS (Ω := Ω) L β hβ).state =
      boundaryGibbsDiagStateMat (Ω := Ω) L β := rfl

@[simp] theorem boundaryMatrixKMS_dyn (L : Matrix Ω Ω ℝ) (β : ℝ) (hβ : 0 < β) :
    (boundaryMatrixKMS (Ω := Ω) L β hβ).dyn = boundaryDyn (Ω := Ω) L := rfl

end

end Derived
end AQFT
end PillarB
