import Mathlib
import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixGibbsState

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω] [Nonempty Ω]

def boundaryGibbsZ (L : Matrix Ω Ω ℝ) (β : ℝ) : ℝ :=
  ∑ i, boundaryGibbsWeight (Ω := Ω) L β i

omit [DecidableEq Ω] in
@[simp] theorem boundaryGibbsZ_pos (L : Matrix Ω Ω ℝ) (β : ℝ) :
    0 < boundaryGibbsZ (Ω := Ω) L β := by
  classical
  obtain ⟨i₀⟩ := ‹Nonempty Ω›
  unfold boundaryGibbsZ
  have hpos : 0 < boundaryGibbsWeight (Ω := Ω) L β i₀ :=
    boundaryGibbsWeight_pos (Ω := Ω) L β i₀
  have hle : boundaryGibbsWeight (Ω := Ω) L β i₀ ≤
      ∑ i, boundaryGibbsWeight (Ω := Ω) L β i := by
    exact Finset.single_le_sum
      (fun i _ => le_of_lt (boundaryGibbsWeight_pos (Ω := Ω) L β i))
      (by simp)
  exact lt_of_lt_of_le hpos hle

omit [DecidableEq Ω] in
@[simp] theorem boundaryGibbsZ_ne_zero (L : Matrix Ω Ω ℝ) (β : ℝ) :
    boundaryGibbsZ (Ω := Ω) L β ≠ 0 := by
  exact ne_of_gt (boundaryGibbsZ_pos (Ω := Ω) L β)

def boundaryGibbsProb (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) : ℝ :=
  boundaryGibbsWeight (Ω := Ω) L β i / boundaryGibbsZ (Ω := Ω) L β

omit [DecidableEq Ω] in
@[simp] theorem boundaryGibbsProb_nonneg
    (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) :
    0 ≤ boundaryGibbsProb (Ω := Ω) L β i := by
  unfold boundaryGibbsProb
  exact div_nonneg (le_of_lt (boundaryGibbsWeight_pos (Ω := Ω) L β i))
    (le_of_lt (boundaryGibbsZ_pos (Ω := Ω) L β))

omit [DecidableEq Ω] in
@[simp] theorem boundaryGibbsProb_pos
    (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) :
    0 < boundaryGibbsProb (Ω := Ω) L β i := by
  unfold boundaryGibbsProb
  exact div_pos (boundaryGibbsWeight_pos (Ω := Ω) L β i)
    (boundaryGibbsZ_pos (Ω := Ω) L β)

omit [DecidableEq Ω] in
@[simp] theorem sum_boundaryGibbsProb (L : Matrix Ω Ω ℝ) (β : ℝ) :
    ∑ i, boundaryGibbsProb (Ω := Ω) L β i = 1 := by
  classical
  have hZ : boundaryGibbsZ (Ω := Ω) L β ≠ 0 :=
    boundaryGibbsZ_ne_zero (Ω := Ω) L β
  unfold boundaryGibbsProb
  calc
    ∑ i, boundaryGibbsWeight (Ω := Ω) L β i / boundaryGibbsZ (Ω := Ω) L β
        = (∑ i, boundaryGibbsWeight (Ω := Ω) L β i) / boundaryGibbsZ (Ω := Ω) L β := by
            rw [Finset.sum_div]
    _ = boundaryGibbsZ (Ω := Ω) L β / boundaryGibbsZ (Ω := Ω) L β := by
          simp [boundaryGibbsZ]
    _ = 1 := by
          exact div_self hZ

omit [DecidableEq Ω] in
@[simp] theorem sum_boundaryGibbsProb_complex (L : Matrix Ω Ω ℝ) (β : ℝ) :
    ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex)) = 1 := by
  exact_mod_cast (sum_boundaryGibbsProb (Ω := Ω) L β)

def boundaryGibbsDiagLinear (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω →ₗ[ℂ] ℂ where
  toFun := fun A =>
    ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i)
  map_add' := by
    intro A B
    simp [mul_add, Finset.sum_add_distrib]
  map_smul' := by
    intro c A
    calc
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * (c * A i i))
          = ∑ i, c * ((((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i)) := by
              apply Finset.sum_congr rfl
              intro i hi
              simp [mul_assoc, mul_comm]
      _ = c * ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i) := by
            rw [Finset.mul_sum]

def boundaryGibbsStateLinear (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω →ₗ[ℂ] ℂ where
  toFun := fun A =>
    ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i)
  map_add' := by
    intro A B
    simp [mul_add, Finset.sum_add_distrib]
  map_smul' := by
    intro c A
    calc
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * (c * A i i))
          = ∑ i, c * ((((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i)) := by
              apply Finset.sum_congr rfl
              intro i hi
              simp [mul_assoc, mul_comm]
      _ = c * ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := by
            rw [Finset.mul_sum]

def boundaryGibbsStateCLM (L : Matrix Ω Ω ℝ) (β : ℝ) : Mat Ω →L[ℂ] ℂ where
  toLinearMap := boundaryGibbsStateLinear (Ω := Ω) L β
  cont := by
    simpa using (boundaryGibbsStateLinear (Ω := Ω) L β).continuous_of_finiteDimensional

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem boundaryGibbsDiagLinear_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryGibbsDiagLinear (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem boundaryGibbsStateLinear_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryGibbsStateLinear (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem boundaryGibbsStateCLM_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryGibbsStateCLM (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

theorem IsRealNonneg.add {z w : Complex}
    (hz : IsRealNonneg z) (hw : IsRealNonneg w) : IsRealNonneg (z + w) := by
  rcases hz with ⟨hz_im, hz_re⟩
  rcases hw with ⟨hw_im, hw_re⟩
  refine ⟨?_, ?_⟩
  · simp [hz_im, hw_im]
  · simpa using add_nonneg hz_re hw_re

theorem IsRealNonneg.ofReal_mul {r : ℝ} {z : Complex}
    (hr : 0 ≤ r) (hz : IsRealNonneg z) :
    IsRealNonneg (((r : ℝ) : Complex) * z) := by
  rcases hz with ⟨hz_im, hz_re⟩
  refine ⟨?_, ?_⟩
  · simp [Complex.mul_im, hz_im]
  · simpa [Complex.mul_re, hz_im] using mul_nonneg hr hz_re

@[simp] theorem isRealNonneg_zero : IsRealNonneg (0 : Complex) := by
  simp [IsRealNonneg]

theorem isRealNonneg_sum {α : Type*} (s : Finset α) (f : α → Complex)
    (h : ∀ a, a ∈ s → IsRealNonneg (f a)) : IsRealNonneg (Finset.sum s f) := by
  classical
  revert h
  refine Finset.induction_on s ?_ ?_
  · intro h
    simp [isRealNonneg_zero]
  · intro a s ha hs h
    have ha' : IsRealNonneg (f a) := h a (by simp)
    have hs' : IsRealNonneg (Finset.sum s f) := by
      apply hs
      intro x hx
      exact h x (by simp [hx])
    simpa [Finset.sum_insert, ha] using IsRealNonneg.add ha' hs'

theorem isRealNonneg_star_mul_self_complex (z : Complex) : IsRealNonneg (star z * z) := by
  refine ⟨?_, ?_⟩
  · change ((star z) * z).im = 0
    simp [Complex.mul_im]
    ring
  · change 0 ≤ ((star z) * z).re
    simp [Complex.mul_re]
    nlinarith [sq_nonneg z.re, sq_nonneg z.im]

omit [DecidableEq Ω] [Nonempty Ω] in
theorem isRealNonneg_star_mul_self_diag (A : Mat Ω) (i : Ω) :
    IsRealNonneg (((star A) * A) i i) := by
  classical
  rw [Matrix.mul_apply]
  refine isRealNonneg_sum (s := Finset.univ) (f := fun j => (star A i j) * A j i) ?_
  intro j hj
  simpa [star_eq_conjTranspose] using isRealNonneg_star_mul_self_complex (A j i)

omit [DecidableEq Ω] in
theorem boundaryGibbsState_positive
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    IsRealNonneg (boundaryGibbsStateCLM (Ω := Ω) L β (star A * A)) := by
  classical
  rw [boundaryGibbsStateCLM_apply]
  refine isRealNonneg_sum
    (s := Finset.univ)
    (f := fun i => (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * ((star A * A) i i))) ?_
  intro i hi
  exact IsRealNonneg.ofReal_mul
    (boundaryGibbsProb_nonneg (Ω := Ω) L β i)
    (isRealNonneg_star_mul_self_diag (Ω := Ω) A i)

@[simp] theorem boundaryGibbsState_one (L : Matrix Ω Ω ℝ) (β : ℝ) :
    boundaryGibbsStateCLM (Ω := Ω) L β 1 = 1 := by
  calc
    boundaryGibbsStateCLM (Ω := Ω) L β 1
        = ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * (1 : Mat Ω) i i) := by
            simp [boundaryGibbsStateCLM_apply]
    _ = ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex)) := by
          simp
    _ = 1 := by
          exact sum_boundaryGibbsProb_complex (Ω := Ω) L β

def boundaryGibbsState (L : Matrix Ω Ω ℝ) (β : ℝ) : CStarStateOn (Mat Ω) where
  toCLM := boundaryGibbsStateCLM (Ω := Ω) L β
  positive' := by
    intro A
    exact boundaryGibbsState_positive (Ω := Ω) L β A
  normalized' := by
    exact boundaryGibbsState_one (Ω := Ω) L β

def boundaryPhysicalGibbsStateMat (L : Matrix Ω Ω ℝ) (β : ℝ) : StateOn (Mat Ω) :=
  (boundaryGibbsState (Ω := Ω) L β).toStateOn

abbrev boundaryDiagonalGibbsStateMat (L : Matrix Ω Ω ℝ) (β : ℝ) : StateOn (Mat Ω) :=
  boundaryPhysicalGibbsStateMat (Ω := Ω) L β

@[simp] theorem boundaryPhysicalGibbsStateMat_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryPhysicalGibbsStateMat (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

@[simp] theorem boundaryGibbsState_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryGibbsState (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

@[simp] theorem boundaryGibbsState_toStateOn_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    (boundaryGibbsState (Ω := Ω) L β).toStateOn A =
      ∑ i, (((boundaryGibbsProb (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

end

end Derived
end AQFT
end PillarB
