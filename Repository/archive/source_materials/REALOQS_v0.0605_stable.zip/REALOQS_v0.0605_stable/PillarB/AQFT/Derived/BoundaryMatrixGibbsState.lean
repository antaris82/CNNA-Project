import Mathlib
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixAlgebra
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixDynamicsFromL
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryGibbsWeight (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) : ℝ :=
  Real.exp (-β * L i i)

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryGibbsWeight_pos (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) :
    0 < boundaryGibbsWeight (Ω := Ω) L β i := by
  simpa [boundaryGibbsWeight] using (Real.exp_pos (-β * L i i))

omit [Fintype Ω] [DecidableEq Ω] in
@[simp] theorem boundaryGibbsWeight_complex
    (L : Matrix Ω Ω ℝ) (β : ℝ) (i : Ω) :
    (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex)) =
      Complex.exp (-((β * L i i : ℝ) : Complex)) := by
  simp [boundaryGibbsWeight]

omit [Fintype Ω] [DecidableEq Ω] in
theorem boundaryGibbsWeight_shift
    (L : Matrix Ω Ω ℝ) (β : ℝ) (i j : Ω) :
    (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
        Complex.exp (((β * L i i : ℝ) : Complex)) *
        Complex.exp (-((β * L j j : ℝ) : Complex))) =
      (((boundaryGibbsWeight (Ω := Ω) L β j : ℝ) : Complex)) := by
  rw [boundaryGibbsWeight_complex, boundaryGibbsWeight_complex]
  calc
    Complex.exp (-((β * L i i : ℝ) : Complex)) *
          Complex.exp (((β * L i i : ℝ) : Complex)) *
          Complex.exp (-((β * L j j : ℝ) : Complex))
        = Complex.exp ((-((β * L i i : ℝ) : Complex)) + (((β * L i i : ℝ) : Complex))) *
            Complex.exp (-((β * L j j : ℝ) : Complex)) := by
              rw [← Complex.exp_add]
    _ = Complex.exp (0 : Complex) * Complex.exp (-((β * L j j : ℝ) : Complex)) := by simp
    _ = Complex.exp (-((β * L j j : ℝ) : Complex)) := by simp

def boundaryGibbsDiagStateMat (L : Matrix Ω Ω ℝ) (β : ℝ) : StateOn (Mat Ω) :=
  { toFun := fun A =>
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i) }

omit [DecidableEq Ω] in
@[simp] theorem boundaryGibbsDiagStateMat_apply
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β A =
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) * A i i) := rfl

omit [DecidableEq Ω] in
theorem boundaryGibbsDiagStateMat_invariant
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (A : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β (boundaryDynMap (Ω := Ω) L t A) =
      boundaryGibbsDiagStateMat (Ω := Ω) L β A := by
  simp_rw [boundaryGibbsDiagStateMat_apply, boundaryDynMap_diag]

theorem boundaryGibbsDiagStateMat_mul_expand
    (L : Matrix Ω Ω ℝ) (β : ℝ) (A B : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β ((matrixStarAlgebra Ω).mul A B) =
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
        (∑ j, A i j * B j i)) := by
  simp [boundaryGibbsDiagStateMat, matrixStarAlgebra, Matrix.mul_apply]

theorem boundaryGibbsDiagStateMat_mul_boundaryDyn_expand
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (A B : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul (boundaryDynMap (Ω := Ω) L t A) B) =
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
        (∑ j, (phaseMinusR L t i * A i j * phasePlusR L t j) * B j i)) := by
  simp [boundaryGibbsDiagStateMat, matrixStarAlgebra, Matrix.mul_apply, boundaryDynMap,
    Finset.mul_sum, mul_assoc]

theorem boundaryGibbsDiagStateMat_mul_dyn_right_expand
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (A B : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul B (boundaryDynMap (Ω := Ω) L t A)) =
      ∑ i, (((boundaryGibbsWeight (Ω := Ω) L β i : ℝ) : Complex) *
        (∑ j, B i j * (phaseMinusR L t j * A j i * phasePlusR L t i))) := by
  simp [boundaryGibbsDiagStateMat, matrixStarAlgebra, Matrix.mul_apply, boundaryDynMap,
    Finset.mul_sum, mul_assoc]

theorem boundaryGibbsDiagStateMat_mul_dyn_right_expand_swapped
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (A B : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul B (boundaryDynMap (Ω := Ω) L t A)) =
      ∑ j, (((boundaryGibbsWeight (Ω := Ω) L β j : ℝ) : Complex) *
        (∑ i, B j i * (phaseMinusR L t i * A i j * phasePlusR L t j))) := by
  simpa using
    (boundaryGibbsDiagStateMat_mul_dyn_right_expand (Ω := Ω) L β t A B)

theorem boundaryGibbsDiagStateMat_mul_dyn_right_expand_kernel_order
    (L : Matrix Ω Ω ℝ) (β t : ℝ) (A B : Mat Ω) :
    boundaryGibbsDiagStateMat (Ω := Ω) L β
        ((matrixStarAlgebra Ω).mul B (boundaryDynMap (Ω := Ω) L t A)) =
      ∑ i, ∑ j,
        (((boundaryGibbsWeight (Ω := Ω) L β j : ℝ) : Complex) *
          (B j i * (phaseMinusR L t i * A i j * phasePlusR L t j))) := by
  rw [boundaryGibbsDiagStateMat_mul_dyn_right_expand_swapped (Ω := Ω) L β t A B]
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]

end
end Derived
end AQFT
end PillarB
