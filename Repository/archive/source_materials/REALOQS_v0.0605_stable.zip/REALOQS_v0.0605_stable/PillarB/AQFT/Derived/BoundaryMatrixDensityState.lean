import Mathlib
import REALOQS.PillarB.AQFT.CStarState
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixCStar
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullExp

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Derived

open scoped BigOperators

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω] [Nonempty Ω]

def matTrace (A : Mat Ω) : ℂ :=
  ∑ i, A i i

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem matTrace_apply (A : Mat Ω) : matTrace (Ω := Ω) A = ∑ i, A i i := rfl

omit [DecidableEq Ω] [Nonempty Ω] in
@[simp] theorem matTrace_smul (c : ℂ) (A : Mat Ω) :
    matTrace (Ω := Ω) (c • A) = c * matTrace (Ω := Ω) A := by
  classical
  unfold matTrace

  simp [Matrix.smul_apply, smul_eq_mul]

  simpa using (Finset.mul_sum (s := (Finset.univ : Finset Ω)) (a := c) (f := fun i => A i i)).symm

omit [DecidableEq Ω] [Nonempty Ω] in
theorem matTrace_mul_comm (A B : Mat Ω) :
    matTrace (Ω := Ω) (A * B) = matTrace (Ω := Ω) (B * A) := by
  classical
  unfold matTrace

  calc
    (∑ i : Ω, (A * B) i i)
        = ∑ i : Ω, ∑ j : Ω, A i j * B j i := by
            classical
            simp [Matrix.mul_apply]
    _ = ∑ j : Ω, ∑ i : Ω, A i j * B j i := by
            classical

            simpa using
              (Finset.sum_comm
                (s := (Finset.univ : Finset Ω))
                (t := (Finset.univ : Finset Ω))
                (f := fun i j => A i j * B j i))
    _ = ∑ j : Ω, ∑ i : Ω, B j i * A i j := by
            classical
            refine Finset.sum_congr rfl ?_
            intro j hj
            refine Finset.sum_congr rfl ?_
            intro i hi
            simp [mul_comm]
    _ = ∑ j : Ω, (B * A) j j := by
            classical
            simp [Matrix.mul_apply]

omit [DecidableEq Ω] [Nonempty Ω] in
theorem matTrace_mul_mul_mul_cycle (X Y Z : Mat Ω) :
    matTrace (Ω := Ω) (X * Y * Z) = matTrace (Ω := Ω) (Z * X * Y) := by
  classical

  simpa [mul_assoc] using
    (matTrace_mul_comm (Ω := Ω) (A := X * Y) (B := Z))

omit [Nonempty Ω] in
theorem re_matTrace_eq_sum_re_diag (A : Mat Ω) :
    (matTrace (Ω := Ω) A).re = ∑ i, (A i i).re := by
  classical
  unfold matTrace

  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
  · simp
  · intro a s ha ih
    simp [Finset.sum_insert, ha, ih, Complex.add_re]

def gibbsHalf (L : Matrix Ω Ω ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-( ( (1:ℝ) / 2 : ℝ) : ℂ))

def boundaryDensityZ (L : Matrix Ω Ω ℝ) : ℝ :=
  ∑ i, ((star (gibbsHalf (Ω := Ω) L) * (gibbsHalf (Ω := Ω) L)) i i).re

def gibbsSandwichTrace (L : Matrix Ω Ω ℝ) (A : Mat Ω) : ℂ :=
  matTrace (Ω := Ω) (star (gibbsHalf (Ω := Ω) L) * A * (gibbsHalf (Ω := Ω) L))

def gibbsSandwichLinear (L : Matrix Ω Ω ℝ) : Mat Ω →ₗ[ℂ] ℂ where
  toFun := fun A => ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹ * gibbsSandwichTrace (Ω := Ω) L A
  map_add' := by
    intro A B
    simp [gibbsSandwichTrace, matTrace, mul_add, add_mul, mul_assoc,
      Finset.sum_add_distrib]
  map_smul' := by
    intro c A
    have htrace :
        gibbsSandwichTrace (Ω := Ω) L (c • A) = c * gibbsSandwichTrace (Ω := Ω) L A := by
      unfold gibbsSandwichTrace matTrace
      simp only [Matrix.mul_apply, Finset.mul_sum, Finset.sum_mul,
        Matrix.smul_apply, smul_eq_mul, mul_assoc]
      refine Finset.sum_congr rfl ?_
      intro i hi
      refine Finset.sum_congr rfl ?_
      intro x hx
      refine Finset.sum_congr rfl ?_
      intro x_1 hx_1
      ring
    calc
      (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
          gibbsSandwichTrace (Ω := Ω) L (c • A)
          = (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
              (c * gibbsSandwichTrace (Ω := Ω) L A) := by rw [htrace]
      _ = c * ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) *
              gibbsSandwichTrace (Ω := Ω) L A) := by ring

def gibbsSandwichCLM (L : Matrix Ω Ω ℝ) : Mat Ω →L[ℂ] ℂ where
  toLinearMap := gibbsSandwichLinear (Ω := Ω) L
  cont := by
    simpa using (gibbsSandwichLinear (Ω := Ω) L).continuous_of_finiteDimensional

def densityMatrixSandwich (L : Matrix Ω Ω ℝ) : Mat Ω :=
  (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) •
    (gibbsHalf (Ω := Ω) L * star (gibbsHalf (Ω := Ω) L))

omit [Nonempty Ω] in
theorem gibbsSandwichTrace_eq_matTrace_density_mul
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    gibbsSandwichTrace (Ω := Ω) L A =
      matTrace (Ω := Ω)
        ((gibbsHalf (Ω := Ω) L * star (gibbsHalf (Ω := Ω) L)) * A) := by
  classical

  have hcycle :=
    (matTrace_mul_mul_mul_cycle (Ω := Ω)
      (X := star (gibbsHalf (Ω := Ω) L)) (Y := A) (Z := gibbsHalf (Ω := Ω) L))
  simpa [gibbsSandwichTrace, mul_assoc] using hcycle

omit [Nonempty Ω] in
theorem gibbsSandwichCLM_eq_matTrace_density_mul
    (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    gibbsSandwichCLM (Ω := Ω) L A =
      matTrace (Ω := Ω) ((densityMatrixSandwich (Ω := Ω) L) * A) := by
  classical

  simp [gibbsSandwichCLM, gibbsSandwichLinear]
  have htr := gibbsSandwichTrace_eq_matTrace_density_mul (Ω := Ω) L A

  rw [htr]

  simp [densityMatrixSandwich, mul_assoc]

  classical

  simpa using
    (Finset.mul_sum (s := (Finset.univ : Finset Ω))
      (a := (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹))
      (f := fun i : Ω =>
        (gibbsHalf (Ω := Ω) L * (Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * A)) i i))

omit [DecidableEq Ω] [Nonempty Ω] in

theorem exists_entry_ne_zero (A : Mat Ω) (hA : A ≠ 0) : ∃ i j, A i j ≠ 0 := by
  classical
  by_contra h
  have h0 : A = 0 := by
    ext i j
    by_contra hij
    exact h ⟨i, j, hij⟩
  exact hA h0

theorem density_isRealNonneg_star_mul_self_complex (z : ℂ) : IsRealNonneg (star z * z) := by
  refine ⟨?_, ?_⟩
  · change ((star z) * z).im = 0
    simp [Complex.mul_im]
    ring
  · change 0 ≤ ((star z) * z).re
    simp [Complex.mul_re]
    nlinarith [sq_nonneg z.re, sq_nonneg z.im]

theorem star_mul_self_re_pos {z : ℂ} (hz : z ≠ 0) : 0 < (star z * z).re := by
  have : z.re ≠ 0 ∨ z.im ≠ 0 := by
    by_contra h
    push_neg at h
    apply hz
    apply Complex.ext <;> simp [h.1, h.2]
  simp [Complex.mul_re] at *
  have hsq : 0 < z.re ^ 2 + z.im ^ 2 := by
    rcases this with h | h
    · have : 0 < z.re ^ 2 := sq_pos_of_ne_zero h
      nlinarith [this, sq_nonneg z.im]
    · have : 0 < z.im ^ 2 := sq_pos_of_ne_zero h
      nlinarith [this, sq_nonneg z.re]

  nlinarith [hsq]

omit [DecidableEq Ω] [Nonempty Ω] in

theorem density_isRealNonneg_star_mul_self_diag (A : Mat Ω) (i : Ω) :
    IsRealNonneg (((star A) * A) i i) := by
  classical

  rw [Matrix.mul_apply]

  have hsum :
      IsRealNonneg (Finset.sum (Finset.univ : Finset Ω)
        (fun j => (star A i j) * A j i)) := by

    refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
    · simp [IsRealNonneg]
    · intro a s ha hs
      have ha' : IsRealNonneg ((star A i a) * A a i) := by

        simpa [star_eq_conjTranspose] using
          density_isRealNonneg_star_mul_self_complex (A a i)
      rcases ha' with ⟨ha_im, ha_re⟩
      rcases hs with ⟨hs_im, hs_re⟩
      refine ⟨?_, ?_⟩
      · rw [Finset.sum_insert ha]
        rw [Complex.add_im]
        rw [ha_im, hs_im]
        simp
      · simpa [Finset.sum_insert, ha] using add_nonneg ha_re hs_re
  simpa using hsum

omit [Nonempty Ω] in

theorem isRealNonneg_matTrace_star_mul_self (X : Mat Ω) :
    IsRealNonneg (matTrace (Ω := Ω) (star X * X)) := by
  classical
  unfold matTrace
  have hdiag : ∀ i : Ω, IsRealNonneg (((star X) * X) i i) :=
    fun i => density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := X) i

  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?h0 ?hstep
  · simp [IsRealNonneg]
  · intro a s ha ih
    have ha' : IsRealNonneg (((star X) * X) a a) := hdiag a
    have hs' : IsRealNonneg (Finset.sum s (fun x => ((star X) * X) x x)) := ih
    rcases ha' with ⟨ha_im, ha_re⟩
    rcases hs' with ⟨hs_im, hs_re⟩
    refine ⟨?_, ?_⟩
    · rw [Finset.sum_insert ha, Complex.add_im, ha_im, hs_im]
      simp
    · have hnn : 0 ≤ (((star X) * X) a a).re + (Finset.sum s (fun x => ((star X) * X) x x)).re :=
        add_nonneg ha_re hs_re
      simpa [Finset.sum_insert ha, Complex.add_re] using hnn

theorem boundaryDensityZ_pos (L : Matrix Ω Ω ℝ) : 0 < boundaryDensityZ (Ω := Ω) L := by
  classical

  have hB_ne : gibbsHalf (Ω := Ω) L ≠ 0 := by

    have hmul :
        gibbsHalf (Ω := Ω) L * hamExp (Ω := Ω) L (( ( (1:ℝ) / 2 : ℝ) : ℂ)) = (1 : Mat Ω) := by

      have hadd := hamExp_add (Ω := Ω) L (-( ( (1:ℝ) / 2 : ℝ) : ℂ)) ((( (1:ℝ) / 2 : ℝ) : ℂ))

      have hz : (-( ( (1:ℝ) / 2 : ℝ) : ℂ)) + ((( (1:ℝ) / 2 : ℝ) : ℂ)) = 0 := by
        simp

      simpa [gibbsHalf, hz] using (by

        simpa [hz] using hadd.symm)
    intro h0

    have hmul0 : (0 : Mat Ω) = (1 : Mat Ω) := by
      have hmul' := hmul
      simp [h0] at hmul'
    exact (zero_ne_one (α := Mat Ω)) hmul0
  rcases exists_entry_ne_zero (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) hB_ne with ⟨i0, j0, hij0⟩

  have hdiag_pos : 0 < ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re := by

    have hterm_pos : 0 < (star (gibbsHalf (Ω := Ω) L i0 j0) * gibbsHalf (Ω := Ω) L i0 j0).re :=
      star_mul_self_re_pos hij0

    have hterm_nonneg :
        ∀ i : Ω,
          0 ≤ (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      intro i
      exact (density_isRealNonneg_star_mul_self_complex (gibbsHalf (Ω := Ω) L i j0)).2

    have hdiag :
        (star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0 =
          ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0) := by

      classical

      simp [Matrix.mul_apply, star_eq_conjTranspose, Matrix.conjTranspose_apply]

    have hdiag_re :
        ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re =
          ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      classical

      simpa [hdiag] using congrArg Complex.re hdiag

    have hle : (star (gibbsHalf (Ω := Ω) L i0 j0) * gibbsHalf (Ω := Ω) L i0 j0).re ≤
        ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re := by
      classical
      exact Finset.single_le_sum (fun i _ => hterm_nonneg i) (by simp)
    have : 0 < ∑ i, (star (gibbsHalf (Ω := Ω) L i j0) * gibbsHalf (Ω := Ω) L i j0).re :=
      lt_of_lt_of_le hterm_pos hle
    rw [hdiag_re]
    exact this

  unfold boundaryDensityZ

  have hZ_ge : ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) j0 j0).re ≤
      ∑ i, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re := by
    classical
    exact Finset.single_le_sum (fun i _ =>
      (density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i).2)
      (by simp)
  have hsum_pos : 0 < ∑ i, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re :=
    lt_of_lt_of_le hdiag_pos hZ_ge
  exact hsum_pos

@[simp] theorem boundaryDensityZ_ne_zero (L : Matrix Ω Ω ℝ) : boundaryDensityZ (Ω := Ω) L ≠ 0 :=
  ne_of_gt (boundaryDensityZ_pos (Ω := Ω) L)

@[simp] theorem gibbsSandwich_one (L : Matrix Ω Ω ℝ) :
    gibbsSandwichCLM (Ω := Ω) L 1 = 1 := by
  classical
  have hZ : boundaryDensityZ (Ω := Ω) L ≠ 0 := boundaryDensityZ_ne_zero (Ω := Ω) L

  have htrace : gibbsSandwichTrace (Ω := Ω) L 1 = ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ) := by
    unfold gibbsSandwichTrace

    simp [matTrace, boundaryDensityZ]

    classical
    apply Finset.sum_congr rfl
    intro i hi

    have hiR : IsRealNonneg (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i) :=
      density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i

    have him : (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i).im = 0 := hiR.1

    apply Complex.ext
    · simp
    · simpa [him]

  unfold gibbsSandwichCLM gibbsSandwichLinear
  have hZc : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)) ≠ 0 := by
    exact_mod_cast hZ
  simp [htrace, hZc]

theorem density_IsRealNonneg_ofReal_mul {r : ℝ} {z : ℂ} (hr : 0 ≤ r) (hz : IsRealNonneg z) :
    IsRealNonneg (((r : ℝ) : ℂ) * z) := by
  rcases hz with ⟨hz_im, hz_re⟩
  refine ⟨?_, ?_⟩
  · simp [Complex.mul_im, hz_im]
  · simpa [Complex.mul_re, hz_im] using mul_nonneg hr hz_re

theorem gibbsSandwich_positive (L : Matrix Ω Ω ℝ) (A : Mat Ω) :
    IsRealNonneg (gibbsSandwichCLM (Ω := Ω) L (star A * A)) := by
  classical
  have hZpos : 0 < boundaryDensityZ (Ω := Ω) L := boundaryDensityZ_pos (Ω := Ω) L
  have hZinv : 0 ≤ (boundaryDensityZ (Ω := Ω) L)⁻¹ := le_of_lt (inv_pos.2 hZpos)

  let B : Mat Ω := gibbsHalf (Ω := Ω) L
  have hrewrite : star B * (star A * A) * B = star (A * B) * (A * B) := by

    simp [B, mul_assoc, star_mul, star_eq_conjTranspose]

  unfold gibbsSandwichCLM gibbsSandwichLinear

  have hz : IsRealNonneg (matTrace (Ω := Ω) (star (A * B) * (A * B))) := by
    simpa using isRealNonneg_matTrace_star_mul_self (Ω := Ω) (X := (A * B))

  have hzTrace : IsRealNonneg (gibbsSandwichTrace (Ω := Ω) L (star A * A)) := by

    simpa [gibbsSandwichTrace, matTrace, hrewrite, mul_assoc] using hz
  have hscalar : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) =
      (((((boundaryDensityZ (Ω := Ω) L)⁻¹) : ℝ) : ℂ)) := by

    simp

  dsimp [gibbsSandwichCLM, gibbsSandwichLinear]

  rw [hscalar]
  exact density_IsRealNonneg_ofReal_mul (r := (boundaryDensityZ (Ω := Ω) L)⁻¹) hZinv hzTrace

def boundaryDensityState (L : Matrix Ω Ω ℝ) : CStarStateOn (Mat Ω) where
  toCLM := gibbsSandwichCLM (Ω := Ω) L
  positive' := gibbsSandwich_positive (Ω := Ω) L
  normalized' := gibbsSandwich_one (Ω := Ω) L

def boundaryDensityStateMat (L : Matrix Ω Ω ℝ) : StateOn (Mat Ω) :=
  (boundaryDensityState (Ω := Ω) L).toStateOn

def gibbsOpCore (L : Matrix Ω Ω ℝ) : Mat Ω :=
  hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ))

omit [Nonempty Ω] in
theorem gibbsHalf_star_eq
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L := by
  classical

  have h := hamExp_conjTranspose (Ω := Ω) L (-( ((1 : ℝ) / 2 : ℝ) : ℂ)) hL

  simpa [gibbsHalf, star_eq_conjTranspose] using h

omit [Nonempty Ω] in
theorem gibbsHalf_star_mul_self_eq_gibbsOpCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L := by
  classical

  have hB : star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L :=
    gibbsHalf_star_eq (Ω := Ω) L hL

  set a : ℂ := (-( ((1 : ℝ) / 2 : ℝ) : ℂ)) with ha

  have hadd : hamExp (Ω := Ω) L (a + a) =
      hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa using (hamExp_add (Ω := Ω) L a a)

  have hscalar : a + a = (-((1 : ℝ) : ℂ)) := by
    have : (-( ((1 : ℝ) / 2 : ℝ) : ℂ) + (-( ((1 : ℝ) / 2 : ℝ) : ℂ))) =
        (-((1 : ℝ) : ℂ)) := by
      norm_num
    simpa [ha] using this

  have hadd1 :
      hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    have h1 : hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L (a + a) := by
      simpa using congrArg (fun z => hamExp (Ω := Ω) L z) hscalar.symm
    exact h1.trans hadd

  have this : gibbsOpCore (Ω := Ω) L =
      gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L := by
    simpa [gibbsOpCore, gibbsHalf, ha] using hadd1

  simp [hB, this]

omit [Nonempty Ω] in
theorem boundaryDensityZ_eq_re_matTrace_gibbsOpCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    boundaryDensityZ (Ω := Ω) L = (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re := by
  classical
  have hG :
      star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L :=
    gibbsHalf_star_mul_self_eq_gibbsOpCore (Ω := Ω) L hL

  unfold boundaryDensityZ
  have hG' :
      Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L =
        gibbsOpCore (Ω := Ω) L := by
    simpa using hG

  have hZ :
      (∑ i : Ω,
          ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re) =
        ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re := by
    simpa using congrArg (fun M : Mat Ω => ∑ i : Ω, (M i i).re) hG'

  have hre :
      (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re =
        ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re :=
    re_matTrace_eq_sum_re_diag (Ω := Ω) (A := gibbsOpCore (Ω := Ω) L)

  have hStar_to_conj :
      (∑ i : Ω, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re) =
        ∑ i : Ω,
          ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re := by

    simp

  calc
    (∑ i : Ω, ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re)
        = ∑ i : Ω,
            ((Matrix.conjTranspose (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i).re :=
      hStar_to_conj
    _ = ∑ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).re := hZ
    _ = (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).re := hre.symm

omit [Nonempty Ω] in
theorem matTrace_gibbsOpCore_im_eq_zero
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    (matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L)).im = 0 := by
  classical
  have hG :
      star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L =
        gibbsOpCore (Ω := Ω) L :=
    gibbsHalf_star_mul_self_eq_gibbsOpCore (Ω := Ω) L hL
  have hdiag_im :
      ∀ i : Ω, ((gibbsOpCore (Ω := Ω) L) i i).im = 0 := by
    intro i
    have hiR :
        IsRealNonneg (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i) :=
      density_isRealNonneg_star_mul_self_diag (Ω := Ω) (A := gibbsHalf (Ω := Ω) L) i
    have him : (((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L)) i i).im = 0 := hiR.1
    have hentry :
        ((star (gibbsHalf (Ω := Ω) L) * gibbsHalf (Ω := Ω) L) i i) =
          (gibbsOpCore (Ω := Ω) L) i i := by
      simpa using congrArg (fun M : Mat Ω => M i i) hG
    rw [← hentry]
    exact him
  unfold matTrace
  refine Finset.induction_on (s := (Finset.univ : Finset Ω)) ?_ ?_
  · simp
  · intro a s ha ih
    have ha_im : ((gibbsOpCore (Ω := Ω) L) a a).im = 0 := hdiag_im a
    simp [Finset.sum_insert, ha, ha_im, ih, Complex.add_im]

omit [Nonempty Ω] in
theorem matTrace_gibbsOpCore_eq_ofReal_boundaryDensityZ
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    matTrace (Ω := Ω) (gibbsOpCore (Ω := Ω) L) =
      ((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ) := by
  apply Complex.ext
  · simpa using (boundaryDensityZ_eq_re_matTrace_gibbsOpCore (Ω := Ω) L hL).symm
  · simpa using matTrace_gibbsOpCore_im_eq_zero (Ω := Ω) L hL

def densityMatrixCore (L : Matrix Ω Ω ℝ) : Mat Ω :=
  (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • gibbsOpCore (Ω := Ω) L

@[simp] theorem matTrace_densityMatrixCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    matTrace (Ω := Ω) (densityMatrixCore (Ω := Ω) L) = 1 := by
  have hZ : boundaryDensityZ (Ω := Ω) L ≠ 0 := boundaryDensityZ_ne_zero (Ω := Ω) L
  have hZc : (((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)) ≠ 0 := by
    exact_mod_cast hZ
  rw [show densityMatrixCore (Ω := Ω) L =
      ((((boundaryDensityZ (Ω := Ω) L : ℝ) : ℂ)⁻¹) • gibbsOpCore (Ω := Ω) L) by rfl]
  rw [matTrace_smul]
  rw [matTrace_gibbsOpCore_eq_ofReal_boundaryDensityZ (Ω := Ω) L hL]
  simp [hZc]

omit [Nonempty Ω] in
theorem densityMatrixSandwich_eq_densityMatrixCore
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) :
    densityMatrixSandwich (Ω := Ω) L = densityMatrixCore (Ω := Ω) L := by
  classical
  unfold densityMatrixSandwich densityMatrixCore

  have hB : star (gibbsHalf (Ω := Ω) L) = gibbsHalf (Ω := Ω) L :=
    gibbsHalf_star_eq (Ω := Ω) L hL

  set a : ℂ := -(((1 : ℝ) / 2 : ℝ) : ℂ)
  have hadd : hamExp (Ω := Ω) L (a + a) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa [a] using (hamExp_add (Ω := Ω) L a a)

  have hscalar : a + a = -((1 : ℝ) : ℂ) := by

    have : (-(((1 : ℝ) / 2 : ℝ) : ℂ) + -(((1 : ℝ) / 2 : ℝ) : ℂ)) = -((1 : ℝ) : ℂ) := by
      norm_num
    simpa [a] using this

  have hadd1 : hamExp (Ω := Ω) L (-((1 : ℝ) : ℂ)) =
        hamExp (Ω := Ω) L a * hamExp (Ω := Ω) L a := by
    simpa [hscalar] using hadd

  have hBB : gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L = gibbsOpCore (Ω := Ω) L := by

    have : gibbsOpCore (Ω := Ω) L =
        gibbsHalf (Ω := Ω) L * gibbsHalf (Ω := Ω) L := by
      simpa [gibbsOpCore, gibbsHalf, a] using hadd1
    simpa using this.symm

  simp [hB, hBB]

theorem boundaryDensityStateMat_eq_matTrace_densityMatrixCore_mul
    (L : Matrix Ω Ω ℝ) (hL : Matrix.transpose L = L) (A : Mat Ω) :
    boundaryDensityStateMat (Ω := Ω) L A =
      matTrace (Ω := Ω) ((densityMatrixCore (Ω := Ω) L) * A) := by
  unfold boundaryDensityStateMat
  rw [CStarStateOn.toStateOn_apply]
  unfold boundaryDensityState
  rw [gibbsSandwichCLM_eq_matTrace_density_mul (Ω := Ω) L A]
  rw [densityMatrixSandwich_eq_densityMatrixCore (Ω := Ω) L hL]

end

end Derived
end AQFT
end PillarB
