import Mathlib
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.Normed.Operator.ContinuousLinearMap
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixFullKMSFromL
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixLocalNet
import REALOQS.PillarB.AQFT.Derived.BoundaryMatrixStateNet
import REALOQS.PillarB.AQFT.GNS

set_option autoImplicit false

open scoped Matrix.Norms.L2Operator

namespace PillarB
namespace AQFT
namespace Derived

noncomputable section

universe u

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryMatrixGNSSesq
    [Nonempty Ω]
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (X Y : Mat Ω) : ℂ :=
  (boundaryDensityStateAtBeta (Ω := Ω) L β hL).toStateOn
    ((matrixStarAlgebraCStar Ω).mul ((matrixStarAlgebraCStar Ω).star X) Y)

@[simp] theorem boundaryMatrixGNSSesq_apply
    [Nonempty Ω]
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (X Y : Mat Ω) :
    boundaryMatrixGNSSesq (Ω := Ω) L β hL X Y =
      boundaryDensityStateMatAtBeta (Ω := Ω) L β (star X * Y) := by
  simp [boundaryMatrixGNSSesq,
    matrixStarAlgebraCStar_mul_apply, matrixStarAlgebraCStar_star_apply]

def boundaryMatrixLeftMulLinear (A : Mat Ω) : Mat Ω →ₗ[ℂ] Mat Ω where
  toFun := fun X => A * X
  map_add' := by
    intro X Y
    simp [Matrix.mul_add]
  map_smul' := by
    intro c X
    ext i j
    simp [Matrix.mul_apply, Matrix.smul_apply, smul_eq_mul, Finset.mul_sum, mul_left_comm]

def boundaryMatrixLeftMulCLM (A : Mat Ω) : Mat Ω →L[ℂ] Mat Ω where
  toLinearMap := boundaryMatrixLeftMulLinear (Ω := Ω) A
  cont := by
    simpa using (boundaryMatrixLeftMulLinear (Ω := Ω) A).continuous_of_finiteDimensional

section GNSBasicApplyLemmas

variable {Ω : Type u} [Fintype Ω]

@[simp] theorem boundaryMatrixLeftMulCLM_apply (A X : Mat Ω) :
    boundaryMatrixLeftMulCLM (Ω := Ω) A X = A * X := rfl

def boundaryMatrixMatrixGNSPi (A : Mat Ω) : Mat Ω →L[ℂ] Mat Ω :=
  boundaryMatrixLeftMulCLM (Ω := Ω) A

@[simp] theorem boundaryMatrixMatrixGNSPi_apply (A X : Mat Ω) :
    boundaryMatrixMatrixGNSPi (Ω := Ω) A X = A * X := rfl

end GNSBasicApplyLemmas

section GNSApplyLemmas

variable {Ω : Type u} [Fintype Ω] [DecidableEq Ω]

def boundaryMatrixTopGNSPi
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω))) :
    Mat Ω →L[ℂ] Mat Ω :=
  boundaryMatrixMatrixGNSPi (Ω := Ω) (RegionBlockMat.toMatrix A)

@[simp] theorem boundaryMatrixTopGNSPi_apply
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω)))
    (X : Mat Ω) :
    boundaryMatrixTopGNSPi (Ω := Ω) A X = RegionBlockMat.toMatrix A * X := rfl

end GNSApplyLemmas

theorem boundaryMatrixTopGNSPi_add
    (A B : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω)))
    (X : Mat Ω) :
    boundaryMatrixTopGNSPi (Ω := Ω)
      (((boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixTopRegion (Ω := Ω))).add A B) X =
      boundaryMatrixTopGNSPi (Ω := Ω) A X + boundaryMatrixTopGNSPi (Ω := Ω) B X := by
  change (RegionBlockMat.toMatrix A + RegionBlockMat.toMatrix B) * X =
      RegionBlockMat.toMatrix A * X + RegionBlockMat.toMatrix B * X
  exact add_mul (RegionBlockMat.toMatrix A) (RegionBlockMat.toMatrix B) X

theorem boundaryMatrixTopGNSPi_mul
    (A B : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω)))
    (X : Mat Ω) :
    boundaryMatrixTopGNSPi (Ω := Ω)
      (((boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixTopRegion (Ω := Ω))).mul A B) X =
      boundaryMatrixTopGNSPi (Ω := Ω) A (boundaryMatrixTopGNSPi (Ω := Ω) B X) := by
  change (RegionBlockMat.toMatrix A * RegionBlockMat.toMatrix B) * X =
      RegionBlockMat.toMatrix A * (RegionBlockMat.toMatrix B * X)
  exact mul_assoc (RegionBlockMat.toMatrix A) (RegionBlockMat.toMatrix B) X

theorem boundaryMatrixTopGNSPi_one
    (X : Mat Ω) :
    boundaryMatrixTopGNSPi (Ω := Ω)
      ((boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixTopRegion (Ω := Ω))).one X = X := by
  change (1 : Mat Ω) * X = X
  exact one_mul X

def boundaryMatrixGNSCyclicVec : Mat Ω := 1

section GNSCyclicLemmas

variable {Ω : Type u}

theorem boundaryMatrixTopGNS_cyclic
    [Fintype Ω] [DecidableEq Ω] [Nonempty Ω]
    (X : Mat Ω) :
    ∃ A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω)),
      boundaryMatrixTopGNSPi (Ω := Ω) A (boundaryMatrixGNSCyclicVec (Ω := Ω)) = X := by
  refine ⟨matrixToTopRegion (Ω := Ω) X, ?_⟩
  rw [boundaryMatrixTopGNSPi_apply]
  simp [boundaryMatrixGNSCyclicVec, matrixToTopRegion_toMatrix]

end GNSCyclicLemmas

theorem boundaryMatrixTop_state_from_cyclic
    [Nonempty Ω]
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L)
    (A : (boundaryMatrixLocalNet (Ω := Ω)).LAN.Alg (boundaryMatrixTopRegion (Ω := Ω))) :
    boundaryMatrixTop (Ω := Ω) L β hL A =
      boundaryMatrixGNSSesq (Ω := Ω) L β hL
        (boundaryMatrixGNSCyclicVec (Ω := Ω))
        (boundaryMatrixTopGNSPi (Ω := Ω) A (boundaryMatrixGNSCyclicVec (Ω := Ω))) := by
  rw [boundaryMatrixTop_apply, boundaryMatrixTopGNSPi_apply]
  simp [boundaryMatrixGNSSesq, boundaryMatrixGNSCyclicVec,
    matrixStarAlgebraCStar_mul_apply, matrixStarAlgebraCStar_star_apply]

def boundaryMatrixTopGNSDatum
    [Nonempty Ω]
    (L : Matrix Ω Ω ℝ) (β : ℝ) (hL : Matrix.transpose L = L) :
    GNSDatum
      (SA := (boundaryMatrixLocalNet (Ω := Ω)).SA (boundaryMatrixTopRegion (Ω := Ω)))
      (ω := boundaryMatrixTop (Ω := Ω) L β hL) where
  H := Mat Ω
  instNormedAddCommGroup := by infer_instance
  instNormedSpace := by infer_instance
  sesq := boundaryMatrixGNSSesq (Ω := Ω) L β hL
  pi := boundaryMatrixTopGNSPi (Ω := Ω)
  pi_add := by
    intro A B ξ
    exact boundaryMatrixTopGNSPi_add (Ω := Ω) A B ξ
  pi_mul := by
    intro A B ξ
    exact boundaryMatrixTopGNSPi_mul (Ω := Ω) A B ξ
  pi_one := by
    intro ξ
    exact boundaryMatrixTopGNSPi_one (Ω := Ω) ξ
  cyclicVec := boundaryMatrixGNSCyclicVec (Ω := Ω)
  cyclic := by
    intro ξ
    exact boundaryMatrixTopGNS_cyclic (Ω := Ω) ξ
  state_from_cyclic := by
    intro A
    exact boundaryMatrixTop_state_from_cyclic (Ω := Ω) L β hL A

end

end Derived
end AQFT
end PillarB
