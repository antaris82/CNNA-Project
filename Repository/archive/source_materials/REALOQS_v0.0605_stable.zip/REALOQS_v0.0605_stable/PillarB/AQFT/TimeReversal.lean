import REALOQS.PillarB.AQFT.KMS

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u

structure TimeReversalOn (A : Type u)
    [Zero A] [One A] [Add A] [Mul A] [Neg A] [Star A] [SMul ℂ A] where
  toFun : A → A
  map_zero' : toFun 0 = 0
  map_one' : toFun 1 = 1
  map_add' : ∀ a b : A, toFun (a + b) = toFun a + toFun b
  map_mul' : ∀ a b : A, toFun (a * b) = toFun a * toFun b
  map_neg' : ∀ a : A, toFun (-a) = -toFun a
  map_star' : ∀ a : A, toFun (star a) = star (toFun a)
  map_smul' : ∀ z : ℂ, ∀ a : A, toFun (z • a) = (star z) • toFun a
  involutive' : ∀ a : A, toFun (toFun a) = a

section Basic

variable {A : Type u}
variable [Zero A] [One A] [Add A] [Mul A] [Neg A] [Star A] [SMul ℂ A]

instance : CoeFun (TimeReversalOn A) (fun _ => A → A) :=
  ⟨TimeReversalOn.toFun⟩

namespace TimeReversalOn

@[simp] theorem map_zero (T : TimeReversalOn A) : T 0 = 0 :=
  T.map_zero'

@[simp] theorem map_one (T : TimeReversalOn A) : T 1 = 1 :=
  T.map_one'

@[simp] theorem map_add (T : TimeReversalOn A) (a b : A) :
    T (a + b) = T a + T b :=
  T.map_add' a b

@[simp] theorem map_mul (T : TimeReversalOn A) (a b : A) :
    T (a * b) = T a * T b :=
  T.map_mul' a b

@[simp] theorem map_neg (T : TimeReversalOn A) (a : A) :
    T (-a) = -T a :=
  T.map_neg' a

@[simp] theorem map_star (T : TimeReversalOn A) (a : A) :
    T (star a) = star (T a) :=
  T.map_star' a

@[simp] theorem map_smul (T : TimeReversalOn A) (z : ℂ) (a : A) :
    T (z • a) = (star z) • T a :=
  T.map_smul' z a

@[simp] theorem involutive (T : TimeReversalOn A) (a : A) :
    T (T a) = a :=
  T.involutive' a

theorem injective (T : TimeReversalOn A) : Function.Injective T := by
  intro a b hab
  have := congrArg T hab
  simpa using this

theorem surjective (T : TimeReversalOn A) : Function.Surjective T := by
  intro a
  refine ⟨T a, ?_⟩
  exact T.involutive a

end TimeReversalOn

def TimeReversalIntertwines
    {SA : StarAlgebra A}
    (T : TimeReversalOn A)
    (Dplus Dminus : StarAlgDynamics (SA := SA)) : Prop :=
  ∀ t : ℝ, ∀ a : A, T (Dplus.α t a) = Dminus.α t (T a)

end Basic

end AQFT
end PillarB
