import Mathlib.Analysis.InnerProductSpace.Basic
import REALOQS.PillarA.Core.ToC.AQFTSubstrate
import REALOQS.PillarB.AQFT.CStarNorm
import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT

universe u v

structure GNSDatum {A : Type u} (SA : StarAlgebra A) (ω : StateOn A) where
  H : Type v
  instNormedAddCommGroup : NormedAddCommGroup H
  instNormedSpace : NormedSpace ℂ H
  sesq : H → H → ℂ
  pi : A → H →L[ℂ] H
  pi_add : ∀ a b ξ, pi (SA.add a b) ξ = pi a ξ + pi b ξ
  pi_mul : ∀ a b ξ, pi (SA.mul a b) ξ = pi a (pi b ξ)
  pi_one : ∀ ξ, pi SA.one ξ = ξ
  cyclicVec : H
  cyclic : ∀ ξ : H, ∃ a : A, pi a cyclicVec = ξ
  state_from_cyclic : ∀ a : A, ω a = sesq cyclicVec (pi a cyclicVec)

attribute [instance] GNSDatum.instNormedAddCommGroup GNSDatum.instNormedSpace

abbrev GNS {A : Type u} (S : PillarA.ToC.AQFTSubstrate A) (ω : S.StateOn) : Type (u + 1) :=
  S.GNSData ω

end AQFT
end PillarB
