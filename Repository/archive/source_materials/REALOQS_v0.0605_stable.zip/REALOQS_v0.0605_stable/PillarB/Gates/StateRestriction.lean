import REALOQS.PillarB.AQFT.State

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v w

section

variable {A : Type u} {B : Type v} {C : Type w}
variable {SA : StarAlgebra A} {SB : StarAlgebra B} {SC : StarAlgebra C}

theorem restrict_id (ψ : StateOn A) :
    StateOn.restrict (SA := SA) (SB := SA) (StarAlgHom.id SA) ψ = ψ :=
by

  simpa using (StateOn.restrict_id (SA := SA) (ψ := ψ))

theorem restrict_comp (g : StarAlgHom SB SC) (f : StarAlgHom SA SB) (ψ : StateOn C) :
    StateOn.restrict (SA := SA) (SB := SC) (StarAlgHom.comp g f) ψ =
      StateOn.restrict (SA := SA) (SB := SB) f
        (StateOn.restrict (SA := SB) (SB := SC) g ψ) :=
  StateOn.restrict_comp (SA := SA) (SB := SB) (SC := SC) g f ψ

theorem restrict_preserves_normalized (f : StarAlgHom SA SB) {ψ : StateOn B} :
    IsNormalized SB ψ → IsNormalized SA (StateOn.restrict (SA := SA) (SB := SB) f ψ) :=
  StateOn.restrict_preserves_normalized (SA := SA) (SB := SB) f

theorem restrict_preserves_positive (f : StarAlgHom SA SB) {ψ : StateOn B} :
    IsPositive SB ψ → IsPositive SA (StateOn.restrict (SA := SA) (SB := SB) f ψ) :=
  StateOn.restrict_preserves_positive (SA := SA) (SB := SB) f

end

end Gates
end AQFT
end PillarB
