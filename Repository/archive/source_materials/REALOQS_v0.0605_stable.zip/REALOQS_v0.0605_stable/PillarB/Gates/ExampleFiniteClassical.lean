import REALOQS.PillarB.Examples.FiniteClassical

set_option autoImplicit false

namespace PillarB
namespace Gates

open PillarB.Examples
open PillarB.Examples.FiniteClassical

namespace FiniteClassicalGate

open PillarA

theorem gate_LAN_incl_id (n : Nat)
    (r : (localAlgebraNet n).RN.Region)
    (x : (localAlgebraNet n).Alg r) :
    (localAlgebraNet n).incl (a := r) (b := r) (le_rfl) x = x := by
  simpa using (localAlgebraNet n).incl_id r x

theorem gate_LAN_incl_comp (n : Nat)
    {a b c : (localAlgebraNet n).RN.Region}
    (hab : a ≤ b) (hbc : b ≤ c)
    (x : (localAlgebraNet n).Alg a) :
    (localAlgebraNet n).incl (a := b) (b := c) hbc
        ((localAlgebraNet n).incl (a := a) (b := b) hab x)
      =
    (localAlgebraNet n).incl (a := a) (b := c) (le_trans hab hbc) x := by
  simpa using (localAlgebraNet n).incl_comp hab hbc x

theorem gate_SN_restrict_id (n : Nat)
    (r : (stateNet n).RN.Region)
    (ρ : (stateNet n).State r) :
    (stateNet n).restrict (a := r) (b := r) (le_rfl) ρ = ρ := by
  simpa using (stateNet n).restrict_id r ρ

theorem gate_SN_restrict_comp (n : Nat)
    {a b c : (stateNet n).RN.Region}
    (hab : a ≤ b) (hbc : b ≤ c)
    (ρ : (stateNet n).State c) :
    (stateNet n).restrict (a := a) (b := b) hab
        ((stateNet n).restrict (a := b) (b := c) hbc ρ)
      =
    (stateNet n).restrict (a := a) (b := c) (le_trans hab hbc) ρ := by
  simpa using (stateNet n).restrict_comp hab hbc ρ

theorem gate_globalCone_compat (n : Nat) (i : Fin n)
    {a b : (stateNet n).RN.Region} (hab : a ≤ b) :
    (stateNet n).restrict hab ((globalCone n i).ω b) = (globalCone n i).ω a := by
  simpa using
    (PillarA.LayerA.GlobalStateCone.gate_cone_compat
      (SN := stateNet n)
      (C := globalCone n i)
      hab)

end FiniteClassicalGate

end Gates
end PillarB
