import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

variable (D : Region.CausalDisjoint (RN := N.LAN.RN))

private def inclLeft {a b : N.LAN.RN.Region} : N.LAN.Alg a → N.LAN.Alg (a ⊔ b) :=
  N.LAN.incl (show a ≤ a ⊔ b from le_sup_left)

private def inclRight {a b : N.LAN.RN.Region} : N.LAN.Alg b → N.LAN.Alg (a ⊔ b) :=
  N.LAN.incl (show b ≤ a ⊔ b from le_sup_right)

def Locality : Prop :=
  ∀ {a b : N.LAN.RN.Region},
    D.disj a b →
      ∀ (x : N.LAN.Alg a) (y : N.LAN.Alg b),
        Commute (SA := N.SA (a ⊔ b)) (inclLeft (N := N) (a := a) (b := b) x)
          (inclRight (N := N) (a := a) (b := b) y)

theorem gate_locality_commute (hLoc : Locality (N := N) (D := D))
    {a b : N.LAN.RN.Region} (hab : D.disj a b)
    (x : N.LAN.Alg a) (y : N.LAN.Alg b) :
    Commute (SA := N.SA (a ⊔ b)) (inclLeft (N := N) (a := a) (b := b) x)
      (inclRight (N := N) (a := a) (b := b) y) :=
  hLoc hab x y

end HaagKastler

end Gates
end AQFT
end PillarB
