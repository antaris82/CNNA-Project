import REALOQS.PillarA.Core.BInterfaces.CovariantNets
import REALOQS.PillarB.AQFT.GlobalCone
import REALOQS.PillarB.AQFT.State
import REALOQS.PillarB.AQFT.StateNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u v

variable {Ω : Type u}

namespace HaagKastler

abbrev SN (N : LocalStarAlgebraNet Ω) : PillarA.LayerA.StateNet Ω := N.toStateNet

abbrev GlobalState (N : LocalStarAlgebraNet Ω) :=
  PillarA.LayerA.GlobalStateCone (SN := SN N)

def IsPhysical {N : LocalStarAlgebraNet Ω} (ω : GlobalState N) : Prop :=
  ∀ r : N.LAN.RN.Region,
    IsPositive (A := N.LAN.Alg r) (N.SA r) (ω.ω r) ∧
      IsNormalized (A := N.LAN.Alg r) (N.SA r) (ω.ω r)

section

variable {G : Type v} [Group G]

structure CovariantStateAction (N : LocalStarAlgebraNet Ω) where
  RA : PillarA.LayerA.CovariantNets.RegionAction (RN := (SN N).RN) (G := G)
  actState : ∀ g : G, ∀ r : (SN N).RN.Region,
    (SN N).State r → (SN N).State (RA.act g r)
  naturality :
    ∀ (g : G) {a b : (SN N).RN.Region} (hab : a ≤ b)
      (ψ : (SN N).State b),
      actState g a ((SN N).restrict hab ψ) =
        (SN N).restrict
          (RA.act_le (RN := (SN N).RN) (G := G) g hab)
          (actState g b ψ)

def IsInvariant {N : LocalStarAlgebraNet Ω}
    (C : CovariantStateAction (G := G) N)
    (ω : GlobalState N) : Prop :=
  ∀ (g : G) (r : (SN N).RN.Region),
    C.actState g r (ω.ω r) = ω.ω (C.RA.act g r)

def IsUniqueInvariant {N : LocalStarAlgebraNet Ω}
    (C : CovariantStateAction (G := G) N)
    (ω₀ : GlobalState N) : Prop :=
  ∀ ω : GlobalState N,
    IsInvariant (G := G) (C := C) ω → ω = ω₀

end

end HaagKastler

end Gates
end AQFT
end PillarB
