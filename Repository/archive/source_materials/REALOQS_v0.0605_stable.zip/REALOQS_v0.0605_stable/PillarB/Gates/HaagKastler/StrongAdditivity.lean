import REALOQS.PillarB.Gates.HaagKastler.Additivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

namespace HaagKastler

universe u v

def StrongAdditivity {Ω : Type u} (N : LocalStarAlgebraNet (Ω := Ω)) : Prop :=
  ∀ (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region)
    (h : ∀ u, u ∈ U → u ≤ r)
    (S : PillarB.AQFT.HaagKastler.StarSubalgebra (N.SA r)),
      (∀ u (hu : u ∈ U) (x : N.LAN.Alg u), N.LAN.incl (h u hu) x ∈ S.carrier) →
      S.carrier = Set.univ

end HaagKastler

end Gates
end AQFT
end PillarB
