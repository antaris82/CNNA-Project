import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

variable {Ω : Type u}

namespace HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

def Isotony : Prop :=
  ∀ {a b : N.LAN.RN.Region} (hab : a ≤ b), Function.Injective (N.LAN.incl hab)

theorem gate_isotony_incl_injective (hIso : Isotony (N := N))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    Function.Injective (N.LAN.incl hab) :=
  hIso hab

theorem gate_isotony_inclHom_injective (hIso : Isotony (N := N))
    {a b : N.LAN.RN.Region} (hab : a ≤ b) :
    Function.Injective (N.inclHom hab) :=
  hIso hab

end HaagKastler

end Gates
end AQFT
end PillarB
