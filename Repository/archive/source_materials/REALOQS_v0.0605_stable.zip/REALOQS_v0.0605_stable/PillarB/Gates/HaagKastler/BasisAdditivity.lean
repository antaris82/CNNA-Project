import REALOQS.PillarB.Gates.HaagKastler.Additivity

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable {Ω : Type u}

structure RegionBasis (N : LocalStarAlgebraNet (Ω := Ω)) where
  basic : Set N.LAN.RN.Region

section BasisGeneratedSets

variable (N : LocalStarAlgebraNet (Ω := Ω))
variable (B : RegionBasis (N := N))

def basisGenSet (r : N.LAN.RN.Region) : Set (N.LAN.Alg r) :=
  { y |
      ∃ (u : N.LAN.RN.Region), B.basic u ∧
        ∃ (h : u ≤ r), ∃ x : N.LAN.Alg u, N.LAN.incl h x = y }

def finiteBasisGenSet (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region) :
    Set (N.LAN.Alg r) :=
  { y |
      ∃ (u : N.LAN.RN.Region), u ∈ U ∧ B.basic u ∧
        ∃ (h : u ≤ r), ∃ x : N.LAN.Alg u, N.LAN.incl h x = y }

def BasisCover (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region) : Prop :=
  ∀ ⦃ω : Ω⦄, ω ∈ N.LAN.RN.carrier r →
    ∃ u : N.LAN.RN.Region, u ∈ U ∧ ω ∈ N.LAN.RN.carrier u

end BasisGeneratedSets

section BasisAdditivityDefs

variable (N : LocalStarAlgebraNet (Ω := Ω))
variable (B : RegionBasis (N := N))

def AdditivityOnBasis : Prop :=
  ∀ r : N.LAN.RN.Region,
    IsGeneratedBy (SA := N.SA r) (basisGenSet (N := N) B r)

def StrongAdditivityOnBasis : Prop :=
  ∀ (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region),
    BasisCover (N := N) U r →
    (∀ u, u ∈ U → B.basic u) →
    IsGeneratedBy (SA := N.SA r) (finiteBasisGenSet (N := N) B U r)

theorem mem_basisGenSet_of_basic
    {u r : N.LAN.RN.Region} (hu : B.basic u) (h : u ≤ r) (x : N.LAN.Alg u) :
    N.LAN.incl h x ∈ basisGenSet (N := N) B r := by
  refine ⟨u, hu, h, x, rfl⟩

theorem mem_finiteBasisGenSet_of_basic
    {U : Finset N.LAN.RN.Region} {u r : N.LAN.RN.Region}
    (huU : u ∈ U) (hu : B.basic u) (h : u ≤ r) (x : N.LAN.Alg u) :
    N.LAN.incl h x ∈ finiteBasisGenSet (N := N) B U r := by
  refine ⟨u, huU, hu, h, x, rfl⟩

theorem finiteBasisGenSet_subset_basisGenSet
    (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region) :
    finiteBasisGenSet (N := N) B U r ⊆ basisGenSet (N := N) B r := by
  intro y hy
  rcases hy with ⟨u, _huU, hu, h, x, rfl⟩
  exact mem_basisGenSet_of_basic (N := N) (B := B) hu h x

@[simp] theorem gate_additivityOnBasis_generated
    (hAdd : AdditivityOnBasis (N := N) B)
    (r : N.LAN.RN.Region) (x : N.LAN.Alg r) :
    GeneratedBy (SA := N.SA r) (basisGenSet (N := N) B r) x :=
  hAdd r x

@[simp] theorem gate_strongAdditivityOnBasis_generated
    (hAdd : StrongAdditivityOnBasis (N := N) B)
    (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region)
    (hCover : BasisCover (N := N) U r)
    (hBasic : ∀ u, u ∈ U → B.basic u)
    (x : N.LAN.Alg r) :
    GeneratedBy (SA := N.SA r) (finiteBasisGenSet (N := N) B U r) x :=
  hAdd U r hCover hBasic x

theorem gate_strongAdditivityOnBasis_generated_in_basis
    (hAdd : StrongAdditivityOnBasis (N := N) B)
    (U : Finset N.LAN.RN.Region) (r : N.LAN.RN.Region)
    (hCover : BasisCover (N := N) U r)
    (hBasic : ∀ u, u ∈ U → B.basic u)
    (x : N.LAN.Alg r) :
    GeneratedBy (SA := N.SA r) (basisGenSet (N := N) B r) x := by
  exact GeneratedBy.mono (SA := N.SA r)
    (finiteBasisGenSet_subset_basisGenSet (N := N) (B := B) U r)
    (gate_strongAdditivityOnBasis_generated
      (N := N) (B := B) hAdd U r hCover hBasic x)

end BasisAdditivityDefs

end HaagKastler

end Gates
end AQFT
end PillarB
