import REALOQS.PillarB.AQFT.HaagKastler.Support
import REALOQS.PillarB.AQFT.LocalNet

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

variable {Ω : Type u}

namespace HaagKastler

open PillarB.AQFT.HaagKastler

variable (N : LocalStarAlgebraNet (Ω := Ω))

structure CausalCompletion where
  cl : N.LAN.RN.Region → N.LAN.RN.Region
  extensive : ∀ r, r ≤ cl r
  monotone : ∀ {a b}, a ≤ b → cl a ≤ cl b
  idempotent : ∀ r, cl (cl r) = cl r

namespace CausalCompletion

variable {N}

theorem le_cl (CC : CausalCompletion (N := N)) (r : N.LAN.RN.Region) : r ≤ CC.cl r :=
  CC.extensive r

end CausalCompletion

def TimeSlice (CC : CausalCompletion (N := N)) (isTimeSlice : N.LAN.RN.Region → Prop) : Prop :=
  ∀ r : N.LAN.RN.Region,
    isTimeSlice r →
      ∃ e : StarAlgIso (SA := N.SA r) (SB := N.SA (CC.cl r)),
        e.hom = N.inclHom (CC.extensive r)

theorem gate_timeSlice_iso
    {CC : CausalCompletion (N := N)} {isTimeSlice : N.LAN.RN.Region → Prop}
    (hTS : TimeSlice (N := N) CC isTimeSlice)
    (r : N.LAN.RN.Region) (hr : isTimeSlice r) :
    ∃ e : StarAlgIso (SA := N.SA r) (SB := N.SA (CC.cl r)),
      e.hom = N.inclHom (CC.extensive r) :=
  hTS r hr

end HaagKastler

end Gates
end AQFT
end PillarB
