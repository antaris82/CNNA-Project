import REALOQS.PillarB.AQFT.QuasiLocal.StateLift

set_option autoImplicit false

namespace PillarB
namespace AQFT
namespace Gates

universe u

variable {Ω : Type u}

theorem quasilocal_stateLift_restrict
    (N : LocalStarAlgebraNet (Ω := Ω))
    (C : PillarA.LayerA.GlobalStateCone (SN := QuasiLocal.SN N))
    (r : N.LAN.RN.Region) :
    QuasiLocal.restrictToRegion N (QuasiLocal.stateLift N C) r = C.ω r := by
  simpa using (QuasiLocal.gate_restrictToRegion_stateLift (N := N) C r)

end Gates
end AQFT
end PillarB
