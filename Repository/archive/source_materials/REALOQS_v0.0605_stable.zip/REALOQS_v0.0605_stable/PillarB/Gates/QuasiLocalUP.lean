import REALOQS.PillarB.AQFT.QuasiLocal.Structure

set_option autoImplicit false

namespace PillarB
namespace Gates

universe u w

variable {Ω : Type u}

open PillarB.AQFT

theorem gate_quasilocal_existsUnique_extension
    (N : AQFT.LocalStarAlgebraNet (Ω := Ω))
    {B : Type w}
    (f : ∀ r : N.LAN.RN.Region, N.LAN.Alg r → B)
    (hf : AQFT.QuasiLocal.Compatible (Ω := Ω) N f) :
    ∃! g : AQFT.QuasiLocal.Carrier (Ω := Ω) N → B,
      AQFT.QuasiLocal.Extends (Ω := Ω) N g f := by
  simpa using
    (AQFT.QuasiLocal.existsUnique_extension (Ω := Ω) N f hf)

end Gates
end PillarB
