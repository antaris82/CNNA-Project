import Mathlib
import REALOQS.PillarA.Core.MatrixNorms
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
import REALOQS.PillarC.OQS.Finite.RectKraus
import REALOQS.PillarC.OQS.Lindblad
import REALOQS.PillarC.OQS.NonMarkov
import REALOQS.PillarC.OQS.Semigroup
import REALOQS.PillarC.OQS.Stinespring

set_option linter.style.longLine false
set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_OQS_CompilerFromA

noncomputable section

namespace ToC

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
open _root_.PillarA.LayerA
open _root_.PillarC.OQS
open _root_.PillarC.OQS.Finite.RectKraus

variable {b : Nat}

abbrev MatΩ (p : Policy b) := Mat (Ω (b := b) p)

noncomputable def lbbGate
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) : Prop :=
  1 ≤ _root_.PillarA.LayerA.MatrixNorm.frob st1.LBB

noncomputable def scalarPhase
    (p : Policy b)
    (st1 :
      _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    Complex := by
  classical
  exact if lbbGate (b := b) p st1 then (-1 : Complex) else 1

@[simp] theorem scalarPhase_mul_star
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    star (scalarPhase (b := b) p st1) * scalarPhase (b := b) p st1 = 1 := by
  classical
  by_cases h : lbbGate (b := b) p st1
  · simp [scalarPhase, h]
  · simp [scalarPhase, h]

noncomputable def compiledUnitary
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    RectMat (Ω (b := b) p) (Ω (b := b) p) :=
  scalarPhase (b := b) p st1 • (1 : MatΩ (b := b) p)

@[simp] theorem compiledUnitary_apply_diag
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p)
    (i : Ω (b := b) p) :
    compiledUnitary (b := b) p st1 i i = scalarPhase (b := b) p st1 := by
  simp [compiledUnitary]

@[simp] theorem compiledUnitary_apply_offdiag
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p)
    {i j : Ω (b := b) p} (h : i ≠ j) :
    compiledUnitary (b := b) p st1 i j = 0 := by
  simp [compiledUnitary, h]

theorem compiledUnitary_unitary
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    Matrix.conjTranspose (compiledUnitary (b := b) p st1) *
        compiledUnitary (b := b) p st1 =
      (1 : MatΩ (b := b) p) := by
  classical
  let s : Complex := scalarPhase (b := b) p st1
  calc
    Matrix.conjTranspose (compiledUnitary (b := b) p st1) *
        compiledUnitary (b := b) p st1
        = (star s • (1 : MatΩ (b := b) p)) * (s • (1 : MatΩ (b := b) p)) := by
            simp [compiledUnitary, s, Matrix.conjTranspose_smul]
    _ = star s • (s • ((1 : MatΩ (b := b) p) * (1 : MatΩ (b := b) p))) := by
          rw [smul_mul_assoc, mul_smul_comm]
    _ = (star s * s : Complex) • (1 : MatΩ (b := b) p) := by
          simp [smul_smul]
    _ = (1 : Complex) • (1 : MatΩ (b := b) p) := by
          have hs : star s * s = (1 : Complex) := by
            simpa [s] using scalarPhase_mul_star (b := b) p st1
          rw [hs]
    _ = (1 : MatΩ (b := b) p) := by
          simp

def compileKraus
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    RectKrausOps (Ω (b := b) p) (Ω (b := b) p) 1 :=
  fun _ => compiledUnitary (b := b) p st1

def compileChannel
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    CPTPChannel (MatΩ (b := b) p) (MatΩ (b := b) p) :=
  CPTPChannel.ofChannel
    ⟨rectKrausMap (α := Ω (b := b) p) (β := Ω (b := b) p) 1
      (compileKraus (b := b) p st1)⟩
    (IsRectKrausCP (α := Ω (b := b) p) (β := Ω (b := b) p) 1
      (rectKrausMap (α := Ω (b := b) p) (β := Ω (b := b) p) 1
        (compileKraus (b := b) p st1)))
    (Matrix.conjTranspose (compiledUnitary (b := b) p st1) *
      compiledUnitary (b := b) p st1 = (1 : MatΩ (b := b) p))

theorem compileChannel_isCP
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    (compileChannel (b := b) p st1).isCP := by
  exact ⟨compileKraus (b := b) p st1, rfl⟩

theorem compileChannel_isTP
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    (compileChannel (b := b) p st1).isTP := by
  simpa [compileChannel] using compiledUnitary_unitary (b := b) p st1

def compileChannel_stinespring
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    StinespringDilation (compileChannel (b := b) p st1) := by
  let Φ := compileChannel (b := b) p st1
  exact
    { E := Unit
      V := fun ρ => (Φ.map ρ, ())
      discard := fun be => be.1
      dilationEq := True }

theorem compileChannel_hasStinespring
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    HasStinespring (compileChannel (b := b) p st1) := by
  exact ⟨compileChannel_stinespring (b := b) p st1⟩

def iterateChannel
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    Nat → CPTPChannel (MatΩ (b := b) p) (MatΩ (b := b) p)
  | 0 => CPTPChannel.id _ True True
  | n + 1 => CPTPChannel.comp (iterateChannel p st1 n) (compileChannel (b := b) p st1)

def derivedSemigroup
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    MarkovSemigroup (MatΩ (b := b) p) where
  Φ := iterateChannel (b := b) p st1
  map_zero := by
    intro x
    rfl
  map_add := by
    intro t s x
    induction t generalizing x with
    | zero =>
        simp [iterateChannel]
    | succ t ih =>
        simp [iterateChannel, Nat.succ_add, ih, CPTPChannel.map_comp]

def derivedGenerator
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    LindbladGenerator (MatΩ (b := b) p) where
  L := (compileChannel (b := b) p st1).toChannel.map
  isGKSL := (compileChannel (b := b) p st1).isCP ∧ (compileChannel (b := b) p st1).isTP

theorem derivedGenerator_generates
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    (derivedGenerator (b := b) p st1).Generates (derivedSemigroup (b := b) p st1) := by
  intro t x
  simp [derivedGenerator, derivedSemigroup, iterateChannel, CPTPChannel.map_comp]

def derivedProcess
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    NonMarkovProcess (MatΩ (b := b) p) where
  step := (derivedSemigroup (b := b) p st1).Φ
  memoryLaw := ∃ G : LindbladGenerator (MatΩ (b := b) p),
    G.Generates (derivedSemigroup (b := b) p st1)

theorem derivedProcess_memoryLaw
    (p : Policy b)
    (st1 : _root_.PillarA.Ideal.Adapter.TreeOfCliquesApproxDtNStabilized.ReducedOpState p) :
    (derivedProcess (b := b) p st1).memoryLaw := by
  exact ⟨derivedGenerator (b := b) p st1, derivedGenerator_generates (b := b) p st1⟩

end ToC

end
end TreeOfCliques_OQS_CompilerFromA
end Examples
end REALOQS
