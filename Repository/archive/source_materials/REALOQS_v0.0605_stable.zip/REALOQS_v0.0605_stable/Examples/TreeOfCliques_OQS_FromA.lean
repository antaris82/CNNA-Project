import REALOQS.Examples.TreeOfCliques_OQS_CompilerFromA
import REALOQS.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff

set_option autoImplicit false

namespace REALOQS
namespace Examples
namespace TreeOfCliques_OQS_FromA

noncomputable section

namespace ToC

open _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff
open REALOQS.Examples.TreeOfCliques_OQS_CompilerFromA.ToC

variable {b : Nat}

abbrev st1AB (p : _root_.PillarA.LayerA.Policy b) :=
  _root_.PillarA.Ideal.Adapter.TreeOfCliquesAQFTHandoff.st1 (b := b) p

def Φ_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  compileChannel (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_isCP
    (p : _root_.PillarA.LayerA.Policy b) :
    (Φ_oqs_fromA (b := b) p).isCP := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_isCP (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_isTP
    (p : _root_.PillarA.LayerA.Policy b) :
    (Φ_oqs_fromA (b := b) p).isTP := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_isTP (b := b) p (st1AB (b := b) p)

theorem Φ_oqs_fromA_hasStinespring
    (p : _root_.PillarA.LayerA.Policy b) :
    _root_.PillarC.OQS.HasStinespring (Φ_oqs_fromA (b := b) p) := by
  simpa [Φ_oqs_fromA, st1AB] using
    compileChannel_hasStinespring (b := b) p (st1AB (b := b) p)

def S_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedSemigroup (b := b) p (st1AB (b := b) p)

def G_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedGenerator (b := b) p (st1AB (b := b) p)

def P_oqs_fromA
    (p : _root_.PillarA.LayerA.Policy b) :=
  derivedProcess (b := b) p (st1AB (b := b) p)

theorem G_oqs_fromA_generates
    (p : _root_.PillarA.LayerA.Policy b) :
    (G_oqs_fromA (b := b) p).Generates (S_oqs_fromA (b := b) p) := by
  simpa [G_oqs_fromA, S_oqs_fromA, st1AB] using
    derivedGenerator_generates (b := b) p (st1AB (b := b) p)

theorem P_oqs_fromA_memoryLaw
    (p : _root_.PillarA.LayerA.Policy b) :
    (P_oqs_fromA (b := b) p).memoryLaw := by
  simpa [P_oqs_fromA, st1AB] using
    derivedProcess_memoryLaw (b := b) p (st1AB (b := b) p)

end ToC

end
end TreeOfCliques_OQS_FromA
end Examples
end REALOQS
