# Import Policy (Phase 8)

Goal: keep **Pillar A / Core** and **Pillar A / Update** substrate-agnostic.

## Hard rules

1. No `REALOQS.PillarA.Core.*` file may import `REALOQS.PillarA.Ideal.*`.
2. No `REALOQS.PillarA.Update.*` file may import `REALOQS.PillarA.Ideal.*`.
3. Outside of `REALOQS.PillarA.Ideal.*`, any IDEAL-specific imports must go via
   `REALOQS.PillarA.Ideal.Adapter.*` re-export wrappers.

The IDEAL adapter directory is the *only* intended exposure surface of the
IDEAL substrate to non-IDEAL modules.

## Local check

Run the policy checker from a repository root that contains the `REALOQS/`
folder:

```bash
python3 REALOQS/tools/check_import_policy.py
```

It exits non-zero on violations.

## Pillar B

Additional rules (enforced by `tools/check_import_policy.py`):
- `REALOQS.PillarB.*` must not import `REALOQS.PillarA.Ideal.*`.
- `REALOQS.PillarB.Interface` is restricted to importing `REALOQS.PillarA.Core.Exports` (and optionally `Mathlib.*`).
- `REALOQS.PillarB.*` must not import `REALOQS.PillarA.All`.
