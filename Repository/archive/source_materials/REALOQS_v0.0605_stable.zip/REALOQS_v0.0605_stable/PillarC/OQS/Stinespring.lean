import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS

universe u v

structure StinespringDilation {A : Type u} {B : Type v} (Φ : CPTPChannel A B) where

  E : Type u

  V : A → (B × E)

  discard : (B × E) → B

  dilationEq : Prop

def HasStinespring {A : Type u} {B : Type v} (Φ : CPTPChannel A B) : Prop :=
  Nonempty (StinespringDilation Φ)

namespace HasStinespring

variable {A : Type u} {B : Type v} {Φ : CPTPChannel A B}

noncomputable def witness (h : HasStinespring Φ) : StinespringDilation Φ :=
  Classical.choice h

end HasStinespring

end OQS
end PillarC
