import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace OQS

universe u

structure NonMarkovProcess (A : Type u) where
  step : Nat → CPTPChannel A A

  memoryLaw : Prop

end OQS
end PillarC
