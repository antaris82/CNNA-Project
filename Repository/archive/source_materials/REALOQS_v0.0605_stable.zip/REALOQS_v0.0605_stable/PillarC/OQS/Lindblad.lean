import REALOQS.PillarC.OQS.Semigroup

set_option autoImplicit false

namespace PillarC
namespace OQS

universe u

structure LindbladGenerator (A : Type u) where
  L : A → A

  isGKSL : Prop

namespace LindbladGenerator

variable {A : Type u} (G : LindbladGenerator (A := A))

def Generates (S : MarkovSemigroup (A := A)) : Prop :=
  ∀ (t : Nat) (x : A), (S.Φ (t + 1)).toChannel.map x = G.L ((S.Φ t).toChannel.map x)

end LindbladGenerator

end OQS
end PillarC
