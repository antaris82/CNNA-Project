import Mathlib
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace Integration

open PillarA.LayerA

universe u v w

structure NetChannel {Ω : Type u} (LAN : LocalAlgebraNet (Ω := Ω)) where
  map : ∀ r : LAN.RN.Region, LAN.Alg r → LAN.Alg r
  respects_incl : ∀ {a b : LAN.RN.Region} (hab : a ≤ b) (x : LAN.Alg a),
      LAN.incl hab (map a x) = map b (LAN.incl hab x)

namespace NetChannel

variable {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)}

instance : CoeFun (NetChannel LAN) (fun _ => ∀ r : LAN.RN.Region, LAN.Alg r → LAN.Alg r) where
  coe Φ := Φ.map

@[simp] theorem gate_respects_incl (Φ : NetChannel LAN)
    {a b : LAN.RN.Region} (hab : a ≤ b) (x : LAN.Alg a) :
    LAN.incl hab (Φ.map a x) = Φ.map b (LAN.incl hab x) :=
  Φ.respects_incl hab x

end NetChannel

structure ChannelInfluence {Ω : Type u} (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) where

  inf0 : Ω → Ω → Prop

namespace ChannelInfluence
variable {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)} {Φ : NetChannel LAN}

def inf (I : ChannelInfluence LAN Φ) (x y : Ω) : Prop := x = y ∨ I.inf0 x y

@[simp] theorem sound (I : ChannelInfluence LAN Φ) (x : Ω) : I.inf x x := Or.inl rfl

def diagonal (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) : ChannelInfluence LAN Φ :=
  { inf0 := fun _ _ => False }

def Nondegenerate (I : ChannelInfluence LAN Φ) : Prop :=
    ∃ x y : Ω, x ≠ y ∧ I.inf0 x y

theorem diagonal_degenerate (LAN : LocalAlgebraNet (Ω := Ω)) (Φ : NetChannel LAN) :
      ¬ Nondegenerate (LAN := LAN) (Φ := Φ)
          (ChannelInfluence.diagonal (LAN := LAN) (Φ := Φ)) := by
    intro h
    rcases h with ⟨x, y, hxy, hinf⟩
    cases hinf

end ChannelInfluence

end Integration
end PillarC
