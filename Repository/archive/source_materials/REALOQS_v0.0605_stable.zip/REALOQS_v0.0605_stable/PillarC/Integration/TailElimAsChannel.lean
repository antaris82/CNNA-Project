import Mathlib
import REALOQS.PillarA.Update.TailEliminationDtN
import REALOQS.PillarC.OQS.Channel

set_option autoImplicit false

namespace PillarC
namespace Integration

open PillarC.OQS
open PillarA.Update

universe u

def stage1Channel {b : Nat} (A : TwoStageApprox b) : Channel A.S A.S :=
  ⟨A.stage1⟩

def stage1CPTP {b : Nat} (A : TwoStageApprox b) (cp tp : Prop) : CPTPChannel A.S A.S :=
  CPTPChannel.ofChannel (stage1Channel (A := A)) cp tp

theorem gate_stage1_is_DtN
    {b : Nat} {A : TwoStageApprox b}
    (Sem : TailElimDtNSemantics A) (s : A.S) :
    (Sem.opObserver.op (A.stage1 s)) =
      linOpOfMatrix (α := Sem.split.B) (Sem.split.DtN_of (Sem.L s) (Sem.inv s)) := by
  simpa using
    (PillarA.Update.TailElimDtNSemantics.gate_STAGE1_IS_DTN (Sem := Sem) (s := s))

end Integration
end PillarC
