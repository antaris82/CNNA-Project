import Mathlib
import REALOQS.PillarA.Core.BInterfaces.LocalAlgebraNet
import REALOQS.PillarA.Kinematics.DiscreteSpacetime
import REALOQS.PillarC.Integration.Locality

set_option autoImplicit false

namespace PillarC
namespace Integration

open PillarA.Kinematics
open PillarA.LayerA

universe u

abbrev Event (Ω : Type u) : Type u := Nat × Ω

def spacetimeOfInfluence (Ω : Type u) (inf : Ω → Ω → Prop) :
    DiscreteSpacetime (Event Ω) where
  τ := Prod.fst
  step := fun e₁ e₂ => e₂.1 = e₁.1 + 1 ∧ inf e₁.2 e₂.2
  step_tau := by
    intro x y h
    simpa using h.1

def spacetimeOfChannel
    {Ω : Type u} {LAN : LocalAlgebraNet (Ω := Ω)}
    {Φ : NetChannel LAN} (I : ChannelInfluence LAN Φ)
    (_nd : ChannelInfluence.Nondegenerate (LAN := LAN) (Φ := Φ) I) :
    DiscreteSpacetime (Event Ω) :=
  spacetimeOfInfluence Ω I.inf
end Integration
end PillarC
