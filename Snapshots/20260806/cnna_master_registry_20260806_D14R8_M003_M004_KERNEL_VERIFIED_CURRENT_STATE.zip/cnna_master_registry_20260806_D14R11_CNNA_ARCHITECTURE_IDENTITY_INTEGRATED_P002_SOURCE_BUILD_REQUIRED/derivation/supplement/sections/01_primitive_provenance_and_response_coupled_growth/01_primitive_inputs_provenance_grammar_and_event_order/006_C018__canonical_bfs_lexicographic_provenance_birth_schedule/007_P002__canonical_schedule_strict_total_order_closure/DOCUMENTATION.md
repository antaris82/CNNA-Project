# 007 · P002 — Canonical schedule strict-total-order closure

**Canonical node label:** `007 · P002`  
**Semantic ID:** `P002`  
**Current section path:** `1.1.6.1`  
**Documentation tier:** `D2`  
**Documentation state:** `COMPLETE_V2`  
**Proof state:** `SOURCE_COMPLETE_KERNEL_BUILD_REQUIRED`

## Position In Derivation

P002 is the proof-certification child of `006 · C018`. Its hard mathematical input is the C003 provenance-address grammar, while its Lean proof module imports the C018 owner module in the permitted proof-to-core direction. The DAG certification edge points from P002 to C018; the Lean import points from `CNNAProofsP002` to `CNNA`.

P002 has one static responsibility:

> Prove that the C018 breadth-first/lexicographic relation is a strict total order on provenance addresses and induces a strict total order on open-slot selected children modulo extensional equality of the selected child address.

The node does not own state-dependent least-open selection. C004 owns least-open existence and uniqueness after C005 introduces the born prefix and unsaturation predicate.

## Formal Statement

Let `BirthBefore` be the C018 order on provenance addresses. The public closure packages:

1. `¬ BirthBefore a a`;
2. `BirthBefore a b -> BirthBefore b c -> BirthBefore a c`;
3. asymmetry;
4. trichotomy `a < b ∨ a = b ∨ b < a`;
5. comparison of distinct addresses.

For C018 `OpenBirthSlot` records it packages irreflexivity, transitivity, and asymmetry of `OpenSlotBefore`, together with the extensional trichotomy

\[
 s <_{slot} t
 \;\lor\;
 \operatorname{child}(s)=\operatorname{child}(t)
 \;\lor\;
 t <_{slot} s.
\]

For a predicate `Q` on slot records,

\[
 \operatorname{IsMinimalSelectedChild}(Q,s)
 \iff Q(s)\land\forall t\,[Q(t)\Rightarrow\neg(t<_{slot}s)].
\]

The uniqueness theorem concludes equality of the selected child addresses of any two minimal witnesses.

## Hypotheses

The order closure quantifies only over:

- a C003 branching parameter and provenance addresses;
- a C018 canonical schedule;
- C018 open-slot records;
- an arbitrary predicate on those records for the minimality theorem.

No `ResponseCapableState`, born prefix, unsaturation proof, numerical response, or Python execution is a P002 hypothesis.

## Introduction Reason

C018 defines and proves the order primitives. P002 exposes their reusable proof contract without enlarging C018's core API and without importing later state layers. This gives downstream termination proofs one named certification boundary while preserving the package direction `CNNAProofsP002 -> CNNA`.

## Proof Strategy

1. Construct the address fields directly from C018 `birthBefore_*` theorems.
2. Construct the slot fields directly from C018 `openSlotBefore_*` theorems.
3. Derive extensional slot trichotomy by applying address trichotomy to the two selected child addresses.
4. For minimal-witness uniqueness, split on equality of selected children.
5. Under inequality, use C018 total comparison of distinct selected children.
6. Each comparison direction contradicts one of the two minimality hypotheses.
7. Export the closure through a stable proposition-valued public contract.

## Lemma Chain

```text
C018.BirthBefore
  -> birthBefore_irrefl
  -> birthBefore_trans
  -> birthBefore_asymm
  -> birthBefore_trichotomy
  -> birthBefore_total_of_ne

C018.OpenSlotBefore
  -> openSlotBefore_irrefl
  -> openSlotBefore_trans
  -> openSlotBefore_asymm
  -> openSlotBefore_total_of_distinct_children

P002
  -> CanonicalScheduleStrictTotalOrderClosure
  -> canonicalScheduleStrictTotalOrderClosure
  -> IsMinimalSelectedChild
  -> minimalSelectedChild_unique
  -> CanonicalScheduleStrictTotalOrderContract
  -> canonicalScheduleStrictTotalOrderContract
```

## Formal Realization

The proof source is:

`derivation/code/lean/proofs/src/CNNAProofs/Derivation/S01_PrimitiveResponseCoupledFiniteProvenance/S01_PrimitiveInputsGrammarAndEventOrder/S06_C018_CanonicalBfsLexicographicProvenanceBirthSchedule/Proofs/S01_P002_CanonicalScheduleStrictTotalOrderClosure.lean`

The independent root `proofs/src/CNNAProofsP002.lean` exports exactly this module. The separate library target prevents changes to the exact source sets already bound to the P001 and M003/M004 kernel evidence.

There is no P002 Python module. Static order closure is a theorem packaging task, not a second implementation of the C018 schedule.

## Counterexamples Or Necessity Checks

1. **Remove transitivity:** two locally comparable steps no longer justify an earlier-than conclusion across a chain.
2. **Remove total comparison:** two distinct minimal selected children may remain incomparable, so uniqueness does not follow.
3. **Demand record equality:** proof-bearing slot records may encode the same selected child without being definitionally identical; the correct result is extensional child equality.
4. **Add least-open state selection:** the statement would require C005/C004 and create a backward dependency at node 007.
5. **Add Python agreement:** this would conflate a static theorem facade with the later executable selector owned by C004.

## Axiom Profile

The P002 axiom audit enumerates all six public declarations with `#print axioms`. The source policy excludes project-local axioms and automation shortcuts. The exact transitive profile is not asserted until the local Lean 4.31.0 build runs; only `propext`, `Quot.sound`, and `Classical.choice` are permitted by the audit infrastructure.

## Result

The contract and all six public declarations are implemented. Static package-boundary checks can verify source presence, imports, declaration coverage, forbidden-token absence, and hash-scope separation. Kernel verification remains pending the local build.

## Remaining Limits

P002 does not prove:

- existence of an un-born address in an unsaturated C005 state;
- uniqueness of the C004 next-open address;
- equality with the Python positional selector;
- termination of the full finite birth process.

The first three are C004 responsibilities. Full finite schedule exhaustivity and termination belong to P004.

## Downstream Handoff

`E141: P002 -> C018` certifies the owner closure after the local build. `E151: P002 -> P004` supplies the static order interface used by finite schedule exhaustivity. The obsolete `P002 -> P003` edge is absent because P003 consumes C018/C004 directly.

## Code Line Register

Path: `derivation/code/lean/proofs/src/CNNAProofs/Derivation/S01_PrimitiveResponseCoupledFiniteProvenance/S01_PrimitiveInputsGrammarAndEventOrder/S06_C018_CanonicalBfsLexicographicProvenanceBirthSchedule/Proofs/S01_P002_CanonicalScheduleStrictTotalOrderClosure.lean`

- `CanonicalScheduleStrictTotalOrderClosure`, structure, lines 19–65.
- `canonicalScheduleStrictTotalOrderClosure`, theorem, lines 69–99.
- `IsMinimalSelectedChild`, definition, lines 104–109.
- `minimalSelectedChild_unique`, theorem, lines 115–131.
- `CanonicalScheduleStrictTotalOrderContract`, definition, lines 134–135.
- `canonicalScheduleStrictTotalOrderContract`, theorem, lines 138–140.
