# Open-provenance documentation visual inspection

- Main paper: `derivation/paper/main/paper.pdf` — 29 pages — SHA-256 `dd219a5f21266ec6509fde1271ac425fcbfe1c5c5e5e540a89bb1e4d5955e939`.
- Supplement: `derivation/supplement/supplementary.pdf` — 101 pages — SHA-256 `fa0a0ae49854277d624981fddf4cd756da490141940e39dd047c053848c1f869`.
- Main pages inspected: 1--3, including title, hypothesis/status guard, reduction distinctions, citations, and traceability transition.
- Supplement pages inspected: 1--3 and selected late P001/M003/M004/reference pages.
- Result: no clipped title, formula, table, or conceptual-status box was observed on the inspected pages.
- The generalized completion claim remains visibly marked as a research hypothesis; finite POVM, OQS, and AQFT are not promoted beyond their nodewise status.
