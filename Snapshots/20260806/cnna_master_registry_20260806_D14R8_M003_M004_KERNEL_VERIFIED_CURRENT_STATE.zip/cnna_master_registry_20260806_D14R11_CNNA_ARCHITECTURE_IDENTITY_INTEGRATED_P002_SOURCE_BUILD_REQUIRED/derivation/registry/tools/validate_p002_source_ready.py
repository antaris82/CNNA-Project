#!/usr/bin/env python3
from pathlib import Path
import csv,json,re,sys
ROOT=Path(__file__).resolve().parents[3]
DAG=ROOT/'derivation/registry/dag'
SRC=ROOT/'derivation/code/lean/proofs/src/CNNAProofs/Derivation/S01_PrimitiveResponseCoupledFiniteProvenance/S01_PrimitiveInputsGrammarAndEventOrder/S06_C018_CanonicalBfsLexicographicProvenanceBirthSchedule/Proofs/S01_P002_CanonicalScheduleStrictTotalOrderClosure.lean'
def rows(p):
 with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
errors=[]; text=SRC.read_text(encoding='utf-8') if SRC.is_file() else ''
required=['CanonicalScheduleStrictTotalOrderClosure','canonicalScheduleStrictTotalOrderClosure','IsMinimalSelectedChild','minimalSelectedChild_unique','CanonicalScheduleStrictTotalOrderContract','canonicalScheduleStrictTotalOrderContract']
for name in required:
 if not re.search(r'^(?:structure|def|theorem)\s+'+re.escape(name)+r'\b',text,re.M):errors.append('missing '+name)
for token in ['ResponseCapableState','Unsaturated','bornNonRoot','nextOpen','native_decide','noncomputable','Classical','simp','simpa']:
 if re.search(r'\b'+re.escape(token)+r'\b',text):errors.append('forbidden token '+token)
node=json.loads((ROOT/'derivation/registry/nodes/P002.json').read_text())
if 'least open slot' in node['contract']['statement'].lower():errors.append('dynamic contract leakage')
status=next(r for r in rows(DAG/'DAG_DISPLAY_STATUS.tsv') if r['id']=='P002')
if status['display_status']!='ACTIVE' or status['color']!='#F4A340':errors.append('P002 display status')
edges=rows(DAG/'EDGES.tsv')
if any(e['source']=='P002' and e['target']=='P003' for e in edges):errors.append('obsolete P002->P003 edge')
result={'schema':'cnna.p002-static-order-source-audit.v1','status':'PASS' if not errors else 'FAIL','public_declarations':len(required),'source_build_required':True,'dynamic_scope_owner':'C004','errors':errors}
(DAG/'P002_SOURCE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2));sys.exit(1 if errors else 0)
