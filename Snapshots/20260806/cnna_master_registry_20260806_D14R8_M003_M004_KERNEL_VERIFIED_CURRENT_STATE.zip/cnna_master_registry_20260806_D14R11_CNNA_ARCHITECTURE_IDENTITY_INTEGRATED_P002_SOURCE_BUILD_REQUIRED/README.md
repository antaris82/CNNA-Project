# CNNA (ComplemeNt Net Architecture)

## From Primitive Provenance to Mathematical Structure

**A Response-Coupled Derivation on a Growing $b$-ary Tree**

The name **ComplemeNt Net Architecture** identifies the project-wide construction principle. The same growing provenance net is repeatedly separated into a realized or retained part, a relative complement, and an interface through which effective response and the next growth step are determined. This architecture begins with the empty-carrier/root transition, becomes explicit in the born-prefix/open-slot distinction, and continues through Schur/DtN cuts, record/live dynamics, nested channels, and later OQS/AQFT specializations.

Framework context: **Generalized Open Provenance Systems**. The current package formalizes the finite deterministic CNNA specialization; universal completion and later OQS/POVM/AQFT specializations retain their explicit nodewise status.

This package contains the current CNNA registry, mathlib-free Core, proof sources, canonical yEd Live DAG, paper, supplement, reference registry, and validation artifacts.

P001 is kernel-verified under Lean 4.31.0 with mathlib v4.31.0: all 142 registered declarations passed the axiom audit and full package-boundary audit. M003 and M004 are kernel-verified through 11 public closure and handoff declarations with exact current-source evidence.

P002 has the corrected static contract. Its six public declarations package the C018 strict total order on provenance addresses, the extensional order on selected open-slot children, and minimal selected-child uniqueness. State-dependent least-open existence, uniqueness, saturation behavior, and executable-selector agreement remain owned by C004. P002 source and its dedicated audit are complete; the local Lean 4.31.0 build is the remaining gate.

The admitted transitive trust profile for verified proof nodes is limited to `propext`, `Classical.choice`, and `Quot.sound`. No project-local axiom or `sorry` is admitted.

Verification command:

```bash
cd derivation/code/lean
./audit/run_package_boundary_audit.sh --build
```
