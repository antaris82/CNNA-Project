# CNNA current-state validation

## Project identity

**CNNA (ComplemeNt Net Architecture) — From Primitive Provenance to Mathematical Structure**  
*A Response-Coupled Derivation on a Growing $b$-ary Tree*

The project name is now defined at the beginning of the main paper and supplement. CNNA denotes the recurring relative-complement architecture of one growing provenance net: empty baseline and first realization, born prefix and open continuation, retained boundary and eliminated interior, record and live context, nested cuts, and later reduced-observation specializations.

The generalized framework remains **Generalized Open Provenance Systems**. Universal provenance completion is a research hypothesis, not a theorem of the current DAG.

## Current verified/source state

- DAG: 145 nodes, 401 edges; P002 is active.
- P001: 142/142 declarations kernel verified.
- M003/M004: 11/11 declarations kernel verified.
- P002: six public source declarations; local kernel build still required.
- CNNA architecture map: 27 throughline assignments.
- Open-provenance map: 74 total role assignments across 41 nodes.
- External references: 31 sources, 57 unique uses, 18 claim assertions.
- Main paper: 31 pages, SHA-256 `2b3af2cade5ed576d246fb565d8483f40ed3491e7530236710453f3cf92f5a36`.
- Supplement: 101 pages, SHA-256 `6d235e5fd6716c7bfe8d8364cd30c7c7389f0cb721530d59e40a4ea3ea396831`.
- Native yEd-Live DAG SHA-256: `7082aab6d541f6c983adf9b7fc0592b6acfca4ac8e61d9924684873ca818bdc1`.

## Conceptual safeguards

- Complement is stage-, cut-, scale-, or projection-relative, not an intrinsic permanent node label.
- The CNNA identity is interpretive and does not promote any node beyond its registered evidence status.
- Schur/DtN elimination is not identified with partial trace or marginalization.
- The retained finite POVM remains a Legacy migration target, not a current derived-only theorem.
- POVM, instrument, process tensor/comb, Weyl/GNS, and modular/AQFT structures remain progressively later specializations.
