#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter
from pathlib import Path
import csv
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
TOOLS = ROOT / "derivation/registry/tools"
LEAN = ROOT / "derivation/code/lean"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


errors: list[str] = []
checks = [
    ("D0", "validate_d0.py"),
    ("D0 traceability", "validate_d0_traceability.py"),
    ("D2 structural", "validate_d2_structural.py"),
    ("G0", "validate_g0.py"),
    ("G1", "validate_g1.py"),
    ("G2", "validate_g2.py"),
    ("P001", "validate_p001_kernel_verified.py"),
    ("M003/M004", "validate_m003_m004_kernel_verified.py"),
]
for label, script in checks:
    run = subprocess.run([sys.executable, str(TOOLS / script)], cwd=ROOT, capture_output=True, text=True)
    if run.returncode:
        errors.append(label + ": " + (run.stdout + run.stderr).strip())

nodes = rows(ROOT / "derivation/registry/dag/NODES.tsv")
edges = rows(ROOT / "derivation/registry/dag/EDGES.tsv")
display = rows(ROOT / "derivation/registry/dag/DAG_DISPLAY_STATUS.tsv")
if len(nodes) != 145 or len(edges) != 402:
    errors.append("DAG cardinality")
expected_display = Counter({"FINISHED": 24, "FINISHED_EXTENSION_REQUIRED": 1, "UNFINISHED": 120})
if Counter(row["display_status"] for row in display) != expected_display:
    errors.append("DAG display status counts")

state = json.loads((ROOT / "CURRENT_STATE.json").read_text(encoding="utf-8"))
validation = json.loads((ROOT / "VALIDATION.json").read_text(encoding="utf-8"))
p001 = state.get("p001", {})
if p001.get("status") != "KERNEL_VERIFIED" or p001.get("proof_declarations") != 142 or p001.get("kernel_verified_declarations") != 142:
    errors.append("CURRENT_STATE P001")
lean = validation.get("lean", {})
if (
    lean.get("proof_modules") != 15
    or lean.get("p001_declarations") != 142
    or lean.get("p001_kernel_verified_declarations") != 142
    or lean.get("p001_unverified_declarations") != 0
    or lean.get("m003_m004_declarations") != 11
    or lean.get("m003_m004_kernel_verified_declarations") != 11
    or lean.get("m003_m004_unverified_declarations") != 0
):
    errors.append("VALIDATION Lean state")

main = ROOT / "derivation/paper/main/paper.pdf"
supp = ROOT / "derivation/supplement/supplementary.pdf"
if not main.is_file() or not supp.is_file():
    errors.append("PDF missing")
else:
    documentation = state.get("documentation", {})
    validation_docs = validation.get("documentation", {})
    if documentation.get("main_paper_pdf_sha256") != sha(main):
        errors.append("CURRENT_STATE main PDF hash")
    if documentation.get("supplementary_pdf_sha256") != sha(supp):
        errors.append("CURRENT_STATE supplementary PDF hash")
    if validation_docs.get("main_paper_pdf_sha256") != sha(main):
        errors.append("VALIDATION main PDF hash")
    if validation_docs.get("supplementary_pdf_sha256") != sha(supp):
        errors.append("VALIDATION supplementary PDF hash")
    binding = (ROOT / "derivation/supplement/MAIN_PAPER_SHA256.txt").read_text(encoding="utf-8").split()[0]
    if binding != sha(main):
        errors.append("supplement-to-main hash binding")

for path in ROOT.rglob("*"):
    if path.is_dir() and path.name in {"__pycache__", ".pytest_cache"}:
        errors.append("cache directory " + str(path.relative_to(ROOT)))
    if path.is_file() and (path.suffix in {".pyc", ".pyo"} or path.name in {".coverage"}):
        errors.append("cache file " + str(path.relative_to(ROOT)))
for directory, stem in [
    (ROOT / "derivation/paper/main", "paper"),
    (ROOT / "derivation/supplement", "supplementary"),
]:
    for suffix in ["aux", "bbl", "bcf", "blg", "fdb_latexmk", "fls", "log", "out", "run.xml", "xdv"]:
        if (directory / f"{stem}.{suffix}").exists():
            errors.append("LaTeX intermediate " + suffix)

if errors:
    print("\n".join("FAIL " + error for error in errors))
    sys.exit(1)
print("CURRENT_STATE_VALIDATION PASS")
print(json.dumps({
    "nodes": 145,
    "edges": 402,
    "display_status_counts": dict(expected_display),
    "p001": "KERNEL_VERIFIED",
    "proof_modules": 15,
    "p001_declarations": 142,
    "kernel_verified_declarations": 142,
    "p001_unverified_declarations": 0,
    "m003_m004_kernel_verified_declarations": 11,
    "m003_m004_unverified_declarations": 0,
    "exact_source_evidence": "MATCH",
}, indent=2))
