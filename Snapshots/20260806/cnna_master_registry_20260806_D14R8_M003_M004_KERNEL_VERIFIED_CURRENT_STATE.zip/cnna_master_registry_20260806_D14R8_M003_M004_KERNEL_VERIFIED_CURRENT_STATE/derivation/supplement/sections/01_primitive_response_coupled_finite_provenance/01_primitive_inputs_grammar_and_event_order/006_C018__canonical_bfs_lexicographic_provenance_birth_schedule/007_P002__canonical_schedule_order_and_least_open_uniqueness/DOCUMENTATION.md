# 007 · P002 — Canonical schedule order and least-open uniqueness

**Canonical node label:** `007 · P002`  
**Semantic ID:** `P002`  
**Current section path:** `1.1.6.1`  
**Documentation tier:** `D2`  
**Documentation state:** `COMPLETE_V2`  
**Proof state:** `BLOCKED_ARCHITECTURAL_RELOCATION_OR_CONTRACT_SPLIT_REQUIRED`

## Position In Derivation

P002 is canonical node 007 and is displayed as a proof-certification child of `006 · C018`. The registered hard predecessor is `C003` through `E140`, while `E141` points from P002 back to its owner C018 as a non-hard certification edge. P002 also has hard outgoing support edges to P003 and P004.

The registered statement is:

> Prove transitivity, total comparability on admissible slots, uniqueness of the least open slot, and agreement with the executable BFS/lexicographic selector.

This statement combines two distinct semantic layers. Transitivity and total comparability concern the static C003/C018 address grammar. Least-open uniqueness and executable-selector agreement require a state-dependent born prefix that is not introduced until C005 and is consumed by C004. This layer mismatch is the central result of the present dossier.

Documentation completion does not mean proof completion. P002 remains red, unfrozen and unavailable as a closed predecessor.

## Formal Statement

The contract decomposes into four clauses.

### P002-A: static address-order transitivity

For C003 provenance addresses, C018 defines

\[
 a\prec c
 \iff
 |a|<|c|\;\lor\;\bigl(|a|=|c|\land a<_{\mathrm{lex}}c\bigr).
\]

The required clause is

\[
 a\prec b\land b\prec c\Longrightarrow a\prec c.
\]

### P002-B: static slot comparability

For bounded C018 slot records `left` and `right`, the induced relation compares their selected child addresses. The precise current theorem is conditional:

\[
 \operatorname{child}(left)\ne\operatorname{child}(right)
 \Longrightarrow
 left\prec_{slot}right\;\lor\;right\prec_{slot}left.
\]

The distinct-child hypothesis is necessary because the formal slot structure can contain proof-relevant or representationally different records selecting the same child unless extensional identity is separately established.

### P002-C: dynamic least-open existence and uniqueness

For a response-capable state `X`, define

\[
 \operatorname{Open}_X(a)
 \iff
 \operatorname{depth}(a)\ne0
 \land \operatorname{depth}(a)\le L
 \land a\notin X.\operatorname{bornNonRoot}.
\]

Let

\[
 \operatorname{Next}_X(a)
 \iff
 \operatorname{Open}_X(a)
 \land
 \forall e\,\bigl(\operatorname{Open}_X(e)\Rightarrow\neg(e\prec a)\bigr).
\]

For an unsaturated state, the desired theorem is

\[
 \operatorname{Unsaturated}(X)
 \Longrightarrow
 \exists!a\;\operatorname{Next}_X(a).
\]

This is not expressible from C003 and C018 alone because `bornNonRoot`, the initial-segment invariant and saturation are properties of C005.

### P002-D: executable-selector agreement

For a C005 state with

\[
 n=|X.\operatorname{bornNonRoot}|,
 \qquad
 X.\operatorname{bornNonRoot}=\operatorname{schedule.addresses}[0:n],
\]

the Python selector returns `schedule.slots[n]`. The intended semantic agreement is that this positional object is exactly the unique object satisfying the relational predicate `Next_X`.

The current package contains a finite exhaustive Python audit and a Lean prefix-boundary theorem. It does not contain a theorem that executes Python inside Lean or a dedicated P002 facade bundling both layers.

## Hypotheses

P002-A requires only the C003 address type and the C018 relation.

P002-B additionally requires two bounded C018 slots and inequality of their selected child addresses.

P002-C requires objects that are not predecessors of node 007:

- a C005 `ResponseCapableState`;
- a finite C003 cutoff carrier;
- a born non-root list satisfying non-rootness, cutoff, distinctness, parent closure and C018 initial-segment closure;
- unsaturation, meaning at least one admissible address is not born.

P002-D requires the exact C005 Python prefix invariant and the absence of a sentinel beyond saturation.

The dependence of P002-C and P002-D on C005 is not optional proof convenience. Without a state-dependent born set, the word **open** has no dynamic meaning.

## Introduction Reason

The intended purpose of P002 was to separate load-bearing order closure from the definition node C018 and make the result reusable by later schedule proofs. That is a sound proof-engineering motive. The current statement, however, expanded beyond static order closure and absorbed least-open selection, which belongs to the recurrent-state layer.

The current node placement is architecturally inconsistent with the state-dependent clauses: later C004 evidence cannot be treated as available at node 007.

## Proof Strategy

A scientifically coherent proof is naturally divided into two modules.

### Static module

1. Reuse C018 `birthBefore_trans`.
2. Reuse C018 trichotomy or `birthBefore_total_of_ne`.
3. Lift comparison to slot child addresses.
4. State the required distinct-child or extensional-slot hypothesis explicitly.

This module is already present inside C018 and requires no separate P002 mathematics.

### Dynamic module

1. Introduce `AdmissibleOpenAddress X a` from the C005 state.
2. Enumerate the finite C003 carrier through cutoff `L`.
3. Fold the carrier using C018 comparison, preserving the invariant that the current witness is open and no open enumerated candidate precedes it.
4. Under unsaturation, seed the fold with one open witness and obtain a minimal open address.
5. Use total comparability of distinct addresses to prove equality of any two minimal witnesses.
6. Use C005 initial-segment closure to prove that every born admissible address precedes the selected address and every admissible predecessor is born.
7. Reconstruct the unique C003 parent and final rank from the selected child address.
8. Compare the relational object with Python's indexed candidate under the exact C005 prefix invariant.

Steps 1-7 are implemented in the later C004 Lean core. Step 8 is supported by Python regression tests and the language-independent prefix-boundary theorem, but no direct cross-language kernel theorem exists.

## Lemma Chain

### Already verified in C018

```text
BirthBefore
  -> birthBefore_irrefl
  -> birthBefore_trans
  -> birthBefore_asymm
  -> birthBefore_trichotomy
  -> birthBefore_total_of_ne

OpenSlotBefore
  -> openSlotBefore_irrefl
  -> openSlotBefore_trans
  -> openSlotBefore_asymm
  -> openSlotBefore_total_of_distinct_children
```

### Verified downstream in C004

```text
AdmissibleOpenAddress
Unsaturated
IsNextOpenAddress
NextOpenSlot
  -> addressesAtDepth
  -> addressesUpTo
  -> preferEarlierOpen
  -> MinimalAmong
  -> leastOpenFrom
  -> leastOpenFrom_minimal
  -> exists_of_unsaturated
  -> no_open_before
  -> child_unique
  -> unique
  -> born_before_next
  -> earlier_admissible_is_born
  -> admissible_born_iff_before_next
  -> parent_born
  -> parent_rank_unique
  -> no_next_of_saturated
```

The second chain is downstream of C005 and cannot be imported into P002 at node 007 without introducing a backward hard dependency or changing P002's position.

## Formal Realization

There is no dedicated P002 Python file and no dedicated P002 Lean module in the current package. The paths recorded in the cross-layer map are planned paths only.

The static evidence resides in:

- `S06_C018_CanonicalBfsLexicographicProvenanceBirthSchedule.lean`.

The dynamic evidence resides in:

- `S02_C004_NextOpenProvenanceSlotSnplus1NGe1.lean`;
- `s02_c004__next_open_provenance_slot_snplus1_n_ge_1.py`;
- its focused Python test module.

This distributed evidence is mathematically substantial, but the registered P002 proof facade, import boundary and ownership theorem do not exist. Therefore `E141: P002 -> C018` remains `PLANNED_BLOCKED`.

The present documentation closure changes no Python or Lean source and creates no synthetic proof module.

## Counterexamples Or Necessity Checks

1. **No born state.** A strict total order on all addresses determines an earliest address globally, but it does not determine the earliest address not yet born. Openness is undefined without a born set.
2. **No initial-segment invariant.** If the born set is an arbitrary subset, Python's positional index `n` need not identify the relationally least un-born address.
3. **No unsaturation.** The existential theorem is false at saturation. The correct result is absence of a successor, not a sentinel object.
4. **No total comparison.** A finite partially ordered open set can have several incomparable minimal elements; uniqueness does not follow.
5. **Duplicate child representation.** Two distinct slot records selecting one child defeat strict slot comparability unless the theorem is stated extensionally or assumes distinct children.
6. **Retrospective evidence treated as predecessor evidence.** Importing C004 into node 007 would create a cycle through C005/C018 or reverse the canonical derivation order. A proof existing later does not make the earlier ownership placement correct.
7. **Finite tests treated as a universal theorem.** The exhaustive Python grid is strong regression evidence for the tested finite domain, but it does not quantify over all natural `b,L` in the Lean kernel.

All necessity checks pass as documentation counterchecks. They do not close the proof gate.

## Axiom Profile

The supporting C018 and C004 Lean modules belong to the mathlib-free `CNNA` core and were part of the exact 26-job Lean 4.31.0 core build. Their source-local proofs introduce no project axiom, `sorry`, classical choice or noncomputable selector.

P002 itself has no Lean declaration and therefore has no P002-specific `#print axioms` profile. Reporting the C018/C004 profile as a P002 theorem profile would be misleading. The correct status is:

```text
supporting core theorem profile: mathlib-free and kernel-built
P002 facade theorem profile: not available; module absent
```

## Result

The audit resolves the four contract clauses as follows:

| Clause | Current evidence | P002 status |
|---|---|---|
| schedule-order transitivity | kernel-verified in C018 | mathematically discharged, not P002-owned |
| slot comparability | kernel-verified in C018 under distinct-child hypothesis | mathematically discharged with explicit scope |
| least-open existence and uniqueness | kernel-verified downstream in C004 under C005 state hypotheses | unavailable at node 007 |
| executable-selector agreement | exhaustive finite Python audit plus Lean prefix-boundary theorem | strong semantic evidence, no direct cross-language theorem |

The P002 dossier is complete. The proof gate is not closed.

## Remaining Limits

The DAG and code must adopt one of the following coherent resolutions.

### Resolution A: static contraction

Restrict P002 to static order closure. Because C018 already contains the complete constructive theorem chain, either make P002 a thin certified facade imported by C018 or remove P002 as redundant. This resolution does not include least-open uniqueness.

### Resolution B: dynamic relocation

Move or re-own P002 after C005/C004. The proof facade can then package:

- C018 strict-total address order;
- C005 born-prefix invariants;
- C004 existence, uniqueness, prefix-boundary and saturation theorems;
- the executable finite agreement audit.

The owner/certification edge must then be revised so it does not pretend that a downstream state theorem certifies C018 before that state exists.

Until one resolution is implemented:

- P002 remains `CORE_REQUIRES_PROOF`;
- `E141` remains blocked;
- P003 and P004 may use C018/C004 evidence directly only after their own dependency structures are made explicit;
- no freeze or proof-completion claim is permitted.

## Downstream Handoff

- `E145 P002 -> P003` currently expresses intended reuse for canonical birth-cut selection. Because P002 is not closed, P003 must retain an explicit blocked dependency or be rewired to the actual C018/C005/C004 prerequisites.
- `E151 P002 -> P004` currently expresses intended reuse for finite exhaustivity and termination. P004 may reuse the static order and dynamic prefix theorems, but finite enumeration completeness remains a separate theorem.
- `E141 P002 -> C018` remains a planned certification edge and is not promoted by documentation completion.

The current graph geometry and edge records are preserved. P002 remains open and explicitly records the unresolved ownership choice.

## Code Line Register

P002 has no owned source module. The following anchors are **supporting evidence**, not P002 declaration ownership.

### C018 Lean static-order support

| Symbol | Kind | Lines | Role |
|---|---|---:|---|
| `BirthBefore` | `DEF` | 33-39 | canonical depth-then-lex relation |
| `birthBefore_trans` | `THEOREM` | 183-199 | transitivity clause |
| `birthBefore_trichotomy` | `THEOREM` | 205-225 | constructive trichotomy |
| `birthBefore_total_of_ne` | `THEOREM` | 226-240 | total comparison of distinct addresses |
| `OpenSlotBefore` | `DEF` | 280-286 | child-address-induced slot relation |
| `openSlotBefore_trans` | `THEOREM` | 307-313 | slot-order transitivity |
| `openSlotBefore_total_of_distinct_children` | `THEOREM` | 320-329 | conditional slot comparability |

Source SHA-256: `d332704d80a9aaa1eca72b7961d868aabceeead7320bbbd5766b1d2ba2bb53a1`.

### C005 state prerequisite

| Symbol | Layer | Lines | Role |
|---|---|---:|---|
| `ResponseCapableState` | Python | 41-104 | executable born-prefix state |
| `ResponseCapableState` | Lean core | 51-81 | formal born-prefix state and invariants |

Python source SHA-256: `96b9867f44f4a5021cd017033e796f41e0fcc9195c09505796129bdbd469f240`.  
Lean source SHA-256: `732f5cf1227d57955c144b99043f0c58bb6535ae3a3d2bf3ac584385df0cb6cc`.

### C004 dynamic least-open support

| Symbol | Kind | Lines | Role |
|---|---|---:|---|
| `AdmissibleOpenAddress` | `DEF` | 89-95 | state-dependent openness |
| `Unsaturated` | `DEF` | 96-99 | existence precondition |
| `IsNextOpenAddress` | `DEF` | 108-116 | relational least-open specification |
| `NextOpenSlot` | `ABBREV` | 117-123 | proof-bearing selected address |
| `exists_of_unsaturated` | `THEOREM` | 236-251 | constructive finite existence |
| `child_unique` | `THEOREM` | 274-285 | unique child address |
| `unique` | `THEOREM` | 286-292 | unique proof-bearing object |
| `admissible_born_iff_before_next` | `THEOREM` | 328-340 | exact C005/C018 prefix boundary |
| `parent_rank_unique` | `THEOREM` | 430-442 | unique C003 slot reconstruction |
| `no_next_of_saturated` | `THEOREM` | 451-459 | no sentinel at saturation |

Lean source SHA-256: `e729d8ac3ebcf263049f660b8ea33bd9087d60fd1796d076a7c55659e922281a`.

### Python executable agreement support

| Symbol | Kind | Lines | Role |
|---|---|---:|---|
| `is_next_open_provenance_slot` | `FUNCTION` | 24-51 | extensional relational predicate |
| `next_open_provenance_slot` | `FUNCTION` | 54-91 | indexed executable selector with invariant checks |
| `TestNextOpenProvenanceSlot` | `CLASS` | 34-107 | exhaustive small-grid agreement and saturation controls |

Python source SHA-256: `d939caa5a08845e0ee8faa737e79efebdec29031de08d5d52b51f77c3aab0535`.  
Test source SHA-256: `e03128bfa022ebd4939c778fee4cc19eda4711544922d965ae227457392b725f`.

The canonical machine-readable register is `derivation/registry/documentation/CODE_ANCHORS.tsv`. Every P002 entry is marked `SUPPORTING_EVIDENCE`; no entry is represented as an owned P002 source declaration.
