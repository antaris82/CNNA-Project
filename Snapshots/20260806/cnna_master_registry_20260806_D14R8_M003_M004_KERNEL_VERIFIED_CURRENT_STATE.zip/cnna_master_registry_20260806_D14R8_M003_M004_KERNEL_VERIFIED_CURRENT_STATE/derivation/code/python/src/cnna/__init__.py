"""CNNA derivation package."""
