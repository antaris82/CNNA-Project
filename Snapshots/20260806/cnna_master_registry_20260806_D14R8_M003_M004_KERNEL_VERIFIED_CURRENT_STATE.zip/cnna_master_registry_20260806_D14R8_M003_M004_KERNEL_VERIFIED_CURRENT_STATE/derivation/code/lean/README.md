# Lean package boundary

The Lean tree contains two Lake packages:

- `core/`: `cnna_core` / `CNNA`, Lean 4.31.0, 24 modules, no package
  dependencies and no mathlib imports;
- `proofs/`: `cnna_proofs` / `CNNAProofs`, Lean 4.31.0, pinned mathlib
  `v4.31.0`, local dependency `../core`, 15 source modules.

The only permitted import direction is `CNNAProofs -> CNNA`.

P001 retains exact-source-bound kernel evidence for all 142 declarations. Its
immutable source scope contains only the twelve P001 proof modules plus the
P001 axiom-audit module. The proof aggregator belongs to the separate current
M003/M004 integration scope because it exposes the closure and handoff layer.
Audit-runner sources have their own third scope. All three scopes are disjoint
and hash-checked before a build begins.

```bash
python3 audit/check_package_boundary.py
./audit/run_package_boundary_audit.sh --build
```
