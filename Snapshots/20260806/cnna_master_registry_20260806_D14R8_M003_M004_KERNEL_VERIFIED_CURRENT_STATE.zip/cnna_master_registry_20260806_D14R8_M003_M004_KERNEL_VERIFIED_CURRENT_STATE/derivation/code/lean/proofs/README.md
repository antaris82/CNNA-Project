# CNNA proof package

`CNNAProofs` depends on pinned mathlib `v4.31.0` and the sibling `cnna_core` package. It never reverses the permitted `CNNAProofs -> CNNA` dependency.

The P001 subpackage has 142 kernel-verified, axiom-audited declarations with exact source evidence. Two additional modules close the public M003 and M004 interfaces:

- `M003M004/S01_CanonicalM003Closure.lean`;
- `M003M004/S02_CanonicalM004ClosureAndHandoff.lean`.

The second module imports only the first and consumes its domain, pair-existence, and positivity fields directly. The local build is authoritative for the 11 new declarations.

```bash
cd ..
./audit/run_package_boundary_audit.sh --build
```
