# CNNA master registry — current verified state

This package contains the current CNNA registry, Core and proof sources, canonical yEd Live DAG, paper, supplement, reference registry, and validation artifacts.

P001 is kernel-verified under Lean 4.31.0 with mathlib v4.31.0: all 142 registered P001 declarations passed the axiom audit and full package-boundary audit. M003 and M004 are also kernel-verified: the 11 public canonical closure and handoff declarations build warning-free, pass their separate axiom audit, and are bound to the exact current source hashes.

`CanonicalM003Closure` internalizes the parent coordinate and packages domain, existence, and universal positivity. `CanonicalM004Closure` consumes that interface directly and supplies a representative-independent immutable C008 handoff. C008 remains the next separate state-mutation node.

The admitted transitive trust profile is limited to `propext`, `Classical.choice`, and `Quot.sound`. No project-local axiom or `sorry` is admitted.

The paper and supplement describe only the current mathematical state. The supplement is bound to the exact main-paper PDF by `derivation/supplement/MAIN_PAPER_SHA256.txt`.

Verification command:

```bash
cd derivation/code/lean
./audit/run_package_boundary_audit.sh --build
```
