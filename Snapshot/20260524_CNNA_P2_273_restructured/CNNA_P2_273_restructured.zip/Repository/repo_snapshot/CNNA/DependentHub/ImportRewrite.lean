import CNNA.PillarB.BuildAll
import CNNA.PillarC.BuildAll
import CNNA.PillarD.BuildAll
import CNNA.PillarE.BuildAll

set_option autoImplicit false

namespace CNNA.DependentHub

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

structure ImportRewriteBatch
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  pillarB : CNNA.PillarB.DependentHubImportRewriteCertificate Cell T
  pillarC : CNNA.PillarC.DependentHubImportRewriteCertificate Cell T
  pillarD : CNNA.PillarD.DependentHubImportRewriteCertificate Cell T
  pillarE : CNNA.PillarE.DependentHubImportRewriteCertificate Cell T
  pillarC_source_matches_pillarB : pillarC.input.source = pillarB.input.source
  pillarD_source_matches_pillarB : pillarD.input.source = pillarB.input.source
  pillarE_source_matches_pillarB : pillarE.input.source = pillarB.input.source

namespace ImportRewriteBatch

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def source (batch : ImportRewriteBatch Cell T) :
    CNNA.PillarA.Handoff.PillarAStep1Closed Cell T :=
  batch.pillarB.input.source

theorem pillarC_source_eq_source
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarC.input.source = batch.source := by
  change batch.pillarC.input.source = batch.pillarB.input.source
  exact batch.pillarC_source_matches_pillarB

theorem pillarD_source_eq_source
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarD.input.source = batch.source := by
  change batch.pillarD.input.source = batch.pillarB.input.source
  exact batch.pillarD_source_matches_pillarB

theorem pillarE_source_eq_source
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarE.input.source = batch.source := by
  change batch.pillarE.input.source = batch.pillarB.input.source
  exact batch.pillarE_source_matches_pillarB

theorem pillarB_source_eq_regulator_node_closed
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarB.source = batch.pillarB.regulatorNode.closed :=
  batch.pillarB.source_eq_regulator_node_closed

theorem pillarC_source_eq_regulator_node_closed
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarC.source = batch.pillarC.regulatorNode.closed :=
  batch.pillarC.source_eq_regulator_node_closed

theorem pillarD_source_eq_regulator_node_closed
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarD.source = batch.pillarD.regulatorNode.closed :=
  batch.pillarD.source_eq_regulator_node_closed

theorem pillarE_source_eq_regulator_node_closed
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarE.source = batch.pillarE.regulatorNode.closed :=
  batch.pillarE.source_eq_regulator_node_closed

theorem pillarB_request_noFoundationWrite
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarB.input.feedback.request.foundationWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  batch.pillarB.request_noFoundationWrite

theorem pillarC_update_noPillarInternalWrite
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarC.input.feedback.update.pillarInternalWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  batch.pillarC.update_noPillarInternalWrite

theorem pillarD_request_noFoundationWrite
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarD.input.feedback.request.foundationWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  batch.pillarD.request_noFoundationWrite

theorem pillarE_update_noPillarInternalWrite
    (batch : ImportRewriteBatch Cell T) :
    batch.pillarE.input.feedback.update.pillarInternalWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  batch.pillarE.update_noPillarInternalWrite

end ImportRewriteBatch

end CNNA.DependentHub
