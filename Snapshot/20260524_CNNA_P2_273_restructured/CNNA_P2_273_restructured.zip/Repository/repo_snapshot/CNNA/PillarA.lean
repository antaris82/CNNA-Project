import CNNA.PillarA.BuildAll
