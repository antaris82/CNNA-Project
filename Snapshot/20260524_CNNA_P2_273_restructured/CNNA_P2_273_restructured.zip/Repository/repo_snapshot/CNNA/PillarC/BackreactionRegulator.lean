import CNNA.PillarA.Handoff.Regulator.TypedSurface

set_option autoImplicit false

namespace CNNA.PillarC

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

abbrev ABackreactionRegulatorInput
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  CNNA.PillarA.Handoff.CToARegulatorInput Cell T

def regulatorBranch
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    (input : ABackreactionRegulatorInput Cell T) :=
  input.feedback

def sourceClosed
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    (input : ABackreactionRegulatorInput Cell T) :
    CNNA.PillarA.Handoff.PillarAStep1Closed Cell T :=
  input.source

structure DependentHubImportRewriteCertificate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  input : ABackreactionRegulatorInput Cell T
  source_matches_regulator_node : input.source = input.feedback.node.closed

namespace DependentHubImportRewriteCertificate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def source (certificate : DependentHubImportRewriteCertificate Cell T) :
    CNNA.PillarA.Handoff.PillarAStep1Closed Cell T :=
  certificate.input.source

def regulatorNode (certificate : DependentHubImportRewriteCertificate Cell T) :
    CNNA.PillarA.Handoff.RegulatedHandoffFactorNode
      CNNA.PillarA.Handoff.HandoffFactorTarget.pillarAToC Cell T :=
  certificate.input.feedback.node

theorem source_eq_regulator_node_closed
    (certificate : DependentHubImportRewriteCertificate Cell T) :
    certificate.source = certificate.regulatorNode.closed := by
  change certificate.input.source = certificate.input.feedback.node.closed
  exact certificate.source_matches_regulator_node

theorem request_kind
    (certificate : DependentHubImportRewriteCertificate Cell T) :
    certificate.input.feedback.request.surfaceKind =
      CNNA.PillarA.Handoff.BackreactionRegulatorSurfaceKind.request :=
  certificate.input.feedback.request_kind_eq

theorem request_noFoundationWrite
    (certificate : DependentHubImportRewriteCertificate Cell T) :
    certificate.input.feedback.request.foundationWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  certificate.input.feedback.request_noFoundationWrite

theorem update_noPillarInternalWrite
    (certificate : DependentHubImportRewriteCertificate Cell T) :
    certificate.input.feedback.update.pillarInternalWriteStatus =
      CNNA.PillarA.Handoff.BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  certificate.input.feedback.update_noPillarInternalWrite

end DependentHubImportRewriteCertificate

end CNNA.PillarC
