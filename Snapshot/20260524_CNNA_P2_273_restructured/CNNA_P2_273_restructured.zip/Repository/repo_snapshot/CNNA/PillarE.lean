import CNNA.PillarE.BuildAll
