import CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.AdapterTarget

set_option autoImplicit false

namespace CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedLevelStepExecMirrorSourceAdapter

abbrev adapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.externalEvidenceDiagnosticsTarget

theorem adapterSurface_no_theory_closure :
    adapterSurface.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

end CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedLevelStepExecMirrorSourceAdapter
