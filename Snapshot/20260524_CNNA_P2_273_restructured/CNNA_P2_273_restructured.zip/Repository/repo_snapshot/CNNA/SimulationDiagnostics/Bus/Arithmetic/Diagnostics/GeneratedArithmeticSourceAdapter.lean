import CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.AdapterTarget
import CNNA.PillarA.Arithmetic.SourceAndApproximation

set_option autoImplicit false

namespace CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedArithmeticSourceAdapter

abbrev adapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.sourceAndApproximationDiagnosticsTarget

theorem adapterSurface_no_theory_closure :
    adapterSurface.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

end CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedArithmeticSourceAdapter
