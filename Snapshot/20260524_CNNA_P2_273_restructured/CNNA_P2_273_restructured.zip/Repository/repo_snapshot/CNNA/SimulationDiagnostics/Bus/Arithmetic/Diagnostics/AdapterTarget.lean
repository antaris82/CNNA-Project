import CNNA.SimulationDiagnostics.Bus.Arithmetic.Surface

set_option autoImplicit false

namespace CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics

abbrev generatedPipelineDiagnosticsTarget :
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAdapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.diagnosticsSurface
    "CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedPipeline"
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAttachmentTarget.generatedPipeline

abbrev sourceAndApproximationDiagnosticsTarget :
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAdapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.diagnosticsSurface
    "CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.SourceAndApproximation"
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAttachmentTarget.sourceAndApproximation

abbrev handoffTransitDiagnosticsTarget :
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAdapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.diagnosticsSurface
    "CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.HandoffTransit"
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAttachmentTarget.handoffTransit

abbrev externalEvidenceDiagnosticsTarget :
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAdapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.diagnosticsSurface
    "CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.ExternalEvidence"
    CNNA.SimulationDiagnostics.Bus.Arithmetic.ArithmeticAttachmentTarget.externalEvidenceOnly

theorem generatedPipelineDiagnosticsTarget_no_theory_closure :
    generatedPipelineDiagnosticsTarget.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

theorem sourceAndApproximationDiagnosticsTarget_no_theory_closure :
    sourceAndApproximationDiagnosticsTarget.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

theorem handoffTransitDiagnosticsTarget_no_theory_closure :
    handoffTransitDiagnosticsTarget.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

theorem externalEvidenceDiagnosticsTarget_no_theory_closure :
    externalEvidenceDiagnosticsTarget.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

end CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics
