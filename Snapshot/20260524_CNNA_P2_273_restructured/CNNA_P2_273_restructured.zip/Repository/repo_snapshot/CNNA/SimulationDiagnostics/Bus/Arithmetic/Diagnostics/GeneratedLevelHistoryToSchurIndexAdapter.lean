import CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.AdapterTarget
import CNNA.PillarA.Arithmetic.GeneratedPipeline

set_option autoImplicit false

namespace CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedLevelHistoryToSchurIndexAdapter

abbrev adapterSurface :=
  CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.generatedPipelineDiagnosticsTarget

theorem adapterSurface_no_theory_closure :
    adapterSurface.busTarget.controlSurface.mayCloseCNNATheoryClaim = false :=
  rfl

end CNNA.SimulationDiagnostics.Bus.Arithmetic.Diagnostics.GeneratedLevelHistoryToSchurIndexAdapter
