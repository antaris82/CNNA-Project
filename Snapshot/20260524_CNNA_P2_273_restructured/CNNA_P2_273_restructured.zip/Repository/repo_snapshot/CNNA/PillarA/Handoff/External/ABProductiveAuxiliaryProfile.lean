import CNNA.PillarA.Handoff.External.AToBEndpointProfile
import CNNA.PillarA.Handoff.Regulator.TypedSurface

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u v w x

inductive ExternalABAuxiliaryDerivationMode where
  | rawPreservedRegulatedHandoff
  | blockedByEndpointMismatch
  | comparisonOnly
  deriving DecidableEq, Repr

inductive ExternalABRawRegulatedStatus where
  | declared
  | aligned
  | blocked
  deriving DecidableEq, Repr

inductive ExternalABFoundationWriteStatus where
  | noFoundationWrite
  deriving DecidableEq, Repr

inductive ExternalABPillarInternalWriteStatus where
  | noPillarInternalWrite
  deriving DecidableEq, Repr

structure ExternalABProductiveAuxiliaryProfile
    (Cell : Nat → Type x) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  endpoint : ExternalAToBEndpointProfile Cell T
  regulatedNode : PillarAToBRegulatedFactorNode Cell T
  regulatorBranch :
    BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarB
      HandoffFactorTarget.pillarAToB Cell T
  derivationMode : ExternalABAuxiliaryDerivationMode
  rawRegulatedStatus : ExternalABRawRegulatedStatus
  foundationWriteStatus : ExternalABFoundationWriteStatus
  pillarInternalWriteStatus : ExternalABPillarInternalWriteStatus
  regulatorNode_eq_regulatedNode : regulatorBranch.node = regulatedNode
  rawHandoff_eq_regulatedHandoff : endpoint.handoff = regulatedNode.baseABHandoff
  endpointRelease_eq_regulatedRequest :
    endpoint.contract.releaseCertificate = regulatedNode.requestRelease
  derivationMode_eq_rawPreserved :
    derivationMode =
      ExternalABAuxiliaryDerivationMode.rawPreservedRegulatedHandoff
  rawRegulatedStatus_eq_aligned :
    rawRegulatedStatus = ExternalABRawRegulatedStatus.aligned
  foundationWriteStatus_eq_noFoundationWrite :
    foundationWriteStatus = ExternalABFoundationWriteStatus.noFoundationWrite
  pillarInternalWriteStatus_eq_noPillarInternalWrite :
    pillarInternalWriteStatus =
      ExternalABPillarInternalWriteStatus.noPillarInternalWrite

namespace ExternalABProductiveAuxiliaryProfile

variable {Cell : Nat → Type x} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def rawHandoff (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    ABHandoffStrong Cell T :=
  profile.endpoint.handoff

def regulatedHandoff (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    ABHandoffStrong Cell T :=
  profile.regulatedNode.baseABHandoff

def rawPayload (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    SectorExportStrong Cell T :=
  profile.rawHandoff.payload

def regulatedPayload (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    SectorExportStrong Cell T :=
  profile.regulatedHandoff.payload

def rawSource (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    Step1MathDataStrong Cell T :=
  profile.rawHandoff.source

def regulatedSource (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    Step1MathDataStrong Cell T :=
  profile.regulatedHandoff.source

def requestCertificate
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    GeneratorRequestApproximationReleaseCertificate :=
  profile.regulatedNode.requestRelease

def global (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    GlobalTheoryApproximationState :=
  profile.requestCertificate.global

def limitProfile (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    PillarAToBLimitApproximationProfile :=
  profile.requestCertificate.limitProfile

theorem endpoint_target_is_B
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.contract.target = ExternalPillarATarget.pillarB :=
  profile.endpoint.target_is_B

theorem endpoint_status_is_released
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.contract.status = ExternalEndpointReleaseStatus.released :=
  profile.endpoint.status_is_released

theorem endpoint_derivationMode_is_fromInternalSpine
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.contract.derivationMode =
      ExternalEndpointDerivationMode.fromInternalSpine :=
  profile.endpoint.derivationMode_is_fromInternalSpine

theorem derivationMode_is_rawPreserved
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.derivationMode =
      ExternalABAuxiliaryDerivationMode.rawPreservedRegulatedHandoff :=
  profile.derivationMode_eq_rawPreserved

theorem rawRegulatedStatus_is_aligned
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.rawRegulatedStatus = ExternalABRawRegulatedStatus.aligned :=
  profile.rawRegulatedStatus_eq_aligned

theorem foundationWriteStatus_is_noFoundationWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.foundationWriteStatus =
      ExternalABFoundationWriteStatus.noFoundationWrite :=
  profile.foundationWriteStatus_eq_noFoundationWrite

theorem pillarInternalWriteStatus_is_noPillarInternalWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.pillarInternalWriteStatus =
      ExternalABPillarInternalWriteStatus.noPillarInternalWrite :=
  profile.pillarInternalWriteStatus_eq_noPillarInternalWrite

theorem regulatorNode_eq_regulatedNode_theorem
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.node = profile.regulatedNode :=
  profile.regulatorNode_eq_regulatedNode

theorem rawHandoff_eq_regulatedHandoff_theorem
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.rawHandoff = profile.regulatedHandoff :=
  profile.rawHandoff_eq_regulatedHandoff

theorem rawPayload_eq_regulatedPayload
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.rawPayload = profile.regulatedPayload := by
  exact congrArg ABHandoffStrong.payload
    profile.rawHandoff_eq_regulatedHandoff

theorem rawSource_eq_regulatedSource
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.rawSource = profile.regulatedSource := by
  exact congrArg ABHandoffStrong.source
    profile.rawHandoff_eq_regulatedHandoff

theorem endpointRelease_eq_regulatedRequest_theorem
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.contract.releaseCertificate =
      profile.regulatedNode.requestRelease :=
  profile.endpointRelease_eq_regulatedRequest

theorem endpoint_global_eq_regulated_global
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.global = profile.regulatedNode.global := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.global
    profile.endpointRelease_eq_regulatedRequest

theorem endpoint_limitProfile_eq_regulated_limitProfile
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.endpoint.limitProfile = profile.regulatedNode.requestRelease.limitProfile := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.limitProfile
    profile.endpointRelease_eq_regulatedRequest

theorem global_eq_regulated_global
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.global = profile.regulatedNode.global := by
  rfl

theorem limitProfile_eq_regulated_limitProfile
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.limitProfile = profile.regulatedNode.requestRelease.limitProfile := by
  rfl

theorem regulator_request_noFoundationWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.request.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  profile.regulatorBranch.request_noFoundationWrite

theorem regulator_constraint_noFoundationWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.constraint.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  profile.regulatorBranch.constraint_noFoundationWrite

theorem regulator_failure_noFoundationWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.failure.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  profile.regulatorBranch.failure_noFoundationWrite

theorem regulator_update_noFoundationWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.update.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  profile.regulatorBranch.update_noFoundationWrite

theorem regulator_request_noPillarInternalWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.request.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  profile.regulatorBranch.request_noPillarInternalWrite

theorem regulator_update_noPillarInternalWrite
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.update.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  profile.regulatorBranch.update_noPillarInternalWrite

theorem regulator_request_kind
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.request.surfaceKind =
      BackreactionRegulatorSurfaceKind.request :=
  profile.regulatorBranch.request_kind_eq

theorem regulator_update_kind
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatorBranch.update.surfaceKind =
      BackreactionRegulatorSurfaceKind.update :=
  profile.regulatorBranch.update_kind_eq

theorem regulatedNode_exposure_factorNodeOnly
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatedNode.exposureStatus =
      HandoffFactorExposureStatus.factorNodeOnly :=
  profile.regulatedNode.exposureStatus_factorNodeOnly

theorem raw_aToBInput_eq_source_exportData
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.rawHandoff.aToBInput = profile.rawHandoff.source.exportData := by
  exact profile.rawHandoff.payload_eq_source_exportData

theorem regulated_aToBInput_eq_source_exportData
    (profile : ExternalABProductiveAuxiliaryProfile Cell T) :
    profile.regulatedHandoff.aToBInput =
      profile.regulatedHandoff.source.exportData := by
  exact profile.regulatedHandoff.payload_eq_source_exportData

end ExternalABProductiveAuxiliaryProfile

end CNNA.PillarA.Handoff
