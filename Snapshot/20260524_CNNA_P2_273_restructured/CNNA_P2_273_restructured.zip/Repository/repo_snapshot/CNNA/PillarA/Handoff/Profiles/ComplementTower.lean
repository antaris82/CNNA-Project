import CNNA.PillarA.Handoff.Profiles.GlobalApproximation
import CNNA.PillarA.Generator.ComplementTower

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

structure ComplementFamilyApproximationTowerProfile where
  globalProfile : GlobalApproximationHandoffProfile
  tower : CNNA.PillarA.Generator.ComplementFamilyApproximationTower
  tower_matches_lock : tower.lock = globalProfile.lock

namespace ComplementFamilyApproximationTowerProfile

def state (profile : ComplementFamilyApproximationTowerProfile) :
    CNNA.PillarA.Generator.GlobalTheoryApproximationState :=
  profile.globalProfile.state

theorem tower_state_eq (profile : ComplementFamilyApproximationTowerProfile) :
    profile.tower.global = profile.state := by
  rw [ComplementFamilyApproximationTowerProfile.state,
    CNNA.PillarA.Generator.ComplementFamilyApproximationTower.global,
    profile.tower_matches_lock]
  rfl

end ComplementFamilyApproximationTowerProfile

structure PillarAToBLimitApproximationProfile where
  towerProfile : ComplementFamilyApproximationTowerProfile
  aToBProfileMatchesTowerState :
    towerProfile.globalProfile.state = towerProfile.tower.global

namespace PillarAToBLimitApproximationProfile

def state (profile : PillarAToBLimitApproximationProfile) :
    CNNA.PillarA.Generator.GlobalTheoryApproximationState :=
  profile.towerProfile.globalProfile.state

theorem state_eq_tower_global (profile : PillarAToBLimitApproximationProfile) :
    profile.state = profile.towerProfile.tower.global :=
  profile.aToBProfileMatchesTowerState

end PillarAToBLimitApproximationProfile

end CNNA.PillarA.Handoff
