import CNNA.PillarA.Handoff.Internal.CompatibilityAggregator

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalBoundarySchurDtNHubFacadeStatus where
  | declared
  | connected
  | blocked
  deriving DecidableEq, Repr

inductive InternalBoundarySchurDtNHubPayloadExposureStatus where
  | typedGeneratorOutputsOnly
  | payloadDeferred
  | payloadReady
  | blocked
  deriving DecidableEq, Repr

inductive InternalBoundarySchurDtNHubAxiomImportStatus where
  | cutEdgeReadoutOnly
  | primitiveImported
  | blocked
  deriving DecidableEq, Repr

inductive InternalBoundarySchurDtNHubComponent where
  | boundaryPort
  | multiSchur
  | topBoundaryDtN
  | generalizedTopBoundaryDtN
  deriving DecidableEq, Repr

structure InternalBoundarySchurDtNHubHandoffFacade where
  aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}
  status : InternalBoundarySchurDtNHubFacadeStatus
  payloadExposure : InternalBoundarySchurDtNHubPayloadExposureStatus
  axiomImportStatus : InternalBoundarySchurDtNHubAxiomImportStatus
  status_declared :
    status = InternalBoundarySchurDtNHubFacadeStatus.declared
  payloadExposure_typedGeneratorOutputsOnly :
    payloadExposure =
      InternalBoundarySchurDtNHubPayloadExposureStatus.typedGeneratorOutputsOnly
  axiomImportStatus_cutEdgeReadoutOnly :
    axiomImportStatus =
      InternalBoundarySchurDtNHubAxiomImportStatus.cutEdgeReadoutOnly

namespace InternalBoundarySchurDtNHubHandoffFacade

def state
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    GlobalTheoryApproximationState :=
  facade.aggregator.state

def standard
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    InternalHubInterfaceStandard.{u, v} :=
  facade.aggregator.spineSkeleton.spineCertificate.standard

def generatorReleaseCertificate
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorOutputReleaseCertificate :=
  facade.aggregator.spineSkeleton.generatorReleaseCertificate

def internalReleaseCertificate
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    GeneratorRequestApproximationReleaseCertificate :=
  facade.aggregator.spineSkeleton.internalReleaseCertificate

def stableOutputRecord
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.output :=
  facade.aggregator.spineSkeleton.spineCertificate.catalog.records.stableRecord

def cutStateRecord
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.cutState :=
  facade.aggregator.spineSkeleton.spineCertificate.catalog.records.interfaceSurface

def residualRecord
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.residual :=
  facade.aggregator.spineSkeleton.spineCertificate.catalog.records.darkComplement

def reviewGateRecord
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.reviewGate :=
  facade.aggregator.spineSkeleton.spineCertificate.catalog.records.regulatorBranch

def boundaryPortProfile
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    CNNA.PillarA.Generator.LevelHistoryBoundaryPortOutputProfile :=
  facade.aggregator.generatorAggregator.facade.levelHistoryBoundaryPort

def multiSchurProfile
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    CNNA.PillarA.Generator.MultiSchurOutputProfile :=
  facade.aggregator.generatorAggregator.facade.multiSchur

def topBoundaryDtNProfile
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    CNNA.PillarA.Generator.TopBoundaryDtNOutputProfile :=
  facade.aggregator.generatorAggregator.facade.topBoundaryDtN

def generalizedTopBoundaryDtNProfile
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    CNNA.PillarA.Generator.GeneralizedTopBoundaryDtNOutputProfile :=
  facade.aggregator.generatorAggregator.facade.generalizedTopBoundaryDtN

theorem status_is_declared
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.status = InternalBoundarySchurDtNHubFacadeStatus.declared :=
  facade.status_declared

theorem payloadExposure_is_typedGeneratorOutputsOnly
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.payloadExposure =
      InternalBoundarySchurDtNHubPayloadExposureStatus.typedGeneratorOutputsOnly :=
  facade.payloadExposure_typedGeneratorOutputsOnly

theorem axiomImportStatus_is_cutEdgeReadoutOnly
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.axiomImportStatus =
      InternalBoundarySchurDtNHubAxiomImportStatus.cutEdgeReadoutOnly :=
  facade.axiomImportStatus_cutEdgeReadoutOnly

theorem generator_route_is_retained
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.generatorAggregator.routeExposure =
      CNNA.PillarA.Generator.NeutralGeneratorCompatibilityRouteExposure.retainedCompatibilityRoute :=
  facade.aggregator.generator_route_is_retained

theorem generator_cutover_is_noCutover
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.generatorAggregator.cutoverStatus =
      CNNA.PillarA.Generator.NeutralGeneratorCompatibilityCutoverStatus.noCutover :=
  facade.aggregator.generator_cutover_is_noCutover

theorem handoff_consumerCutover_is_noConsumerCutover
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.consumerCutover =
      InternalHandoffCompatibilityConsumerCutoverStatus.noConsumerCutover :=
  facade.aggregator.consumerCutover_is_noConsumerCutover

theorem spine_exposure_is_aInternalOnly
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.spineSkeleton.exposureStatus =
      InternalGeneratorSpineExposureStatus.aInternalOnly :=
  facade.aggregator.spine_exposure_is_aInternalOnly

theorem request_global_eq_internal_state
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.request.global = facade.state :=
  facade.aggregator.request_global_eq_internal_state

theorem output_state_eq_internal_state
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.output.state = facade.state :=
  facade.aggregator.output_state_eq_internal_state

theorem boundaryPort_source_eq
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.boundaryPortProfile.profile.source =
      facade.aggregator.generatorAggregator.facade.source :=
  facade.aggregator.generatorAggregator.facade.levelHistoryBoundaryPort_source_eq

theorem multiSchur_source_eq
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.multiSchurProfile.profile.source =
      facade.aggregator.generatorAggregator.facade.source :=
  facade.aggregator.generatorAggregator.facade.multiSchur_source_eq

theorem topBoundaryDtN_source_eq
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.topBoundaryDtNProfile.profile.source =
      facade.aggregator.generatorAggregator.facade.source :=
  facade.aggregator.generatorAggregator.facade.topBoundaryDtN_source_eq

theorem generalizedTopBoundaryDtN_source_eq
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.generalizedTopBoundaryDtNProfile.profile.source =
      facade.aggregator.generatorAggregator.facade.source :=
  facade.aggregator.generatorAggregator.facade.generalizedTopBoundaryDtN_source_eq

theorem boundaryPort_kind
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.boundaryPortProfile.profile.kind =
      CNNA.PillarA.Generator.DerivedOutputKind.levelHistoryBoundaryPort :=
  CNNA.PillarA.Generator.GeneratorOutputCompatibilityFacade.levelHistoryBoundaryPort_kind
    facade.aggregator.generatorAggregator.facade

theorem multiSchur_kind
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.multiSchurProfile.profile.kind =
      CNNA.PillarA.Generator.DerivedOutputKind.multiSchur :=
  CNNA.PillarA.Generator.GeneratorOutputCompatibilityFacade.multiSchur_kind
    facade.aggregator.generatorAggregator.facade

theorem topBoundaryDtN_kind
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.topBoundaryDtNProfile.profile.kind =
      CNNA.PillarA.Generator.DerivedOutputKind.topBoundaryDtN :=
  CNNA.PillarA.Generator.GeneratorOutputCompatibilityFacade.topBoundaryDtN_kind
    facade.aggregator.generatorAggregator.facade

theorem generalizedTopBoundaryDtN_kind
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.generalizedTopBoundaryDtNProfile.profile.kind =
      CNNA.PillarA.Generator.DerivedOutputKind.generalizedTopBoundaryDtN :=
  CNNA.PillarA.Generator.GeneratorOutputCompatibilityFacade.generalizedTopBoundaryDtN_kind
    facade.aggregator.generatorAggregator.facade

theorem release_scope_is_generatorOutputLayerOnly
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.aggregator.generatorAggregator.releaseCertificate.releasedScope =
      CNNA.PillarA.Generator.GeneratorOutputReleaseScope.generatorOutputLayerOnly :=
  facade.aggregator.generatorAggregator.release_scope_is_generatorOutputLayerOnly

theorem input_direction_generatorToHub
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.standard.input.direction = InternalHandoffDirection.generatorToHub :=
  facade.standard.input_direction

theorem output_direction_hubToInternalHandoff
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.standard.output.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.output_direction

theorem cutState_direction_hubToInternalHandoff
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.standard.cutState.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.cutState_direction

theorem residual_direction_hubToInternalHandoff
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.standard.residual.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.residual_direction

theorem reviewGate_direction_regulatorToInterface
    (facade : InternalBoundarySchurDtNHubHandoffFacade.{u, v, w}) :
    facade.standard.reviewGate.direction =
      InternalHandoffDirection.regulatorToInterface :=
  facade.standard.reviewGate_direction

end InternalBoundarySchurDtNHubHandoffFacade

end CNNA.PillarA.Handoff
