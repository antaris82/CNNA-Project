import CNNA.PillarA.Handoff.Internal.CutEdgeAxiomRecovery

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalTriadicComponentKind where
  | brightSystem
  | darkComplement
  | interfaceSurface
  | regulatorBranch
  | stableRecord
  deriving DecidableEq, Repr

inductive InternalTriadicRegulatorBranchKind where
  | generatorRelease
  | reviewGate
  | handoffRegulator
  | residualBackjump
  deriving DecidableEq, Repr

inductive InternalTriadicStabilityStatus where
  | declared
  | stabilized
  | blocked
  | comparisonOnly
  deriving DecidableEq, Repr

inductive InternalTriadicBackjumpRoute where
  | hubInterfaceStandard
  | cutEdgeRecovery
  | releaseCertificate
  | naturalDerivationSite
  deriving DecidableEq, Repr

structure InternalTriadicRegulatorBranch
    (standard : InternalHubInterfaceStandard.{u, v}) where
  kind : InternalTriadicRegulatorBranchKind
  schema : InternalHandoffTypeSchema.{u, v}
  schema_eq_reviewGate : schema = standard.reviewGate

namespace InternalTriadicRegulatorBranch

variable {standard : InternalHubInterfaceStandard.{u, v}}

def releaseCertificate
    (branch : InternalTriadicRegulatorBranch standard) :
    GeneratorRequestApproximationReleaseCertificate :=
  branch.schema.releaseCertificate

def global
    (branch : InternalTriadicRegulatorBranch standard) :
    GlobalTheoryApproximationState :=
  branch.schema.global

theorem schema_direction
    (branch : InternalTriadicRegulatorBranch standard) :
    branch.schema.direction = InternalHandoffDirection.regulatorToInterface := by
  rw [branch.schema_eq_reviewGate]
  exact standard.reviewGate_direction

theorem schema_source_role
    (branch : InternalTriadicRegulatorBranch standard) :
    branch.schema.source.role = InternalHandoffRole.regulator := by
  rw [branch.schema_eq_reviewGate]
  exact standard.reviewGate_source_role

theorem releaseCertificate_eq_standard
    (branch : InternalTriadicRegulatorBranch standard) :
    branch.releaseCertificate = standard.releaseCertificate := by
  change branch.schema.releaseCertificate = standard.input.releaseCertificate
  rw [branch.schema_eq_reviewGate]
  exact standard.reviewGate_releaseCertificate_eq

theorem global_eq_input_global
    (branch : InternalTriadicRegulatorBranch standard) :
    branch.global = standard.input.global := by
  change branch.schema.global = standard.input.global
  rw [branch.schema_eq_reviewGate]
  exact standard.reviewGate_global_eq_input_global

end InternalTriadicRegulatorBranch

structure InternalHubTriadicInterfaceProfile
    (standard : InternalHubInterfaceStandard.{u, v}) where
  cutRecovery : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard
  regulatorBranch : InternalTriadicRegulatorBranch standard
  stabilityStatus : InternalTriadicStabilityStatus
  backjumpRoute : InternalTriadicBackjumpRoute
  brightSystem : InternalHandoffTypeSchema.{u, v}
  darkComplement : InternalHandoffTypeSchema.{u, v}
  interfaceSurface : InternalHandoffTypeSchema.{u, v}
  stableRecord : InternalHandoffTypeSchema.{u, v}
  brightSystem_eq_output : brightSystem = standard.output
  darkComplement_eq_residual : darkComplement = standard.residual
  interfaceSurface_eq_cutState : interfaceSurface = standard.cutState
  stableRecord_eq_output : stableRecord = standard.output

namespace InternalHubTriadicInterfaceProfile

variable {standard : InternalHubInterfaceStandard.{u, v}}

def component
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard)
    (kind : InternalTriadicComponentKind) :
    InternalHandoffTypeSchema.{u, v} :=
  match kind with
  | InternalTriadicComponentKind.brightSystem => profile.brightSystem
  | InternalTriadicComponentKind.darkComplement => profile.darkComplement
  | InternalTriadicComponentKind.interfaceSurface => profile.interfaceSurface
  | InternalTriadicComponentKind.regulatorBranch => profile.regulatorBranch.schema
  | InternalTriadicComponentKind.stableRecord => profile.stableRecord

def releaseCertificate
    (_profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    GeneratorRequestApproximationReleaseCertificate :=
  standard.releaseCertificate

def hubKind
    (_profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    InternalHubKind :=
  standard.hubKind

def family
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    InternalCutEdgeTheoryFamily :=
  profile.cutRecovery.family

theorem recovery_family_eq_hub_family
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.family = InternalCutEdgeTheoryFamily.forHub standard.hubKind :=
  profile.cutRecovery.family_eq_hub_family

theorem brightSystem_global_eq_input_global
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.brightSystem.global = standard.input.global := by
  rw [profile.brightSystem_eq_output]
  exact standard.output_global_eq_input_global

theorem darkComplement_global_eq_input_global
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.darkComplement.global = standard.input.global := by
  rw [profile.darkComplement_eq_residual]
  exact standard.residual_global_eq_input_global

theorem interfaceSurface_global_eq_input_global
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.interfaceSurface.global = standard.input.global := by
  rw [profile.interfaceSurface_eq_cutState]
  exact standard.cutState_global_eq_input_global

theorem stableRecord_global_eq_input_global
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.stableRecord.global = standard.input.global := by
  rw [profile.stableRecord_eq_output]
  exact standard.output_global_eq_input_global

theorem regulator_global_eq_input_global
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.regulatorBranch.global = standard.input.global :=
  profile.regulatorBranch.global_eq_input_global

theorem regulator_direction
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.regulatorBranch.schema.direction =
      InternalHandoffDirection.regulatorToInterface :=
  profile.regulatorBranch.schema_direction

theorem interfaceSurface_direction
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.interfaceSurface.direction =
      InternalHandoffDirection.hubToInternalHandoff := by
  rw [profile.interfaceSurface_eq_cutState]
  exact standard.cutState_direction

theorem darkComplement_direction
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.darkComplement.direction =
      InternalHandoffDirection.hubToInternalHandoff := by
  rw [profile.darkComplement_eq_residual]
  exact standard.residual_direction

theorem stableRecord_direction
    (profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard) :
    profile.stableRecord.direction =
      InternalHandoffDirection.hubToInternalHandoff := by
  rw [profile.stableRecord_eq_output]
  exact standard.output_direction

end InternalHubTriadicInterfaceProfile

structure InternalHubTriadicTypedRecords
    (standard : InternalHubInterfaceStandard.{u, v}) where
  brightSystem : InternalHandoffTypedRecord standard.output
  darkComplement : InternalHandoffTypedRecord standard.residual
  interfaceSurface : InternalHandoffTypedRecord standard.cutState
  regulatorBranch : InternalHandoffTypedRecord standard.reviewGate
  stableRecord : InternalHandoffTypedRecord standard.output

namespace InternalHubTriadicTypedRecords

variable {standard : InternalHubInterfaceStandard.{u, v}}

def brightRecord
    (records : InternalHubTriadicTypedRecords standard) :
    InternalHandoffTypedRecord standard.output :=
  records.brightSystem

def darkComplementRecord
    (records : InternalHubTriadicTypedRecords standard) :
    InternalHandoffTypedRecord standard.residual :=
  records.darkComplement

def interfaceRecord
    (records : InternalHubTriadicTypedRecords standard) :
    InternalHandoffTypedRecord standard.cutState :=
  records.interfaceSurface

def regulatorRecord
    (records : InternalHubTriadicTypedRecords standard) :
    InternalHandoffTypedRecord standard.reviewGate :=
  records.regulatorBranch

def stableOutputRecord
    (records : InternalHubTriadicTypedRecords standard) :
    InternalHandoffTypedRecord standard.output :=
  records.stableRecord

theorem bright_global_eq_input_global
    (_records : InternalHubTriadicTypedRecords standard) :
    standard.output.global = standard.input.global :=
  standard.output_global_eq_input_global

theorem darkComplement_global_eq_input_global
    (_records : InternalHubTriadicTypedRecords standard) :
    standard.residual.global = standard.input.global :=
  standard.residual_global_eq_input_global

theorem interface_global_eq_input_global
    (_records : InternalHubTriadicTypedRecords standard) :
    standard.cutState.global = standard.input.global :=
  standard.cutState_global_eq_input_global

theorem regulator_global_eq_input_global
    (_records : InternalHubTriadicTypedRecords standard) :
    standard.reviewGate.global = standard.input.global :=
  standard.reviewGate_global_eq_input_global

end InternalHubTriadicTypedRecords

structure InternalHubTriadicInterfaceCatalog where
  standard : InternalHubInterfaceStandard.{u, v}
  profile : InternalHubTriadicInterfaceProfile.{u, v, w} standard
  records : InternalHubTriadicTypedRecords standard

namespace InternalHubTriadicInterfaceCatalog

def hubKind
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    InternalHubKind :=
  catalog.standard.hubKind

def family
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    InternalCutEdgeTheoryFamily :=
  catalog.profile.family

theorem family_eq_hub_family
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    catalog.family = InternalCutEdgeTheoryFamily.forHub catalog.hubKind :=
  catalog.profile.recovery_family_eq_hub_family

theorem bright_global_eq_input_global
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    catalog.standard.output.global = catalog.standard.input.global :=
  catalog.records.bright_global_eq_input_global

theorem darkComplement_global_eq_input_global
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    catalog.standard.residual.global = catalog.standard.input.global :=
  catalog.records.darkComplement_global_eq_input_global

theorem interface_global_eq_input_global
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    catalog.standard.cutState.global = catalog.standard.input.global :=
  catalog.records.interface_global_eq_input_global

theorem regulator_global_eq_input_global
    (catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}) :
    catalog.standard.reviewGate.global = catalog.standard.input.global :=
  catalog.records.regulator_global_eq_input_global

end InternalHubTriadicInterfaceCatalog

end CNNA.PillarA.Handoff
