import CNNA.PillarA.Handoff.External.ABProductiveAuxiliaryProfile

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

inductive ExternalAResidualDownstreamStage where
  | atPillarB
  | bToC
  | cToD
  | dToE
  | atPillarE
  deriving DecidableEq, Repr

inductive ExternalAProvenanceSignalKind where
  | foundationSource
  | generatorRequest
  | generatorOutput
  | internalHandoffSpine
  | rawABHandoff
  | regulatedABHandoff
  | regulatorBranch
  | limitApproximation
  | residualComplement
  deriving DecidableEq, Repr

inductive ExternalAResidualDischargeKind where
  | retainedResidualProfile
  | namedIrrelevanceTheorem
  | approximationCertificate
  | redMissingProofMarker
  deriving DecidableEq, Repr

inductive ExternalAResidualAccountingStatus where
  | accounted
  | blocked
  deriving DecidableEq, Repr

inductive ExternalAResidualProjectionStatus where
  | noSilentProjection
  | silentProjectionBlocked
  deriving DecidableEq, Repr

inductive ExternalAResidualContractStatus where
  | active
  | blocked
  deriving DecidableEq, Repr

structure ExternalAResidualProvenanceEntry where
  stage : ExternalAResidualDownstreamStage
  signal : ExternalAProvenanceSignalKind
  discharge : ExternalAResidualDischargeKind
  accountingStatus : ExternalAResidualAccountingStatus
  projectionStatus : ExternalAResidualProjectionStatus
  accountingStatus_eq_accounted :
    accountingStatus = ExternalAResidualAccountingStatus.accounted
  projectionStatus_eq_noSilentProjection :
    projectionStatus = ExternalAResidualProjectionStatus.noSilentProjection

namespace ExternalAResidualProvenanceEntry

def isRetained (entry : ExternalAResidualProvenanceEntry) : Prop :=
  entry.discharge = ExternalAResidualDischargeKind.retainedResidualProfile

def isDischargedByIrrelevance
    (entry : ExternalAResidualProvenanceEntry) : Prop :=
  entry.discharge = ExternalAResidualDischargeKind.namedIrrelevanceTheorem

def isDischargedByApproximation
    (entry : ExternalAResidualProvenanceEntry) : Prop :=
  entry.discharge = ExternalAResidualDischargeKind.approximationCertificate

def isRedMissingProof (entry : ExternalAResidualProvenanceEntry) : Prop :=
  entry.discharge = ExternalAResidualDischargeKind.redMissingProofMarker

theorem accountingStatus_is_accounted
    (entry : ExternalAResidualProvenanceEntry) :
    entry.accountingStatus = ExternalAResidualAccountingStatus.accounted :=
  entry.accountingStatus_eq_accounted

theorem projectionStatus_is_noSilentProjection
    (entry : ExternalAResidualProvenanceEntry) :
    entry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  entry.projectionStatus_eq_noSilentProjection

end ExternalAResidualProvenanceEntry

structure ExternalAResidualProvenanceContract
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  auxiliary : ExternalABProductiveAuxiliaryProfile Cell T
  foundationEntry : ExternalAResidualProvenanceEntry
  generatorRequestEntry : ExternalAResidualProvenanceEntry
  generatorOutputEntry : ExternalAResidualProvenanceEntry
  internalSpineEntry : ExternalAResidualProvenanceEntry
  rawABHandoffEntry : ExternalAResidualProvenanceEntry
  regulatedABHandoffEntry : ExternalAResidualProvenanceEntry
  regulatorBranchEntry : ExternalAResidualProvenanceEntry
  limitApproximationEntry : ExternalAResidualProvenanceEntry
  residualComplementEntry : ExternalAResidualProvenanceEntry
  contractStatus : ExternalAResidualContractStatus
  requestCertificate : GeneratorRequestApproximationReleaseCertificate
  foundation_signal_eq :
    foundationEntry.signal =
      ExternalAProvenanceSignalKind.foundationSource
  generatorRequest_signal_eq :
    generatorRequestEntry.signal =
      ExternalAProvenanceSignalKind.generatorRequest
  generatorOutput_signal_eq :
    generatorOutputEntry.signal =
      ExternalAProvenanceSignalKind.generatorOutput
  internalSpine_signal_eq :
    internalSpineEntry.signal =
      ExternalAProvenanceSignalKind.internalHandoffSpine
  rawABHandoff_signal_eq :
    rawABHandoffEntry.signal =
      ExternalAProvenanceSignalKind.rawABHandoff
  regulatedABHandoff_signal_eq :
    regulatedABHandoffEntry.signal =
      ExternalAProvenanceSignalKind.regulatedABHandoff
  regulatorBranch_signal_eq :
    regulatorBranchEntry.signal =
      ExternalAProvenanceSignalKind.regulatorBranch
  limitApproximation_signal_eq :
    limitApproximationEntry.signal =
      ExternalAProvenanceSignalKind.limitApproximation
  residualComplement_signal_eq :
    residualComplementEntry.signal =
      ExternalAProvenanceSignalKind.residualComplement
  contractStatus_eq_active :
    contractStatus = ExternalAResidualContractStatus.active
  requestCertificate_eq_auxiliary :
    requestCertificate = auxiliary.requestCertificate

namespace ExternalAResidualProvenanceContract

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def global (contract : ExternalAResidualProvenanceContract Cell T) :
    GlobalTheoryApproximationState :=
  contract.requestCertificate.global

def limitProfile (contract : ExternalAResidualProvenanceContract Cell T) :
    PillarAToBLimitApproximationProfile :=
  contract.requestCertificate.limitProfile

def rawHandoff (contract : ExternalAResidualProvenanceContract Cell T) :
    ABHandoffStrong Cell T :=
  contract.auxiliary.rawHandoff

def regulatedHandoff (contract : ExternalAResidualProvenanceContract Cell T) :
    ABHandoffStrong Cell T :=
  contract.auxiliary.regulatedHandoff

def entries (contract : ExternalAResidualProvenanceContract Cell T) :
    List ExternalAResidualProvenanceEntry :=
  [contract.foundationEntry,
   contract.generatorRequestEntry,
   contract.generatorOutputEntry,
   contract.internalSpineEntry,
   contract.rawABHandoffEntry,
   contract.regulatedABHandoffEntry,
   contract.regulatorBranchEntry,
   contract.limitApproximationEntry,
   contract.residualComplementEntry]

theorem contractStatus_is_active
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.contractStatus = ExternalAResidualContractStatus.active :=
  contract.contractStatus_eq_active

theorem requestCertificate_matches_auxiliary
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.requestCertificate = contract.auxiliary.requestCertificate :=
  contract.requestCertificate_eq_auxiliary

theorem global_eq_auxiliary_global
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.global = contract.auxiliary.global := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.global
    contract.requestCertificate_eq_auxiliary

theorem limitProfile_eq_auxiliary_limitProfile
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.limitProfile = contract.auxiliary.limitProfile := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.limitProfile
    contract.requestCertificate_eq_auxiliary

theorem rawHandoff_eq_regulatedHandoff
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.rawHandoff = contract.regulatedHandoff :=
  contract.auxiliary.rawHandoff_eq_regulatedHandoff_theorem

theorem foundation_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.foundationEntry.signal =
      ExternalAProvenanceSignalKind.foundationSource :=
  contract.foundation_signal_eq

theorem generatorRequest_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorRequestEntry.signal =
      ExternalAProvenanceSignalKind.generatorRequest :=
  contract.generatorRequest_signal_eq

theorem generatorOutput_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorOutputEntry.signal =
      ExternalAProvenanceSignalKind.generatorOutput :=
  contract.generatorOutput_signal_eq

theorem internalSpine_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.internalSpineEntry.signal =
      ExternalAProvenanceSignalKind.internalHandoffSpine :=
  contract.internalSpine_signal_eq

theorem rawABHandoff_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.rawABHandoffEntry.signal =
      ExternalAProvenanceSignalKind.rawABHandoff :=
  contract.rawABHandoff_signal_eq

theorem regulatedABHandoff_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatedABHandoffEntry.signal =
      ExternalAProvenanceSignalKind.regulatedABHandoff :=
  contract.regulatedABHandoff_signal_eq

theorem regulatorBranch_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatorBranchEntry.signal =
      ExternalAProvenanceSignalKind.regulatorBranch :=
  contract.regulatorBranch_signal_eq

theorem limitApproximation_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.limitApproximationEntry.signal =
      ExternalAProvenanceSignalKind.limitApproximation :=
  contract.limitApproximation_signal_eq

theorem residualComplement_signal
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.residualComplementEntry.signal =
      ExternalAProvenanceSignalKind.residualComplement :=
  contract.residualComplement_signal_eq

theorem foundation_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.foundationEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.foundationEntry.accountingStatus_is_accounted

theorem generatorRequest_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorRequestEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.generatorRequestEntry.accountingStatus_is_accounted

theorem generatorOutput_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorOutputEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.generatorOutputEntry.accountingStatus_is_accounted

theorem internalSpine_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.internalSpineEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.internalSpineEntry.accountingStatus_is_accounted

theorem rawABHandoff_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.rawABHandoffEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.rawABHandoffEntry.accountingStatus_is_accounted

theorem regulatedABHandoff_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatedABHandoffEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.regulatedABHandoffEntry.accountingStatus_is_accounted

theorem regulatorBranch_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatorBranchEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.regulatorBranchEntry.accountingStatus_is_accounted

theorem limitApproximation_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.limitApproximationEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.limitApproximationEntry.accountingStatus_is_accounted

theorem residualComplement_accounted
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.residualComplementEntry.accountingStatus =
      ExternalAResidualAccountingStatus.accounted :=
  contract.residualComplementEntry.accountingStatus_is_accounted

theorem foundation_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.foundationEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.foundationEntry.projectionStatus_is_noSilentProjection

theorem generatorRequest_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorRequestEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.generatorRequestEntry.projectionStatus_is_noSilentProjection

theorem generatorOutput_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.generatorOutputEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.generatorOutputEntry.projectionStatus_is_noSilentProjection

theorem internalSpine_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.internalSpineEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.internalSpineEntry.projectionStatus_is_noSilentProjection

theorem rawABHandoff_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.rawABHandoffEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.rawABHandoffEntry.projectionStatus_is_noSilentProjection

theorem regulatedABHandoff_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatedABHandoffEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.regulatedABHandoffEntry.projectionStatus_is_noSilentProjection

theorem regulatorBranch_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.regulatorBranchEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.regulatorBranchEntry.projectionStatus_is_noSilentProjection

theorem limitApproximation_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.limitApproximationEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.limitApproximationEntry.projectionStatus_is_noSilentProjection

theorem residualComplement_noSilentProjection
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.residualComplementEntry.projectionStatus =
      ExternalAResidualProjectionStatus.noSilentProjection :=
  contract.residualComplementEntry.projectionStatus_is_noSilentProjection

theorem noFoundationWrite
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.auxiliary.foundationWriteStatus =
      ExternalABFoundationWriteStatus.noFoundationWrite :=
  contract.auxiliary.foundationWriteStatus_is_noFoundationWrite

theorem noPillarInternalWrite
    (contract : ExternalAResidualProvenanceContract Cell T) :
    contract.auxiliary.pillarInternalWriteStatus =
      ExternalABPillarInternalWriteStatus.noPillarInternalWrite :=
  contract.auxiliary.pillarInternalWriteStatus_is_noPillarInternalWrite

end ExternalAResidualProvenanceContract

end CNNA.PillarA.Handoff
