import CNNA.PillarA.Handoff.External.EstablishedTheoryReviewGates

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

inductive ExternalHandoffEndpointStandardReleaseStatus where
  | declared
  | released
  | blocked
  deriving DecidableEq, Repr

inductive ExternalHandoffEndpointStandardCoverageStatus where
  | aToBEndpointReleased
  | downstreamResidualContractReleased
  | establishedTheoryReviewGatesReleased
  | blocked
  deriving DecidableEq, Repr

inductive ExternalHandoffEndpointStandardPayloadStatus where
  | structuralEndpointOnly
  deriving DecidableEq, Repr

structure ExternalHandoffEndpointStandardReleaseCertificate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  reviewCatalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T
  status : ExternalHandoffEndpointStandardReleaseStatus
  endpointCoverageStatus : ExternalHandoffEndpointStandardCoverageStatus
  residualCoverageStatus : ExternalHandoffEndpointStandardCoverageStatus
  reviewGateCoverageStatus : ExternalHandoffEndpointStandardCoverageStatus
  payloadStatus : ExternalHandoffEndpointStandardPayloadStatus
  releaseCertificate : GeneratorRequestApproximationReleaseCertificate
  status_eq_released :
    status = ExternalHandoffEndpointStandardReleaseStatus.released
  endpointCoverageStatus_eq_aToBEndpointReleased :
    endpointCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.aToBEndpointReleased
  residualCoverageStatus_eq_downstreamResidualContractReleased :
    residualCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.downstreamResidualContractReleased
  reviewGateCoverageStatus_eq_establishedTheoryReviewGatesReleased :
    reviewGateCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.establishedTheoryReviewGatesReleased
  payloadStatus_eq_structuralEndpointOnly :
    payloadStatus =
      ExternalHandoffEndpointStandardPayloadStatus.structuralEndpointOnly
  releaseCertificate_eq_residualContract :
    releaseCertificate = reviewCatalog.residualContract.requestCertificate

namespace ExternalHandoffEndpointStandardReleaseCertificate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def residualContract
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    ExternalAResidualProvenanceContract Cell T :=
  certificate.reviewCatalog.residualContract

def auxiliary
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    ExternalABProductiveAuxiliaryProfile Cell T :=
  certificate.residualContract.auxiliary

def endpoint
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    ExternalAToBEndpointProfile Cell T :=
  certificate.auxiliary.endpoint

def rawHandoff
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    ABHandoffStrong Cell T :=
  certificate.residualContract.rawHandoff

def regulatedHandoff
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    ABHandoffStrong Cell T :=
  certificate.residualContract.regulatedHandoff

def global
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    GlobalTheoryApproximationState :=
  certificate.releaseCertificate.global

def limitProfile
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    PillarAToBLimitApproximationProfile :=
  certificate.releaseCertificate.limitProfile

def reviewGates
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    List (ExternalEstablishedTheoryCutBlockReviewGate Cell T) :=
  certificate.reviewCatalog.gates

theorem status_is_released
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.status = ExternalHandoffEndpointStandardReleaseStatus.released :=
  certificate.status_eq_released

theorem endpointCoverageStatus_is_aToBEndpointReleased
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.endpointCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.aToBEndpointReleased :=
  certificate.endpointCoverageStatus_eq_aToBEndpointReleased

theorem residualCoverageStatus_is_downstreamResidualContractReleased
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.residualCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.downstreamResidualContractReleased :=
  certificate.residualCoverageStatus_eq_downstreamResidualContractReleased

theorem reviewGateCoverageStatus_is_establishedTheoryReviewGatesReleased
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewGateCoverageStatus =
      ExternalHandoffEndpointStandardCoverageStatus.establishedTheoryReviewGatesReleased :=
  certificate.reviewGateCoverageStatus_eq_establishedTheoryReviewGatesReleased

theorem payloadStatus_is_structuralEndpointOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.payloadStatus =
      ExternalHandoffEndpointStandardPayloadStatus.structuralEndpointOnly :=
  certificate.payloadStatus_eq_structuralEndpointOnly

theorem releaseCertificate_matches_residualContract
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.releaseCertificate =
      certificate.residualContract.requestCertificate :=
  certificate.releaseCertificate_eq_residualContract

theorem endpoint_status_is_released
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.endpoint.contract.status = ExternalEndpointReleaseStatus.released :=
  ExternalAToBEndpointProfile.status_is_released certificate.endpoint

theorem endpoint_derivationMode_is_fromInternalSpine
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.endpoint.contract.derivationMode =
      ExternalEndpointDerivationMode.fromInternalSpine :=
  ExternalAToBEndpointProfile.derivationMode_is_fromInternalSpine
    certificate.endpoint

theorem auxiliary_rawRegulatedStatus_is_aligned
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.auxiliary.rawRegulatedStatus =
      ExternalABRawRegulatedStatus.aligned :=
  ExternalABProductiveAuxiliaryProfile.rawRegulatedStatus_is_aligned
    certificate.auxiliary

theorem noFoundationWrite
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.auxiliary.foundationWriteStatus =
      ExternalABFoundationWriteStatus.noFoundationWrite :=
  ExternalABProductiveAuxiliaryProfile.foundationWriteStatus_is_noFoundationWrite
    certificate.auxiliary

theorem noPillarInternalWrite
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.auxiliary.pillarInternalWriteStatus =
      ExternalABPillarInternalWriteStatus.noPillarInternalWrite :=
  ExternalABProductiveAuxiliaryProfile.pillarInternalWriteStatus_is_noPillarInternalWrite
    certificate.auxiliary

theorem residualContract_is_active
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.residualContract.contractStatus =
      ExternalAResidualContractStatus.active :=
  ExternalAResidualProvenanceContract.contractStatus_is_active
    certificate.residualContract

theorem rawHandoff_eq_regulatedHandoff
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.rawHandoff = certificate.regulatedHandoff :=
  certificate.residualContract.rawHandoff_eq_regulatedHandoff

theorem aqft_noPrimitiveImport
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.aqftGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  certificate.reviewCatalog.aqft_noPrimitiveImport

theorem oqs_noPrimitiveImport
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.oqsGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  certificate.reviewCatalog.oqs_noPrimitiveImport

theorem geometry_noPrimitiveImport
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.geometryGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  certificate.reviewCatalog.geometry_noPrimitiveImport

theorem spacetimeInterface_noPrimitiveImport
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.spacetimeInterfaceGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  certificate.reviewCatalog.spacetimeInterface_noPrimitiveImport

theorem matter_noPrimitiveImport
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.matterGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  certificate.reviewCatalog.matter_noPrimitiveImport

theorem aqft_reviewGateOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.aqftGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  certificate.reviewCatalog.aqft_reviewGateOnly

theorem oqs_reviewGateOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.oqsGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  certificate.reviewCatalog.oqs_reviewGateOnly

theorem geometry_reviewGateOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.geometryGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  certificate.reviewCatalog.geometry_reviewGateOnly

theorem spacetimeInterface_reviewGateOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.spacetimeInterfaceGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  certificate.reviewCatalog.spacetimeInterface_reviewGateOnly

theorem matter_reviewGateOnly
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.reviewCatalog.matterGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  certificate.reviewCatalog.matter_reviewGateOnly

theorem global_eq_residualContract_global
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.global = certificate.residualContract.global := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.global
    certificate.releaseCertificate_eq_residualContract

theorem limitProfile_eq_residualContract_limitProfile
    (certificate : ExternalHandoffEndpointStandardReleaseCertificate Cell T) :
    certificate.limitProfile = certificate.residualContract.limitProfile := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.limitProfile
    certificate.releaseCertificate_eq_residualContract

end ExternalHandoffEndpointStandardReleaseCertificate

end CNNA.PillarA.Handoff
