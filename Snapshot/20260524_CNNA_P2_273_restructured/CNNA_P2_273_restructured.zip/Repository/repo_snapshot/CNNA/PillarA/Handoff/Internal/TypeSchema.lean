import CNNA.PillarA.Handoff.Profiles.ReleaseCertificate

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v

inductive InternalHandoffRole where
  | producer
  | consumer
  | interface
  | regulator
  | handoff
  deriving DecidableEq, Repr

inductive InternalHandoffDirection where
  | generatorToHub
  | hubToHub
  | hubToInternalHandoff
  | regulatorToInterface
  | internalHandoffToExternalSurface
  deriving DecidableEq, Repr

structure InternalHandoffEndpoint where
  carrier : Type u
  role : InternalHandoffRole

namespace InternalHandoffEndpoint

def sameRole (left right : InternalHandoffEndpoint) : Prop :=
  left.role = right.role

theorem sameRole_refl (endpoint : InternalHandoffEndpoint) :
    endpoint.sameRole endpoint := by
  rfl

end InternalHandoffEndpoint

structure InternalHandoffTypeSchema where
  source : InternalHandoffEndpoint
  target : InternalHandoffEndpoint
  direction : InternalHandoffDirection
  releaseCertificate : GeneratorRequestApproximationReleaseCertificate
  payloadType : Type v

namespace InternalHandoffTypeSchema

def gate (schema : InternalHandoffTypeSchema) : RealDataFirstUnlockGate :=
  schema.releaseCertificate.gate

def lock (schema : InternalHandoffTypeSchema) : SinglePreparationLock :=
  schema.releaseCertificate.lock

def request (schema : InternalHandoffTypeSchema) : GeneratorRequestProfile :=
  schema.releaseCertificate.request

def global (schema : InternalHandoffTypeSchema) : GlobalTheoryApproximationState :=
  schema.releaseCertificate.global

def limitProfile (schema : InternalHandoffTypeSchema) :
    PillarAToBLimitApproximationProfile :=
  schema.releaseCertificate.limitProfile

theorem request_global_eq_lock (schema : InternalHandoffTypeSchema) :
    schema.request.global = schema.lock.state :=
  schema.releaseCertificate.request_global_eq_lock

theorem request_global_eq_limit_state (schema : InternalHandoffTypeSchema) :
    schema.request.global = schema.limitProfile.state :=
  schema.releaseCertificate.request_global_eq_limit_state

theorem gate_global_eq_limit_state (schema : InternalHandoffTypeSchema) :
    schema.gate.global = schema.limitProfile.state :=
  schema.releaseCertificate.gate_global_eq_limit_state

theorem released_tier_is_limit_profile (schema : InternalHandoffTypeSchema) :
    schema.gate.releasedTier =
      CNNA.PillarA.Generator.RequestedDataTier.limitProfile :=
  schema.releaseCertificate.released_tier_is_limit_profile

end InternalHandoffTypeSchema

structure InternalHandoffTypedRecord (schema : InternalHandoffTypeSchema) where
  payload : schema.payloadType

namespace InternalHandoffTypedRecord

theorem request_global_eq_lock {schema : InternalHandoffTypeSchema}
    (_record : InternalHandoffTypedRecord schema) :
    schema.request.global = schema.lock.state :=
  schema.request_global_eq_lock

theorem request_global_eq_limit_state {schema : InternalHandoffTypeSchema}
    (_record : InternalHandoffTypedRecord schema) :
    schema.request.global = schema.limitProfile.state :=
  schema.request_global_eq_limit_state

end InternalHandoffTypedRecord

structure InternalHandoffPortContract (schema : InternalHandoffTypeSchema) where
  producerEndpoint : InternalHandoffEndpoint
  consumerEndpoint : InternalHandoffEndpoint
  producer_matches_source : producerEndpoint = schema.source
  consumer_matches_target : consumerEndpoint = schema.target

namespace InternalHandoffPortContract

theorem producer_role_eq_source {schema : InternalHandoffTypeSchema}
    (contract : InternalHandoffPortContract schema) :
    contract.producerEndpoint.role = schema.source.role := by
  rw [contract.producer_matches_source]

theorem consumer_role_eq_target {schema : InternalHandoffTypeSchema}
    (contract : InternalHandoffPortContract schema) :
    contract.consumerEndpoint.role = schema.target.role := by
  rw [contract.consumer_matches_target]

def typedRecord {schema : InternalHandoffTypeSchema}
    (_contract : InternalHandoffPortContract schema)
    (payload : schema.payloadType) :
    InternalHandoffTypedRecord schema where
  payload := payload

end InternalHandoffPortContract

end CNNA.PillarA.Handoff
