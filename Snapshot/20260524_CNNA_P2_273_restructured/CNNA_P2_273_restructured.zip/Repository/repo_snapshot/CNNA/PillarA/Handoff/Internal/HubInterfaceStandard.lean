import CNNA.PillarA.Handoff.Internal.TypeSchema

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v

inductive InternalHubKind where
  | arithmetic
  | algebra
  | boundary
  | finite
  | coupling
  | structural
  | generatorConsumer
  | internalHandoff
  deriving DecidableEq, Repr

inductive InternalHubInterfaceChannel where
  | input
  | output
  | cutState
  | residual
  | reviewGate
  deriving DecidableEq, Repr

structure InternalHubInterfaceStandard where
  hubCarrier : Type u
  hubKind : InternalHubKind
  input : InternalHandoffTypeSchema.{u, v}
  output : InternalHandoffTypeSchema.{u, v}
  cutState : InternalHandoffTypeSchema.{u, v}
  residual : InternalHandoffTypeSchema.{u, v}
  reviewGate : InternalHandoffTypeSchema.{u, v}
  input_target_consumer : input.target.role = InternalHandoffRole.consumer
  output_source_producer : output.source.role = InternalHandoffRole.producer
  cutState_source_interface : cutState.source.role = InternalHandoffRole.interface
  residual_source_interface : residual.source.role = InternalHandoffRole.interface
  reviewGate_source_regulator :
    reviewGate.source.role = InternalHandoffRole.regulator
  input_direction_generatorToHub :
    input.direction = InternalHandoffDirection.generatorToHub
  output_direction_hubToInternalHandoff :
    output.direction = InternalHandoffDirection.hubToInternalHandoff
  cutState_direction_hubToInternalHandoff :
    cutState.direction = InternalHandoffDirection.hubToInternalHandoff
  residual_direction_hubToInternalHandoff :
    residual.direction = InternalHandoffDirection.hubToInternalHandoff
  reviewGate_direction_regulatorToInterface :
    reviewGate.direction = InternalHandoffDirection.regulatorToInterface
  output_release_eq_input : output.releaseCertificate = input.releaseCertificate
  cutState_release_eq_input : cutState.releaseCertificate = input.releaseCertificate
  residual_release_eq_input : residual.releaseCertificate = input.releaseCertificate
  reviewGate_release_eq_input : reviewGate.releaseCertificate = input.releaseCertificate

namespace InternalHubInterfaceStandard

def schema (standard : InternalHubInterfaceStandard)
    (channel : InternalHubInterfaceChannel) : InternalHandoffTypeSchema.{u, v} :=
  match channel with
  | InternalHubInterfaceChannel.input => standard.input
  | InternalHubInterfaceChannel.output => standard.output
  | InternalHubInterfaceChannel.cutState => standard.cutState
  | InternalHubInterfaceChannel.residual => standard.residual
  | InternalHubInterfaceChannel.reviewGate => standard.reviewGate

def releaseCertificate (standard : InternalHubInterfaceStandard) :
    GeneratorRequestApproximationReleaseCertificate :=
  standard.input.releaseCertificate

def gate (standard : InternalHubInterfaceStandard) : RealDataFirstUnlockGate :=
  standard.input.gate

def lock (standard : InternalHubInterfaceStandard) : SinglePreparationLock :=
  standard.input.lock

def request (standard : InternalHubInterfaceStandard) : GeneratorRequestProfile :=
  standard.input.request

def global (standard : InternalHubInterfaceStandard) :
    GlobalTheoryApproximationState :=
  standard.input.global

def limitProfile (standard : InternalHubInterfaceStandard) :
    PillarAToBLimitApproximationProfile :=
  standard.input.limitProfile

theorem input_target_role
    (standard : InternalHubInterfaceStandard) :
    standard.input.target.role = InternalHandoffRole.consumer :=
  standard.input_target_consumer

theorem output_source_role
    (standard : InternalHubInterfaceStandard) :
    standard.output.source.role = InternalHandoffRole.producer :=
  standard.output_source_producer

theorem cutState_source_role
    (standard : InternalHubInterfaceStandard) :
    standard.cutState.source.role = InternalHandoffRole.interface :=
  standard.cutState_source_interface

theorem residual_source_role
    (standard : InternalHubInterfaceStandard) :
    standard.residual.source.role = InternalHandoffRole.interface :=
  standard.residual_source_interface

theorem reviewGate_source_role
    (standard : InternalHubInterfaceStandard) :
    standard.reviewGate.source.role = InternalHandoffRole.regulator :=
  standard.reviewGate_source_regulator

theorem input_direction
    (standard : InternalHubInterfaceStandard) :
    standard.input.direction = InternalHandoffDirection.generatorToHub :=
  standard.input_direction_generatorToHub

theorem output_direction
    (standard : InternalHubInterfaceStandard) :
    standard.output.direction = InternalHandoffDirection.hubToInternalHandoff :=
  standard.output_direction_hubToInternalHandoff

theorem cutState_direction
    (standard : InternalHubInterfaceStandard) :
    standard.cutState.direction = InternalHandoffDirection.hubToInternalHandoff :=
  standard.cutState_direction_hubToInternalHandoff

theorem residual_direction
    (standard : InternalHubInterfaceStandard) :
    standard.residual.direction = InternalHandoffDirection.hubToInternalHandoff :=
  standard.residual_direction_hubToInternalHandoff

theorem reviewGate_direction
    (standard : InternalHubInterfaceStandard) :
    standard.reviewGate.direction = InternalHandoffDirection.regulatorToInterface :=
  standard.reviewGate_direction_regulatorToInterface

theorem output_releaseCertificate_eq
    (standard : InternalHubInterfaceStandard) :
    standard.output.releaseCertificate = standard.releaseCertificate :=
  standard.output_release_eq_input

theorem cutState_releaseCertificate_eq
    (standard : InternalHubInterfaceStandard) :
    standard.cutState.releaseCertificate = standard.releaseCertificate :=
  standard.cutState_release_eq_input

theorem residual_releaseCertificate_eq
    (standard : InternalHubInterfaceStandard) :
    standard.residual.releaseCertificate = standard.releaseCertificate :=
  standard.residual_release_eq_input

theorem reviewGate_releaseCertificate_eq
    (standard : InternalHubInterfaceStandard) :
    standard.reviewGate.releaseCertificate = standard.releaseCertificate :=
  standard.reviewGate_release_eq_input

theorem output_global_eq_input_global
    (standard : InternalHubInterfaceStandard) :
    standard.output.global = standard.input.global := by
  change standard.output.releaseCertificate.global =
    standard.input.releaseCertificate.global
  rw [standard.output_release_eq_input]

theorem cutState_global_eq_input_global
    (standard : InternalHubInterfaceStandard) :
    standard.cutState.global = standard.input.global := by
  change standard.cutState.releaseCertificate.global =
    standard.input.releaseCertificate.global
  rw [standard.cutState_release_eq_input]

theorem residual_global_eq_input_global
    (standard : InternalHubInterfaceStandard) :
    standard.residual.global = standard.input.global := by
  change standard.residual.releaseCertificate.global =
    standard.input.releaseCertificate.global
  rw [standard.residual_release_eq_input]

theorem reviewGate_global_eq_input_global
    (standard : InternalHubInterfaceStandard) :
    standard.reviewGate.global = standard.input.global := by
  change standard.reviewGate.releaseCertificate.global =
    standard.input.releaseCertificate.global
  rw [standard.reviewGate_release_eq_input]

theorem request_global_eq_lock
    (standard : InternalHubInterfaceStandard) :
    standard.request.global = standard.lock.state :=
  standard.input.request_global_eq_lock

theorem gate_global_eq_limit_state
    (standard : InternalHubInterfaceStandard) :
    standard.gate.global = standard.limitProfile.state :=
  standard.input.gate_global_eq_limit_state

end InternalHubInterfaceStandard

structure InternalHubInterfaceTypedRecords
    (standard : InternalHubInterfaceStandard.{u, v}) where
  input : InternalHandoffTypedRecord standard.input
  output : InternalHandoffTypedRecord standard.output
  cutState : InternalHandoffTypedRecord standard.cutState
  residual : InternalHandoffTypedRecord standard.residual
  reviewGate : InternalHandoffTypedRecord standard.reviewGate

namespace InternalHubInterfaceTypedRecords

variable {standard : InternalHubInterfaceStandard.{u, v}}

def recordFor
    (records : InternalHubInterfaceTypedRecords standard)
    (channel : InternalHubInterfaceChannel) :
    InternalHandoffTypedRecord (standard.schema channel) :=
  match channel with
  | InternalHubInterfaceChannel.input => records.input
  | InternalHubInterfaceChannel.output => records.output
  | InternalHubInterfaceChannel.cutState => records.cutState
  | InternalHubInterfaceChannel.residual => records.residual
  | InternalHubInterfaceChannel.reviewGate => records.reviewGate

theorem input_request_global_eq_lock
    (_records : InternalHubInterfaceTypedRecords standard) :
    standard.input.request.global = standard.input.lock.state :=
  standard.input.request_global_eq_lock

theorem output_global_eq_input_global
    (_records : InternalHubInterfaceTypedRecords standard) :
    standard.output.global = standard.input.global :=
  standard.output_global_eq_input_global

theorem residual_global_eq_input_global
    (_records : InternalHubInterfaceTypedRecords standard) :
    standard.residual.global = standard.input.global :=
  standard.residual_global_eq_input_global

end InternalHubInterfaceTypedRecords

structure InternalHubInterfacePortContracts
    (standard : InternalHubInterfaceStandard.{u, v}) where
  input : InternalHandoffPortContract standard.input
  output : InternalHandoffPortContract standard.output
  cutState : InternalHandoffPortContract standard.cutState
  residual : InternalHandoffPortContract standard.residual
  reviewGate : InternalHandoffPortContract standard.reviewGate

namespace InternalHubInterfacePortContracts

variable {standard : InternalHubInterfaceStandard.{u, v}}

def contractFor
    (contracts : InternalHubInterfacePortContracts standard)
    (channel : InternalHubInterfaceChannel) :
    InternalHandoffPortContract (standard.schema channel) :=
  match channel with
  | InternalHubInterfaceChannel.input => contracts.input
  | InternalHubInterfaceChannel.output => contracts.output
  | InternalHubInterfaceChannel.cutState => contracts.cutState
  | InternalHubInterfaceChannel.residual => contracts.residual
  | InternalHubInterfaceChannel.reviewGate => contracts.reviewGate

def typedRecords
    (contracts : InternalHubInterfacePortContracts standard)
    (inputPayload : standard.input.payloadType)
    (outputPayload : standard.output.payloadType)
    (cutStatePayload : standard.cutState.payloadType)
    (residualPayload : standard.residual.payloadType)
    (reviewGatePayload : standard.reviewGate.payloadType) :
    InternalHubInterfaceTypedRecords standard where
  input := contracts.input.typedRecord inputPayload
  output := contracts.output.typedRecord outputPayload
  cutState := contracts.cutState.typedRecord cutStatePayload
  residual := contracts.residual.typedRecord residualPayload
  reviewGate := contracts.reviewGate.typedRecord reviewGatePayload

theorem input_consumer_target
    (contracts : InternalHubInterfacePortContracts standard) :
    contracts.input.consumerEndpoint.role = InternalHandoffRole.consumer := by
  calc
    contracts.input.consumerEndpoint.role = standard.input.target.role :=
      contracts.input.consumer_role_eq_target
    _ = InternalHandoffRole.consumer := standard.input_target_role

theorem output_producer_source
    (contracts : InternalHubInterfacePortContracts standard) :
    contracts.output.producerEndpoint.role = InternalHandoffRole.producer := by
  calc
    contracts.output.producerEndpoint.role = standard.output.source.role :=
      contracts.output.producer_role_eq_source
    _ = InternalHandoffRole.producer := standard.output_source_role

theorem reviewGate_regulator_source
    (contracts : InternalHubInterfacePortContracts standard) :
    contracts.reviewGate.producerEndpoint.role = InternalHandoffRole.regulator := by
  calc
    contracts.reviewGate.producerEndpoint.role = standard.reviewGate.source.role :=
      contracts.reviewGate.producer_role_eq_source
    _ = InternalHandoffRole.regulator := standard.reviewGate_source_role

end InternalHubInterfacePortContracts

end CNNA.PillarA.Handoff
