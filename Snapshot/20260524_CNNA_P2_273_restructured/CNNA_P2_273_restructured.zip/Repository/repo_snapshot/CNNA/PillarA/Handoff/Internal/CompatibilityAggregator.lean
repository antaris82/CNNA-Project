import CNNA.PillarA.Generator.CompatibilityAggregator
import CNNA.PillarA.Handoff.Internal.GeneratorSpineSkeleton

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalHandoffCompatibilityAggregatorStatus where
  | generatorSpineFacadeAttached
  deriving DecidableEq, Repr

inductive InternalHandoffCompatibilityConsumerCutoverStatus where
  | noConsumerCutover
  deriving DecidableEq, Repr

inductive InternalHandoffCompatibilityImportRouteStatus where
  | legacyRoutesRetained
  | neutralAggregatorVisible
  deriving DecidableEq, Repr

structure InternalHandoffCompatibilityAggregator where
  spineSkeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}
  generatorAggregator :
    CNNA.PillarA.Generator.NeutralGeneratorCompatibilityAggregator
  status : InternalHandoffCompatibilityAggregatorStatus
  consumerCutover : InternalHandoffCompatibilityConsumerCutoverStatus
  importRouteStatus : InternalHandoffCompatibilityImportRouteStatus
  typedSurface_eq : generatorAggregator.typedSurface = spineSkeleton.typedSurface
  state_eq : generatorAggregator.state = spineSkeleton.state
  status_eq :
    status =
      InternalHandoffCompatibilityAggregatorStatus.generatorSpineFacadeAttached
  consumerCutover_eq :
    consumerCutover =
      InternalHandoffCompatibilityConsumerCutoverStatus.noConsumerCutover
  importRouteStatus_eq :
    importRouteStatus =
      InternalHandoffCompatibilityImportRouteStatus.legacyRoutesRetained

namespace InternalHandoffCompatibilityAggregator

def state (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    GlobalTheoryApproximationState :=
  aggregator.spineSkeleton.state

def generatorState
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    GlobalTheoryApproximationState :=
  aggregator.generatorAggregator.state

def request (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorRequestProfile :=
  aggregator.spineSkeleton.request

def output (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorOutputProfile :=
  aggregator.spineSkeleton.output

theorem typedSurface_matches_spine
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.generatorAggregator.typedSurface =
      aggregator.spineSkeleton.typedSurface :=
  aggregator.typedSurface_eq

theorem generator_state_eq_internal_state
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.generatorState = aggregator.state :=
  aggregator.state_eq

theorem status_is_generatorSpineFacadeAttached
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.status =
      InternalHandoffCompatibilityAggregatorStatus.generatorSpineFacadeAttached :=
  aggregator.status_eq

theorem consumerCutover_is_noConsumerCutover
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.consumerCutover =
      InternalHandoffCompatibilityConsumerCutoverStatus.noConsumerCutover :=
  aggregator.consumerCutover_eq

theorem importRouteStatus_is_legacyRoutesRetained
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.importRouteStatus =
      InternalHandoffCompatibilityImportRouteStatus.legacyRoutesRetained :=
  aggregator.importRouteStatus_eq

theorem generator_route_is_retained
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.generatorAggregator.routeExposure =
      CNNA.PillarA.Generator.NeutralGeneratorCompatibilityRouteExposure.retainedCompatibilityRoute :=
  aggregator.generatorAggregator.routeExposure_is_retainedCompatibilityRoute

theorem generator_cutover_is_noCutover
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.generatorAggregator.cutoverStatus =
      CNNA.PillarA.Generator.NeutralGeneratorCompatibilityCutoverStatus.noCutover :=
  aggregator.generatorAggregator.cutoverStatus_is_noCutover

theorem spine_exposure_is_aInternalOnly
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.spineSkeleton.exposureStatus =
      InternalGeneratorSpineExposureStatus.aInternalOnly :=
  aggregator.spineSkeleton.exposureStatus_is_aInternalOnly

theorem request_global_eq_internal_state
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.request.global = aggregator.state :=
  aggregator.spineSkeleton.generator_request_global_eq_internal_state

theorem output_state_eq_internal_state
    (aggregator : InternalHandoffCompatibilityAggregator.{u, v, w}) :
    aggregator.output.state = aggregator.state :=
  aggregator.spineSkeleton.generator_output_state_eq_internal_state

end InternalHandoffCompatibilityAggregator

end CNNA.PillarA.Handoff
