import CNNA.PillarA.Handoff.Internal.SpineReleaseCertificate
import CNNA.PillarA.Handoff.Outputs.A_to_B

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w x

inductive ExternalPillarATarget where
  | pillarB
  | pillarC
  | pillarD
  | pillarE
  deriving DecidableEq, Repr

inductive ExternalEndpointReleaseStatus where
  | declared
  | released
  | blocked
  deriving DecidableEq, Repr

inductive ExternalEndpointDerivationMode where
  | fromInternalSpine
  | blockedByMissingSpine
  | comparisonOnly
  deriving DecidableEq, Repr

structure ExternalAToBEndpointContract where
  spine : InternalHandoffSpineReleaseCertificate.{u, v, w}
  stableOutputRecord : InternalHandoffTypedRecord spine.standard.output
  target : ExternalPillarATarget
  status : ExternalEndpointReleaseStatus
  derivationMode : ExternalEndpointDerivationMode
  releaseCertificate : GeneratorRequestApproximationReleaseCertificate
  stableOutputRecord_eq_catalog :
    stableOutputRecord = spine.catalog.records.stableOutputRecord
  target_is_pillarB : target = ExternalPillarATarget.pillarB
  status_released : status = ExternalEndpointReleaseStatus.released
  derivationMode_fromInternalSpine :
    derivationMode = ExternalEndpointDerivationMode.fromInternalSpine
  releaseCertificate_eq_spine : releaseCertificate = spine.releaseCertificate
  spine_status_released :
    spine.status = InternalHandoffSpineReleaseStatus.released

namespace ExternalAToBEndpointContract

def standard (contract : ExternalAToBEndpointContract) :
    InternalHubInterfaceStandard.{u, v} :=
  contract.spine.standard

def outputSchema (contract : ExternalAToBEndpointContract) :
    InternalHandoffTypeSchema.{u, v} :=
  contract.standard.output

def global (contract : ExternalAToBEndpointContract) :
    GlobalTheoryApproximationState :=
  contract.releaseCertificate.global

def limitProfile (contract : ExternalAToBEndpointContract) :
    PillarAToBLimitApproximationProfile :=
  contract.releaseCertificate.limitProfile

theorem target_is_B (contract : ExternalAToBEndpointContract) :
    contract.target = ExternalPillarATarget.pillarB :=
  contract.target_is_pillarB

theorem status_is_released (contract : ExternalAToBEndpointContract) :
    contract.status = ExternalEndpointReleaseStatus.released :=
  contract.status_released

theorem derivationMode_is_fromInternalSpine
    (contract : ExternalAToBEndpointContract) :
    contract.derivationMode = ExternalEndpointDerivationMode.fromInternalSpine :=
  contract.derivationMode_fromInternalSpine

theorem spine_status_is_released
    (contract : ExternalAToBEndpointContract) :
    contract.spine.status = InternalHandoffSpineReleaseStatus.released :=
  contract.spine_status_released

theorem releaseCertificate_matches_spine
    (contract : ExternalAToBEndpointContract) :
    contract.releaseCertificate = contract.spine.releaseCertificate :=
  contract.releaseCertificate_eq_spine

theorem releaseCertificate_matches_standard
    (contract : ExternalAToBEndpointContract) :
    contract.releaseCertificate = contract.standard.releaseCertificate := by
  calc
    contract.releaseCertificate = contract.spine.releaseCertificate :=
      contract.releaseCertificate_eq_spine
    _ = contract.standard.releaseCertificate :=
      contract.spine.releaseCertificate_matches_standard

theorem global_eq_standard_global
    (contract : ExternalAToBEndpointContract) :
    contract.global = contract.standard.global := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.global
    contract.releaseCertificate_matches_standard

theorem limitProfile_eq_standard_limitProfile
    (contract : ExternalAToBEndpointContract) :
    contract.limitProfile = contract.standard.limitProfile := by
  exact congrArg GeneratorRequestApproximationReleaseCertificate.limitProfile
    contract.releaseCertificate_matches_standard

theorem outputSchema_global_eq_contract_global
    (contract : ExternalAToBEndpointContract) :
    contract.outputSchema.global = contract.global := by
  calc
    contract.outputSchema.global = contract.standard.global :=
      contract.standard.output_global_eq_input_global
    _ = contract.global :=
      Eq.symm contract.global_eq_standard_global

theorem stableOutputRecord_is_catalog_record
    (contract : ExternalAToBEndpointContract) :
    contract.stableOutputRecord = contract.spine.catalog.records.stableOutputRecord :=
  contract.stableOutputRecord_eq_catalog

end ExternalAToBEndpointContract

structure ExternalAToBEndpointProfile
    (Cell : Nat → Type x) [CNNA.PillarA.Foundation.SubstrateClass Cell]
    (T : CNNA.PillarA.ToC.TruncatedFamily Cell) where
  contract : ExternalAToBEndpointContract
  handoff : ABHandoffStrong Cell T
  payload_eq_source_exportData : handoff.payload = handoff.source.exportData

namespace ExternalAToBEndpointProfile

variable {Cell : Nat → Type x} [CNNA.PillarA.Foundation.SubstrateClass Cell]
variable {T : CNNA.PillarA.ToC.TruncatedFamily Cell}

def source (profile : ExternalAToBEndpointProfile Cell T) :
    Step1MathDataStrong Cell T :=
  profile.handoff.source

def payload (profile : ExternalAToBEndpointProfile Cell T) :
    SectorExportStrong Cell T :=
  profile.handoff.payload

def aToBInput (profile : ExternalAToBEndpointProfile Cell T) :
    SectorExportStrong Cell T :=
  profile.handoff.aToBInput

def global (profile : ExternalAToBEndpointProfile Cell T) :
    GlobalTheoryApproximationState :=
  profile.contract.global

def limitProfile (profile : ExternalAToBEndpointProfile Cell T) :
    PillarAToBLimitApproximationProfile :=
  profile.contract.limitProfile

theorem target_is_B
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.contract.target = ExternalPillarATarget.pillarB :=
  profile.contract.target_is_B

theorem status_is_released
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.contract.status = ExternalEndpointReleaseStatus.released :=
  profile.contract.status_is_released

theorem derivationMode_is_fromInternalSpine
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.contract.derivationMode =
      ExternalEndpointDerivationMode.fromInternalSpine :=
  profile.contract.derivationMode_is_fromInternalSpine

theorem spine_status_is_released
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.contract.spine.status = InternalHandoffSpineReleaseStatus.released :=
  profile.contract.spine_status_is_released

theorem payload_eq_source_exportData_theorem
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.payload = profile.source.exportData := by
  exact profile.payload_eq_source_exportData

theorem aToBInput_eq_payload
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.aToBInput = profile.payload := by
  rfl

theorem aToBInput_eq_source_exportData
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.aToBInput = profile.source.exportData := by
  exact profile.payload_eq_source_exportData

theorem global_eq_contract_global
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.global = profile.contract.global := by
  rfl

theorem global_eq_standard_global
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.global = profile.contract.standard.global :=
  profile.contract.global_eq_standard_global

theorem limitProfile_eq_standard_limitProfile
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.limitProfile = profile.contract.standard.limitProfile :=
  profile.contract.limitProfile_eq_standard_limitProfile

theorem outputSchema_global_eq_profile_global
    (profile : ExternalAToBEndpointProfile Cell T) :
    profile.contract.outputSchema.global = profile.global :=
  profile.contract.outputSchema_global_eq_contract_global

end ExternalAToBEndpointProfile

end CNNA.PillarA.Handoff
