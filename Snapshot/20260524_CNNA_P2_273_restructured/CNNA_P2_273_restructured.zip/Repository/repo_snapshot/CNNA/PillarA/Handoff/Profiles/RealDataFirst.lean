import CNNA.PillarA.Handoff.Profiles.ComplementTower

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u

abbrev GlobalTheoryApproximationState :=
  CNNA.PillarA.Generator.GlobalTheoryApproximationState

abbrev SinglePreparationLock :=
  CNNA.PillarA.Generator.SinglePreparationLock

abbrev GeneratorRequestProfile :=
  CNNA.PillarA.Generator.GeneratorRequestProfile

abbrev RequestedDataTier :=
  CNNA.PillarA.Generator.RequestedDataTier

abbrev RequestStatus :=
  CNNA.PillarA.Generator.RequestStatus

inductive ReleaseTargetKind where
  | generatorRequest
  | hub
  | interface
  | handoff
  | limitTower
  deriving DecidableEq, Repr

structure DataTierArtifact (tier : RequestedDataTier) where
  artifactType : Type u
  witness : Nonempty artifactType

namespace DataTierArtifact

variable {tier : RequestedDataTier}

theorem nonempty (artifact : DataTierArtifact tier) :
    Nonempty artifact.artifactType :=
  artifact.witness

end DataTierArtifact

structure ComputedArtifactChecklist where
  carrier : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.carrier))
  approximant : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.approximant))
  matrix : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.matrix))
  dirichlet : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.dirichlet))
  dtn : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.dtn))
  operator : Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.operator))
  limitProfile :
    Option (DataTierArtifact (CNNA.PillarA.Generator.RequestedDataTier.limitProfile))

structure DataTierReleaseCertificate where
  global : GlobalTheoryApproximationState
  target : ReleaseTargetKind
  requestedTier : RequestedDataTier
  artifact : DataTierArtifact requestedTier

namespace DataTierReleaseCertificate

def releasedTier (certificate : DataTierReleaseCertificate) :
    RequestedDataTier :=
  certificate.requestedTier

theorem releasedTier_eq_requested
    (certificate : DataTierReleaseCertificate) :
    certificate.releasedTier = certificate.requestedTier := by
  rfl

theorem has_artifact (certificate : DataTierReleaseCertificate) :
    Nonempty certificate.artifact.artifactType :=
  certificate.artifact.witness

end DataTierReleaseCertificate

structure NonClosingDataPlaceholder where
  global : GlobalTheoryApproximationState
  target : ReleaseTargetKind
  requestedTier : RequestedDataTier
  status : RequestStatus
  nonClosingStatus :
    status = CNNA.PillarA.Generator.RequestStatus.blockedUntilRealData ∨
      status = CNNA.PillarA.Generator.RequestStatus.quarantinedSimulationControl

namespace NonClosingDataPlaceholder

theorem status_blocks_closure (placeholder : NonClosingDataPlaceholder) :
    placeholder.status = CNNA.PillarA.Generator.RequestStatus.blockedUntilRealData ∨
      placeholder.status = CNNA.PillarA.Generator.RequestStatus.quarantinedSimulationControl :=
  placeholder.nonClosingStatus

end NonClosingDataPlaceholder

structure RealDataFirstUnlockGate where
  lock : SinglePreparationLock
  certificate : DataTierReleaseCertificate
  certificate_matches_lock : certificate.global = lock.state

namespace RealDataFirstUnlockGate

def global (gate : RealDataFirstUnlockGate) :
    GlobalTheoryApproximationState :=
  gate.lock.state

def releasedTier (gate : RealDataFirstUnlockGate) :
    RequestedDataTier :=
  gate.certificate.requestedTier

theorem certificate_global_eq_lock
    (gate : RealDataFirstUnlockGate) :
    gate.certificate.global = gate.lock.state :=
  gate.certificate_matches_lock

theorem certificate_has_artifact
    (gate : RealDataFirstUnlockGate) :
    Nonempty gate.certificate.artifact.artifactType :=
  gate.certificate.has_artifact

end RealDataFirstUnlockGate

structure GeneratorRequestReleaseCertificate where
  gate : RealDataFirstUnlockGate
  request : GeneratorRequestProfile
  request_global_matches_gate : request.global = gate.global
  request_tier_matches_certificate :
    request.requestedDataTier = gate.certificate.requestedTier

namespace GeneratorRequestReleaseCertificate

theorem request_global_eq_lock
    (certificate : GeneratorRequestReleaseCertificate) :
    certificate.request.global = certificate.gate.lock.state := by
  calc
    certificate.request.global = certificate.gate.global :=
      certificate.request_global_matches_gate
    _ = certificate.gate.lock.state := by
      rfl

theorem request_tier_eq_released
    (certificate : GeneratorRequestReleaseCertificate) :
    certificate.request.requestedDataTier = certificate.gate.releasedTier := by
  change certificate.request.requestedDataTier = certificate.gate.certificate.requestedTier
  exact certificate.request_tier_matches_certificate

end GeneratorRequestReleaseCertificate

structure LimitTowerReleaseCertificate where
  limitProfile : PillarAToBLimitApproximationProfile
  gate : RealDataFirstUnlockGate
  gate_matches_limit_state : gate.global = limitProfile.state
  gate_releases_limit_profile :
    gate.certificate.requestedTier = CNNA.PillarA.Generator.RequestedDataTier.limitProfile

namespace LimitTowerReleaseCertificate

theorem gate_global_eq_limit_state
    (certificate : LimitTowerReleaseCertificate) :
    certificate.gate.global = certificate.limitProfile.state :=
  certificate.gate_matches_limit_state

theorem released_tier_is_limit_profile
    (certificate : LimitTowerReleaseCertificate) :
    certificate.gate.releasedTier = CNNA.PillarA.Generator.RequestedDataTier.limitProfile := by
  change certificate.gate.certificate.requestedTier =
    CNNA.PillarA.Generator.RequestedDataTier.limitProfile
  exact certificate.gate_releases_limit_profile

end LimitTowerReleaseCertificate

end CNNA.PillarA.Handoff
