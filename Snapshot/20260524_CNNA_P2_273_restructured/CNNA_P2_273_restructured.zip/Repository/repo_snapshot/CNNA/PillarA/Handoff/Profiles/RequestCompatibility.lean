import CNNA.PillarA.Handoff.Profiles.RealDataFirst

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

structure GeneratorRequestProfileFacade where
  globalProfile : GlobalApproximationHandoffProfile
  request : GeneratorRequestProfile
  request_global_matches_profile : request.global = globalProfile.state

namespace GeneratorRequestProfileFacade

def state (facade : GeneratorRequestProfileFacade) :
    GlobalTheoryApproximationState :=
  facade.globalProfile.state

def requestedTier (facade : GeneratorRequestProfileFacade) :
    RequestedDataTier :=
  facade.request.requestedDataTier

theorem request_global_eq_state
    (facade : GeneratorRequestProfileFacade) :
    facade.request.global = facade.state := by
  change facade.request.global = facade.globalProfile.state
  exact facade.request_global_matches_profile

theorem state_eq_lock
    (facade : GeneratorRequestProfileFacade) :
    facade.state = facade.globalProfile.lock.state := by
  rfl

theorem request_global_eq_lock
    (facade : GeneratorRequestProfileFacade) :
    facade.request.global = facade.globalProfile.lock.state := by
  calc
    facade.request.global = facade.state :=
      facade.request_global_eq_state
    _ = facade.globalProfile.lock.state := by
      rfl

end GeneratorRequestProfileFacade

structure GeneratorRequestCompatibilityFacade where
  profileFacade : GeneratorRequestProfileFacade
  gate : RealDataFirstUnlockGate
  gate_global_matches_profile : gate.global = profileFacade.state
  request_tier_matches_gate :
    profileFacade.request.requestedDataTier = gate.certificate.requestedTier

namespace GeneratorRequestCompatibilityFacade

def state (facade : GeneratorRequestCompatibilityFacade) :
    GlobalTheoryApproximationState :=
  facade.profileFacade.state

def requestedTier (facade : GeneratorRequestCompatibilityFacade) :
    RequestedDataTier :=
  facade.profileFacade.requestedTier

theorem gate_global_eq_state
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.gate.global = facade.state := by
  change facade.gate.global = facade.profileFacade.state
  exact facade.gate_global_matches_profile

theorem request_global_eq_gate
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.profileFacade.request.global = facade.gate.global := by
  calc
    facade.profileFacade.request.global = facade.profileFacade.state :=
      facade.profileFacade.request_global_eq_state
    _ = facade.gate.global :=
      Eq.symm facade.gate_global_matches_profile

theorem request_tier_eq_released
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.profileFacade.request.requestedDataTier = facade.gate.releasedTier := by
  change facade.profileFacade.request.requestedDataTier =
    facade.gate.certificate.requestedTier
  exact facade.request_tier_matches_gate

def releaseCertificate
    (facade : GeneratorRequestCompatibilityFacade) :
    GeneratorRequestReleaseCertificate where
  gate := facade.gate
  request := facade.profileFacade.request
  request_global_matches_gate := facade.request_global_eq_gate
  request_tier_matches_certificate := facade.request_tier_matches_gate

theorem releaseCertificate_gate
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.releaseCertificate.gate = facade.gate := by
  rfl

theorem releaseCertificate_request
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.releaseCertificate.request = facade.profileFacade.request := by
  rfl

theorem releaseCertificate_tier
    (facade : GeneratorRequestCompatibilityFacade) :
    facade.releaseCertificate.request.requestedDataTier =
      facade.releaseCertificate.gate.certificate.requestedTier := by
  change facade.profileFacade.request.requestedDataTier =
    facade.gate.certificate.requestedTier
  exact facade.request_tier_matches_gate

end GeneratorRequestCompatibilityFacade

end CNNA.PillarA.Handoff
