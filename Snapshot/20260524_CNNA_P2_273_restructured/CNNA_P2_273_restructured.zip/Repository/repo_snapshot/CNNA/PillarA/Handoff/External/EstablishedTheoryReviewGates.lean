import CNNA.PillarA.Handoff.External.AResidualProvenanceContract

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

inductive ExternalEstablishedTheoryCutBlock where
  | aqft
  | openQuantumSystems
  | geometry
  | spacetimeInterface
  | matter
  deriving DecidableEq, Repr

inductive ExternalEstablishedTheoryReferenceRole where
  | comparisonReadoutTarget
  | falsificationTarget
  deriving DecidableEq, Repr

inductive ExternalEstablishedTheoryGateStatus where
  | active
  | blocked
  deriving DecidableEq, Repr

inductive ExternalEstablishedTheoryPrimitiveImportStatus where
  | noPrimitiveImport
  deriving DecidableEq, Repr

inductive ExternalEstablishedTheoryMismatchRoute where
  | naturalBackjumpOrFalsification
  deriving DecidableEq, Repr

inductive ExternalEstablishedTheoryPayloadClaimStatus where
  | reviewGateOnly
  deriving DecidableEq, Repr

structure ExternalEstablishedTheoryCutBlockReviewGate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  residualContract : ExternalAResidualProvenanceContract Cell T
  target : ExternalEstablishedTheoryCutBlock
  downstreamStage : ExternalAResidualDownstreamStage
  referenceRole : ExternalEstablishedTheoryReferenceRole
  gateStatus : ExternalEstablishedTheoryGateStatus
  primitiveImportStatus : ExternalEstablishedTheoryPrimitiveImportStatus
  mismatchRoute : ExternalEstablishedTheoryMismatchRoute
  payloadClaimStatus : ExternalEstablishedTheoryPayloadClaimStatus
  gateStatus_eq_active :
    gateStatus = ExternalEstablishedTheoryGateStatus.active
  primitiveImportStatus_eq_noPrimitiveImport :
    primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport
  mismatchRoute_eq_naturalBackjumpOrFalsification :
    mismatchRoute =
      ExternalEstablishedTheoryMismatchRoute.naturalBackjumpOrFalsification
  payloadClaimStatus_eq_reviewGateOnly :
    payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly

namespace ExternalEstablishedTheoryCutBlockReviewGate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def global (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    GlobalTheoryApproximationState :=
  gate.residualContract.global

def limitProfile (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    PillarAToBLimitApproximationProfile :=
  gate.residualContract.limitProfile

def rawHandoff (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    ABHandoffStrong Cell T :=
  gate.residualContract.rawHandoff

def regulatedHandoff (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    ABHandoffStrong Cell T :=
  gate.residualContract.regulatedHandoff

theorem gateStatus_is_active
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.gateStatus = ExternalEstablishedTheoryGateStatus.active :=
  gate.gateStatus_eq_active

theorem primitiveImportStatus_is_noPrimitiveImport
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  gate.primitiveImportStatus_eq_noPrimitiveImport

theorem mismatchRoute_is_naturalBackjumpOrFalsification
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.mismatchRoute =
      ExternalEstablishedTheoryMismatchRoute.naturalBackjumpOrFalsification :=
  gate.mismatchRoute_eq_naturalBackjumpOrFalsification

theorem payloadClaimStatus_is_reviewGateOnly
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  gate.payloadClaimStatus_eq_reviewGateOnly

theorem residualContract_is_active
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.residualContract.contractStatus =
      ExternalAResidualContractStatus.active :=
  gate.residualContract.contractStatus_is_active

theorem residualContract_rawHandoff_eq_regulatedHandoff
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.rawHandoff = gate.regulatedHandoff :=
  gate.residualContract.rawHandoff_eq_regulatedHandoff

theorem residualContract_noFoundationWrite
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.residualContract.auxiliary.foundationWriteStatus =
      ExternalABFoundationWriteStatus.noFoundationWrite :=
  gate.residualContract.noFoundationWrite

theorem residualContract_noPillarInternalWrite
    (gate : ExternalEstablishedTheoryCutBlockReviewGate Cell T) :
    gate.residualContract.auxiliary.pillarInternalWriteStatus =
      ExternalABPillarInternalWriteStatus.noPillarInternalWrite :=
  gate.residualContract.noPillarInternalWrite

end ExternalEstablishedTheoryCutBlockReviewGate

structure ExternalEstablishedTheoryCutBlockReviewCatalog
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  residualContract : ExternalAResidualProvenanceContract Cell T
  aqftGate : ExternalEstablishedTheoryCutBlockReviewGate Cell T
  oqsGate : ExternalEstablishedTheoryCutBlockReviewGate Cell T
  geometryGate : ExternalEstablishedTheoryCutBlockReviewGate Cell T
  spacetimeInterfaceGate : ExternalEstablishedTheoryCutBlockReviewGate Cell T
  matterGate : ExternalEstablishedTheoryCutBlockReviewGate Cell T
  aqftContract_eq : aqftGate.residualContract = residualContract
  oqsContract_eq : oqsGate.residualContract = residualContract
  geometryContract_eq : geometryGate.residualContract = residualContract
  spacetimeInterfaceContract_eq :
    spacetimeInterfaceGate.residualContract = residualContract
  matterContract_eq : matterGate.residualContract = residualContract
  aqftTarget_eq : aqftGate.target = ExternalEstablishedTheoryCutBlock.aqft
  oqsTarget_eq :
    oqsGate.target = ExternalEstablishedTheoryCutBlock.openQuantumSystems
  geometryTarget_eq :
    geometryGate.target = ExternalEstablishedTheoryCutBlock.geometry
  spacetimeInterfaceTarget_eq :
    spacetimeInterfaceGate.target =
      ExternalEstablishedTheoryCutBlock.spacetimeInterface
  matterTarget_eq : matterGate.target = ExternalEstablishedTheoryCutBlock.matter
  aqftStage_eq : aqftGate.downstreamStage = ExternalAResidualDownstreamStage.atPillarB
  oqsStage_eq : oqsGate.downstreamStage = ExternalAResidualDownstreamStage.bToC
  geometryStage_eq : geometryGate.downstreamStage = ExternalAResidualDownstreamStage.cToD
  spacetimeInterfaceStage_eq :
    spacetimeInterfaceGate.downstreamStage = ExternalAResidualDownstreamStage.dToE
  matterStage_eq : matterGate.downstreamStage = ExternalAResidualDownstreamStage.atPillarE

namespace ExternalEstablishedTheoryCutBlockReviewCatalog

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def gates (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    List (ExternalEstablishedTheoryCutBlockReviewGate Cell T) :=
  [catalog.aqftGate,
   catalog.oqsGate,
   catalog.geometryGate,
   catalog.spacetimeInterfaceGate,
   catalog.matterGate]

def global (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    GlobalTheoryApproximationState :=
  catalog.residualContract.global

def limitProfile (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    PillarAToBLimitApproximationProfile :=
  catalog.residualContract.limitProfile

theorem aqftTarget
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.aqftGate.target = ExternalEstablishedTheoryCutBlock.aqft :=
  catalog.aqftTarget_eq

theorem oqsTarget
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.oqsGate.target =
      ExternalEstablishedTheoryCutBlock.openQuantumSystems :=
  catalog.oqsTarget_eq

theorem geometryTarget
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.geometryGate.target = ExternalEstablishedTheoryCutBlock.geometry :=
  catalog.geometryTarget_eq

theorem spacetimeInterfaceTarget
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.spacetimeInterfaceGate.target =
      ExternalEstablishedTheoryCutBlock.spacetimeInterface :=
  catalog.spacetimeInterfaceTarget_eq

theorem matterTarget
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.matterGate.target = ExternalEstablishedTheoryCutBlock.matter :=
  catalog.matterTarget_eq

theorem aqftStage
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.aqftGate.downstreamStage =
      ExternalAResidualDownstreamStage.atPillarB :=
  catalog.aqftStage_eq

theorem oqsStage
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.oqsGate.downstreamStage = ExternalAResidualDownstreamStage.bToC :=
  catalog.oqsStage_eq

theorem geometryStage
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.geometryGate.downstreamStage =
      ExternalAResidualDownstreamStage.cToD :=
  catalog.geometryStage_eq

theorem spacetimeInterfaceStage
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.spacetimeInterfaceGate.downstreamStage =
      ExternalAResidualDownstreamStage.dToE :=
  catalog.spacetimeInterfaceStage_eq

theorem matterStage
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.matterGate.downstreamStage =
      ExternalAResidualDownstreamStage.atPillarE :=
  catalog.matterStage_eq

theorem aqft_noPrimitiveImport
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.aqftGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  catalog.aqftGate.primitiveImportStatus_is_noPrimitiveImport

theorem oqs_noPrimitiveImport
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.oqsGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  catalog.oqsGate.primitiveImportStatus_is_noPrimitiveImport

theorem geometry_noPrimitiveImport
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.geometryGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  catalog.geometryGate.primitiveImportStatus_is_noPrimitiveImport

theorem spacetimeInterface_noPrimitiveImport
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.spacetimeInterfaceGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  catalog.spacetimeInterfaceGate.primitiveImportStatus_is_noPrimitiveImport

theorem matter_noPrimitiveImport
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.matterGate.primitiveImportStatus =
      ExternalEstablishedTheoryPrimitiveImportStatus.noPrimitiveImport :=
  catalog.matterGate.primitiveImportStatus_is_noPrimitiveImport

theorem aqft_reviewGateOnly
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.aqftGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  catalog.aqftGate.payloadClaimStatus_is_reviewGateOnly

theorem oqs_reviewGateOnly
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.oqsGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  catalog.oqsGate.payloadClaimStatus_is_reviewGateOnly

theorem geometry_reviewGateOnly
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.geometryGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  catalog.geometryGate.payloadClaimStatus_is_reviewGateOnly

theorem spacetimeInterface_reviewGateOnly
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.spacetimeInterfaceGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  catalog.spacetimeInterfaceGate.payloadClaimStatus_is_reviewGateOnly

theorem matter_reviewGateOnly
    (catalog : ExternalEstablishedTheoryCutBlockReviewCatalog Cell T) :
    catalog.matterGate.payloadClaimStatus =
      ExternalEstablishedTheoryPayloadClaimStatus.reviewGateOnly :=
  catalog.matterGate.payloadClaimStatus_is_reviewGateOnly

end ExternalEstablishedTheoryCutBlockReviewCatalog

end CNNA.PillarA.Handoff
