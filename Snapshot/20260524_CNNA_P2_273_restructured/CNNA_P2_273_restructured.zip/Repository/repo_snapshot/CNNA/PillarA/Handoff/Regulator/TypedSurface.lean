import CNNA.PillarA.Handoff.FactorNode.Regulated
import CNNA.PillarA.Handoff.Inputs.BuildAll

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Generator

universe u

inductive BackreactionRegulatorSource where
  | pillarB
  | pillarC
  | pillarD
  | pillarE
  deriving DecidableEq, Repr

inductive BackreactionRegulatorSurfaceKind where
  | request
  | constraint
  | failure
  | update
  deriving DecidableEq, Repr

inductive BackreactionRegulatorWriteScope where
  | handoffRequestProfileData
  deriving DecidableEq, Repr

inductive BackreactionRegulatorFoundationWriteStatus where
  | noFoundationWrite
  deriving DecidableEq, Repr

inductive BackreactionRegulatorPillarInternalWriteStatus where
  | noPillarInternalWrite
  deriving DecidableEq, Repr

structure BackreactionRegulatorTypedSurface
    (source : BackreactionRegulatorSource)
    (target : HandoffFactorTarget)
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  node : RegulatedHandoffFactorNode target Cell T
  surfaceKind : BackreactionRegulatorSurfaceKind
  requestProfile : GeneratorRequestProfile
  requestProfile_eq : requestProfile = node.requestRelease.request
  globalState : GlobalTheoryApproximationState
  globalState_eq : globalState = node.global
  writeScope : BackreactionRegulatorWriteScope
  writeScope_eq :
    writeScope = BackreactionRegulatorWriteScope.handoffRequestProfileData
  foundationWriteStatus : BackreactionRegulatorFoundationWriteStatus
  foundationWriteStatus_eq :
    foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite
  pillarInternalWriteStatus : BackreactionRegulatorPillarInternalWriteStatus
  pillarInternalWriteStatus_eq :
    pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite

namespace BackreactionRegulatorTypedSurface

variable {source : BackreactionRegulatorSource}
variable {target : HandoffFactorTarget}
variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def factorNode
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    RegulatedHandoffFactorNode target Cell T :=
  surface.node

def lock
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    SinglePreparationLock :=
  surface.node.lock

def requestCertificate
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    GeneratorRequestApproximationReleaseCertificate :=
  surface.node.requestRelease

def outputCertificate
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    CNNA.PillarA.Generator.GeneratorOutputReleaseCertificate :=
  surface.node.outputRelease

theorem requestProfile_eq_node_request
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.requestProfile = surface.node.requestRelease.request :=
  surface.requestProfile_eq

theorem globalState_eq_node_global
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.globalState = surface.node.global :=
  surface.globalState_eq

theorem writeScope_is_handoffRequestProfileData
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.writeScope =
      BackreactionRegulatorWriteScope.handoffRequestProfileData :=
  surface.writeScope_eq

theorem noFoundationWrite
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  surface.foundationWriteStatus_eq

theorem noPillarInternalWrite
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  surface.pillarInternalWriteStatus_eq

theorem node_exposure_factorNodeOnly
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.node.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  surface.node.exposureStatus_factorNodeOnly

theorem output_state_eq_global
    (surface : BackreactionRegulatorTypedSurface source target Cell T) :
    surface.node.outputRelease.state = surface.node.global :=
  surface.node.output_state_eq_global

end BackreactionRegulatorTypedSurface

structure BackreactionRegulatorBranchTypedSurfaces
    (source : BackreactionRegulatorSource)
    (target : HandoffFactorTarget)
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  request : BackreactionRegulatorTypedSurface source target Cell T
  request_kind :
    request.surfaceKind = BackreactionRegulatorSurfaceKind.request
  constraint : BackreactionRegulatorTypedSurface source target Cell T
  constraint_kind :
    constraint.surfaceKind = BackreactionRegulatorSurfaceKind.constraint
  failure : BackreactionRegulatorTypedSurface source target Cell T
  failure_kind :
    failure.surfaceKind = BackreactionRegulatorSurfaceKind.failure
  update : BackreactionRegulatorTypedSurface source target Cell T
  update_kind :
    update.surfaceKind = BackreactionRegulatorSurfaceKind.update
  constraint_node_matches_request : constraint.node = request.node
  failure_node_matches_request : failure.node = request.node
  update_node_matches_request : update.node = request.node

namespace BackreactionRegulatorBranchTypedSurfaces

variable {source : BackreactionRegulatorSource}
variable {target : HandoffFactorTarget}
variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def node
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    RegulatedHandoffFactorNode target Cell T :=
  branch.request.node

theorem request_kind_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.request.surfaceKind = BackreactionRegulatorSurfaceKind.request :=
  branch.request_kind

theorem constraint_kind_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.constraint.surfaceKind = BackreactionRegulatorSurfaceKind.constraint :=
  branch.constraint_kind

theorem failure_kind_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.failure.surfaceKind = BackreactionRegulatorSurfaceKind.failure :=
  branch.failure_kind

theorem update_kind_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.update.surfaceKind = BackreactionRegulatorSurfaceKind.update :=
  branch.update_kind

theorem constraint_node_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.constraint.node = branch.node := by
  change branch.constraint.node = branch.request.node
  exact branch.constraint_node_matches_request

theorem failure_node_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.failure.node = branch.node := by
  change branch.failure.node = branch.request.node
  exact branch.failure_node_matches_request

theorem update_node_eq
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.update.node = branch.node := by
  change branch.update.node = branch.request.node
  exact branch.update_node_matches_request

theorem request_noFoundationWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.request.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  branch.request.noFoundationWrite

theorem constraint_noFoundationWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.constraint.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  branch.constraint.noFoundationWrite

theorem failure_noFoundationWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.failure.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  branch.failure.noFoundationWrite

theorem update_noFoundationWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.update.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  branch.update.noFoundationWrite

theorem request_noPillarInternalWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.request.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  branch.request.noPillarInternalWrite

theorem update_noPillarInternalWrite
    (branch : BackreactionRegulatorBranchTypedSurfaces source target Cell T) :
    branch.update.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  branch.update.noPillarInternalWrite

end BackreactionRegulatorBranchTypedSurfaces

abbrev BToARegulatorInput
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  BToAInput Cell T
    (BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarB
      HandoffFactorTarget.pillarAToB Cell T)

abbrev CToARegulatorInput
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  CToAInput Cell T
    (BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarC
      HandoffFactorTarget.pillarAToC Cell T)

abbrev DToARegulatorInput
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  DToAInput Cell T
    (BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarD
      HandoffFactorTarget.pillarAToD Cell T)

abbrev EToARegulatorInput
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  EToAInput Cell T
    (BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarE
      HandoffFactorTarget.pillarAToE Cell T)

structure BackreactionRegulatorTypedSurfaceMigrationBatch
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  bToA :
    BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarB
      HandoffFactorTarget.pillarAToB Cell T
  cToA :
    BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarC
      HandoffFactorTarget.pillarAToC Cell T
  dToA :
    BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarD
      HandoffFactorTarget.pillarAToD Cell T
  eToA :
    BackreactionRegulatorBranchTypedSurfaces
      BackreactionRegulatorSource.pillarE
      HandoffFactorTarget.pillarAToE Cell T
  cToA_node_matches_bToA : cToA.node.closed = bToA.node.closed
  dToA_node_matches_bToA : dToA.node.closed = bToA.node.closed
  eToA_node_matches_bToA : eToA.node.closed = bToA.node.closed

namespace BackreactionRegulatorTypedSurfaceMigrationBatch

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def sourceClosed
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    PillarAStep1Closed Cell T :=
  batch.bToA.node.closed

theorem cToA_closed_eq_source
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.cToA.node.closed = batch.sourceClosed := by
  change batch.cToA.node.closed = batch.bToA.node.closed
  exact batch.cToA_node_matches_bToA

theorem dToA_closed_eq_source
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.dToA.node.closed = batch.sourceClosed := by
  change batch.dToA.node.closed = batch.bToA.node.closed
  exact batch.dToA_node_matches_bToA

theorem eToA_closed_eq_source
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.eToA.node.closed = batch.sourceClosed := by
  change batch.eToA.node.closed = batch.bToA.node.closed
  exact batch.eToA_node_matches_bToA

theorem bToA_request_kind
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.bToA.request.surfaceKind = BackreactionRegulatorSurfaceKind.request :=
  batch.bToA.request_kind_eq

theorem cToA_update_noPillarInternalWrite
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.cToA.update.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  batch.cToA.update_noPillarInternalWrite

theorem dToA_request_noFoundationWrite
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.dToA.request.foundationWriteStatus =
      BackreactionRegulatorFoundationWriteStatus.noFoundationWrite :=
  batch.dToA.request_noFoundationWrite

theorem eToA_update_noPillarInternalWrite
    (batch : BackreactionRegulatorTypedSurfaceMigrationBatch Cell T) :
    batch.eToA.update.pillarInternalWriteStatus =
      BackreactionRegulatorPillarInternalWriteStatus.noPillarInternalWrite :=
  batch.eToA.update_noPillarInternalWrite

end BackreactionRegulatorTypedSurfaceMigrationBatch

end CNNA.PillarA.Handoff
