import CNNA.PillarA.Handoff.Outputs.BuildAll
import CNNA.PillarA.Handoff.Profiles.ReleaseCertificate
import CNNA.PillarA.Generator.OutputReleaseCertificate

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

inductive HandoffFactorTarget where
  | pillarAToB
  | pillarAToC
  | pillarAToD
  | pillarAToE
  | pillarAToCayleyDickson
  deriving DecidableEq, Repr

inductive HandoffFactorExposureStatus where
  | factorNodeOnly
  | downstreamConsumerReleased
  deriving DecidableEq, Repr

structure RegulatedHandoffFactorNode (target : HandoffFactorTarget)
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  closed : PillarAStep1Closed Cell T
  requestRelease : GeneratorRequestApproximationReleaseCertificate
  outputRelease : CNNA.PillarA.Generator.GeneratorOutputReleaseCertificate
  output_state_matches_request : outputRelease.state = requestRelease.global
  cutoff_matches_request : closed.cutoff = requestRelease.global.L_max
  exposureStatus : HandoffFactorExposureStatus
  exposure_is_factor_node_only :
    exposureStatus = HandoffFactorExposureStatus.factorNodeOnly

abbrev PillarAToBRegulatedFactorNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  RegulatedHandoffFactorNode HandoffFactorTarget.pillarAToB Cell T

abbrev PillarAToCRegulatedFactorNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  RegulatedHandoffFactorNode HandoffFactorTarget.pillarAToC Cell T

abbrev PillarAToDRegulatedFactorNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  RegulatedHandoffFactorNode HandoffFactorTarget.pillarAToD Cell T

abbrev PillarAToERegulatedFactorNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  RegulatedHandoffFactorNode HandoffFactorTarget.pillarAToE Cell T

abbrev PillarAToCayleyDicksonRegulatedFactorNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) :=
  RegulatedHandoffFactorNode HandoffFactorTarget.pillarAToCayleyDickson Cell T

namespace RegulatedHandoffFactorNode

variable {target : HandoffFactorTarget}
variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def baseClosed (node : RegulatedHandoffFactorNode target Cell T) :
    PillarAStep1Closed Cell T :=
  node.closed

def requestCertificate (node : RegulatedHandoffFactorNode target Cell T) :
    GeneratorRequestApproximationReleaseCertificate :=
  node.requestRelease

def outputCertificate (node : RegulatedHandoffFactorNode target Cell T) :
    CNNA.PillarA.Generator.GeneratorOutputReleaseCertificate :=
  node.outputRelease

def lock (node : RegulatedHandoffFactorNode target Cell T) :
    SinglePreparationLock :=
  node.requestRelease.lock

def global (node : RegulatedHandoffFactorNode target Cell T) :
    GlobalTheoryApproximationState :=
  node.requestRelease.global

def cutoff (node : RegulatedHandoffFactorNode target Cell T) : Nat :=
  node.closed.cutoff

def baseABHandoff (node : RegulatedHandoffFactorNode target Cell T) :
    ABHandoffStrong Cell T :=
  node.closed.handoff


theorem baseClosed_eq_closed (node : RegulatedHandoffFactorNode target Cell T) :
    node.baseClosed = node.closed := by
  rfl

theorem requestCertificate_eq_requestRelease
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.requestCertificate = node.requestRelease := by
  rfl

theorem outputCertificate_eq_outputRelease
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.outputCertificate = node.outputRelease := by
  rfl

theorem output_state_eq_global
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.outputRelease.state = node.global := by
  change node.outputRelease.state = node.requestRelease.global
  exact node.output_state_matches_request

theorem global_eq_lock_state
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.global = node.lock.state := by
  rfl

theorem output_state_eq_lock_state
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.outputRelease.state = node.lock.state := by
  calc
    node.outputRelease.state = node.global :=
      node.output_state_eq_global
    _ = node.lock.state :=
      node.global_eq_lock_state

theorem cutoff_eq_global_L_max
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.cutoff = node.global.L_max := by
  change node.closed.cutoff = node.requestRelease.global.L_max
  exact node.cutoff_matches_request

theorem exposureStatus_factorNodeOnly
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  node.exposure_is_factor_node_only

theorem output_release_scope_generator_only
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.outputRelease.releasedScope =
      CNNA.PillarA.Generator.GeneratorOutputReleaseScope.generatorOutputLayerOnly :=
  node.outputRelease.releasedScope_is_generator_output_layer_only

theorem request_tier_eq_limit_profile
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.requestRelease.request.requestedDataTier =
      CNNA.PillarA.Generator.RequestedDataTier.limitProfile :=
  node.requestRelease.request_tier_eq_limit_profile

theorem request_global_eq_limit_state
    (node : RegulatedHandoffFactorNode target Cell T) :
    node.requestRelease.request.global = node.requestRelease.limitProfile.state :=
  node.requestRelease.request_global_eq_limit_state

end RegulatedHandoffFactorNode

structure RegulatedHandoffFactorNodeMigrationBatch
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  pillarAToB : PillarAToBRegulatedFactorNode Cell T
  pillarAToC : PillarAToCRegulatedFactorNode Cell T
  pillarAToD : PillarAToDRegulatedFactorNode Cell T
  pillarAToE : PillarAToERegulatedFactorNode Cell T
  pillarAToCayleyDickson : PillarAToCayleyDicksonRegulatedFactorNode Cell T
  pillarAToC_closed_matches : pillarAToC.closed = pillarAToB.closed
  pillarAToD_closed_matches : pillarAToD.closed = pillarAToB.closed
  pillarAToE_closed_matches : pillarAToE.closed = pillarAToB.closed
  pillarAToCayleyDickson_closed_matches :
    pillarAToCayleyDickson.closed = pillarAToB.closed

namespace RegulatedHandoffFactorNodeMigrationBatch

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

def sourceClosed (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    PillarAStep1Closed Cell T :=
  batch.pillarAToB.closed

def sourceABHandoff (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    ABHandoffStrong Cell T :=
  batch.sourceClosed.handoff

theorem pillarAToC_closed_eq_source
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToC.closed = batch.sourceClosed := by
  change batch.pillarAToC.closed = batch.pillarAToB.closed
  exact batch.pillarAToC_closed_matches

theorem pillarAToD_closed_eq_source
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToD.closed = batch.sourceClosed := by
  change batch.pillarAToD.closed = batch.pillarAToB.closed
  exact batch.pillarAToD_closed_matches

theorem pillarAToE_closed_eq_source
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToE.closed = batch.sourceClosed := by
  change batch.pillarAToE.closed = batch.pillarAToB.closed
  exact batch.pillarAToE_closed_matches

theorem pillarAToCayleyDickson_closed_eq_source
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToCayleyDickson.closed = batch.sourceClosed := by
  change batch.pillarAToCayleyDickson.closed = batch.pillarAToB.closed
  exact batch.pillarAToCayleyDickson_closed_matches

theorem pillarAToB_exposure_factorNodeOnly
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToB.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  batch.pillarAToB.exposureStatus_factorNodeOnly

theorem pillarAToC_exposure_factorNodeOnly
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToC.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  batch.pillarAToC.exposureStatus_factorNodeOnly

theorem pillarAToD_exposure_factorNodeOnly
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToD.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  batch.pillarAToD.exposureStatus_factorNodeOnly

theorem pillarAToE_exposure_factorNodeOnly
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToE.exposureStatus = HandoffFactorExposureStatus.factorNodeOnly :=
  batch.pillarAToE.exposureStatus_factorNodeOnly

theorem pillarAToCayleyDickson_exposure_factorNodeOnly
    (batch : RegulatedHandoffFactorNodeMigrationBatch Cell T) :
    batch.pillarAToCayleyDickson.exposureStatus =
      HandoffFactorExposureStatus.factorNodeOnly :=
  batch.pillarAToCayleyDickson.exposureStatus_factorNodeOnly

end RegulatedHandoffFactorNodeMigrationBatch

end CNNA.PillarA.Handoff
