import CNNA.PillarA.Generator.TypedIOSurface
import CNNA.PillarA.Handoff.Internal.SpineReleaseCertificate

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalGeneratorSpineAttachmentStatus where
  | typedIOSurfaceAttached
  | internalSpineRetained
  deriving DecidableEq, Repr

inductive InternalGeneratorSpineExposureStatus where
  | aInternalOnly
  | noExternalEndpointRelease
  deriving DecidableEq, Repr

structure InternalGeneratorToHandoffSpineSkeleton where
  typedSurface : CNNA.PillarA.Generator.NeutralGeneratorTypedIOSurface
  spineCertificate : InternalHandoffSpineReleaseCertificate.{u, v, w}
  attachmentStatus : InternalGeneratorSpineAttachmentStatus
  exposureStatus : InternalGeneratorSpineExposureStatus
  state_eq : typedSurface.state = spineCertificate.global
  attachmentStatus_eq :
    attachmentStatus =
      InternalGeneratorSpineAttachmentStatus.typedIOSurfaceAttached
  exposureStatus_eq :
    exposureStatus = InternalGeneratorSpineExposureStatus.aInternalOnly

namespace InternalGeneratorToHandoffSpineSkeleton

def state (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    GlobalTheoryApproximationState :=
  skeleton.spineCertificate.global

def generatorState
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    GlobalTheoryApproximationState :=
  skeleton.typedSurface.state

def request (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorRequestProfile :=
  skeleton.typedSurface.request

def output (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorOutputProfile :=
  skeleton.typedSurface.output

def generatorReleaseCertificate
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    CNNA.PillarA.Generator.GeneratorOutputReleaseCertificate :=
  skeleton.typedSurface.certificate

def internalReleaseCertificate
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    GeneratorRequestApproximationReleaseCertificate :=
  skeleton.spineCertificate.releaseCertificate

theorem attachmentStatus_is_typedIOSurfaceAttached
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.attachmentStatus =
      InternalGeneratorSpineAttachmentStatus.typedIOSurfaceAttached :=
  skeleton.attachmentStatus_eq

theorem exposureStatus_is_aInternalOnly
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.exposureStatus = InternalGeneratorSpineExposureStatus.aInternalOnly :=
  skeleton.exposureStatus_eq

theorem generator_state_eq_internal_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.generatorState = skeleton.state :=
  skeleton.state_eq

theorem typedSurface_status_is_typedSurfaceOnly
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.typedSurface.status =
      CNNA.PillarA.Generator.NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  skeleton.typedSurface.status_is_typedSurfaceOnly

theorem internal_spine_status_is_released
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.spineCertificate.status = InternalHandoffSpineReleaseStatus.released :=
  skeleton.spineCertificate.status_is_released

theorem generator_request_global_eq_internal_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.request.global = skeleton.state := by
  calc
    skeleton.request.global = skeleton.generatorState :=
      skeleton.typedSurface.request_global_matches_state
    _ = skeleton.state := skeleton.generator_state_eq_internal_state

theorem generator_output_state_eq_internal_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.output.state = skeleton.state := by
  calc
    skeleton.output.state = skeleton.generatorState :=
      skeleton.typedSurface.output_state_matches_state
    _ = skeleton.state := skeleton.generator_state_eq_internal_state

theorem generator_release_state_eq_internal_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.generatorReleaseCertificate.state = skeleton.state := by
  calc
    skeleton.generatorReleaseCertificate.state = skeleton.generatorState :=
      skeleton.typedSurface.release_state_matches_state
    _ = skeleton.state := skeleton.generator_state_eq_internal_state

theorem internal_request_global_eq_lock_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.spineCertificate.standard.request.global =
      skeleton.spineCertificate.standard.lock.state :=
  skeleton.spineCertificate.request_global_eq_lock

theorem internal_gate_global_eq_limit_state
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.spineCertificate.standard.gate.global =
      skeleton.spineCertificate.standard.limitProfile.state :=
  skeleton.spineCertificate.gate_global_eq_limit_state

theorem internal_output_global_eq_input_global
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.spineCertificate.standard.output.global =
      skeleton.spineCertificate.standard.input.global :=
  skeleton.spineCertificate.bright_global_eq_input_global

theorem no_external_endpoint_release
    (skeleton : InternalGeneratorToHandoffSpineSkeleton.{u, v, w}) :
    skeleton.exposureStatus ≠
      InternalGeneratorSpineExposureStatus.noExternalEndpointRelease := by
  intro h
  have impossible :
      InternalGeneratorSpineExposureStatus.aInternalOnly =
        InternalGeneratorSpineExposureStatus.noExternalEndpointRelease :=
    skeleton.exposureStatus_is_aInternalOnly.symm.trans h
  cases impossible

end InternalGeneratorToHandoffSpineSkeleton

end CNNA.PillarA.Handoff
