import CNNA.PillarA.Handoff.Internal.TriadicInterfaceProfile

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalHandoffSpineReleaseStatus where
  | declared
  | released
  | blocked
  deriving DecidableEq, Repr

structure InternalHandoffSpineReleaseCertificate where
  catalog : InternalHubTriadicInterfaceCatalog.{u, v, w}
  status : InternalHandoffSpineReleaseStatus
  typeSchemaStatus : InternalHandoffSpineReleaseStatus
  hubInterfaceStatus : InternalHandoffSpineReleaseStatus
  cutEdgeRecoveryStatus : InternalHandoffSpineReleaseStatus
  triadicInterfaceStatus : InternalHandoffSpineReleaseStatus
  releaseCertificate : GeneratorRequestApproximationReleaseCertificate
  status_released : status = InternalHandoffSpineReleaseStatus.released
  typeSchema_released : typeSchemaStatus = InternalHandoffSpineReleaseStatus.released
  hubInterface_released :
    hubInterfaceStatus = InternalHandoffSpineReleaseStatus.released
  cutEdgeRecovery_released :
    cutEdgeRecoveryStatus = InternalHandoffSpineReleaseStatus.released
  triadicInterface_released :
    triadicInterfaceStatus = InternalHandoffSpineReleaseStatus.released
  releaseCertificate_eq_standard :
    releaseCertificate = catalog.standard.releaseCertificate

namespace InternalHandoffSpineReleaseCertificate

def standard
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    InternalHubInterfaceStandard.{u, v} :=
  certificate.catalog.standard

def hubKind
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    InternalHubKind :=
  certificate.standard.hubKind

def family
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    InternalCutEdgeTheoryFamily :=
  certificate.catalog.family

def global
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    GlobalTheoryApproximationState :=
  certificate.standard.global

def limitProfile
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    PillarAToBLimitApproximationProfile :=
  certificate.standard.limitProfile

theorem status_is_released
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.status = InternalHandoffSpineReleaseStatus.released :=
  certificate.status_released

theorem typeSchema_is_released
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.typeSchemaStatus = InternalHandoffSpineReleaseStatus.released :=
  certificate.typeSchema_released

theorem hubInterface_is_released
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.hubInterfaceStatus = InternalHandoffSpineReleaseStatus.released :=
  certificate.hubInterface_released

theorem cutEdgeRecovery_is_released
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.cutEdgeRecoveryStatus = InternalHandoffSpineReleaseStatus.released :=
  certificate.cutEdgeRecovery_released

theorem triadicInterface_is_released
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.triadicInterfaceStatus = InternalHandoffSpineReleaseStatus.released :=
  certificate.triadicInterface_released

theorem family_eq_hub_family
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.family = InternalCutEdgeTheoryFamily.forHub certificate.hubKind :=
  certificate.catalog.family_eq_hub_family

theorem bright_global_eq_input_global
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.output.global = certificate.standard.input.global :=
  certificate.catalog.bright_global_eq_input_global

theorem darkComplement_global_eq_input_global
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.residual.global = certificate.standard.input.global :=
  certificate.catalog.darkComplement_global_eq_input_global

theorem interface_global_eq_input_global
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.cutState.global = certificate.standard.input.global :=
  certificate.catalog.interface_global_eq_input_global

theorem regulator_global_eq_input_global
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.reviewGate.global = certificate.standard.input.global :=
  certificate.catalog.regulator_global_eq_input_global

theorem request_global_eq_lock
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.request.global = certificate.standard.lock.state :=
  certificate.standard.request_global_eq_lock

theorem gate_global_eq_limit_state
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.standard.gate.global = certificate.standard.limitProfile.state :=
  certificate.standard.gate_global_eq_limit_state

theorem releaseCertificate_matches_standard
    (certificate : InternalHandoffSpineReleaseCertificate.{u, v, w}) :
    certificate.releaseCertificate = certificate.standard.releaseCertificate :=
  certificate.releaseCertificate_eq_standard

end InternalHandoffSpineReleaseCertificate

end CNNA.PillarA.Handoff
