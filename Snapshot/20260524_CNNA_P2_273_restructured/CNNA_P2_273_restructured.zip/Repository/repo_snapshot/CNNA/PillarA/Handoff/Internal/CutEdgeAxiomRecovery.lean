import CNNA.PillarA.Handoff.Internal.HubInterfaceStandard

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

universe u v w

inductive InternalCutEdgeTheoryFamily where
  | arithmetic
  | algebra
  | boundary
  | finite
  | coupling
  | structural
  | generatorConsumer
  | internalHandoff
  deriving DecidableEq, Repr

namespace InternalCutEdgeTheoryFamily

def forHub : InternalHubKind → InternalCutEdgeTheoryFamily
  | InternalHubKind.arithmetic => InternalCutEdgeTheoryFamily.arithmetic
  | InternalHubKind.algebra => InternalCutEdgeTheoryFamily.algebra
  | InternalHubKind.boundary => InternalCutEdgeTheoryFamily.boundary
  | InternalHubKind.finite => InternalCutEdgeTheoryFamily.finite
  | InternalHubKind.coupling => InternalCutEdgeTheoryFamily.coupling
  | InternalHubKind.structural => InternalCutEdgeTheoryFamily.structural
  | InternalHubKind.generatorConsumer => InternalCutEdgeTheoryFamily.generatorConsumer
  | InternalHubKind.internalHandoff => InternalCutEdgeTheoryFamily.internalHandoff

theorem forHub_arithmetic :
    forHub InternalHubKind.arithmetic = InternalCutEdgeTheoryFamily.arithmetic := by
  rfl

theorem forHub_algebra :
    forHub InternalHubKind.algebra = InternalCutEdgeTheoryFamily.algebra := by
  rfl

theorem forHub_boundary :
    forHub InternalHubKind.boundary = InternalCutEdgeTheoryFamily.boundary := by
  rfl

theorem forHub_finite :
    forHub InternalHubKind.finite = InternalCutEdgeTheoryFamily.finite := by
  rfl

theorem forHub_coupling :
    forHub InternalHubKind.coupling = InternalCutEdgeTheoryFamily.coupling := by
  rfl

theorem forHub_structural :
    forHub InternalHubKind.structural = InternalCutEdgeTheoryFamily.structural := by
  rfl

theorem forHub_generatorConsumer :
    forHub InternalHubKind.generatorConsumer =
      InternalCutEdgeTheoryFamily.generatorConsumer := by
  rfl

theorem forHub_internalHandoff :
    forHub InternalHubKind.internalHandoff =
      InternalCutEdgeTheoryFamily.internalHandoff := by
  rfl

end InternalCutEdgeTheoryFamily

inductive InternalCutEdgeIsolationMode where
  | hubLocal
  | handoffSurface
  | externalEndpoint
  deriving DecidableEq, Repr

inductive InternalCutEdgeRecoveryStatus where
  | declared
  | comparisonRouted
  | recovered
  | blocked
  deriving DecidableEq, Repr

inductive InternalCutEdgeAxiomSource where
  | cutStateReadout
  | residualReadout
  | reviewGateReadout
  deriving DecidableEq, Repr

structure InternalCutEdgeAxiomRequirement where
  carrier : Type w
  family : InternalCutEdgeTheoryFamily
  source : InternalCutEdgeAxiomSource
  status : InternalCutEdgeRecoveryStatus

namespace InternalCutEdgeAxiomRequirement

def withStatus
    (requirement : InternalCutEdgeAxiomRequirement.{w})
    (status : InternalCutEdgeRecoveryStatus) :
    InternalCutEdgeAxiomRequirement.{w} where
  carrier := requirement.carrier
  family := requirement.family
  source := requirement.source
  status := status

theorem withStatus_family
    (requirement : InternalCutEdgeAxiomRequirement.{w})
    (status : InternalCutEdgeRecoveryStatus) :
    (requirement.withStatus status).family = requirement.family := by
  rfl

theorem withStatus_source
    (requirement : InternalCutEdgeAxiomRequirement.{w})
    (status : InternalCutEdgeRecoveryStatus) :
    (requirement.withStatus status).source = requirement.source := by
  rfl

theorem withStatus_status
    (requirement : InternalCutEdgeAxiomRequirement.{w})
    (status : InternalCutEdgeRecoveryStatus) :
    (requirement.withStatus status).status = status := by
  rfl

end InternalCutEdgeAxiomRequirement

structure InternalHubCutEdgeAxiomRecoveryProfile
    (standard : InternalHubInterfaceStandard.{u, v}) where
  requirement : InternalCutEdgeAxiomRequirement.{w}
  isolationMode : InternalCutEdgeIsolationMode
  requirement_matches_hub :
    requirement.family = InternalCutEdgeTheoryFamily.forHub standard.hubKind

namespace InternalHubCutEdgeAxiomRecoveryProfile

variable {standard : InternalHubInterfaceStandard.{u, v}}

def family
    (profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalCutEdgeTheoryFamily :=
  profile.requirement.family

def source
    (profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalCutEdgeAxiomSource :=
  profile.requirement.source

def status
    (profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalCutEdgeRecoveryStatus :=
  profile.requirement.status

def releaseCertificate
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    GeneratorRequestApproximationReleaseCertificate :=
  standard.releaseCertificate

def cutStateSchema
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalHandoffTypeSchema.{u, v} :=
  standard.cutState

def residualSchema
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalHandoffTypeSchema.{u, v} :=
  standard.residual

def reviewGateSchema
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    InternalHandoffTypeSchema.{u, v} :=
  standard.reviewGate

theorem family_eq_hub_family
    (profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    profile.family = InternalCutEdgeTheoryFamily.forHub standard.hubKind :=
  profile.requirement_matches_hub

theorem cutState_source_role
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.cutState.source.role = InternalHandoffRole.interface :=
  standard.cutState_source_role

theorem residual_source_role
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.residual.source.role = InternalHandoffRole.interface :=
  standard.residual_source_role

theorem reviewGate_source_role
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.reviewGate.source.role = InternalHandoffRole.regulator :=
  standard.reviewGate_source_role

theorem cutState_direction
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.cutState.direction = InternalHandoffDirection.hubToInternalHandoff :=
  standard.cutState_direction

theorem residual_direction
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.residual.direction = InternalHandoffDirection.hubToInternalHandoff :=
  standard.residual_direction

theorem reviewGate_direction
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.reviewGate.direction = InternalHandoffDirection.regulatorToInterface :=
  standard.reviewGate_direction

theorem cutState_global_eq_input_global
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.cutState.global = standard.input.global :=
  standard.cutState_global_eq_input_global

theorem residual_global_eq_input_global
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.residual.global = standard.input.global :=
  standard.residual_global_eq_input_global

theorem reviewGate_global_eq_input_global
    (_profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard) :
    standard.reviewGate.global = standard.input.global :=
  standard.reviewGate_global_eq_input_global

end InternalHubCutEdgeAxiomRecoveryProfile

structure InternalHubCutEdgeAxiomRecoveryRecords
    (standard : InternalHubInterfaceStandard.{u, v}) where
  cutState : InternalHandoffTypedRecord standard.cutState
  residual : InternalHandoffTypedRecord standard.residual
  reviewGate : InternalHandoffTypedRecord standard.reviewGate

namespace InternalHubCutEdgeAxiomRecoveryRecords

variable {standard : InternalHubInterfaceStandard.{u, v}}

def cutStateRecord
    (records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    InternalHandoffTypedRecord standard.cutState :=
  records.cutState

def residualRecord
    (records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    InternalHandoffTypedRecord standard.residual :=
  records.residual

def reviewGateRecord
    (records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    InternalHandoffTypedRecord standard.reviewGate :=
  records.reviewGate

theorem cutState_global_eq_input_global
    (_records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    standard.cutState.global = standard.input.global :=
  standard.cutState_global_eq_input_global

theorem residual_global_eq_input_global
    (_records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    standard.residual.global = standard.input.global :=
  standard.residual_global_eq_input_global

theorem reviewGate_global_eq_input_global
    (_records : InternalHubCutEdgeAxiomRecoveryRecords standard) :
    standard.reviewGate.global = standard.input.global :=
  standard.reviewGate_global_eq_input_global

end InternalHubCutEdgeAxiomRecoveryRecords

structure InternalHubCutEdgeAxiomRecoveryCatalog where
  standard : InternalHubInterfaceStandard.{u, v}
  profile : InternalHubCutEdgeAxiomRecoveryProfile.{u, v, w} standard
  records : InternalHubCutEdgeAxiomRecoveryRecords standard

namespace InternalHubCutEdgeAxiomRecoveryCatalog

def hubKind
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    InternalHubKind :=
  catalog.standard.hubKind

def family
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    InternalCutEdgeTheoryFamily :=
  catalog.profile.family

theorem family_eq_hub_family
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    catalog.family = InternalCutEdgeTheoryFamily.forHub catalog.hubKind :=
  catalog.profile.family_eq_hub_family

theorem cutState_global_eq_input_global
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    catalog.standard.cutState.global = catalog.standard.input.global :=
  catalog.records.cutState_global_eq_input_global

theorem residual_global_eq_input_global
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    catalog.standard.residual.global = catalog.standard.input.global :=
  catalog.records.residual_global_eq_input_global

theorem reviewGate_global_eq_input_global
    (catalog : InternalHubCutEdgeAxiomRecoveryCatalog.{u, v, w}) :
    catalog.standard.reviewGate.global = catalog.standard.input.global :=
  catalog.records.reviewGate_global_eq_input_global

end InternalHubCutEdgeAxiomRecoveryCatalog

end CNNA.PillarA.Handoff
