import CNNA.PillarA.Generator.RequestProfile

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

structure GlobalApproximationHandoffProfile where
  lock : CNNA.PillarA.Generator.SinglePreparationLock
  profile : CNNA.PillarA.Generator.GeneratorRequestProfile
  profile_matches_lock : profile.global = lock.state

namespace GlobalApproximationHandoffProfile

def state (handoffProfile : GlobalApproximationHandoffProfile) :
    CNNA.PillarA.Generator.GlobalTheoryApproximationState :=
  handoffProfile.lock.state

theorem profile_global_eq (handoffProfile : GlobalApproximationHandoffProfile) :
    handoffProfile.profile.global = handoffProfile.lock.state :=
  handoffProfile.profile_matches_lock

theorem state_eq (handoffProfile : GlobalApproximationHandoffProfile) :
    handoffProfile.state = handoffProfile.lock.state := by
  rfl

end GlobalApproximationHandoffProfile

end CNNA.PillarA.Handoff
