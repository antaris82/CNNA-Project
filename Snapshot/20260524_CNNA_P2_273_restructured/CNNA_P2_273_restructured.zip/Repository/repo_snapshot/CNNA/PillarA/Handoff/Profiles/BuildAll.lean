import CNNA.PillarA.Handoff.Profiles.GlobalApproximation
import CNNA.PillarA.Handoff.Profiles.ComplementTower
import CNNA.PillarA.Handoff.Profiles.RealDataFirst
import CNNA.PillarA.Handoff.Profiles.RequestCompatibility
import CNNA.PillarA.Handoff.Profiles.ReleaseCertificate
