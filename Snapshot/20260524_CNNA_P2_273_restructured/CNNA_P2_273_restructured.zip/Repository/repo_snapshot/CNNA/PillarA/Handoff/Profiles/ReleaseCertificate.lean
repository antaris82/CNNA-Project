import CNNA.PillarA.Handoff.Profiles.RequestCompatibility

set_option autoImplicit false

namespace CNNA.PillarA.Handoff

structure GeneratorRequestApproximationReleaseCertificate where
  requestCompatibility : GeneratorRequestCompatibilityFacade
  limitTowerRelease : LimitTowerReleaseCertificate
  sameGate : requestCompatibility.gate = limitTowerRelease.gate

namespace GeneratorRequestApproximationReleaseCertificate

def gate (certificate : GeneratorRequestApproximationReleaseCertificate) :
    RealDataFirstUnlockGate :=
  certificate.requestCompatibility.gate

def lock (certificate : GeneratorRequestApproximationReleaseCertificate) :
    SinglePreparationLock :=
  certificate.gate.lock

def request (certificate : GeneratorRequestApproximationReleaseCertificate) :
    GeneratorRequestProfile :=
  certificate.requestCompatibility.profileFacade.request

def global (certificate : GeneratorRequestApproximationReleaseCertificate) :
    GlobalTheoryApproximationState :=
  certificate.gate.global

def limitProfile (certificate : GeneratorRequestApproximationReleaseCertificate) :
    PillarAToBLimitApproximationProfile :=
  certificate.limitTowerRelease.limitProfile

def requestReleaseCertificate
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    GeneratorRequestReleaseCertificate :=
  certificate.requestCompatibility.releaseCertificate

theorem gate_eq_limit_gate
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.gate = certificate.limitTowerRelease.gate := by
  exact certificate.sameGate

theorem request_global_eq_gate
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.request.global = certificate.gate.global := by
  change certificate.requestCompatibility.profileFacade.request.global =
    certificate.requestCompatibility.gate.global
  exact GeneratorRequestCompatibilityFacade.request_global_eq_gate
    certificate.requestCompatibility

theorem gate_global_eq_limit_state
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.gate.global = certificate.limitProfile.state := by
  change certificate.requestCompatibility.gate.global =
    certificate.limitTowerRelease.limitProfile.state
  rw [certificate.sameGate]
  exact LimitTowerReleaseCertificate.gate_global_eq_limit_state
    certificate.limitTowerRelease

theorem request_global_eq_limit_state
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.request.global = certificate.limitProfile.state := by
  calc
    certificate.request.global = certificate.gate.global :=
      certificate.request_global_eq_gate
    _ = certificate.limitProfile.state :=
      certificate.gate_global_eq_limit_state

theorem request_global_eq_lock
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.request.global = certificate.lock.state := by
  change certificate.requestCompatibility.profileFacade.request.global =
    certificate.requestCompatibility.gate.lock.state
  exact GeneratorRequestReleaseCertificate.request_global_eq_lock
    certificate.requestReleaseCertificate

theorem released_tier_is_limit_profile
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.gate.releasedTier =
      CNNA.PillarA.Generator.RequestedDataTier.limitProfile := by
  change certificate.requestCompatibility.gate.releasedTier =
    CNNA.PillarA.Generator.RequestedDataTier.limitProfile
  rw [certificate.sameGate]
  exact LimitTowerReleaseCertificate.released_tier_is_limit_profile
    certificate.limitTowerRelease

theorem request_tier_eq_limit_profile
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.request.requestedDataTier =
      CNNA.PillarA.Generator.RequestedDataTier.limitProfile := by
  change certificate.requestCompatibility.profileFacade.request.requestedDataTier =
    CNNA.PillarA.Generator.RequestedDataTier.limitProfile
  calc
    certificate.requestCompatibility.profileFacade.request.requestedDataTier =
        certificate.requestCompatibility.gate.releasedTier :=
      GeneratorRequestCompatibilityFacade.request_tier_eq_released
        certificate.requestCompatibility
    _ = CNNA.PillarA.Generator.RequestedDataTier.limitProfile :=
      certificate.released_tier_is_limit_profile

theorem requestReleaseCertificate_gate
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.requestReleaseCertificate.gate = certificate.gate := by
  rfl

theorem requestReleaseCertificate_request
    (certificate : GeneratorRequestApproximationReleaseCertificate) :
    certificate.requestReleaseCertificate.request = certificate.request := by
  rfl

end GeneratorRequestApproximationReleaseCertificate

end CNNA.PillarA.Handoff
