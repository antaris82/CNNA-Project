import CNNA.PillarA.Foundation.SubstrateClass

set_option autoImplicit false

namespace CNNA.PillarA.Foundation

universe u v w

abbrev LayeredCell (Cell : Nat → Type u) : Type u :=
  Sigma Cell

structure LayerSlice (Cell : Nat → Type u) [SubstrateClass Cell] where
  level : Nat
  carrier : Finset (Cell level)

namespace LayerSlice

variable {Cell : Nat → Type u} [SubstrateClass Cell]

def card (S : LayerSlice Cell) : Nat :=
  S.carrier.card

theorem mem_carrier_mk_iff {L : Nat} {s : Finset (Cell L)} {x : Cell L} :
    x ∈ (LayerSlice.mk L s).carrier ↔ x ∈ s := by
  rfl

def refine (S : LayerSlice Cell) : LayerSlice Cell :=
  { level := S.level + 1
    carrier := SubstrateClass.refineSet (Cell := Cell) S.carrier }

def coarsen (S : LayerSlice Cell) : LayerSlice Cell :=
  match S with
  | ⟨0, carrier⟩ =>
      { level := 0
        carrier := carrier }
  | ⟨L + 1, carrier⟩ =>
      { level := L
        carrier := SubstrateClass.coarsenSet (Cell := Cell) carrier }

theorem refine_level (S : LayerSlice Cell) :
    S.refine.level = S.level + 1 := by
  rfl

theorem refine_carrier (S : LayerSlice Cell) :
    S.refine.carrier = SubstrateClass.refineSet (Cell := Cell) S.carrier := by
  rfl

theorem coarsen_mk_zero_level (s : Finset (Cell 0)) :
    (LayerSlice.mk 0 s).coarsen.level = 0 := by
  rfl

theorem coarsen_mk_zero_carrier (s : Finset (Cell 0)) :
    (LayerSlice.mk 0 s).coarsen.carrier = s := by
  rfl

theorem coarsen_mk_succ_level {L : Nat} (s : Finset (Cell (L + 1))) :
    (LayerSlice.mk (L + 1) s).coarsen.level = L := by
  rfl

theorem coarsen_mk_succ_carrier {L : Nat} (s : Finset (Cell (L + 1))) :
    (LayerSlice.mk (L + 1) s).coarsen.carrier = SubstrateClass.coarsenSet (Cell := Cell) s := by
  rfl

end LayerSlice

structure BoundarySlice (Cell : Nat → Type u) [SubstrateClass Cell]
    extends LayerSlice Cell where
  boundary : Finset (Cell level)
  boundary_subset : boundary ⊆ carrier

namespace BoundarySlice

variable {Cell : Nat → Type u} [SubstrateClass Cell]

theorem mem_carrier_of_mem_boundary (B : BoundarySlice Cell) {x : Cell B.level}
    (hx : x ∈ B.boundary) :
    x ∈ B.carrier := by
  exact B.boundary_subset hx

def boundaryCard (B : BoundarySlice Cell) : Nat :=
  B.boundary.card

theorem boundaryCard_le_carrierCard (B : BoundarySlice Cell) :
    B.boundaryCard ≤ B.toLayerSlice.card := by
  exact Finset.card_le_card B.boundary_subset

end BoundarySlice

class HasLayerSlice (α : Type v) (Cell : Nat → Type u) [SubstrateClass Cell] where
  layerSlice : α → LayerSlice Cell

class HasBoundarySlice (α : Type v) (Cell : Nat → Type u) [SubstrateClass Cell] where
  boundarySlice : α → BoundarySlice Cell

class HasSourceMap (α : Type v) (β : Type w) where
  sourceMap : α → β

class HasRefinement (α : Type v) (β : Type w) where
  refine : α → β

class HasCoarsening (α : Type v) (β : Type w) where
  coarsen : α → β

section LayerSliceInstances

variable {Cell : Nat → Type u} [SubstrateClass Cell]

instance instHasRefinementLayerSlice : HasRefinement (LayerSlice Cell) (LayerSlice Cell) where
  refine := LayerSlice.refine

instance instHasCoarseningLayerSlice : HasCoarsening (LayerSlice Cell) (LayerSlice Cell) where
  coarsen := LayerSlice.coarsen

end LayerSliceInstances

namespace HasLayerSlice

variable {α : Type v} {Cell : Nat → Type u} [SubstrateClass Cell] [HasLayerSlice α Cell]

def slice (a : α) : LayerSlice Cell :=
  HasLayerSlice.layerSlice (α := α) (Cell := Cell) a

theorem slice_level (a : α) :
    (slice (α := α) (Cell := Cell) a).level =
      (HasLayerSlice.layerSlice (α := α) (Cell := Cell) a).level := by
  rfl

theorem slice_carrier (a : α) :
    (slice (α := α) (Cell := Cell) a).carrier =
      (HasLayerSlice.layerSlice (α := α) (Cell := Cell) a).carrier := by
  rfl

end HasLayerSlice

namespace HasBoundarySlice

variable {α : Type v} {Cell : Nat → Type u} [SubstrateClass Cell] [HasBoundarySlice α Cell]

def slice (a : α) : BoundarySlice Cell :=
  HasBoundarySlice.boundarySlice (α := α) (Cell := Cell) a

theorem boundary_subset_carrier (a : α) :
    (slice (α := α) (Cell := Cell) a).boundary ⊆
      (slice (α := α) (Cell := Cell) a).carrier := by
  exact (slice (α := α) (Cell := Cell) a).boundary_subset

theorem mem_carrier_of_mem_boundary (a : α)
    {x : Cell (slice (α := α) (Cell := Cell) a).level}
    (hx : x ∈ (slice (α := α) (Cell := Cell) a).boundary) :
    x ∈ (slice (α := α) (Cell := Cell) a).carrier := by
  exact boundary_subset_carrier (α := α) (Cell := Cell) a hx

end HasBoundarySlice

end CNNA.PillarA.Foundation
