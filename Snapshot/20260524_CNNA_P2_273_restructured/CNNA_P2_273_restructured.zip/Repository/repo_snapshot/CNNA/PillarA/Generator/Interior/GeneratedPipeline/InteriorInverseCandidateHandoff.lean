import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateShapeSeparation

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation

universe u

inductive InteriorTwoSidedInverseHandoffStatus where
  | handoffFromInteriorInverseCandidateShapeSeparationShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus where
  | interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoLeftProductStatus where
  | noLeftProductInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoRightProductStatus where
  | noRightProductInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoProductValidationStatus where
  | noProductValidationInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoRepairFormulaStatus where
  | noRepairFormulaInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoNewCandidateEntryStatus where
  | noNewCandidateEntryInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoInteriorEliminationCandidateEntryFallbackStatus where
  | noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoFreeMatrixStatus where
  | noFreeMatrixOrEntryTableInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoMatrixInvStatus where
  | noMatrixInvInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseNextGateStatus where
  | positiveInteriorTwoSidedInverseValidationAfterHandoff
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseGeneratedInverseCandidateLedgerStatus where
  | generatedInverseCandidateHandoffClosed
  deriving DecidableEq, Repr

structure InteriorInverseCandidateValidationHandoff
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) where
  sourceShapeSeparation :
    GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M
  sourceMatrix : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T
  sourceAccumulatedEntry :
    GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T
  sourceCandidateEntry : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W
  candidateMatrix : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ
  handoffStatus : InteriorTwoSidedInverseHandoffStatus
  consumptionGateStatus : InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus
  noLeftProductStatus : InteriorTwoSidedInverseNoLeftProductStatus
  noRightProductStatus : InteriorTwoSidedInverseNoRightProductStatus
  noProductValidationStatus : InteriorTwoSidedInverseNoProductValidationStatus
  noRepairFormulaStatus : InteriorTwoSidedInverseNoRepairFormulaStatus
  noNewCandidateEntryStatus : InteriorTwoSidedInverseNoNewCandidateEntryStatus
  noInteriorEliminationCandidateEntryFallbackStatus : InteriorTwoSidedInverseNoInteriorEliminationCandidateEntryFallbackStatus
  noFreeMatrixStatus : InteriorTwoSidedInverseNoFreeMatrixStatus
  noMatrixInvStatus : InteriorTwoSidedInverseNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseNoArithmeticTargetStatus
  nextGateStatus : InteriorTwoSidedInverseNextGateStatus
  sourceShapeSeparation_eq : sourceShapeSeparation = S
  sourceMatrixEqInteriorInverseCandidateShapeSeparationSourceMatrix : sourceMatrix = S.sourceMatrix
  sourceMatrixEqInteriorInverseCandidateMatrixMatrixExport : sourceMatrix = M
  sourceAccumulatedEntryEqInteriorInverseCandidateShapeSeparationAccumulatedEntry :
    sourceAccumulatedEntry = S.accumulatedInverseCandidateEntry
  sourceCandidateEntryEqInteriorInverseCandidateShapeSeparationSourceCandidateEntry :
    sourceCandidateEntry = S.sourceCandidateEntry
  candidateMatrixEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix : candidateMatrix = S.matrix
  candidateMatrixEntryEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix i j = S.matrix i j
  candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix i j = M.matrix i j
  candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix i j = S.accumulatedInverseCandidateEntry.entry i j
  candidateMatrixEntry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix i j = generatedInteriorAccumulatedEntryValue T i j
  sourceStatusEqInteriorInverseCandidateMatrix :
    sourceMatrix.sourceStatus =
      InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus.matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :
    sourceAccumulatedEntry.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  shapeSeparationStatusEqInteriorInverseCandidateShapeSeparation :
    sourceShapeSeparation.shapeSeparationStatus =
      InteriorInverseCandidateShapeSeparationShapeSeparationStatus.shapeSeparationFromInteriorInverseCandidateMatrixMatrix
  sourceSeparationStatusEqInteriorInverseCandidateShapeSeparation :
    sourceShapeSeparation.sourceSeparationStatus =
      InteriorInverseCandidateShapeSeparationSourceSeparationStatus.sourceSeparatedAsInteriorTerminalFoldResidualAccumulatedEntry
  handoffStatus_eq :
    handoffStatus = InteriorTwoSidedInverseHandoffStatus.handoffFromInteriorInverseCandidateShapeSeparationShapeSeparation
  consumptionGateStatus_eq :
    consumptionGateStatus =
      InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus.interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
  noLeftProductStatus_eq :
    noLeftProductStatus = InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff
  noRightProductStatus_eq :
    noRightProductStatus = InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff
  noProductValidationStatus_eq :
    noProductValidationStatus =
      InteriorTwoSidedInverseNoProductValidationStatus.noProductValidationInInteriorTwoSidedInverseHandoff
  noRepairFormulaStatus_eq :
    noRepairFormulaStatus = InteriorTwoSidedInverseNoRepairFormulaStatus.noRepairFormulaInInteriorTwoSidedInverseHandoff
  noNewCandidateEntryStatus_eq :
    noNewCandidateEntryStatus =
      InteriorTwoSidedInverseNoNewCandidateEntryStatus.noNewCandidateEntryInInteriorTwoSidedInverseHandoff
  noInteriorEliminationCandidateEntryFallbackStatusEq :
    noInteriorEliminationCandidateEntryFallbackStatus =
      InteriorTwoSidedInverseNoInteriorEliminationCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseHandoff
  noFreeMatrixStatus_eq :
    noFreeMatrixStatus =
      InteriorTwoSidedInverseNoFreeMatrixStatus.noFreeMatrixOrEntryTableInInteriorTwoSidedInverseHandoff
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseHandoff
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseHandoff
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseHandoff
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseHandoff
  nextGateStatus_eq :
    nextGateStatus = InteriorTwoSidedInverseNextGateStatus.positiveInteriorTwoSidedInverseValidationAfterHandoff

namespace InteriorInverseCandidateValidationHandoff

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}

def fromShapeSeparation
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S where
  sourceShapeSeparation := S
  sourceMatrix := M
  sourceAccumulatedEntry := S.accumulatedInverseCandidateEntry
  sourceCandidateEntry := S.sourceCandidateEntry
  candidateMatrix := S.matrix
  handoffStatus := InteriorTwoSidedInverseHandoffStatus.handoffFromInteriorInverseCandidateShapeSeparationShapeSeparation
  consumptionGateStatus :=
    InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus.interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
  noLeftProductStatus := InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff
  noRightProductStatus := InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff
  noProductValidationStatus :=
    InteriorTwoSidedInverseNoProductValidationStatus.noProductValidationInInteriorTwoSidedInverseHandoff
  noRepairFormulaStatus := InteriorTwoSidedInverseNoRepairFormulaStatus.noRepairFormulaInInteriorTwoSidedInverseHandoff
  noNewCandidateEntryStatus :=
    InteriorTwoSidedInverseNoNewCandidateEntryStatus.noNewCandidateEntryInInteriorTwoSidedInverseHandoff
  noInteriorEliminationCandidateEntryFallbackStatus :=
    InteriorTwoSidedInverseNoInteriorEliminationCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseHandoff
  noFreeMatrixStatus :=
    InteriorTwoSidedInverseNoFreeMatrixStatus.noFreeMatrixOrEntryTableInInteriorTwoSidedInverseHandoff
  noMatrixInvStatus := InteriorTwoSidedInverseNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseHandoff
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noTwoSidedInvStatus := InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff
  noInteriorEliminationCertificateStatus :=
    InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseHandoff
  noDtnDataStatus :=
    InteriorTwoSidedInverseNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseHandoff
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseHandoff
  nextGateStatus := InteriorTwoSidedInverseNextGateStatus.positiveInteriorTwoSidedInverseValidationAfterHandoff
  sourceShapeSeparation_eq := by
    rfl
  sourceMatrixEqInteriorInverseCandidateShapeSeparationSourceMatrix := S.sourceMatrix_eq.symm
  sourceMatrixEqInteriorInverseCandidateMatrixMatrixExport := by
    rfl
  sourceAccumulatedEntryEqInteriorInverseCandidateShapeSeparationAccumulatedEntry := by
    rfl
  sourceCandidateEntryEqInteriorInverseCandidateShapeSeparationSourceCandidateEntry := by
    rfl
  candidateMatrixEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix := by
    rfl
  candidateMatrixEntryEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix := by
    intro i j
    rfl
  candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport := by
    intro i j
    exact S.matrixEntryFromInteriorInverseCandidateMatrixMatrix i j
  candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry := by
    intro i j
    exact S.matrixEntry_from_accumulatedEntry i j
  candidateMatrixEntry_eq_accumulatedTraceValue := by
    intro i j
    exact S.matrixEntry_from_accumulatedTraceValue i j
  sourceStatusEqInteriorInverseCandidateMatrix := M.sourceStatus_eq
  accumulatedSourceStatusEqInteriorTerminalFoldResidual := S.accumulatedSourceStatusEqInteriorTerminalFoldResidual
  shapeSeparationStatusEqInteriorInverseCandidateShapeSeparation := S.shapeSeparationStatus_eq
  sourceSeparationStatusEqInteriorInverseCandidateShapeSeparation := S.sourceSeparationStatus_eq
  handoffStatus_eq := by
    rfl
  consumptionGateStatus_eq := by
    rfl
  noLeftProductStatus_eq := by
    rfl
  noRightProductStatus_eq := by
    rfl
  noProductValidationStatus_eq := by
    rfl
  noRepairFormulaStatus_eq := by
    rfl
  noNewCandidateEntryStatus_eq := by
    rfl
  noInteriorEliminationCandidateEntryFallbackStatusEq := by
    rfl
  noFreeMatrixStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextGateStatus_eq := by
    rfl

end InteriorInverseCandidateValidationHandoff

def interiorInverseCandidateToInteriorTwoSidedInverseValidationHandoffFromShapeSeparation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S :=
  InteriorInverseCandidateValidationHandoff.fromShapeSeparation S

def InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) : Prop :=
  H.consumptionGateStatus =
    InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus.interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate

theorem interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidateForHandoff
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate H :=
  H.consumptionGateStatus_eq

theorem handoffCandidateEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.candidateMatrix = S.matrix :=
  H.candidateMatrixEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix

theorem handoffCandidateSourceEqInteriorInverseCandidateMatrixMatrixExport
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    H.candidateMatrix i j = M.matrix i j :=
  H.candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport i j

theorem handoffCandidateSourceEqInteriorTerminalFoldResidualAccumulatedEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    H.candidateMatrix i j = S.accumulatedInverseCandidateEntry.entry i j :=
  H.candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry i j

theorem noLeftProductForInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.noLeftProductStatus = InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff :=
  H.noLeftProductStatus_eq

theorem noRightProductForInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.noRightProductStatus = InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff :=
  H.noRightProductStatus_eq

theorem noTwoSidedInvForInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.noTwoSidedInvStatus = InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff :=
  H.noTwoSidedInvStatus_eq

theorem noInteriorEliminationCertificateForInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.noInteriorEliminationCertificateStatus =
      InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff :=
  H.noInteriorEliminationCertificateStatus_eq

theorem noInteriorEliminationDataForInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    H.noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseHandoff :=
  H.noInteriorEliminationDataStatus_eq

def regularInteriorInverseCandidateValidationHandoff
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorInverseCandidateValidationHandoff
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp) :=
  interiorInverseCandidateToInteriorTwoSidedInverseValidationHandoffFromShapeSeparation
    (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)

def variableInteriorInverseCandidateValidationHandoff
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorInverseCandidateValidationHandoff
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp) :=
  interiorInverseCandidateToInteriorTwoSidedInverseValidationHandoffFromShapeSeparation
    (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)

structure InteriorInverseCandidateGeneratedInverseCandidateLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorTwoSidedInverseGeneratedInverseCandidateLedgerStatus
  shapeSeparationLedger :
    InteriorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularHandoff :
    InteriorInverseCandidateValidationHandoff
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
  variableHandoff :
    InteriorInverseCandidateValidationHandoff
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
  shapeSeparationLedger_eq_main :
    shapeSeparationLedger =
      interiorInverseCandidateShapeSeparationLedger
        b β p regularWeight variableWeight regularPivot variablePivot
  regularHandoff_eq_main :
    regularHandoff = regularInteriorInverseCandidateValidationHandoff b p regularWeight
  variableHandoff_eq_main :
    variableHandoff = variableInteriorInverseCandidateValidationHandoff β p variableWeight
  regularCandidateFromInteriorInverseCandidateShapeSeparation :
    regularHandoff.candidateMatrix =
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight).matrix
  variableCandidateFromInteriorInverseCandidateShapeSeparation :
    variableHandoff.candidateMatrix =
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight).matrix
  regularCandidateFromInteriorInverseCandidateMatrix :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      regularHandoff.candidateMatrix i j =
        (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight).matrix i j
  variableCandidateFromInteriorInverseCandidateMatrix :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      variableHandoff.candidateMatrix i j =
        (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight).matrix i j
  regularCandidateFromInteriorTerminalFoldResidual :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      regularHandoff.candidateMatrix i j =
        (regularGeneratedInteriorInverseCandidateShapeSeparation
          b p regularWeight).accumulatedInverseCandidateEntry.entry i j
  variableCandidateFromInteriorTerminalFoldResidual :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      variableHandoff.candidateMatrix i j =
        (variableGeneratedInteriorInverseCandidateShapeSeparation
          β p variableWeight).accumulatedInverseCandidateEntry.entry i j
  regularMayConsumeOnlyHandoff :
    InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate regularHandoff
  variableMayConsumeOnlyHandoff :
    InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate variableHandoff
  regularNoLeftProduct :
    regularHandoff.noLeftProductStatus =
      InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff
  variableNoLeftProduct :
    variableHandoff.noLeftProductStatus =
      InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff
  regularNoRightProduct :
    regularHandoff.noRightProductStatus =
      InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff
  variableNoRightProduct :
    variableHandoff.noRightProductStatus =
      InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff
  regularNoTwoSidedInv :
    regularHandoff.noTwoSidedInvStatus =
      InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff
  variableNoTwoSidedInv :
    variableHandoff.noTwoSidedInvStatus =
      InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff
  regularNoInteriorEliminationCertificate :
    regularHandoff.noInteriorEliminationCertificateStatus =
      InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff
  variableNoInteriorEliminationCertificate :
    variableHandoff.noInteriorEliminationCertificateStatus =
      InteriorTwoSidedInverseNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorTwoSidedInverseHandoff
  regularNoInteriorEliminationData :
    regularHandoff.noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseHandoff
  variableNoInteriorEliminationData :
    variableHandoff.noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseHandoff
  status_eq_closed :
    status =
      InteriorTwoSidedInverseGeneratedInverseCandidateLedgerStatus.generatedInverseCandidateHandoffClosed

def interiorInverseCandidateGeneratedInverseCandidateLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorInverseCandidateGeneratedInverseCandidateLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status := InteriorTwoSidedInverseGeneratedInverseCandidateLedgerStatus.generatedInverseCandidateHandoffClosed
  shapeSeparationLedger :=
    interiorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularHandoff := regularInteriorInverseCandidateValidationHandoff b p regularWeight
  variableHandoff := variableInteriorInverseCandidateValidationHandoff β p variableWeight
  shapeSeparationLedger_eq_main := by
    rfl
  regularHandoff_eq_main := by
    rfl
  variableHandoff_eq_main := by
    rfl
  regularCandidateFromInteriorInverseCandidateShapeSeparation := by
    rfl
  variableCandidateFromInteriorInverseCandidateShapeSeparation := by
    rfl
  regularCandidateFromInteriorInverseCandidateMatrix := by
    intro i j
    exact
      (regularInteriorInverseCandidateValidationHandoff
        b p regularWeight).candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport i j
  variableCandidateFromInteriorInverseCandidateMatrix := by
    intro i j
    exact
      (variableInteriorInverseCandidateValidationHandoff
        β p variableWeight).candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport i j
  regularCandidateFromInteriorTerminalFoldResidual := by
    intro i j
    exact
      (regularInteriorInverseCandidateValidationHandoff
        b p regularWeight).candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry i j
  variableCandidateFromInteriorTerminalFoldResidual := by
    intro i j
    exact
      (variableInteriorInverseCandidateValidationHandoff
        β p variableWeight).candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry i j
  regularMayConsumeOnlyHandoff :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).consumptionGateStatus_eq
  variableMayConsumeOnlyHandoff :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).consumptionGateStatus_eq
  regularNoLeftProduct :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).noLeftProductStatus_eq
  variableNoLeftProduct :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).noLeftProductStatus_eq
  regularNoRightProduct :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).noRightProductStatus_eq
  variableNoRightProduct :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).noRightProductStatus_eq
  regularNoTwoSidedInv :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).noTwoSidedInvStatus_eq
  variableNoTwoSidedInv :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).noTwoSidedInvStatus_eq
  regularNoInteriorEliminationCertificate :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).noInteriorEliminationCertificateStatus_eq
  variableNoInteriorEliminationCertificate :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).noInteriorEliminationCertificateStatus_eq
  regularNoInteriorEliminationData :=
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).noInteriorEliminationDataStatus_eq
  variableNoInteriorEliminationData :=
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).noInteriorEliminationDataStatus_eq
  status_eq_closed := by
    rfl

theorem interiorInverseCandidateGeneratedInverseCandidateLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateGeneratedInverseCandidateLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorTwoSidedInverseGeneratedInverseCandidateLedgerStatus.generatedInverseCandidateHandoffClosed := by
  rfl

theorem interiorInverseCandidateGeneratedInverseCandidateLedger_regularMayConsumeOnlyHandoff
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
      (interiorInverseCandidateGeneratedInverseCandidateLedger
        b β p regularWeight variableWeight regularPivot variablePivot).regularHandoff :=
  (interiorInverseCandidateGeneratedInverseCandidateLedger
    b β p regularWeight variableWeight regularPivot variablePivot).regularMayConsumeOnlyHandoff

theorem interiorInverseCandidateGeneratedInverseCandidateLedger_regularNoTwoSidedInv
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateGeneratedInverseCandidateLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularHandoff.noTwoSidedInvStatus =
      InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff := by
  rfl


end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
