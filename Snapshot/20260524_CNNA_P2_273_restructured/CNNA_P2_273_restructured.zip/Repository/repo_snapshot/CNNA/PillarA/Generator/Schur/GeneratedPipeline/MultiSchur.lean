import CNNA.PillarA.Generator.Schur.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
import CNNA.PillarA.Generator.Schur.MultiSchur.MultiSchur

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger

universe u

inductive GeneratedMultiSchurGeneratedMultiSchurSourceStatus where
  | generatedLocallyFromMultiSchurResetLedger
  deriving DecidableEq, Repr

inductive GeneratedMultiSchurNoPublicMultiSchurStrongStatus where
  | noPublicMultiSchurStrongForcedInGeneratedMultiSchur
  deriving DecidableEq, Repr

inductive GeneratedMultiSchurNoForbiddenArithmeticTargetStatus where
  | noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur
  deriving DecidableEq, Repr

def generatedMultiSchurBoundaryOperatorGeneratedMultiSchur
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ :=
  L.sourceGeneralizedTopBoundaryDtN.boundaryOperator

def generatedMultiSchurApplyGeneratedMultiSchur
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    GeneratedBoundaryIndex A → ℝ :=
  L.sourceGeneralizedTopBoundaryDtN.«apply» φ

structure GeneratedMultiSchurGeneratedMultiSchur
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  sourceResetLedger : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H
  sourceStatus : GeneratedMultiSchurGeneratedMultiSchurSourceStatus
  sourceStatusEqMultiSchur :
    sourceStatus = GeneratedMultiSchurGeneratedMultiSchurSourceStatus.generatedLocallyFromMultiSchurResetLedger
  sourceGeneralizedTopBoundaryDtN :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H
  sourceGeneralizedTopBoundaryDtNEqMultiSchur :
    sourceGeneralizedTopBoundaryDtN = sourceResetLedger.sourceGeneralizedTopBoundaryDtN
  sourceTopBoundaryDtN : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H
  sourceTopBoundaryDtNEqMultiSchur :
    sourceTopBoundaryDtN = sourceResetLedger.sourceTopBoundaryDtN
  sourceInteriorEliminationCertificate :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H
  sourceInteriorEliminationCertificateEqMultiSchur :
    sourceInteriorEliminationCertificate = sourceResetLedger.sourceInteriorEliminationCertificate
  sourceInteriorEliminationCertificate_eq_topBoundary :
    sourceInteriorEliminationCertificate = sourceTopBoundaryDtN.sourceCertificate
  boundaryOperator : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ
  boundaryOperatorEqMultiSchur :
    boundaryOperator = sourceResetLedger.sourceGeneralizedTopBoundaryDtN.boundaryOperator
  boundaryOperator_eq_topBoundary :
    boundaryOperator = sourceTopBoundaryDtN.boundaryOperator
  boundaryOperator_eq_certificate :
    boundaryOperator = sourceInteriorEliminationCertificate.boundaryOperator
  boundaryOperator_eq_schur :
    boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  «apply» : (GeneratedBoundaryIndex A → ℝ) → GeneratedBoundaryIndex A → ℝ
  applyEqMultiSchur : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = sourceResetLedger.sourceGeneralizedTopBoundaryDtN.«apply» φ
  apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = boundaryOperator.mulVec φ
  certificate_inverseMatrix_eq_handoffCandidate :
    sourceInteriorEliminationCertificate.inverseMatrix = H.candidateMatrix
  noExternalDtNFromMultiSchur :
    sourceGeneralizedTopBoundaryDtN.noExternalDtNStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger
  sourceGeneralizedNoMultiSchurBeforeGeneratedMultiSchur :
    sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  noPublicMultiSchurStrongStatus : GeneratedMultiSchurNoPublicMultiSchurStrongStatus
  noPublicMultiSchurStrongStatus_eq :
    noPublicMultiSchurStrongStatus =
      GeneratedMultiSchurNoPublicMultiSchurStrongStatus.noPublicMultiSchurStrongForcedInGeneratedMultiSchur
  noForbiddenArithmeticTargetStatus : GeneratedMultiSchurNoForbiddenArithmeticTargetStatus
  noForbiddenArithmeticTargetStatus_eq :
    noForbiddenArithmeticTargetStatus =
      GeneratedMultiSchurNoForbiddenArithmeticTargetStatus.noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur

namespace GeneratedMultiSchurGeneratedMultiSchur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromMultiSchur
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H where
  sourceResetLedger := L
  sourceStatus := GeneratedMultiSchurGeneratedMultiSchurSourceStatus.generatedLocallyFromMultiSchurResetLedger
  sourceStatusEqMultiSchur := by
    rfl
  sourceGeneralizedTopBoundaryDtN := L.sourceGeneralizedTopBoundaryDtN
  sourceGeneralizedTopBoundaryDtNEqMultiSchur := by
    rfl
  sourceTopBoundaryDtN := L.sourceTopBoundaryDtN
  sourceTopBoundaryDtNEqMultiSchur := by
    rfl
  sourceInteriorEliminationCertificate := L.sourceInteriorEliminationCertificate
  sourceInteriorEliminationCertificateEqMultiSchur := by
    rfl
  sourceInteriorEliminationCertificate_eq_topBoundary := by
    exact L.topBoundary_sourceCertificate_eq_certificate.symm
  boundaryOperator := generatedMultiSchurBoundaryOperatorGeneratedMultiSchur L
  boundaryOperatorEqMultiSchur := by
    rfl
  boundaryOperator_eq_topBoundary := by
    exact L.generalized_boundaryOperator_eq_topBoundary
  boundaryOperator_eq_certificate := by
    calc
      L.sourceGeneralizedTopBoundaryDtN.boundaryOperator = L.sourceTopBoundaryDtN.boundaryOperator :=
        L.generalized_boundaryOperator_eq_topBoundary
      _ = L.sourceInteriorEliminationCertificate.boundaryOperator :=
        L.topBoundary_boundaryOperator_eq_certificate
  boundaryOperator_eq_schur := by
    calc
      L.sourceGeneralizedTopBoundaryDtN.boundaryOperator = L.sourceTopBoundaryDtN.boundaryOperator :=
        L.generalized_boundaryOperator_eq_topBoundary
      _ = L.sourceInteriorEliminationCertificate.boundaryOperator :=
        L.topBoundary_boundaryOperator_eq_certificate
      _ = generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
            generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
              L.sourceInteriorEliminationCertificate.inverseMatrix *
              generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
        L.certificate_boundaryOperator_eq_schur
  «apply» := generatedMultiSchurApplyGeneratedMultiSchur L
  applyEqMultiSchur := by
    intro φ
    rfl
  apply_eq_mulVec := by
    intro φ
    exact L.sourceGeneralizedTopBoundaryDtN.apply_eq_mulVec φ
  certificate_inverseMatrix_eq_handoffCandidate := by
    exact L.certificate_inverseMatrix_eq_handoffCandidate
  noExternalDtNFromMultiSchur := by
    exact L.noExternalDtN_from_generalized
  sourceGeneralizedNoMultiSchurBeforeGeneratedMultiSchur := by
    exact L.noMultiSchur_from_generalized
  noPublicMultiSchurStrongStatus :=
    GeneratedMultiSchurNoPublicMultiSchurStrongStatus.noPublicMultiSchurStrongForcedInGeneratedMultiSchur
  noPublicMultiSchurStrongStatus_eq := by
    rfl
  noForbiddenArithmeticTargetStatus :=
    GeneratedMultiSchurNoForbiddenArithmeticTargetStatus.noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur
  noForbiddenArithmeticTargetStatus_eq := by
    rfl

theorem sourceFromMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.sourceStatus = GeneratedMultiSchurGeneratedMultiSchurSourceStatus.generatedLocallyFromMultiSchurResetLedger :=
  G.sourceStatusEqMultiSchur

theorem boundaryOperatorFromMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.boundaryOperator = G.sourceResetLedger.sourceGeneralizedTopBoundaryDtN.boundaryOperator :=
  G.boundaryOperatorEqMultiSchur

theorem boundaryOperator_from_topBoundary
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.boundaryOperator = G.sourceTopBoundaryDtN.boundaryOperator :=
  G.boundaryOperator_eq_topBoundary

theorem boundaryOperator_from_certificate
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.boundaryOperator = G.sourceInteriorEliminationCertificate.boundaryOperator :=
  G.boundaryOperator_eq_certificate

theorem boundaryOperator_from_schur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          G.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  G.boundaryOperator_eq_schur

theorem applyFromMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    G.«apply» φ = G.sourceResetLedger.sourceGeneralizedTopBoundaryDtN.«apply» φ :=
  G.applyEqMultiSchur φ

theorem apply_from_mulVec
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    G.«apply» φ = G.boundaryOperator.mulVec φ :=
  G.apply_eq_mulVec φ

theorem certificate_inverseMatrix_from_handoffCandidate
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.sourceInteriorEliminationCertificate.inverseMatrix = H.candidateMatrix :=
  G.certificate_inverseMatrix_eq_handoffCandidate

theorem noExternalDtNStatusFromMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.sourceGeneralizedTopBoundaryDtN.noExternalDtNStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger :=
  G.noExternalDtNFromMultiSchur

theorem sourceGeneralizedNoMultiSchurStatusBeforeGeneratedMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger :=
  G.sourceGeneralizedNoMultiSchurBeforeGeneratedMultiSchur

theorem noPublicMultiSchurStrongForGeneratedMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.noPublicMultiSchurStrongStatus =
      GeneratedMultiSchurNoPublicMultiSchurStrongStatus.noPublicMultiSchurStrongForcedInGeneratedMultiSchur :=
  G.noPublicMultiSchurStrongStatus_eq

theorem noForbiddenArithmeticTargetForGeneratedMultiSchur
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    G.noForbiddenArithmeticTargetStatus =
      GeneratedMultiSchurNoForbiddenArithmeticTargetStatus.noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur :=
  G.noForbiddenArithmeticTargetStatus_eq

end GeneratedMultiSchurGeneratedMultiSchur

def generatedMultiSchurFromMultiSchurGeneratedMultiSchur
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H :=
  GeneratedMultiSchurGeneratedMultiSchur.fromMultiSchur L

def regularGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    GeneratedMultiSchurGeneratedMultiSchur
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  generatedMultiSchurFromMultiSchurGeneratedMultiSchur L.regularLedger

def variableGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    GeneratedMultiSchurGeneratedMultiSchur
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  generatedMultiSchurFromMultiSchurGeneratedMultiSchur L.variableLedger

structure GeneratedMultiSchurGeneratedMultiSchurLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceMultiSchurLedger : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight
  regularMultiSchur :
    GeneratedMultiSchurGeneratedMultiSchur
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableMultiSchur :
    GeneratedMultiSchurGeneratedMultiSchur
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularFromMultiSchur :
    regularMultiSchur = regularGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur sourceMultiSchurLedger
  variableFromMultiSchur :
    variableMultiSchur = variableGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur sourceMultiSchurLedger
  regularCertificateFromGeneralizedTopBoundaryDtN :
    regularMultiSchur.sourceInteriorEliminationCertificate =
      regularGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  variableCertificateFromGeneralizedTopBoundaryDtN :
    variableMultiSchur.sourceInteriorEliminationCertificate =
      variableGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  regularTopBoundaryDtNFromGeneralizedDtNSource :
    regularMultiSchur.sourceTopBoundaryDtN =
      regularGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  variableTopBoundaryDtNFromGeneralizedDtNSource :
    variableMultiSchur.sourceTopBoundaryDtN =
      variableGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  regularGeneralizedTopBoundaryDtNFromGeneralizedDtNToMultiSchurSourceLedger :
    regularMultiSchur.sourceGeneralizedTopBoundaryDtN =
      regularGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  variableGeneralizedTopBoundaryDtNFromGeneralizedDtNToMultiSchurSourceLedger :
    variableMultiSchur.sourceGeneralizedTopBoundaryDtN =
      variableGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
        sourceMultiSchurLedger.sourceAccumulatedEntryCancellationLedger
  regular_noPublicMultiSchurStrong :
    regularMultiSchur.noPublicMultiSchurStrongStatus =
      GeneratedMultiSchurNoPublicMultiSchurStrongStatus.noPublicMultiSchurStrongForcedInGeneratedMultiSchur
  variable_noPublicMultiSchurStrong :
    variableMultiSchur.noPublicMultiSchurStrongStatus =
      GeneratedMultiSchurNoPublicMultiSchurStrongStatus.noPublicMultiSchurStrongForcedInGeneratedMultiSchur
  regular_noForbiddenArithmeticTarget :
    regularMultiSchur.noForbiddenArithmeticTargetStatus =
      GeneratedMultiSchurNoForbiddenArithmeticTargetStatus.noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur
  variable_noForbiddenArithmeticTarget :
    variableMultiSchur.noForbiddenArithmeticTargetStatus =
      GeneratedMultiSchurNoForbiddenArithmeticTargetStatus.noArithmeticSourceLevelHistoryCharpolyFactorDiscriminantInGeneratedMultiSchur

def generatedMultiSchurGeneratedMultiSchurLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight where
  sourceMultiSchurLedger := L
  regularMultiSchur := regularGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur L
  variableMultiSchur := variableGeneratedMultiSchurFromMultiSchurGeneratedMultiSchur L
  regularFromMultiSchur := by
    rfl
  variableFromMultiSchur := by
    rfl
  regularCertificateFromGeneralizedTopBoundaryDtN := by
    exact L.regularInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN
  variableCertificateFromGeneralizedTopBoundaryDtN := by
    exact L.variableInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN
  regularTopBoundaryDtNFromGeneralizedDtNSource := by
    exact L.regularTopBoundaryDtNEqGeneralizedDtNSource
  variableTopBoundaryDtNFromGeneralizedDtNSource := by
    exact L.variableTopBoundaryDtNEqGeneralizedDtNSource
  regularGeneralizedTopBoundaryDtNFromGeneralizedDtNToMultiSchurSourceLedger := by
    exact L.regularGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger
  variableGeneralizedTopBoundaryDtNFromGeneralizedDtNToMultiSchurSourceLedger := by
    exact L.variableGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger
  regular_noPublicMultiSchurStrong := by
    rfl
  variable_noPublicMultiSchurStrong := by
    rfl
  regular_noForbiddenArithmeticTarget := by
    rfl
  variable_noForbiddenArithmeticTarget := by
    rfl

def generatedMultiSchurGeneratedMultiSchurLedger_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight :=
  generatedMultiSchurGeneratedMultiSchurLedger (generatedResetGeneratedResetLedger L)

theorem generatedMultiSchurGeneratedMultiSchurLedgerRegularBoundaryOperatorFromMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    L.regularMultiSchur.boundaryOperator =
      L.sourceMultiSchurLedger.regularLedger.sourceGeneralizedTopBoundaryDtN.boundaryOperator := by
  rw [L.regularFromMultiSchur]
  rfl

theorem generatedMultiSchurGeneratedMultiSchurLedgerVariableBoundaryOperatorFromMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    L.variableMultiSchur.boundaryOperator =
      L.sourceMultiSchurLedger.variableLedger.sourceGeneralizedTopBoundaryDtN.boundaryOperator := by
  rw [L.variableFromMultiSchur]
  rfl

theorem generatedMultiSchurGeneratedMultiSchurLedger_regular_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ) :
    L.regularMultiSchur.«apply» φ = L.regularMultiSchur.boundaryOperator.mulVec φ :=
  L.regularMultiSchur.apply_eq_mulVec φ

theorem generatedMultiSchurGeneratedMultiSchurLedger_variable_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ) :
    L.variableMultiSchur.«apply» φ = L.variableMultiSchur.boundaryOperator.mulVec φ :=
  L.variableMultiSchur.apply_eq_mulVec φ

end CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
