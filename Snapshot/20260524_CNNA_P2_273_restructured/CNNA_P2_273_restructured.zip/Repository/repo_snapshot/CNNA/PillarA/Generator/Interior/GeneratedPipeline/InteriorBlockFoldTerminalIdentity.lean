import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

universe u

open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus where
  | terminalIdentityFromInteriorBlockFoldInvarianceInvarianceAndTerminalCoverage
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus where
  | sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus where
  | sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus where
  | terminalCoverageNotYetExposedByInteriorAccumulatedTraceEvaluationOrInteriorTerminalFoldResidual
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus where
  | noAccumulatedEntryCancellationInvariantInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus where
  | noProductIdentityProofInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus where
  | noTwoSidedInvInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentity
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter
  | interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening
  deriving DecidableEq, Repr

structure GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  auditStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus
  tracePivotCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus
  terminalFoldResidualCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus
  noAccumulatedEntryCancellationStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus
  invarianceStatus_eq :
    invariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  auditStatus_eq :
    auditStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus.terminalCoverageNotYetExposedByInteriorAccumulatedTraceEvaluationOrInteriorTerminalFoldResidual
  tracePivotCoverageStatus_eq :
    tracePivotCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus_eq :
    terminalFoldResidualCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentity
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentity
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentity
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentity
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentity
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentity
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening

namespace GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T where
  invariance := I
  auditStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus.terminalCoverageNotYetExposedByInteriorAccumulatedTraceEvaluationOrInteriorTerminalFoldResidual
  tracePivotCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  noAccumulatedEntryCancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentity
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentity
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentity
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentity
  noDtnDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentity
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentity
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening
  invarianceStatus_eq :=
    I.invarianceStatus_eq
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    I.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    I.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    I.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  auditStatus_eq := by
    rfl
  tracePivotCoverageStatus_eq := by
    rfl
  terminalFoldResidualCoverageStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem nextConsumer_is_terminalCoverageSharpening
    (A0 : GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    A0.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening :=
  A0.nextConsumerStatus_eq

end GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity

structure GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  tracePivotCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus
  terminalFoldResidualCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus
  leftBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i i = 1
  leftBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorLeftBlockFold W T i j = 0
  rightBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i i = 1
  rightBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorRightBlockFold W T i j = 0
  invarianceStatus_eq :
    invariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  tracePivotCoverageStatus_eq :
    tracePivotCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus_eq :
    terminalFoldResidualCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage

namespace GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInteriorTerminalIdentityFieldSourceTerminalIdentityFieldCertificate
    (C : GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T where
  invariance := C.invariance
  tracePivotCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  leftBlockFold_eq_identity :=
    C.leftBlockFold_eq_identity
  rightBlockFold_eq_identity :=
    C.rightBlockFold_eq_identity
  leftBlockFold_diagonal :=
    C.leftBlockFold_diagonal
  leftBlockFold_offdiag :=
    C.leftBlockFold_offdiag
  rightBlockFold_diagonal :=
    C.rightBlockFold_diagonal
  rightBlockFold_offdiag :=
    C.rightBlockFold_offdiag
  invarianceStatus_eq :=
    C.invarianceStatus_eq
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    C.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  tracePivotCoverageStatus_eq := by
    rfl
  terminalFoldResidualCoverageStatus_eq := by
    rfl

end GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity

structure GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  terminalCoverage : GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  terminalIdentityStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus
  tracePivotCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus
  terminalFoldResidualCoverageStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus
  noAccumulatedEntryCancellationStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus
  invariance_eq_terminalCoverage : invariance = terminalCoverage.invariance
  leftBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftFoldSum_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
        W T invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightFoldSum_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
        W T invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftAccumulatedConvolution_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedLeftConvolution W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightAccumulatedConvolution_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedRightConvolution W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i i = 1
  leftBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorLeftBlockFold W T i j = 0
  rightBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i i = 1
  rightBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorRightBlockFold W T i j = 0
  leftAccumulatedConvolution_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedLeftConvolution W T i i = 1
  leftAccumulatedConvolution_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorAccumulatedLeftConvolution W T i j = 0
  rightAccumulatedConvolution_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedRightConvolution W T i i = 1
  rightAccumulatedConvolution_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorAccumulatedRightConvolution W T i j = 0
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  terminalIdentityStatus_eq :
    terminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus.terminalIdentityFromInteriorBlockFoldInvarianceInvarianceAndTerminalCoverage
  tracePivotCoverageStatus_eq :
    tracePivotCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus_eq :
    terminalFoldResidualCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentity
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentity
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentity
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentity
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentity
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentity
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter

namespace GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTerminalCoverage
    (C : GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T where
  terminalCoverage := C
  invariance := C.invariance
  terminalIdentityStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus.terminalIdentityFromInteriorBlockFoldInvarianceInvarianceAndTerminalCoverage
  tracePivotCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalFoldResidualCoverageStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  noAccumulatedEntryCancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentity
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentity
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentity
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentity
  noDtnDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentity
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentity
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter
  invariance_eq_terminalCoverage := by
    rfl
  leftBlockFold_eq_identity :=
    C.leftBlockFold_eq_identity
  rightBlockFold_eq_identity :=
    C.rightBlockFold_eq_identity
  leftFoldSum_eq_identity := by
    intro i j
    calc
      generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
          W T C.invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
          generatedInteriorLeftBlockFold W T i j :=
        C.invariance.leftFoldSumPreservation i j
      _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
        C.leftBlockFold_eq_identity i j
  rightFoldSum_eq_identity := by
    intro i j
    calc
      generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
          W T C.invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
          generatedInteriorRightBlockFold W T i j :=
        C.invariance.rightFoldSumPreservation i j
      _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
        C.rightBlockFold_eq_identity i j
  leftAccumulatedConvolution_eq_identity := by
    intro i j
    calc
      generatedInteriorAccumulatedLeftConvolution W T i j =
          generatedInteriorLeftBlockFold W T i j :=
        C.invariance.blockFoldNormalForm.leftAccumulatedConvolution_eq_blockFold i j
      _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
        C.leftBlockFold_eq_identity i j
  rightAccumulatedConvolution_eq_identity := by
    intro i j
    calc
      generatedInteriorAccumulatedRightConvolution W T i j =
          generatedInteriorRightBlockFold W T i j :=
        C.invariance.blockFoldNormalForm.rightAccumulatedConvolution_eq_blockFold i j
      _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
        C.rightBlockFold_eq_identity i j
  leftBlockFold_diagonal :=
    C.leftBlockFold_diagonal
  leftBlockFold_offdiag :=
    C.leftBlockFold_offdiag
  rightBlockFold_diagonal :=
    C.rightBlockFold_diagonal
  rightBlockFold_offdiag :=
    C.rightBlockFold_offdiag
  leftAccumulatedConvolution_diagonal := by
    intro i
    calc
      generatedInteriorAccumulatedLeftConvolution W T i i =
          generatedInteriorLeftBlockFold W T i i :=
        C.invariance.blockFoldNormalForm.leftAccumulatedConvolution_eq_blockFold i i
      _ = 1 :=
        C.leftBlockFold_diagonal i
  leftAccumulatedConvolution_offdiag := by
    intro i j hij
    calc
      generatedInteriorAccumulatedLeftConvolution W T i j =
          generatedInteriorLeftBlockFold W T i j :=
        C.invariance.blockFoldNormalForm.leftAccumulatedConvolution_eq_blockFold i j
      _ = 0 :=
        C.leftBlockFold_offdiag i j hij
  rightAccumulatedConvolution_diagonal := by
    intro i
    calc
      generatedInteriorAccumulatedRightConvolution W T i i =
          generatedInteriorRightBlockFold W T i i :=
        C.invariance.blockFoldNormalForm.rightAccumulatedConvolution_eq_blockFold i i
      _ = 1 :=
        C.rightBlockFold_diagonal i
  rightAccumulatedConvolution_offdiag := by
    intro i j hij
    calc
      generatedInteriorAccumulatedRightConvolution W T i j =
          generatedInteriorRightBlockFold W T i j :=
        C.invariance.blockFoldNormalForm.rightAccumulatedConvolution_eq_blockFold i j
      _ = 0 :=
        C.rightBlockFold_offdiag i j hij
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    C.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  terminalIdentityStatus_eq := by
    rfl
  tracePivotCoverageStatus_eq := by
    rfl
  terminalFoldResidualCoverageStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem leftBlockFold_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.leftBlockFold_eq_identity i j

theorem rightBlockFold_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.rightBlockFold_eq_identity i j

theorem leftFoldSum_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
      W T D.invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.leftFoldSum_eq_identity i j

theorem rightFoldSum_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
      W T D.invariance.localStepCancellation.bridge.traceLocalStepInvariant i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.rightFoldSum_eq_identity i j

theorem leftAccumulatedConvolution_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedLeftConvolution W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.leftAccumulatedConvolution_eq_identity i j

theorem rightAccumulatedConvolution_entry_eq_identity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedRightConvolution W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.rightAccumulatedConvolution_eq_identity i j

theorem noAccumulatedEntryCancellationInvariant
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    D.noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentity :=
  D.noAccumulatedEntryCancellationStatus_eq

theorem nextClosureIsInteriorBlockFolde
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    D.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter :=
  D.nextConsumerStatus_eq

end GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity

abbrev RegularGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p wp) :
    RegularGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity b p wp :=
  GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity.fromInvariance I

def variableBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p wp) :
    VariableGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity β p wp :=
  GeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity.fromInvariance I

def regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p wp) :
    RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p wp :=
  GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity.fromInteriorTerminalIdentityFieldSourceTerminalIdentityFieldCertificate C

def variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p wp) :
    VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p wp :=
  GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity.fromInteriorTerminalIdentityFieldSourceTerminalIdentityFieldCertificate C

def regularBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p wp) :
    RegularGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity b p wp :=
  GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity.fromTerminalCoverage C

def variableBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p wp) :
    VariableGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity β p wp :=
  GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity.fromTerminalCoverage C

structure InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity b p regularWeight
  variableAudit : VariableGeneratedInteriorBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity β p variableWeight
  auditStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus
  regularNextConsumerStatus_eq :
    regularAudit.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening
  variableNextConsumerStatus_eq :
    variableAudit.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening
  auditStatus_eq :
    auditStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus.terminalCoverageNotYetExposedByInteriorAccumulatedTraceEvaluationOrInteriorTerminalFoldResidual
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening

namespace InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditLedger

def fromRegularAndVariableInvariance
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularInvariance : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p regularWeight)
    (variableInvariance : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditLedger b β p regularWeight variableWeight where
  regularAudit := regularBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity regularInvariance
  variableAudit := variableBlockFoldTerminalCoverageAuditInteriorBlockFoldTerminalIdentity variableInvariance
  auditStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditStatus.terminalCoverageNotYetExposedByInteriorAccumulatedTraceEvaluationOrInteriorTerminalFoldResidual
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTerminalCoverageOrTerminalFoldResidualCoverageSharpening
  regularNextConsumerStatus_eq := by
    rfl
  variableNextConsumerStatus_eq := by
    rfl
  auditStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalCoverageAuditLedger

structure InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularTerminalIdentity : RegularGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity b p regularWeight
  variableTerminalIdentity : VariableGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity β p variableWeight
  terminalIdentityStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus
  regularNextConsumerStatus_eq :
    regularTerminalIdentity.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter
  variableNextConsumerStatus_eq :
    variableTerminalIdentity.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter
  terminalIdentityStatus_eq :
    terminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus.terminalIdentityFromInteriorBlockFoldInvarianceInvarianceAndTerminalCoverage
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter

namespace InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger

def fromRegularAndVariableTerminalCoverage
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularCoverage : RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p regularWeight)
    (variableCoverage : VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger b β p regularWeight variableWeight where
  regularTerminalIdentity := regularBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity regularCoverage
  variableTerminalIdentity := variableBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity variableCoverage
  terminalIdentityStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityStatus.terminalIdentityFromInteriorBlockFoldInvarianceInvarianceAndTerminalCoverage
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldeAccumulatedEntryCancellationAdapter
  regularNextConsumerStatus_eq := by
    rfl
  variableNextConsumerStatus_eq := by
    rfl
  terminalIdentityStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
