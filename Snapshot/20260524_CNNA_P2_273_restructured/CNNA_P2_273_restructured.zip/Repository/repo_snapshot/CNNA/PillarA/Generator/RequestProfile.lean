set_option autoImplicit false

namespace CNNA.PillarA.Generator

universe u v

inductive PreparationScope where
  | finiteComputation
  | wholeTheory
  | handoffConstrained
  deriving DecidableEq, Repr

inductive ApproximationRegime where
  | noOuterEnvironment
  | hasOuterEnvironment
  | unspecified
  deriving DecidableEq, Repr

inductive RequestStatus where
  | freeFiniteComputation
  | wholeTheoryPreparationCandidate
  | handoffConstrainedRequest
  | derivedInternalRegulatorCandidate
  | quarantinedSimulationControl
  | externalComparisonOnly
  | blockedUntilRealData
  | forbiddenAsOnticInput
  deriving DecidableEq, Repr

inductive RequestedDataTier where
  | carrier
  | approximant
  | matrix
  | dirichlet
  | dtn
  | operator
  | limitProfile
  deriving DecidableEq, Repr

structure LevelWindow where
  L_min : Nat
  L_max : Nat
  valid : L_min ≤ L_max

namespace LevelWindow

def singleton (L : Nat) : LevelWindow where
  L_min := L
  L_max := L
  valid := Nat.le_refl L

theorem singleton_min (L : Nat) : (singleton L).L_min = L := by
  rfl

theorem singleton_max (L : Nat) : (singleton L).L_max = L := by
  rfl

end LevelWindow

structure GlobalTheoryApproximationState where
  scope : PreparationScope
  levelWindow : LevelWindow
  regime : ApproximationRegime
  status : RequestStatus

namespace GlobalTheoryApproximationState

def L_min (state : GlobalTheoryApproximationState) : Nat :=
  state.levelWindow.L_min

def L_max (state : GlobalTheoryApproximationState) : Nat :=
  state.levelWindow.L_max

theorem L_min_le_L_max (state : GlobalTheoryApproximationState) :
    state.L_min ≤ state.L_max :=
  state.levelWindow.valid

end GlobalTheoryApproximationState

structure SinglePreparationLock where
  state : GlobalTheoryApproximationState

namespace SinglePreparationLock

def currentState (lock : SinglePreparationLock) : GlobalTheoryApproximationState :=
  lock.state

theorem currentState_eq (lock : SinglePreparationLock) :
    lock.currentState = lock.state := by
  rfl

end SinglePreparationLock

structure GeneratorRequestProfile where
  global : GlobalTheoryApproximationState
  requestedDataTier : RequestedDataTier

structure LockedHubApproximationView (lock : SinglePreparationLock) (Hub : Type u) where
  hub : Hub

namespace LockedHubApproximationView

def global {Hub : Type u} (lock : SinglePreparationLock)
    (_view : LockedHubApproximationView lock Hub) : GlobalTheoryApproximationState :=
  lock.state

theorem global_eq {Hub : Type u} (lock : SinglePreparationLock)
    (view : LockedHubApproximationView lock Hub) :
    global lock view = lock.state := by
  rfl

theorem same_global {HubA : Type u} {HubB : Type v} (lock : SinglePreparationLock)
    (left : LockedHubApproximationView lock HubA)
    (right : LockedHubApproximationView lock HubB) :
    global lock left = global lock right := by
  rfl

end LockedHubApproximationView

end CNNA.PillarA.Generator
