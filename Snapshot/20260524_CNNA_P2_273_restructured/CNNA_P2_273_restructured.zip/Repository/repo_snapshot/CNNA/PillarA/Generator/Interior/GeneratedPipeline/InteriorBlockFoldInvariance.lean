import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreeFormulaFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.OperationalDegreeReciprocalSource
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepCancellation

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation

universe u

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus where
  | foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldNormalFormSourceStatus where
  | sourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceLocalStepCancellationSourceStatus where
  | sourceFromInteriorLocalStepCancellationFullLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceTraceFoldSourceStatus where
  | sourceFromInteriorAccumulatedTraceEvaluationTraceAndInteriorTerminalFoldResidualFold
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus where
  | noTerminalIdentityInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus where
  | noAccumulatedEntryCancellationInvariantInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus where
  | noProductIdentityProofInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus where
  | noTwoSidedInvInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInFoldInvariance
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity
  deriving DecidableEq, Repr

def generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ pivot : GeneratedInteriorIndex A,
    generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T J pivot i j

def generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ pivot : GeneratedInteriorIndex A,
    generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T J pivot i j

structure GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  blockFoldNormalForm : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T
  localStepCancellation : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T
  invarianceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus
  blockFoldNormalFormSourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldNormalFormSourceStatus
  localStepCancellationSourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceLocalStepCancellationSourceStatus
  traceFoldSourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceTraceFoldSourceStatus
  noTerminalIdentityStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus
  noAccumulatedEntryCancellationStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus
  blockFoldNormalForm_eq_localStepSource :
    blockFoldNormalForm = localStepCancellation.bridge.blockFoldNormalForm
  localStepCancellation_bridgeSourceStatus_eq :
    localStepCancellation.bridgeSourceStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullBridgeSourceStatus.sourceFromBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
  localStepCancellation_status_eq :
    localStepCancellation.cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    blockFoldNormalForm.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    blockFoldNormalForm.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  leftStepPreservation :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T localStepCancellation.bridge.traceLocalStepInvariant pivot i j =
        generatedInteriorLeftBlockFoldKernel W T i j pivot
  rightStepPreservation :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T localStepCancellation.bridge.traceLocalStepInvariant pivot i j =
        generatedInteriorRightBlockFoldKernel W T i j pivot
  leftFoldSumPreservation :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
        W T localStepCancellation.bridge.traceLocalStepInvariant i j =
        generatedInteriorLeftBlockFold W T i j
  rightFoldSumPreservation :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
        W T localStepCancellation.bridge.traceLocalStepInvariant i j =
        generatedInteriorRightBlockFold W T i j
  invarianceStatus_eq :
    invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  blockFoldNormalFormSourceStatus_eq :
    blockFoldNormalFormSourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldNormalFormSourceStatus.sourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
  localStepCancellationSourceStatus_eq :
    localStepCancellationSourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceLocalStepCancellationSourceStatus.sourceFromInteriorLocalStepCancellationFullLocalStepCancellation
  traceFoldSourceStatus_eq :
    traceFoldSourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceTraceFoldSourceStatus.sourceFromInteriorAccumulatedTraceEvaluationTraceAndInteriorTerminalFoldResidualFold
  noTerminalIdentityStatus_eq :
    noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInFoldInvariance
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus.noProductIdentityProofInFoldInvariance
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus.noTwoSidedInvInFoldInvariance
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoInteriorEliminationDataStatus.noInteriorEliminationDataInFoldInvariance
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInFoldInvariance
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInFoldInvariance
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity

namespace GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromLocalStepCancellation
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T where
  blockFoldNormalForm := C.bridge.blockFoldNormalForm
  localStepCancellation := C
  invarianceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  blockFoldNormalFormSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldNormalFormSourceStatus.sourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
  localStepCancellationSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceLocalStepCancellationSourceStatus.sourceFromInteriorLocalStepCancellationFullLocalStepCancellation
  traceFoldSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceTraceFoldSourceStatus.sourceFromInteriorAccumulatedTraceEvaluationTraceAndInteriorTerminalFoldResidualFold
  noTerminalIdentityStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance
  noAccumulatedEntryCancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInFoldInvariance
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus.noProductIdentityProofInFoldInvariance
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus.noTwoSidedInvInFoldInvariance
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoInteriorEliminationDataStatus.noInteriorEliminationDataInFoldInvariance
  noDtnDataStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInFoldInvariance
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInFoldInvariance
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity
  blockFoldNormalForm_eq_localStepSource := by
    rfl
  localStepCancellation_bridgeSourceStatus_eq :=
    C.bridgeSourceStatus_eq
  localStepCancellation_status_eq :=
    C.cancellationStatus_eq
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    C.bridge.blockFoldNormalForm.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    C.bridge.blockFoldNormalForm.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    C.bridge.blockFoldNormalForm.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  leftStepPreservation := by
    intro pivot i j
    exact C.leftBridge_eq_kernel_from_residual_zero pivot i j
  rightStepPreservation := by
    intro pivot i j
    exact C.rightBridge_eq_kernel_from_residual_zero pivot i j
  leftFoldSumPreservation := by
    intro i j
    calc
      generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance W T C.bridge.traceLocalStepInvariant i j =
          ∑ pivot : GeneratedInteriorIndex A,
            generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
              W T C.bridge.traceLocalStepInvariant pivot i j := by
        rfl
      _ = ∑ pivot : GeneratedInteriorIndex A,
            generatedInteriorLeftBlockFoldKernel W T i j pivot := by
        refine Finset.sum_congr rfl ?_
        intro pivot _
        exact C.leftBridge_eq_kernel_from_residual_zero pivot i j
      _ = generatedInteriorLeftBlockFold W T i j := by
        exact (C.bridge.blockFoldNormalForm.leftBlockFold_eq_kernelSum i j).symm
  rightFoldSumPreservation := by
    intro i j
    calc
      generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance W T C.bridge.traceLocalStepInvariant i j =
          ∑ pivot : GeneratedInteriorIndex A,
            generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
              W T C.bridge.traceLocalStepInvariant pivot i j := by
        rfl
      _ = ∑ pivot : GeneratedInteriorIndex A,
            generatedInteriorRightBlockFoldKernel W T i j pivot := by
        refine Finset.sum_congr rfl ?_
        intro pivot _
        exact C.rightBridge_eq_kernel_from_residual_zero pivot i j
      _ = generatedInteriorRightBlockFold W T i j := by
        exact (C.bridge.blockFoldNormalForm.rightBlockFold_eq_kernelSum i j).symm
  invarianceStatus_eq := by
    rfl
  blockFoldNormalFormSourceStatus_eq := by
    rfl
  localStepCancellationSourceStatus_eq := by
    rfl
  traceFoldSourceStatus_eq := by
    rfl
  noTerminalIdentityStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromOperationalDegreeReciprocalSource
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T :=
  fromLocalStepCancellation
    (GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull.fromOperationalDegreeReciprocalSource S)

theorem leftStepPreservesKernel
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T I.localStepCancellation.bridge.traceLocalStepInvariant pivot i j =
      generatedInteriorLeftBlockFoldKernel W T i j pivot :=
  I.leftStepPreservation pivot i j

theorem rightStepPreservesKernel
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T I.localStepCancellation.bridge.traceLocalStepInvariant pivot i j =
      generatedInteriorRightBlockFoldKernel W T i j pivot :=
  I.rightStepPreservation pivot i j

theorem leftFoldSum_eq_blockFold
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldStepSourceInteriorBlockFoldInvariance
      W T I.localStepCancellation.bridge.traceLocalStepInvariant i j =
      generatedInteriorLeftBlockFold W T i j :=
  I.leftFoldSumPreservation i j

theorem rightFoldSum_eq_blockFold
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldStepSourceInteriorBlockFoldInvariance
      W T I.localStepCancellation.bridge.traceLocalStepInvariant i j =
      generatedInteriorRightBlockFold W T i j :=
  I.rightFoldSumPreservation i j

theorem noTerminalIdentity
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    I.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance :=
  I.noTerminalIdentityStatus_eq

theorem noAccumulatedEntryCancellationInvariant
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    I.noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInFoldInvariance :=
  I.noAccumulatedEntryCancellationStatus_eq

theorem nextClosureIsInteriorBlockFoldTerminalIdentity
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    I.nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity :=
  I.nextConsumerStatus_eq

end GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance

abbrev RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularBlockFoldInvarianceInteriorBlockFoldInvariance
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull b p wp) :
    RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p wp :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance.fromLocalStepCancellation C

def variableBlockFoldInvarianceInteriorBlockFoldInvariance
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull β p wp) :
    VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p wp :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance.fromLocalStepCancellation C

def regularBlockFoldInvarianceInteriorBlockFoldInvarianceFromOperationalDegreeReciprocalSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p wp) :
    RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p wp :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance.fromOperationalDegreeReciprocalSource S

def variableBlockFoldInvarianceInteriorBlockFoldInvarianceFromOperationalDegreeReciprocalSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p wp) :
    VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p wp :=
  GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance.fromOperationalDegreeReciprocalSource S

structure InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldInvarianceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularInvariance : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p regularWeight
  variableInvariance : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p variableWeight
  invarianceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus
  regularInvarianceStatus_eq :
    regularInvariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  variableInvarianceStatus_eq :
    variableInvariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  regularNoTerminalIdentityStatus_eq :
    regularInvariance.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance
  variableNoTerminalIdentityStatus_eq :
    variableInvariance.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance
  regularNoAccumulatedEntryCancellationStatus_eq :
    regularInvariance.noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInFoldInvariance
  variableNoAccumulatedEntryCancellationStatus_eq :
    variableInvariance.noAccumulatedEntryCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInFoldInvariance
  regularNoProductIdentityProofStatus_eq :
    regularInvariance.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus.noProductIdentityProofInFoldInvariance
  variableNoProductIdentityProofStatus_eq :
    variableInvariance.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoProductIdentityProofStatus.noProductIdentityProofInFoldInvariance
  regularNoTwoSidedInvStatus_eq :
    regularInvariance.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus.noTwoSidedInvInFoldInvariance
  variableNoTwoSidedInvStatus_eq :
    variableInvariance.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTwoSidedInvStatus.noTwoSidedInvInFoldInvariance
  invarianceStatus_eq :
    invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity

namespace InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldInvarianceLedger

def fromRegularAndVariableCancellations
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularCancellation : RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull b p regularWeight)
    (variableCancellation : VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldInvarianceLedger b β p regularWeight variableWeight where
  regularInvariance := regularBlockFoldInvarianceInteriorBlockFoldInvariance regularCancellation
  variableInvariance := variableBlockFoldInvarianceInteriorBlockFoldInvariance variableCancellation
  invarianceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentity
  regularInvarianceStatus_eq := by
    rfl
  variableInvarianceStatus_eq := by
    rfl
  regularNoTerminalIdentityStatus_eq := by
    rfl
  variableNoTerminalIdentityStatus_eq := by
    rfl
  regularNoAccumulatedEntryCancellationStatus_eq := by
    rfl
  variableNoAccumulatedEntryCancellationStatus_eq := by
    rfl
  regularNoProductIdentityProofStatus_eq := by
    rfl
  variableNoProductIdentityProofStatus_eq := by
    rfl
  regularNoTwoSidedInvStatus_eq := by
    rfl
  variableNoTwoSidedInvStatus_eq := by
    rfl
  invarianceStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromOperationalDegreeReciprocalSources
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p regularWeight)
    (variableSource : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldInvarianceLedger b β p regularWeight variableWeight :=
  fromRegularAndVariableCancellations
    (regularLocalStepCancellationInteriorLocalStepCancellationFullFromOperationalDegreeReciprocalSource regularSource)
    (variableLocalStepCancellationInteriorLocalStepCancellationFullFromOperationalDegreeReciprocalSource variableSource)

end InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceBlockFoldInvarianceLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
