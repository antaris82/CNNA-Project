import CNNA.PillarA.Generator.Schur.Arithmetic.HigherLevelCertificates

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

namespace Schur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}
variable {source : ArithmeticSource Cell T} {L : Nat}

inductive HigherLevelOutcomeRouterStatus where
  | quadraticOrderOutcomeRouterClosed
  deriving DecidableEq, Repr

inductive HigherLevelOutcomeExclusivityStatus where
  | exactlyOneCertificateConstructorSelected
  deriving DecidableEq, Repr

inductive HigherLevelQuadraticOrderDiscriminantForwardingStatus where
  | quadraticOnlyAfterCertificate
  | blockedForIrreducibleOrHigherDegree
  deriving DecidableEq, Repr

structure HigherLevelOutcomeRoute
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  certificate : HigherLevelQuadraticOrderNormCertificateCertificate B b hL z
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome
  outcome_eq_certificate : outcome = HigherLevelQuadraticOrderNormCertificateCertificate.outcome certificate
  routerStatus : HigherLevelOutcomeRouterStatus
  routerStatus_eq : routerStatus = HigherLevelOutcomeRouterStatus.quadraticOrderOutcomeRouterClosed
  exclusivityStatus : HigherLevelOutcomeExclusivityStatus
  exclusivityStatus_eq :
    exclusivityStatus = HigherLevelOutcomeExclusivityStatus.exactlyOneCertificateConstructorSelected
  levelGreaterThanThree : 3 < L
  route : B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory
  noCutSpecCarrierClaim :
    ∀ _k : BoundarySource.LevelHistoryIndex L,
      source.toc.approximant source.concretePolicy = T

namespace HigherLevelOutcomeRoute

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

def fromCertificate
    (C : HigherLevelQuadraticOrderNormCertificateCertificate B b hL z) :
    HigherLevelOutcomeRoute B b hL z where
  certificate := C
  outcome := HigherLevelQuadraticOrderNormCertificateCertificate.outcome C
  outcome_eq_certificate := by
    rfl
  routerStatus := HigherLevelOutcomeRouterStatus.quadraticOrderOutcomeRouterClosed
  routerStatus_eq := by
    rfl
  exclusivityStatus := HigherLevelOutcomeExclusivityStatus.exactlyOneCertificateConstructorSelected
  exclusivityStatus_eq := by
    rfl
  levelGreaterThanThree := hL
  route := B.route_recursiveHistory
  noCutSpecCarrierClaim := by
    intro k
    exact B.noCutSpecCarrierClaim_at k

def forwardingStatus (R : HigherLevelOutcomeRoute B b hL z) :
    HigherLevelQuadraticOrderDiscriminantForwardingStatus :=
  match R.outcome with
  | HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit =>
      HigherLevelQuadraticOrderDiscriminantForwardingStatus.quadraticOnlyAfterCertificate
  | HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner =>
      HigherLevelQuadraticOrderDiscriminantForwardingStatus.quadraticOnlyAfterCertificate
  | HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree =>
      HigherLevelQuadraticOrderDiscriminantForwardingStatus.blockedForIrreducibleOrHigherDegree

theorem router_status_closed
    (R : HigherLevelOutcomeRoute B b hL z) :
    R.routerStatus = HigherLevelOutcomeRouterStatus.quadraticOrderOutcomeRouterClosed :=
  R.routerStatus_eq

theorem exclusivity_status_closed
    (R : HigherLevelOutcomeRoute B b hL z) :
    R.exclusivityStatus = HigherLevelOutcomeExclusivityStatus.exactlyOneCertificateConstructorSelected :=
  R.exclusivityStatus_eq

theorem outcome_three_way
    (R : HigherLevelOutcomeRoute B b hL z) :
    R.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      R.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        R.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree := by
  have hC := HigherLevelQuadraticOrderNormCertificateCertificate.outcome_three_way R.certificate
  cases hC with
  | inl h =>
      exact Or.inl (Eq.trans R.outcome_eq_certificate h)
  | inr hRest =>
      cases hRest with
      | inl h =>
          exact Or.inr (Or.inl (Eq.trans R.outcome_eq_certificate h))
      | inr h =>
          exact Or.inr (Or.inr (Eq.trans R.outcome_eq_certificate h))

theorem route_recursiveHistory
    (R : HigherLevelOutcomeRoute B b hL z) :
    B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory :=
  R.route

theorem noCutSpecCarrierClaim_at
    (R : HigherLevelOutcomeRoute B b hL z)
    (k : BoundarySource.LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  R.noCutSpecCarrierClaim k

end HigherLevelOutcomeRoute

end Schur

namespace StrengtheningQuadraticOrderNormCertificate

abbrev QuadraticOrderNormCertificateOutcomeRouterStatus := Schur.HigherLevelOutcomeRouterStatus
abbrev QuadraticOrderNormCertificateOutcomeExclusivityStatus := Schur.HigherLevelOutcomeExclusivityStatus
abbrev QuadraticOrderNormCertificateQuadraticOrderDiscriminantForwardingStatus := Schur.HigherLevelQuadraticOrderDiscriminantForwardingStatus

abbrev QuadraticOrderNormCertificateOutcomeRoute
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : Schur.SpectralParameter) :=
  Schur.HigherLevelOutcomeRoute B b hL z

def QuadraticOrderNormCertificateOutcomeRouteFromCertificate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (C : Schur.HigherLevelQuadraticOrderNormCertificateCertificate B b hL z) :
    QuadraticOrderNormCertificateOutcomeRoute B b hL z :=
  Schur.HigherLevelOutcomeRoute.fromCertificate C

theorem QuadraticOrderNormCertificateOutcomeRouteThreeWay
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (R : QuadraticOrderNormCertificateOutcomeRoute B b hL z) :
    R.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      R.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        R.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree :=
  Schur.HigherLevelOutcomeRoute.outcome_three_way R

end StrengtheningQuadraticOrderNormCertificate

end CNNA.PillarA.Arithmetic
