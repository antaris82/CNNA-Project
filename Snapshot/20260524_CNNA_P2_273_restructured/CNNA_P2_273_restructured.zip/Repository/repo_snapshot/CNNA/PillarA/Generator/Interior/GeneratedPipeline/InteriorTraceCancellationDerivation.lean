import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTwoSidedInv

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open scoped BigOperators


universe u

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4146 where
  | sourceFromInteriorBlockInteriorEliminationTraceInteriorAccumulatedTraceEvaluationInteriorTerminalFoldResidualInteriorInverseCandidateMatrixInteriorInverseCandidateShapeSeparationInteriorTwoSidedInverseR3a
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefCD4B where
  | traceCancellationDerivedFromInteriorEliminationdbChain
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefD9C7 where
  | traceCancellationDerivationClosed
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4C9D where
  | r4MayConsumeOnlyProductCancellationLedger
  deriving DecidableEq, Repr

structure GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  interiorBlockProfile : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  productNormalFormLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger Cell p A P wp W E K T M S H
  sourceStatus : InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4146
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  noMatrixInvStatus : InteriorTwoSidedInverseValidationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B
  interiorBlockProfileEqInteriorBlock :
    interiorBlockProfile.profile = InteriorBlockStructureProfile.treeRecursive
  interiorBlockRestrictionEqInteriorBlock :
    interiorBlockProfile.restrictionStatus =
      InteriorBlockInteriorRestrictionStatus.interiorRestrictionFromDirichletEntryDirichletMatrix
  interiorBlockEntryClassificationEqInteriorBlock :
    interiorBlockProfile.entryClassificationStatus =
      InteriorBlockEntryClassificationStatus.interiorEntriesClassifiedFromGeneratedDirichletEntries
  interiorBlockNoFreeTableEqInteriorBlock :
    interiorBlockProfile.noFreeInteriorBlockStatus =
      InteriorBlockNoFreeInteriorBlockStatus.noFreeInteriorBlockTable
  localStepStatusEqInteriorEliminationTrace :
    ∀ i : GeneratedInteriorIndex A,
      (T.localStepOf i).stepStatus =
        InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed
  localStepResidualEqInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (T.localStepOf i).residualDatum.rowResidual j =
        generatedInteriorLocalRowResidual W (T.localStepOf i).pivotDatum.pivotIndex j
  localStepColumnResidualEqInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (T.localStepOf i).residualDatum.columnResidual j =
        generatedInteriorLocalColumnResidual W (T.localStepOf i).pivotDatum.pivotIndex j
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorTraceCancellationDerivationRefABA7 :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  traceTerminationEqInteriorAccumulatedTraceEvaluation :
    T.terminationStatus = InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :
    H.sourceAccumulatedEntry.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  matrixSourceStatusEqInteriorInverseCandidateMatrix :
    H.sourceMatrix.sourceStatus =
      InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus.matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  shapeSeparationStatusEqInteriorInverseCandidateShapeSeparation :
    H.sourceShapeSeparation.shapeSeparationStatus =
      InteriorInverseCandidateShapeSeparationShapeSeparationStatus.shapeSeparationFromInteriorInverseCandidateMatrixMatrix
  sourceSeparationStatusEqInteriorInverseCandidateShapeSeparation :
    H.sourceShapeSeparation.sourceSeparationStatus =
      InteriorInverseCandidateShapeSeparationSourceSeparationStatus.sourceSeparatedAsInteriorTerminalFoldResidualAccumulatedEntry
  handoffConsumptionStatusEqInteriorTwoSidedInverse :
    H.consumptionGateStatus =
      InteriorTwoSidedInverseInteriorTwoSidedInverseValidationConsumptionGateStatus.interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate
  handoffCandidateEntry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      H.candidateMatrix i j = generatedInteriorAccumulatedEntryValue T i j
  leftProductNormalForm_eq_r3a :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j
  rightProductNormalForm_eq_r3a :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j
  sourceStatus_eq :
    sourceStatus =
      InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4146.sourceFromInteriorBlockInteriorEliminationTraceInteriorAccumulatedTraceEvaluationInteriorTerminalFoldResidualInteriorInverseCandidateMatrixInteriorInverseCandidateShapeSeparationInteriorTwoSidedInverseR3a
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720

namespace GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromInteriorEliminationdbChain
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource Cell p A P wp W E K T M S H where
  interiorBlockProfile := GeneratedInteriorBlockStructureProfile.fromEntryLemmas W
  productNormalFormLedger := GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger.fromHandoff H
  sourceStatus :=
    InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4146.sourceFromInteriorBlockInteriorEliminationTraceInteriorAccumulatedTraceEvaluationInteriorTerminalFoldResidualInteriorInverseCandidateMatrixInteriorInverseCandidateShapeSeparationInteriorTwoSidedInverseR3a
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus := InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus :=
    InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  interiorBlockProfileEqInteriorBlock := by
    rfl
  interiorBlockRestrictionEqInteriorBlock := by
    rfl
  interiorBlockEntryClassificationEqInteriorBlock := by
    rfl
  interiorBlockNoFreeTableEqInteriorBlock := by
    rfl
  localStepStatusEqInteriorEliminationTrace := by
    intro i
    exact (T.localStepOf i).stepStatus_eq
  localStepResidualEqInteriorBlock := by
    intro i j
    exact T.traceStepResidualEqInteriorBlockInteriorBlock i j
  localStepColumnResidualEqInteriorBlock := by
    intro i j
    exact T.traceStepColumnResidualEqInteriorBlockInteriorBlock i j
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorTraceCancellationDerivationRefABA7 :=
    T.sourceStatus_eq
  traceTerminationEqInteriorAccumulatedTraceEvaluation :=
    T.terminationStatus_eq
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :=
    H.accumulatedSourceStatusEqInteriorTerminalFoldResidual
  matrixSourceStatusEqInteriorInverseCandidateMatrix :=
    H.sourceStatusEqInteriorInverseCandidateMatrix
  shapeSeparationStatusEqInteriorInverseCandidateShapeSeparation :=
    H.shapeSeparationStatusEqInteriorInverseCandidateShapeSeparation
  sourceSeparationStatusEqInteriorInverseCandidateShapeSeparation :=
    H.sourceSeparationStatusEqInteriorInverseCandidateShapeSeparation
  handoffConsumptionStatusEqInteriorTwoSidedInverse :=
    H.consumptionGateStatus_eq
  handoffCandidateEntry_eq_accumulatedTraceValue := by
    intro i j
    exact H.candidateMatrixEntry_eq_accumulatedTraceValue i j
  leftProductNormalForm_eq_r3a := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseLeftProductEntryEqSumAccumulated H i j
  rightProductNormalForm_eq_r3a := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseRightProductEntryEqSumAccumulated H i j
  sourceStatus_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource

structure GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  source : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource Cell p A P wp W E K T M S H
  derivationStatus : InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefCD4B
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  noMatrixInvStatus : InteriorTwoSidedInverseValidationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationNoProductIdentityProofStatus
  interiorEliminationFinalGateGateStatus : InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B
  leftNormalForm_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightNormalForm_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftNormalForm_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i i = 1
  leftNormalForm_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j = 0
  rightNormalForm_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i i = 1
  rightNormalForm_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j = 0
  derivationStatus_eq :
    derivationStatus =
      InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefCD4B.traceCancellationDerivedFromInteriorEliminationdbChain
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus_eq :
    interiorEliminationFinalGateGateStatus = InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720

namespace GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromSource
    (Q : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource Cell p A P wp W E K T M S H)
    (leftEntryIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (rightEntryIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (leftDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i i = 1)
    (leftOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j = 0)
    (rightDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i i = 1)
    (rightOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j = 0) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H where
  source := Q
  derivationStatus :=
    InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefCD4B.traceCancellationDerivedFromInteriorEliminationdbChain
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus := InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus :=
    InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus := InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  leftNormalForm_entry_eq_identity := leftEntryIdentity
  rightNormalForm_entry_eq_identity := rightEntryIdentity
  leftNormalForm_diagonal_entry := leftDiagonal
  leftNormalForm_offdiag_entry := leftOffdiag
  rightNormalForm_diagonal_entry := rightDiagonal
  rightNormalForm_offdiag_entry := rightOffdiag
  derivationStatus_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  interiorEliminationFinalGateGateStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation

def traceCancellationInvariantFromInteriorEliminationdbChain
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H where
  productNormalFormLedger := D.source.productNormalFormLedger
  status := InteriorTwoSidedInverseValidationTraceCancellationStatus.traceCancellationFromInteriorTerminalFoldResidualAccumulatedEntryAndR3aNormalForms
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus := InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus :=
    InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A := D.source.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorTraceCancellationDerivationRefABA7
  accumulatedSourceStatusEqInteriorTerminalFoldResidual := D.source.accumulatedSourceStatusEqInteriorTerminalFoldResidual
  productNormalFormStatus_eq := D.source.productNormalFormLedger.status_eq
  leftNormalForm_entry_eq_identity := D.leftNormalForm_entry_eq_identity
  rightNormalForm_entry_eq_identity := D.rightNormalForm_entry_eq_identity
  leftNormalForm_diagonal_entry := D.leftNormalForm_diagonal_entry
  leftNormalForm_offdiag_entry := D.leftNormalForm_offdiag_entry
  rightNormalForm_diagonal_entry := D.rightNormalForm_diagonal_entry
  rightNormalForm_offdiag_entry := D.rightNormalForm_offdiag_entry
  status_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl

theorem leftNormalFormCancellation_from_traceDerivation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.leftNormalForm_entry_eq_identity i j

theorem rightNormalFormCancellation_from_traceDerivation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.rightNormalForm_entry_eq_identity i j

def productCancellationLedger_from_traceCancellationDerivation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H :=
  GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger.fromTraceCancellationInvariant
    (traceCancellationInvariantFromInteriorEliminationdbChain D)

structure InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationLedger
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  derivation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H
  traceCancellationInvariant :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H
  productCancellationLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefD9C7
  r4GateStatus : InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4C9D
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationNoProductIdentityProofStatus
  interiorEliminationFinalGateGateStatus : InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B
  invariant_eq_derivation :
    traceCancellationInvariant = traceCancellationInvariantFromInteriorEliminationdbChain derivation
  productLedger_eq_derivation :
    productCancellationLedger = productCancellationLedger_from_traceCancellationDerivation derivation
  productLedgerStatus_eq :
    productCancellationLedger.status =
      InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation
  productLedgerNoProductIdentityProof_eq :
    productCancellationLedger.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  productLedgerInteriorEliminationfGateEq :
    productCancellationLedger.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  status_eq :
    status = InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefD9C7.traceCancellationDerivationClosed
  r4GateStatus_eq :
    r4GateStatus = InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4C9D.r4MayConsumeOnlyProductCancellationLedger
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus_eq :
    interiorEliminationFinalGateGateStatus = InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720

namespace InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationLedger

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromTraceCancellationDerivation
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H) :
    InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationLedger Cell p A P wp W E K T M S H where
  derivation := D
  traceCancellationInvariant := traceCancellationInvariantFromInteriorEliminationdbChain D
  productCancellationLedger := productCancellationLedger_from_traceCancellationDerivation D
  status := InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRefD9C7.traceCancellationDerivationClosed
  r4GateStatus := InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationStatusInteriorTraceCancellationDerivationRef4C9D.r4MayConsumeOnlyProductCancellationLedger
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus := InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  invariant_eq_derivation := by
    rfl
  productLedger_eq_derivation := by
    rfl
  productLedgerStatus_eq := by
    rfl
  productLedgerNoProductIdentityProof_eq := by
    rfl
  productLedgerInteriorEliminationfGateEq := by
    rfl
  status_eq := by
    rfl
  r4GateStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  interiorEliminationFinalGateGateStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationLedger

def regularTraceCancellationSourceFromInteriorEliminationdbChain
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource.fromInteriorEliminationdbChain
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableTraceCancellationSourceFromInteriorEliminationdbChain
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource.fromInteriorEliminationdbChain
    (variableInteriorInverseCandidateValidationHandoff β p wp)

def regularTraceCancellationInvariantFromInteriorEliminationdbChain
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp)) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  traceCancellationInvariantFromInteriorEliminationdbChain D

def variableTraceCancellationInvariantFromInteriorEliminationdbChain
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (D : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp)) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  traceCancellationInvariantFromInteriorEliminationdbChain D

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
