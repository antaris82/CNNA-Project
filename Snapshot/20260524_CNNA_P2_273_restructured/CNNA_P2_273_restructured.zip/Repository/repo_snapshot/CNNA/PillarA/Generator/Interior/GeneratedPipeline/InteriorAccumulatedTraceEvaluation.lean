import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry

universe u

inductive InteriorTerminalFoldResidualAccumulatedTraceEvaluationStatus where
  | accumulatedTraceEvaluationFromInteriorAccumulatedTraceEvaluationTrace
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualAccumulatedEntryFoldStatus where
  | accumulatedEntryFoldFromTracePivotStepResidualAndOrder
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualAccumulatedInverseCandidateEntryStatus where
  | accumulatedInverseCandidateEntryFromAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualAccumulatedSourceStatus where
  | accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus where
  | notOnlyLocalResidualWrapper
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualFoldUpdateOrderStatus where
  | foldUpdateOrderRecordedFromTraceStepPair
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualNextPositiveConstructionGate where
  | interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedgerStatus where
  | generatedInteriorAccumulatedEntryClosed
  deriving DecidableEq, Repr

def generatedInteriorTracePivotContribution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (T.traceStepOf i).pivotDatum.pivotEntry + (T.traceStepOf j).pivotDatum.pivotEntry

def generatedInteriorTraceLocalStepContribution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (T.traceStepOf i).localStep.stepUpdate.baseEntry i j

def generatedInteriorTraceResidualContribution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (T.traceStepOf i).residualDatum.rowResidual j

def generatedInteriorTraceFoldUpdateOrderContribution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (T.traceStepOf j).stepUpdate.columnResidual i

def generatedInteriorAccumulatedEntryValue
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorTracePivotContribution T i j +
    generatedInteriorTraceLocalStepContribution T i j +
      generatedInteriorTraceResidualContribution T i j +
        generatedInteriorTraceFoldUpdateOrderContribution T i j

structure GeneratedInteriorAccumulatedEntryFold
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  baseTraceEvaluation : GeneratedInteriorTraceEvaluation Cell p A P wp W E K T
  pivotContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  localStepContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  residualContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  foldUpdateOrderContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  accumulatedEntry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  foldStatus : InteriorTerminalFoldResidualAccumulatedEntryFoldStatus
  sourceStatus : InteriorTerminalFoldResidualAccumulatedSourceStatus
  notOnlyLocalResidualWrapperStatus : InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus
  foldUpdateOrderStatus : InteriorTerminalFoldResidualFoldUpdateOrderStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  trace_is_source : trace = T
  baseTraceEvaluation_is_fromTrace :
    baseTraceEvaluation = GeneratedInteriorTraceEvaluation.fromTrace T
  pivotContribution_from_tracePivotData :
    ∀ i j : GeneratedInteriorIndex A,
      pivotContribution i j = generatedInteriorTracePivotContribution T i j
  localStepContribution_from_traceLocalSteps :
    ∀ i j : GeneratedInteriorIndex A,
      localStepContribution i j = generatedInteriorTraceLocalStepContribution T i j
  residualContribution_from_traceResidualData :
    ∀ i j : GeneratedInteriorIndex A,
      residualContribution i j = generatedInteriorTraceResidualContribution T i j
  foldUpdateOrderContribution_from_traceStepOrder :
    ∀ i j : GeneratedInteriorIndex A,
      foldUpdateOrderContribution i j =
        generatedInteriorTraceFoldUpdateOrderContribution T i j
  accumulatedEntry_from_components :
    ∀ i j : GeneratedInteriorIndex A,
      accumulatedEntry i j =
        pivotContribution i j + localStepContribution i j +
          residualContribution i j + foldUpdateOrderContribution i j
  accumulatedEntry_from_trace :
    ∀ i j : GeneratedInteriorIndex A,
      accumulatedEntry i j = generatedInteriorAccumulatedEntryValue T i j
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  foldStatus_eq :
    foldStatus =
      InteriorTerminalFoldResidualAccumulatedEntryFoldStatus.accumulatedEntryFoldFromTracePivotStepResidualAndOrder
  sourceStatus_eq :
    sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  notOnlyLocalResidualWrapperStatus_eq :
    notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  foldUpdateOrderStatus_eq :
    foldUpdateOrderStatus =
      InteriorTerminalFoldResidualFoldUpdateOrderStatus.foldUpdateOrderRecordedFromTraceStepPair
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation

namespace GeneratedInteriorAccumulatedEntryFold

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromEliminationTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T where
  trace := T
  baseTraceEvaluation := GeneratedInteriorTraceEvaluation.fromTrace T
  pivotContribution := fun i j => generatedInteriorTracePivotContribution T i j
  localStepContribution := fun i j => generatedInteriorTraceLocalStepContribution T i j
  residualContribution := fun i j => generatedInteriorTraceResidualContribution T i j
  foldUpdateOrderContribution := fun i j =>
    generatedInteriorTraceFoldUpdateOrderContribution T i j
  accumulatedEntry := fun i j => generatedInteriorAccumulatedEntryValue T i j
  foldStatus :=
    InteriorTerminalFoldResidualAccumulatedEntryFoldStatus.accumulatedEntryFoldFromTracePivotStepResidualAndOrder
  sourceStatus :=
    InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  notOnlyLocalResidualWrapperStatus :=
    InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  foldUpdateOrderStatus :=
    InteriorTerminalFoldResidualFoldUpdateOrderStatus.foldUpdateOrderRecordedFromTraceStepPair
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  trace_is_source := by
    rfl
  baseTraceEvaluation_is_fromTrace := by
    rfl
  pivotContribution_from_tracePivotData := by
    intro i j
    rfl
  localStepContribution_from_traceLocalSteps := by
    intro i j
    rfl
  residualContribution_from_traceResidualData := by
    intro i j
    rfl
  foldUpdateOrderContribution_from_traceStepOrder := by
    intro i j
    rfl
  accumulatedEntry_from_components := by
    intro i j
    rfl
  accumulatedEntry_from_trace := by
    intro i j
    rfl
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    T.sourceStatus_eq
  foldStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  notOnlyLocalResidualWrapperStatus_eq := by
    rfl
  foldUpdateOrderStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl

end GeneratedInteriorAccumulatedEntryFold

structure GeneratedInteriorAccumulatedTraceEvaluation
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  accumulatedEntryFold : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  evaluationStatus : InteriorTerminalFoldResidualAccumulatedTraceEvaluationStatus
  sourceStatus : InteriorTerminalFoldResidualAccumulatedSourceStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  trace_is_source : trace = T
  accumulatedEntryFold_is_fromTrace :
    accumulatedEntryFold = GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  entry_eq_accumulatedFold :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = accumulatedEntryFold.accumulatedEntry i j
  entry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = generatedInteriorAccumulatedEntryValue T i j
  evaluationStatus_eq :
    evaluationStatus =
      InteriorTerminalFoldResidualAccumulatedTraceEvaluationStatus.accumulatedTraceEvaluationFromInteriorAccumulatedTraceEvaluationTrace
  sourceStatus_eq :
    sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation

namespace GeneratedInteriorAccumulatedTraceEvaluation

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromEliminationTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T where
  trace := T
  accumulatedEntryFold := GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  entry := fun i j =>
    (GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T).accumulatedEntry i j
  evaluationStatus :=
    InteriorTerminalFoldResidualAccumulatedTraceEvaluationStatus.accumulatedTraceEvaluationFromInteriorAccumulatedTraceEvaluationTrace
  sourceStatus :=
    InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  trace_is_source := by
    rfl
  accumulatedEntryFold_is_fromTrace := by
    rfl
  entry_eq_accumulatedFold := by
    intro i j
    rfl
  entry_eq_accumulatedTraceValue := by
    intro i j
    rfl
  evaluationStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl

end GeneratedInteriorAccumulatedTraceEvaluation

structure GeneratedInteriorAccumulatedInverseCandidateEntry
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  accumulatedTraceEvaluation :
    GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  candidateStatus : InteriorTerminalFoldResidualAccumulatedInverseCandidateEntryStatus
  sourceStatus : InteriorTerminalFoldResidualAccumulatedSourceStatus
  notOnlyLocalResidualWrapperStatus : InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorAccumulatedEntryCancellationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorTerminalFoldResidualNextPositiveConstructionGate
  trace_is_source : trace = T
  accumulatedTraceEvaluation_is_fromTrace :
    accumulatedTraceEvaluation =
      GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  entry_eq_accumulatedTraceEvaluation :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = accumulatedTraceEvaluation.entry i j
  entry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = generatedInteriorAccumulatedEntryValue T i j
  source_is_accumulatedTraceEvaluation :
    sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  candidateStatus_eq :
    candidateStatus =
      InteriorTerminalFoldResidualAccumulatedInverseCandidateEntryStatus.accumulatedInverseCandidateEntryFromAccumulatedTraceEvaluation
  notOnlyLocalResidualWrapperStatus_eq :
    notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate = InteriorTerminalFoldResidualNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry

namespace GeneratedInteriorAccumulatedInverseCandidateEntry

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromAccumulatedTraceEvaluation
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T where
  trace := T
  accumulatedTraceEvaluation :=
    GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  entry := fun i j =>
    (GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T).entry i j
  candidateStatus :=
    InteriorTerminalFoldResidualAccumulatedInverseCandidateEntryStatus.accumulatedInverseCandidateEntryFromAccumulatedTraceEvaluation
  sourceStatus :=
    InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  notOnlyLocalResidualWrapperStatus :=
    InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus :=
    InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus :=
    InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextPositiveConstructionGate := InteriorTerminalFoldResidualNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry
  trace_is_source := by
    rfl
  accumulatedTraceEvaluation_is_fromTrace := by
    rfl
  entry_eq_accumulatedTraceEvaluation := by
    intro i j
    rfl
  entry_eq_accumulatedTraceValue := by
    intro i j
    rfl
  source_is_accumulatedTraceEvaluation := by
    rfl
  candidateStatus_eq := by
    rfl
  notOnlyLocalResidualWrapperStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextPositiveConstructionGate_eq := by
    rfl

end GeneratedInteriorAccumulatedInverseCandidateEntry

def accumulatedEntry_from_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T :=
  GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T

def accumulatedTraceEvaluation_from_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T :=
  GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T

def accumulatedInverseCandidateEntry_from_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T :=
  GeneratedInteriorAccumulatedInverseCandidateEntry.fromAccumulatedTraceEvaluation T

theorem accumulatedEntry_uses_pivotData
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    F.pivotContribution i j = generatedInteriorTracePivotContribution T i j :=
  F.pivotContribution_from_tracePivotData i j

theorem accumulatedEntry_uses_localSteps
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    F.localStepContribution i j = generatedInteriorTraceLocalStepContribution T i j :=
  F.localStepContribution_from_traceLocalSteps i j

theorem accumulatedEntry_uses_residualData
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    F.residualContribution i j = generatedInteriorTraceResidualContribution T i j :=
  F.residualContribution_from_traceResidualData i j

theorem accumulatedEntry_respects_foldUpdateOrder
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    F.foldUpdateOrderContribution i j =
      generatedInteriorTraceFoldUpdateOrderContribution T i j :=
  F.foldUpdateOrderContribution_from_traceStepOrder i j

theorem accumulatedEntry_from_components
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    F.accumulatedEntry i j =
      F.pivotContribution i j + F.localStepContribution i j +
        F.residualContribution i j + F.foldUpdateOrderContribution i j :=
  F.accumulatedEntry_from_components i j

theorem inverseCandidateEntry_source_is_accumulatedTraceEvaluation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T) :
    I.accumulatedTraceEvaluation =
      GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T :=
  I.accumulatedTraceEvaluation_is_fromTrace

theorem generatedInteriorInverseCandidateEntry_not_only_localResidualWrapper
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T) :
    F.notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper :=
  F.notOnlyLocalResidualWrapperStatus_eq

theorem noFreeEntryTable_for_accumulatedEntryFold
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T) :
    F.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable :=
  F.noFreeInverseEntryTableStatus_eq

theorem noExternalInverseOracle_for_accumulatedEntryFold
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T) :
    F.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry :=
  F.noExternalInverseOracleStatus_eq

def regularGeneratedInteriorAccumulatedEntryFold
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedEntryFold
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp) :=
  accumulatedEntry_from_eliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableGeneratedInteriorAccumulatedEntryFold
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedEntryFold
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp) :=
  accumulatedEntry_from_eliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularGeneratedInteriorAccumulatedTraceEvaluation
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedTraceEvaluation
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp) :=
  accumulatedTraceEvaluation_from_eliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableGeneratedInteriorAccumulatedTraceEvaluation
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedTraceEvaluation
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp) :=
  accumulatedTraceEvaluation_from_eliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularGeneratedInteriorAccumulatedInverseCandidateEntry
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedInverseCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp) :=
  accumulatedInverseCandidateEntry_from_eliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableGeneratedInteriorAccumulatedInverseCandidateEntry
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorAccumulatedInverseCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp) :=
  accumulatedInverseCandidateEntry_from_eliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedgerStatus
  interiorInverseCandidateEntryLedger :
    InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularAccumulatedFold :
    GeneratedInteriorAccumulatedEntryFold
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
  variableAccumulatedFold :
    GeneratedInteriorAccumulatedEntryFold
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
  regularAccumulatedInverseCandidateEntry :
    GeneratedInteriorAccumulatedInverseCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
  variableAccumulatedInverseCandidateEntry :
    GeneratedInteriorAccumulatedInverseCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
  interiorInverseCandidateEntryLedger_eq_main :
    interiorInverseCandidateEntryLedger =
      generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
        b β p regularWeight variableWeight regularPivot variablePivot
  regularFoldNoFreeEntryTable :
    regularAccumulatedFold.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  variableFoldNoFreeEntryTable :
    variableAccumulatedFold.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  regularFoldNoExternalInverseOracle :
    regularAccumulatedFold.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  variableFoldNoExternalInverseOracle :
    variableAccumulatedFold.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  regularCandidateNoMatrixExport :
    regularAccumulatedInverseCandidateEntry.noMatrixExportStatus =
      InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  variableCandidateNoMatrixExport :
    variableAccumulatedInverseCandidateEntry.noMatrixExportStatus =
      InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  regularCandidateNoProductProof :
    regularAccumulatedInverseCandidateEntry.noProductProofStatus =
      InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  variableCandidateNoProductProof :
    variableAccumulatedInverseCandidateEntry.noProductProofStatus =
      InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  regularNextPositiveConstructionGate :
    regularAccumulatedInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorTerminalFoldResidualNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry
  variableNextPositiveConstructionGate :
    variableAccumulatedInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorTerminalFoldResidualNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry
  status_eq_closed :
    status =
      InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedgerStatus.generatedInteriorAccumulatedEntryClosed

def interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status :=
    InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedgerStatus.generatedInteriorAccumulatedEntryClosed
  interiorInverseCandidateEntryLedger :=
    generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularAccumulatedFold :=
    regularGeneratedInteriorAccumulatedEntryFold b p regularWeight
  variableAccumulatedFold :=
    variableGeneratedInteriorAccumulatedEntryFold β p variableWeight
  regularAccumulatedInverseCandidateEntry :=
    regularGeneratedInteriorAccumulatedInverseCandidateEntry b p regularWeight
  variableAccumulatedInverseCandidateEntry :=
    variableGeneratedInteriorAccumulatedInverseCandidateEntry β p variableWeight
  interiorInverseCandidateEntryLedger_eq_main := by
    rfl
  regularFoldNoFreeEntryTable := by
    rfl
  variableFoldNoFreeEntryTable := by
    rfl
  regularFoldNoExternalInverseOracle := by
    rfl
  variableFoldNoExternalInverseOracle := by
    rfl
  regularCandidateNoMatrixExport := by
    rfl
  variableCandidateNoMatrixExport := by
    rfl
  regularCandidateNoProductProof := by
    rfl
  variableCandidateNoProductProof := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  status_eq_closed := by
    rfl

theorem interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedgerStatus.generatedInteriorAccumulatedEntryClosed := by
  rfl

theorem interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularAccumulatedInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorTerminalFoldResidualNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportAfterAccumulatedEntry := by
  rfl



end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
