import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorProductIdentityProof

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open scoped BigOperators
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof


universe u

def twoSidedInv_from_productIdentityProofR4a
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (Q : GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H) :
    TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix :=
  provenTwoSidedInvFromInteriorTwoSidedInverse Q

def twoSidedInv_from_productCancellationLedger_via_r4a
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H) :
    TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (productIdentityProof_from_productCancellationLedger L)

def twoSidedInvFromInteriorEliminationCertificateLedgerViaR4a
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger Cell p A P wp W E K T M S H) :
    TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (productIdentityProofFromInteriorProductIdentityProofLedger L)

def regularTwoSidedInv_from_reRunProductCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    TwoSidedInv
      (generatedInteriorBlock (regularGeneratedWeightPolicyEntrySource b p regularWeight))
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight).candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (regularProductIdentityProof_from_reRunProductCancellationLedger L)

def variableTwoSidedInv_from_reRunProductCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    TwoSidedInv
      (generatedInteriorBlock (variableGeneratedWeightPolicyEntrySource β p variableWeight))
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight).candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (variableProductIdentityProof_from_reRunProductCancellationLedger L)

def regularTwoSidedInv_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    TwoSidedInv
      (generatedInteriorBlock (regularGeneratedWeightPolicyEntrySource b p regularWeight))
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight).candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (regularProductIdentityProof_from_accumulatedEntryCancellationLedger L)

def variableTwoSidedInv_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    TwoSidedInv
      (generatedInteriorBlock (variableGeneratedWeightPolicyEntrySource β p variableWeight))
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight).candidateMatrix :=
  twoSidedInv_from_productIdentityProofR4a
    (variableProductIdentityProof_from_accumulatedEntryCancellationLedger L)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
