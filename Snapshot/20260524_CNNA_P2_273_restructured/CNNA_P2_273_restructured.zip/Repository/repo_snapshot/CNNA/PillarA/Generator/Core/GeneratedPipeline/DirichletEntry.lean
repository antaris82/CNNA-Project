import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.SourceAndApproximation.MainPath
import CNNA.PillarA.Foundation.WeightPolicy

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition


universe u

inductive DirichletEntryAdjacencySourceStatus where
  | parentChildLevelAdjacencyFromGeneratedCarrier
  deriving DecidableEq, Repr

inductive DirichletEntryWeightPolicySourceStatus where
  | weightPolicyCarriedToGeneratedEntries
  deriving DecidableEq, Repr

inductive DirichletEntryDirichletEntryStatus where
  | entryComputedFromGeneratedAdjacencyAndWeightPolicy
  deriving DecidableEq, Repr

inductive DirichletEntryNoFreeAdjacencyStatus where
  | noFreeAdjacencyRelation
  deriving DecidableEq, Repr

inductive DirichletEntryNoFreeWeightStatus where
  | noFreeWeightFunction
  deriving DecidableEq, Repr

inductive DirichletEntryNoFreeMatrixStatus where
  | matrixExposedOnlyAsEntryFunction
  deriving DecidableEq, Repr

inductive DirichletEntryNoInteriorBlockStatus where
  | noInteriorBlockProfileInDirichletEntry
  deriving DecidableEq, Repr

inductive DirichletEntryNoInverseStatus where
  | noInverseOrInteriorEliminationInDirichletEntry
  deriving DecidableEq, Repr

inductive DirichletEntryNoDtnStatus where
  | noDtnGeneralizedDtnOrMultiSchurInDirichletEntry
  deriving DecidableEq, Repr

inductive DirichletEntryGeneratedDirichletEntryLedgerStatus where
  | generatedDirichletEntryComputedFromSources
  deriving DecidableEq, Repr

def castGeneratedCell
    {Cell : Nat → Type u} {m n : Nat} (h : m = n) (x : Cell m) : Cell n := by
  cases h
  exact x

def generatedForwardAdjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    (i j : GeneratedApproximantIndex A) : Prop :=
  if h : (GeneratedApproximantIndex.level j).val =
      (GeneratedApproximantIndex.level i).val + 1 then
    GeneratedApproximantIndex.cell i ∈
      SubstrateClass.parents
        (Cell := Cell)
        (castGeneratedCell h (GeneratedApproximantIndex.cell j))
  else
    False

instance generatedForwardAdjacentDecidable
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    (i j : GeneratedApproximantIndex A) :
    Decidable (generatedForwardAdjacent i j) := by
  unfold generatedForwardAdjacent
  infer_instance

def generatedAdjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    (i j : GeneratedApproximantIndex A) : Prop :=
  generatedForwardAdjacent i j ∨ generatedForwardAdjacent j i

instance generatedAdjacentDecidable
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    (i j : GeneratedApproximantIndex A) :
    Decidable (generatedAdjacent i j) := by
  unfold generatedAdjacent
  infer_instance

theorem generatedAdjacent_comm
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    (i j : GeneratedApproximantIndex A) :
    generatedAdjacent i j ↔ generatedAdjacent j i := by
  constructor
  · intro h
    cases h with
    | inl hf => exact Or.inr hf
    | inr hr => exact Or.inl hr
  · intro h
    cases h with
    | inl hf => exact Or.inr hf
    | inr hr => exact Or.inl hr

structure GeneratedAdjacencySource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A) where
  status : DirichletEntryAdjacencySourceStatus
  approximantRoute : A.route = ApproximantRoute.generatedToCSubstrate
  partitionRoute : P.route = InteriorEliminationaRPartitionRoute.generatedFromBoundaryInteriorPartitionCarrier
  boundarySubset : P.boundaryCarrier ⊆ P.approximantCarrier
  interiorSubset : P.interiorCarrier ⊆ P.approximantCarrier
  noFreeAdjacencyStatus : DirichletEntryNoFreeAdjacencyStatus
  noCutSpecBoundaryPortsStatus : InteriorEliminationaRNoCutSpecBoundaryPortsStatus
  status_eq_source :
    status =
      DirichletEntryAdjacencySourceStatus.parentChildLevelAdjacencyFromGeneratedCarrier
  noFreeAdjacencyStatus_eq :
    noFreeAdjacencyStatus = DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation
  noCutSpecBoundaryPortsStatus_eq :
    noCutSpecBoundaryPortsStatus =
      InteriorEliminationaRNoCutSpecBoundaryPortsStatus.noCutSpecOrBoundaryPortsInPartitionCore

namespace GeneratedAdjacencySource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}

def fromPartition : GeneratedAdjacencySource Cell p A P where
  status := DirichletEntryAdjacencySourceStatus.parentChildLevelAdjacencyFromGeneratedCarrier
  approximantRoute := A.route_eq_generated
  partitionRoute := P.route_eq_generated
  boundarySubset := P.boundary_subset_approximantCarrier
  interiorSubset := P.interior_subset_approximantCarrier
  noFreeAdjacencyStatus := DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation
  noCutSpecBoundaryPortsStatus := P.noCutSpecBoundaryPortsStatus
  status_eq_source := by
    rfl
  noFreeAdjacencyStatus_eq := by
    rfl
  noCutSpecBoundaryPortsStatus_eq := by
    exact P.noCutSpecBoundaryPortsStatus_eq

def adjacent (_S : GeneratedAdjacencySource Cell p A P)
    (i j : GeneratedApproximantIndex A) : Prop :=
  generatedAdjacent i j

theorem adjacent_eq_generated
    (S : GeneratedAdjacencySource Cell p A P)
    (i j : GeneratedApproximantIndex A) :
    S.adjacent i j = generatedAdjacent i j := by
  rfl

theorem adjacent_comm
    (S : GeneratedAdjacencySource Cell p A P)
    (i j : GeneratedApproximantIndex A) :
    S.adjacent i j ↔ S.adjacent j i := by
  exact generatedAdjacent_comm i j

theorem no_free_adjacency
    (S : GeneratedAdjacencySource Cell p A P) :
    S.noFreeAdjacencyStatus = DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation :=
  S.noFreeAdjacencyStatus_eq

end GeneratedAdjacencySource

structure GeneratedWeightPolicyEntrySource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy) where
  policy : WeightPolicy
  policy_eq_input : policy = wp
  status : DirichletEntryWeightPolicySourceStatus
  sourceWeightHookWeightHookStatus :
    CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath.WeightProvenanceStatus
  noFreeWeightStatus : DirichletEntryNoFreeWeightStatus
  noFreeAdjacencyStatus : DirichletEntryNoFreeAdjacencyStatus
  partitionRoute : P.route = InteriorEliminationaRPartitionRoute.generatedFromBoundaryInteriorPartitionCarrier
  status_eq_source :
    status = DirichletEntryWeightPolicySourceStatus.weightPolicyCarriedToGeneratedEntries
  sourceWeightHookWeightHookStatus_eq :
    sourceWeightHookWeightHookStatus =
      CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath.WeightProvenanceStatus.weightDeferredToGeneratedEntryLemmas
  noFreeWeightStatus_eq :
    noFreeWeightStatus = DirichletEntryNoFreeWeightStatus.noFreeWeightFunction
  noFreeAdjacencyStatus_eq :
    noFreeAdjacencyStatus = DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation

namespace GeneratedWeightPolicyEntrySource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable (wp : WeightPolicy)

def fromPartitionAndPolicy : GeneratedWeightPolicyEntrySource Cell p A P wp where
  policy := wp
  policy_eq_input := by
    rfl
  status := DirichletEntryWeightPolicySourceStatus.weightPolicyCarriedToGeneratedEntries
  sourceWeightHookWeightHookStatus :=
    CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath.WeightProvenanceStatus.weightDeferredToGeneratedEntryLemmas
  noFreeWeightStatus := DirichletEntryNoFreeWeightStatus.noFreeWeightFunction
  noFreeAdjacencyStatus := DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation
  partitionRoute := P.route_eq_generated
  status_eq_source := by
    rfl
  sourceWeightHookWeightHookStatus_eq := by
    rfl
  noFreeWeightStatus_eq := by
    rfl
  noFreeAdjacencyStatus_eq := by
    rfl

theorem no_free_weight
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    W.noFreeWeightStatus = DirichletEntryNoFreeWeightStatus.noFreeWeightFunction :=
  W.noFreeWeightStatus_eq

end GeneratedWeightPolicyEntrySource

def generatedEntryWeight
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedApproximantIndex A) : ℝ :=
  if generatedAdjacent i j then W.policy.constantWeight i j else 0

theorem generatedEntryWeight_zero_of_not_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (h : ¬ generatedAdjacent i j) :
    generatedEntryWeight W i j = 0 := by
  unfold generatedEntryWeight
  simp [h]

theorem generatedEntryWeight_of_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (h : generatedAdjacent i j) :
    generatedEntryWeight W i j = W.policy.constantWeight i j := by
  unfold generatedEntryWeight
  simp [h]

def generatedDirichlet_degree
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedApproximantIndex A) : ℝ :=
  ∑ j : GeneratedApproximantIndex A, generatedEntryWeight W i j

def generatedDirichlet_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedApproximantIndex A) : ℝ :=
  if i = j then generatedDirichlet_degree W i else - generatedEntryWeight W i j

def generatedDirichletMatrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    Matrix (GeneratedApproximantIndex A) (GeneratedApproximantIndex A) ℝ :=
  fun i j => generatedDirichlet_entry W i j

theorem generatedDirichletMatrix_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedApproximantIndex A) :
    generatedDirichletMatrix W i j = generatedDirichlet_entry W i j := by
  rfl

theorem generatedDirichlet_entry_zero_of_not_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (hij : i ≠ j)
    (hadj : ¬ generatedAdjacent i j) :
    generatedDirichlet_entry W i j = 0 := by
  unfold generatedDirichlet_entry generatedEntryWeight
  simp [hij, hadj]

theorem zero_of_not_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (hij : i ≠ j)
    (hadj : ¬ generatedAdjacent i j) :
    generatedDirichletMatrix W i j = 0 := by
  exact generatedDirichlet_entry_zero_of_not_adjacent W hij hadj

theorem generatedDirichlet_entry_offdiag_of_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (hij : i ≠ j)
    (hadj : generatedAdjacent i j) :
    generatedDirichlet_entry W i j = - W.policy.constantWeight i j := by
  unfold generatedDirichlet_entry generatedEntryWeight
  simp [hij, hadj]

theorem offdiag_of_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedApproximantIndex A}
    (hij : i ≠ j)
    (hadj : generatedAdjacent i j) :
    generatedDirichletMatrix W i j = - W.policy.constantWeight i j := by
  exact generatedDirichlet_entry_offdiag_of_adjacent W hij hadj

theorem diag_degree_or_regularized_degree
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedApproximantIndex A) :
    generatedDirichletMatrix W i i = generatedDirichlet_degree W i := by
  unfold generatedDirichletMatrix generatedDirichlet_entry
  simp

def generatedBoundaryDirichletEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedBoundaryIndex A)
    (j : GeneratedApproximantIndex A) : ℝ :=
  generatedDirichlet_entry W (GeneratedBoundaryIndex.toApproximantIndex i) j

def generatedInteriorDirichletEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedInteriorIndex A)
    (j : GeneratedApproximantIndex A) : ℝ :=
  generatedDirichlet_entry W (GeneratedInteriorIndex.toApproximantIndex i) j

theorem boundary_entry_from_generated_source
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedBoundaryIndex A)
    (j : GeneratedApproximantIndex A) :
    generatedDirichletMatrix W (GeneratedBoundaryIndex.toApproximantIndex i) j =
      generatedBoundaryDirichletEntry W i j := by
  rfl

theorem interior_entry_from_generated_source
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedInteriorIndex A)
    (j : GeneratedApproximantIndex A) :
    generatedDirichletMatrix W (GeneratedInteriorIndex.toApproximantIndex i) j =
      generatedInteriorDirichletEntry W i j := by
  rfl

structure GeneratedDirichletEntrySource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy) where
  adjacencySource : GeneratedAdjacencySource Cell p A P
  weightSource : GeneratedWeightPolicyEntrySource Cell p A P wp
  entryStatus : DirichletEntryDirichletEntryStatus
  noFreeMatrixStatus : DirichletEntryNoFreeMatrixStatus
  noInteriorBlockStatus : DirichletEntryNoInteriorBlockStatus
  noInverseStatus : DirichletEntryNoInverseStatus
  noDtnStatus : DirichletEntryNoDtnStatus
  matrix_eq_entry :
    generatedDirichletMatrix weightSource =
      fun i j => generatedDirichlet_entry weightSource i j
  entryStatus_eq :
    entryStatus =
      DirichletEntryDirichletEntryStatus.entryComputedFromGeneratedAdjacencyAndWeightPolicy
  noFreeMatrixStatus_eq :
    noFreeMatrixStatus = DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction
  noInteriorBlockStatus_eq :
    noInteriorBlockStatus = DirichletEntryNoInteriorBlockStatus.noInteriorBlockProfileInDirichletEntry
  noInverseStatus_eq :
    noInverseStatus = DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry
  noDtnStatus_eq :
    noDtnStatus = DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry

namespace GeneratedDirichletEntrySource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable (wp : WeightPolicy)

def fromPartitionAndPolicy : GeneratedDirichletEntrySource Cell p A P wp where
  adjacencySource := GeneratedAdjacencySource.fromPartition
  weightSource := GeneratedWeightPolicyEntrySource.fromPartitionAndPolicy wp
  entryStatus :=
    DirichletEntryDirichletEntryStatus.entryComputedFromGeneratedAdjacencyAndWeightPolicy
  noFreeMatrixStatus := DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction
  noInteriorBlockStatus := DirichletEntryNoInteriorBlockStatus.noInteriorBlockProfileInDirichletEntry
  noInverseStatus := DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry
  noDtnStatus := DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry
  matrix_eq_entry := by
    rfl
  entryStatus_eq := by
    rfl
  noFreeMatrixStatus_eq := by
    rfl
  noInteriorBlockStatus_eq := by
    rfl
  noInverseStatus_eq := by
    rfl
  noDtnStatus_eq := by
    rfl

theorem no_free_matrix
    {wp : WeightPolicy}
    (D : GeneratedDirichletEntrySource Cell p A P wp) :
    D.noFreeMatrixStatus = DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction :=
  D.noFreeMatrixStatus_eq

theorem no_inverse
    {wp : WeightPolicy}
    (D : GeneratedDirichletEntrySource Cell p A P wp) :
    D.noInverseStatus = DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry :=
  D.noInverseStatus_eq

theorem no_dtn
    {wp : WeightPolicy}
    (D : GeneratedDirichletEntrySource Cell p A P wp) :
    D.noDtnStatus = DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry :=
  D.noDtnStatus_eq

end GeneratedDirichletEntrySource

def regularGeneratedAdjacencySource
    (b : Nat) (p : ConcretePolicyOf) :
    GeneratedAdjacencySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) :=
  GeneratedAdjacencySource.fromPartition

def variableGeneratedAdjacencySource
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedAdjacencySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) :=
  GeneratedAdjacencySource.fromPartition

def regularGeneratedWeightPolicyEntrySource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedWeightPolicyEntrySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp :=
  GeneratedWeightPolicyEntrySource.fromPartitionAndPolicy wp

def variableGeneratedWeightPolicyEntrySource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedWeightPolicyEntrySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp :=
  GeneratedWeightPolicyEntrySource.fromPartitionAndPolicy wp

def regularGeneratedDirichletEntrySource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedDirichletEntrySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp :=
  GeneratedDirichletEntrySource.fromPartitionAndPolicy wp

def variableGeneratedDirichletEntrySource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedDirichletEntrySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp :=
  GeneratedDirichletEntrySource.fromPartitionAndPolicy wp

structure DirichletEntryGeneratedDirichletEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : DirichletEntryGeneratedDirichletEntryLedgerStatus
  boundaryInteriorPartitionLedger : InteriorEliminationaRGeneratedPartitionLedger b β p
  regularAdjacencySource :
    GeneratedAdjacencySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p)
  variableAdjacencySource :
    GeneratedAdjacencySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p)
  regularWeightSource :
    GeneratedWeightPolicyEntrySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
  variableWeightSource :
    GeneratedWeightPolicyEntrySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
  regularEntrySource :
    GeneratedDirichletEntrySource
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
  variableEntrySource :
    GeneratedDirichletEntrySource
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
  boundaryInteriorPartitionLedger_eq_main : boundaryInteriorPartitionLedger = generatedPartitionGeneratedPartitionLedger b β p
  regularAdjacency_eq_main :
    regularAdjacencySource = regularGeneratedAdjacencySource b p
  variableAdjacency_eq_main :
    variableAdjacencySource = variableGeneratedAdjacencySource β p
  regularWeight_eq_main :
    regularWeightSource = regularGeneratedWeightPolicyEntrySource b p regularWeight
  variableWeight_eq_main :
    variableWeightSource = variableGeneratedWeightPolicyEntrySource β p variableWeight
  regularEntry_eq_main :
    regularEntrySource = regularGeneratedDirichletEntrySource b p regularWeight
  variableEntry_eq_main :
    variableEntrySource = variableGeneratedDirichletEntrySource β p variableWeight
  regularMatrix_eq_entry :
    generatedDirichletMatrix regularWeightSource =
      fun i j => generatedDirichlet_entry regularWeightSource i j
  variableMatrix_eq_entry :
    generatedDirichletMatrix variableWeightSource =
      fun i j => generatedDirichlet_entry variableWeightSource i j
  regularNoFreeAdjacency :
    regularAdjacencySource.noFreeAdjacencyStatus =
      DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation
  variableNoFreeAdjacency :
    variableAdjacencySource.noFreeAdjacencyStatus =
      DirichletEntryNoFreeAdjacencyStatus.noFreeAdjacencyRelation
  regularNoFreeWeight :
    regularWeightSource.noFreeWeightStatus = DirichletEntryNoFreeWeightStatus.noFreeWeightFunction
  variableNoFreeWeight :
    variableWeightSource.noFreeWeightStatus = DirichletEntryNoFreeWeightStatus.noFreeWeightFunction
  regularNoFreeMatrix :
    regularEntrySource.noFreeMatrixStatus =
      DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction
  variableNoFreeMatrix :
    variableEntrySource.noFreeMatrixStatus =
      DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction
  regularNoInteriorBlock :
    regularEntrySource.noInteriorBlockStatus =
      DirichletEntryNoInteriorBlockStatus.noInteriorBlockProfileInDirichletEntry
  variableNoInteriorBlock :
    variableEntrySource.noInteriorBlockStatus =
      DirichletEntryNoInteriorBlockStatus.noInteriorBlockProfileInDirichletEntry
  regularNoInverse :
    regularEntrySource.noInverseStatus =
      DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry
  variableNoInverse :
    variableEntrySource.noInverseStatus =
      DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry
  regularNoDtn :
    regularEntrySource.noDtnStatus =
      DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry
  variableNoDtn :
    variableEntrySource.noDtnStatus =
      DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry
  status_eq_closed :
    status =
      DirichletEntryGeneratedDirichletEntryLedgerStatus.generatedDirichletEntryComputedFromSources

def generatedDirichletEntryGeneratedDirichletEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    DirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight where
  status :=
    DirichletEntryGeneratedDirichletEntryLedgerStatus.generatedDirichletEntryComputedFromSources
  boundaryInteriorPartitionLedger := generatedPartitionGeneratedPartitionLedger b β p
  regularAdjacencySource := regularGeneratedAdjacencySource b p
  variableAdjacencySource := variableGeneratedAdjacencySource β p
  regularWeightSource := regularGeneratedWeightPolicyEntrySource b p regularWeight
  variableWeightSource := variableGeneratedWeightPolicyEntrySource β p variableWeight
  regularEntrySource := regularGeneratedDirichletEntrySource b p regularWeight
  variableEntrySource := variableGeneratedDirichletEntrySource β p variableWeight
  boundaryInteriorPartitionLedger_eq_main := by
    rfl
  regularAdjacency_eq_main := by
    rfl
  variableAdjacency_eq_main := by
    rfl
  regularWeight_eq_main := by
    rfl
  variableWeight_eq_main := by
    rfl
  regularEntry_eq_main := by
    rfl
  variableEntry_eq_main := by
    rfl
  regularMatrix_eq_entry := by
    rfl
  variableMatrix_eq_entry := by
    rfl
  regularNoFreeAdjacency := by
    rfl
  variableNoFreeAdjacency := by
    rfl
  regularNoFreeWeight := by
    rfl
  variableNoFreeWeight := by
    rfl
  regularNoFreeMatrix := by
    rfl
  variableNoFreeMatrix := by
    rfl
  regularNoInteriorBlock := by
    rfl
  variableNoInteriorBlock := by
    rfl
  regularNoInverse := by
    rfl
  variableNoInverse := by
    rfl
  regularNoDtn := by
    rfl
  variableNoDtn := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).status =
      DirichletEntryGeneratedDirichletEntryLedgerStatus.generatedDirichletEntryComputedFromSources := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_regularNoFreeMatrix
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).regularEntrySource.noFreeMatrixStatus =
      DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_variableNoFreeMatrix
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).variableEntrySource.noFreeMatrixStatus =
      DirichletEntryNoFreeMatrixStatus.matrixExposedOnlyAsEntryFunction := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_regularNoInverse
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).regularEntrySource.noInverseStatus =
      DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_variableNoInverse
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).variableEntrySource.noInverseStatus =
      DirichletEntryNoInverseStatus.noInverseOrInteriorEliminationInDirichletEntry := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_regularNoDtn
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).regularEntrySource.noDtnStatus =
      DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry := by
  rfl

theorem generatedDirichletEntryGeneratedDirichletEntryLedger_variableNoDtn
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight).variableEntrySource.noDtnStatus =
      DirichletEntryNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInDirichletEntry := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
