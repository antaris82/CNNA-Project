import CNNA.PillarA.Generator.Core.SourceAndApproximation.Source

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.Source

universe u

inductive GeneratedPipelineStatus where
  | generatedToCSubstratePipeline
  deriving DecidableEq, Repr

inductive GeneratedPipelineAgreement where
  | sameGeneratedToCPipeline
  deriving DecidableEq, Repr

inductive GeneratedVariationStatus where
  | noArithmeticSpecialVariation
  deriving DecidableEq, Repr

inductive PolicyProvenanceStatus where
  | concretePolicyCarriedByGeneratedMainPath
  deriving DecidableEq, Repr

inductive WeightProvenanceStatus where
  | weightDeferredToGeneratedEntryLemmas
  deriving DecidableEq, Repr

inductive FreeWeightStatus where
  | noFreeWeightFunctionInMainPath
  deriving DecidableEq, Repr

inductive CutSpecCarrierClaimStatus where
  | noCutSpecCarrierClaimInMainPath
  deriving DecidableEq, Repr

inductive MatrixDataStatus where
  | noMatrixDataYetInMainPath
  deriving DecidableEq, Repr

inductive BoundaryPortsStatus where
  | noBoundaryPortsImportInMainPath
  deriving DecidableEq, Repr

structure PolicyProvenanceHook (p : ConcretePolicyOf) where
  status : PolicyProvenanceStatus
  policy : ConcretePolicyOf
  policy_eq_input : policy = p
  cutSpecCarrierClaimStatus : CutSpecCarrierClaimStatus

structure WeightProvenanceHook where
  status : WeightProvenanceStatus
  freeWeightStatus : FreeWeightStatus
  cutSpecCarrierClaimStatus : CutSpecCarrierClaimStatus
  matrixDataStatus : MatrixDataStatus

def policyProvenanceHook (p : ConcretePolicyOf) :
    PolicyProvenanceHook p where
  status := PolicyProvenanceStatus.concretePolicyCarriedByGeneratedMainPath
  policy := p
  policy_eq_input := by
    rfl
  cutSpecCarrierClaimStatus :=
    CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath

def weightProvenanceHook : WeightProvenanceHook where
  status := WeightProvenanceStatus.weightDeferredToGeneratedEntryLemmas
  freeWeightStatus := FreeWeightStatus.noFreeWeightFunctionInMainPath
  cutSpecCarrierClaimStatus :=
    CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  matrixDataStatus := MatrixDataStatus.noMatrixDataYetInMainPath

structure GeneratedMainPath
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf) where
  family : DirectedFamily (Cell := Cell)
  toc : ToCStrongOf Cell
  family_eq_generated : family = generatedBranchFamily Cell
  toc_eq_generated : toc = generatedBranchToC Cell
  carrier_eq_univ : ∀ L : Nat, family.carrier L = Finset.univ
  approximant_carrier_eq_univ_of_le : ∀ {L : Nat}, L ≤ p.L_max →
    (toc.approximant p).carrier L = Finset.univ
  pipelineStatus : GeneratedPipelineStatus
  policyHook : PolicyProvenanceHook p
  weightHook : WeightProvenanceHook
  boundaryPortsStatus : BoundaryPortsStatus
  cutSpecCarrierClaimStatus : CutSpecCarrierClaimStatus
  matrixDataStatus : MatrixDataStatus
  pipelineStatus_eq_generated :
    pipelineStatus = GeneratedPipelineStatus.generatedToCSubstratePipeline
  policyHook_eq : policyHook = policyProvenanceHook p
  weightHook_eq : weightHook = weightProvenanceHook
  noBoundaryPortsImport :
    boundaryPortsStatus = BoundaryPortsStatus.noBoundaryPortsImportInMainPath
  noCutSpecCarrierClaim_proof :
    cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  noMatrixDataYet_proof :
    matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath

def generatedMainPath
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf) :
    GeneratedMainPath Cell p where
  family := generatedBranchFamily Cell
  toc := generatedBranchToC Cell
  family_eq_generated := by
    rfl
  toc_eq_generated := by
    rfl
  carrier_eq_univ := by
    intro L
    exact generatedBranchFamily_carrier (Cell := Cell) L
  approximant_carrier_eq_univ_of_le := by
    intro L hL
    exact generatedBranchToC_approximant_carrier_of_le
      (Cell := Cell) (p := p) hL
  pipelineStatus := GeneratedPipelineStatus.generatedToCSubstratePipeline
  policyHook := policyProvenanceHook p
  weightHook := weightProvenanceHook
  boundaryPortsStatus := BoundaryPortsStatus.noBoundaryPortsImportInMainPath
  cutSpecCarrierClaimStatus :=
    CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  matrixDataStatus := MatrixDataStatus.noMatrixDataYetInMainPath
  pipelineStatus_eq_generated := by
    rfl
  policyHook_eq := by
    rfl
  weightHook_eq := by
    rfl
  noBoundaryPortsImport := by
    rfl
  noCutSpecCarrierClaim_proof := by
    rfl
  noMatrixDataYet_proof := by
    rfl

def regularGeneratedMainPath (b : Nat) (p : ConcretePolicyOf) :
    GeneratedMainPath (ConcreteSubstrate.RegularCell b) p :=
  generatedMainPath (ConcreteSubstrate.RegularCell b) p

def variableGeneratedMainPath (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedMainPath (LevelVariableSubstrate.LevelVariableCell β) p :=
  generatedMainPath (LevelVariableSubstrate.LevelVariableCell β) p

structure RegularVariableGeneratedPathPair
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) where
  regular : GeneratedMainPath (ConcreteSubstrate.RegularCell b) p
  variablePath : GeneratedMainPath (LevelVariableSubstrate.LevelVariableCell β) p
  regular_eq_main : regular = regularGeneratedMainPath b p
  variable_eq_main : variablePath = variableGeneratedMainPath β p
  pipelineAgreement : GeneratedPipelineAgreement
  pipelineAgreement_eq_same :
    pipelineAgreement = GeneratedPipelineAgreement.sameGeneratedToCPipeline
  variationStatus : GeneratedVariationStatus
  noArithmeticSpecialVariation_proof :
    variationStatus = GeneratedVariationStatus.noArithmeticSpecialVariation
  regularPolicyHook_eq : regular.policyHook = policyProvenanceHook p
  variablePolicyHook_eq : variablePath.policyHook = policyProvenanceHook p
  regularWeightHook_eq : regular.weightHook = weightProvenanceHook
  variableWeightHook_eq : variablePath.weightHook = weightProvenanceHook
  regularNoCutSpecCarrierClaim :
    regular.cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  variableNoCutSpecCarrierClaim :
    variablePath.cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  regularNoMatrixDataYet :
    regular.matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath
  variableNoMatrixDataYet :
    variablePath.matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath

def regularVariableGeneratedPathPair
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    RegularVariableGeneratedPathPair b β p where
  regular := regularGeneratedMainPath b p
  variablePath := variableGeneratedMainPath β p
  regular_eq_main := by
    rfl
  variable_eq_main := by
    rfl
  pipelineAgreement := GeneratedPipelineAgreement.sameGeneratedToCPipeline
  pipelineAgreement_eq_same := by
    rfl
  variationStatus := GeneratedVariationStatus.noArithmeticSpecialVariation
  noArithmeticSpecialVariation_proof := by
    rfl
  regularPolicyHook_eq := by
    rfl
  variablePolicyHook_eq := by
    rfl
  regularWeightHook_eq := by
    rfl
  variableWeightHook_eq := by
    rfl
  regularNoCutSpecCarrierClaim := by
    rfl
  variableNoCutSpecCarrierClaim := by
    rfl
  regularNoMatrixDataYet := by
    rfl
  variableNoMatrixDataYet := by
    rfl

theorem GeneratedMainPath.pipeline_eq_generated
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : GeneratedMainPath Cell p) :
    P.pipelineStatus =
      GeneratedPipelineStatus.generatedToCSubstratePipeline :=
  P.pipelineStatus_eq_generated

theorem GeneratedMainPath.policy_hook_eq
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : GeneratedMainPath Cell p) :
    P.policyHook = policyProvenanceHook p :=
  P.policyHook_eq

theorem GeneratedMainPath.weight_hook_eq
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : GeneratedMainPath Cell p) :
    P.weightHook = weightProvenanceHook :=
  P.weightHook_eq

theorem noCutSpecCarrierClaim
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : GeneratedMainPath Cell p) :
    P.cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath :=
  P.noCutSpecCarrierClaim_proof

theorem noMatrixDataYet
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : GeneratedMainPath Cell p) :
    P.matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath :=
  P.noMatrixDataYet_proof

theorem regularGeneratedMainPath_toc
    (b : Nat) (p : ConcretePolicyOf) :
    (regularGeneratedMainPath b p).toc = regularGeneratedToC b := by
  rfl

theorem variableGeneratedMainPath_toc
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (variableGeneratedMainPath β p).toc = variableGeneratedToC β := by
  rfl

theorem regularGeneratedMainPath_family
    (b : Nat) (p : ConcretePolicyOf) :
    (regularGeneratedMainPath b p).family = regularGeneratedFamily b := by
  rfl

theorem variableGeneratedMainPath_family
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (variableGeneratedMainPath β p).family = variableGeneratedFamily β := by
  rfl

theorem regularGeneratedMainPath_carrier_eq_univ
    (b : Nat) (p : ConcretePolicyOf) (L : Nat) :
    (regularGeneratedMainPath b p).family.carrier L = Finset.univ := by
  rfl

theorem variableGeneratedMainPath_carrier_eq_univ
    (β : Nat → Nat) (p : ConcretePolicyOf) (L : Nat) :
    (variableGeneratedMainPath β p).family.carrier L = Finset.univ := by
  rfl

theorem regularGeneratedMainPath_approximant_carrier_eq_univ_of_le
    (b : Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    ((regularGeneratedMainPath b p).toc.approximant p).carrier L = Finset.univ := by
  exact regularGeneratedToC_approximant_carrier_of_le (b := b) (p := p) hL

theorem variableGeneratedMainPath_approximant_carrier_eq_univ_of_le
    (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    ((variableGeneratedMainPath β p).toc.approximant p).carrier L = Finset.univ := by
  exact variableGeneratedToC_approximant_carrier_of_le (β := β) (p := p) hL

theorem sameGeneratedToCPipeline
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    (P : RegularVariableGeneratedPathPair b β p) :
    P.pipelineAgreement =
      GeneratedPipelineAgreement.sameGeneratedToCPipeline :=
  P.pipelineAgreement_eq_same

theorem noArithmeticSpecialVariation
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    (P : RegularVariableGeneratedPathPair b β p) :
    P.variationStatus =
      GeneratedVariationStatus.noArithmeticSpecialVariation :=
  P.noArithmeticSpecialVariation_proof

inductive GeneratedVariationLedgerStatus where
  | generatedRegularVariableProvenanceClosed
  deriving DecidableEq, Repr

structure GeneratedVariationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) where
  status : GeneratedVariationLedgerStatus
  pair : RegularVariableGeneratedPathPair b β p
  pair_eq_main : pair = regularVariableGeneratedPathPair b β p
  samePipeline :
    pair.pipelineAgreement =
      GeneratedPipelineAgreement.sameGeneratedToCPipeline
  noSpecialVariation :
    pair.variationStatus =
      GeneratedVariationStatus.noArithmeticSpecialVariation
  regularPolicyHook : pair.regular.policyHook = policyProvenanceHook p
  variablePolicyHook : pair.variablePath.policyHook = policyProvenanceHook p
  regularWeightHook : pair.regular.weightHook = weightProvenanceHook
  variableWeightHook : pair.variablePath.weightHook = weightProvenanceHook
  regularNoCutSpecCarrierClaim :
    pair.regular.cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  variableNoCutSpecCarrierClaim :
    pair.variablePath.cutSpecCarrierClaimStatus =
      CutSpecCarrierClaimStatus.noCutSpecCarrierClaimInMainPath
  regularNoMatrixDataYet :
    pair.regular.matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath
  variableNoMatrixDataYet :
    pair.variablePath.matrixDataStatus = MatrixDataStatus.noMatrixDataYetInMainPath

def generatedVariationGeneratedVariationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedVariationLedger b β p where
  status :=
    GeneratedVariationLedgerStatus.generatedRegularVariableProvenanceClosed
  pair := regularVariableGeneratedPathPair b β p
  pair_eq_main := by
    rfl
  samePipeline := by
    rfl
  noSpecialVariation := by
    rfl
  regularPolicyHook := by
    rfl
  variablePolicyHook := by
    rfl
  regularWeightHook := by
    rfl
  variableWeightHook := by
    rfl
  regularNoCutSpecCarrierClaim := by
    rfl
  variableNoCutSpecCarrierClaim := by
    rfl
  regularNoMatrixDataYet := by
    rfl
  variableNoMatrixDataYet := by
    rfl

theorem generatedVariationGeneratedVariationLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedVariationGeneratedVariationLedger b β p).status =
      GeneratedVariationLedgerStatus.generatedRegularVariableProvenanceClosed := by
  rfl

theorem generatedVariationGeneratedVariationLedger_samePipeline
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedVariationGeneratedVariationLedger b β p).pair.pipelineAgreement =
      GeneratedPipelineAgreement.sameGeneratedToCPipeline := by
  rfl

theorem generatedVariationGeneratedVariationLedger_noSpecialVariation
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedVariationGeneratedVariationLedger b β p).pair.variationStatus =
      GeneratedVariationStatus.noArithmeticSpecialVariation := by
  rfl

theorem generatedVariationGeneratedVariationLedger_regularNoMatrixDataYet
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedVariationGeneratedVariationLedger b β p).pair.regular.matrixDataStatus =
      MatrixDataStatus.noMatrixDataYetInMainPath := by
  rfl

theorem generatedVariationGeneratedVariationLedger_variableNoMatrixDataYet
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedVariationGeneratedVariationLedger b β p).pair.variablePath.matrixDataStatus =
      MatrixDataStatus.noMatrixDataYetInMainPath := by
  rfl

end CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath
