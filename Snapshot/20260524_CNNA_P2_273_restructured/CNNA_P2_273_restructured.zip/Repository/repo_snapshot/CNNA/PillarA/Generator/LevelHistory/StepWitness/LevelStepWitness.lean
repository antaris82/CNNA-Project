import CNNA.PillarA.Generator.OutputProfile
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ArithmeticSource

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev LevelStepWitnessOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.levelStepWitness

def levelStepWitnessOutputKind : DerivedOutputKind :=
  DerivedOutputKind.levelStepWitness

theorem levelStepWitness_kind_eq (profile : LevelStepWitnessOutputProfile) :
    profile.profile.kind = levelStepWitnessOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource

universe u

abbrev GeneratedLevelHistoryIndexLevelHistoryToSchurIndex (L : Nat) :=
  Fin (L + 1)

inductive LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus where
  | noCutSpecCarrierClaimInLevelHistoryToSchurIndex
  deriving DecidableEq, Repr

inductive LevelHistoryToSchurIndexNoSchurIndexBridgeStatus where
  | noSchurIndexBridgeInLevelHistoryToSchurIndex
  deriving DecidableEq, Repr

inductive LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus where
  | noLevelHistoryMatrixInLevelHistoryToSchurIndex
  deriving DecidableEq, Repr

inductive LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus where
  | noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex
  deriving DecidableEq, Repr

structure GeneratedLevelStepWitnessLevelHistoryToSchurIndex
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  sourceGeneratedArithmeticSourceLedger : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G
  level : Nat
  levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level
  source : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G
  sourceEqGeneratedArithmeticSource : source = sourceGeneratedArithmeticSourceLedger
  boundaryCarrier : Type u
  boundaryCarrier_eq_generated : boundaryCarrier = GeneratedBoundaryIndex A
  boundaryOperator : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ
  boundaryOperatorEqGeneratedArithmeticSource : boundaryOperator = source.boundaryOperator
  boundaryOperator_eq_schur :
    boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  «apply» : (GeneratedBoundaryIndex A → ℝ) → GeneratedBoundaryIndex A → ℝ
  applyEqGeneratedArithmeticSource : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = source.«apply» φ
  apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = boundaryOperator.mulVec φ
  noCutSpecCarrierClaimStatus : LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus
  noCutSpecCarrierClaimStatus_eq :
    noCutSpecCarrierClaimStatus =
      LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus.noCutSpecCarrierClaimInLevelHistoryToSchurIndex
  noSchurIndexBridgeStatus : LevelHistoryToSchurIndexNoSchurIndexBridgeStatus
  noSchurIndexBridgeStatus_eq :
    noSchurIndexBridgeStatus = LevelHistoryToSchurIndexNoSchurIndexBridgeStatus.noSchurIndexBridgeInLevelHistoryToSchurIndex
  noLevelHistoryMatrixStatus : LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus
  noLevelHistoryMatrixStatus_eq :
    noLevelHistoryMatrixStatus = LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistoryToSchurIndex
  noCharpolyDiscriminantStatus : LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex

namespace GeneratedLevelStepWitnessLevelHistoryToSchurIndex

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromGeneratedArithmeticSource
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G where
  sourceGeneratedArithmeticSourceLedger := LevelStepWitness
  level := level
  levelIndex := levelIndex
  source := LevelStepWitness
  sourceEqGeneratedArithmeticSource := by
    rfl
  boundaryCarrier := GeneratedBoundaryIndex A
  boundaryCarrier_eq_generated := by
    rfl
  boundaryOperator := LevelStepWitness.boundaryOperator
  boundaryOperatorEqGeneratedArithmeticSource := by
    rfl
  boundaryOperator_eq_schur := by
    exact LevelStepWitness.boundaryOperator_eq_schur
  «apply» := LevelStepWitness.«apply»
  applyEqGeneratedArithmeticSource := by
    intro φ
    rfl
  apply_eq_mulVec := by
    intro φ
    exact LevelStepWitness.apply_eq_mulVec φ
  noCutSpecCarrierClaimStatus := LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus.noCutSpecCarrierClaimInLevelHistoryToSchurIndex
  noCutSpecCarrierClaimStatus_eq := by
    rfl
  noSchurIndexBridgeStatus := LevelHistoryToSchurIndexNoSchurIndexBridgeStatus.noSchurIndexBridgeInLevelHistoryToSchurIndex
  noSchurIndexBridgeStatus_eq := by
    rfl
  noLevelHistoryMatrixStatus := LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistoryToSchurIndex
  noLevelHistoryMatrixStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex
  noCharpolyDiscriminantStatus_eq := by
    rfl

theorem sourceFromGeneratedArithmeticSource
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.source = W6.sourceGeneratedArithmeticSourceLedger :=
  W6.sourceEqGeneratedArithmeticSource

theorem boundaryCarrier_is_generated
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.boundaryCarrier = GeneratedBoundaryIndex A :=
  W6.boundaryCarrier_eq_generated

theorem boundaryOperatorFromGeneratedArithmeticSource
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.boundaryOperator = W6.source.boundaryOperator :=
  W6.boundaryOperatorEqGeneratedArithmeticSource

theorem boundaryOperator_from_schur
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          W6.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  W6.boundaryOperator_eq_schur

theorem applyFromGeneratedArithmeticSource
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    W6.«apply» φ = W6.source.«apply» φ :=
  W6.applyEqGeneratedArithmeticSource φ

theorem apply_from_mulVec
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    W6.«apply» φ = W6.boundaryOperator.mulVec φ :=
  W6.apply_eq_mulVec φ

theorem noCutSpecCarrierClaimForLevelHistoryToSchurIndex
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.noCutSpecCarrierClaimStatus =
      LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus.noCutSpecCarrierClaimInLevelHistoryToSchurIndex :=
  W6.noCutSpecCarrierClaimStatus_eq

theorem noSchurIndexBridgeForLevelHistoryToSchurIndex
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.noSchurIndexBridgeStatus = LevelHistoryToSchurIndexNoSchurIndexBridgeStatus.noSchurIndexBridgeInLevelHistoryToSchurIndex :=
  W6.noSchurIndexBridgeStatus_eq

theorem noLevelHistoryMatrixForLevelHistoryToSchurIndex
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.noLevelHistoryMatrixStatus =
      LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistoryToSchurIndex :=
  W6.noLevelHistoryMatrixStatus_eq

theorem noCharpolyDiscriminantForLevelHistoryToSchurIndex
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    W6.noCharpolyDiscriminantStatus =
      LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex :=
  W6.noCharpolyDiscriminantStatus_eq

end GeneratedLevelStepWitnessLevelHistoryToSchurIndex

def regularGeneratedLevelStepWitnessFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource L.regularSource level levelIndex

def variableGeneratedLevelStepWitnessFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource L.variableSource level levelIndex

structure LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceGeneratedArithmeticSourceLedger : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight
  level : Nat
  levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level
  regularWitness :
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableWitness :
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularSourceEqGeneratedArithmeticSource : regularWitness.source = sourceGeneratedArithmeticSourceLedger.regularSource
  variableSourceEqGeneratedArithmeticSource : variableWitness.source = sourceGeneratedArithmeticSourceLedger.variableSource
  regularSourceEqGeneratedMultiSchurLevelStepWitnessRef835F :
    regularWitness.source.sourceMultiSchur = sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableSourceEqGeneratedMultiSchurLevelStepWitnessRefFB2D :
    variableWitness.source.sourceMultiSchur = sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regular_boundaryCarrier_eq_generated :
    regularWitness.boundaryCarrier = GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p)
  variable_boundaryCarrier_eq_generated :
    variableWitness.boundaryCarrier = GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p)
  regularBoundaryOperatorEqGeneratedArithmeticSource :
    regularWitness.boundaryOperator = sourceGeneratedArithmeticSourceLedger.regularSource.boundaryOperator
  variableBoundaryOperatorEqGeneratedArithmeticSource :
    variableWitness.boundaryOperator = sourceGeneratedArithmeticSourceLedger.variableSource.boundaryOperator
  regular_boundaryOperator_eq_schur :
    regularWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN
        (regularGeneratedWeightPolicyEntrySource b p regularWeight) -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN
          (regularGeneratedWeightPolicyEntrySource b p regularWeight) *
          regularWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN
            (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variable_boundaryOperator_eq_schur :
    variableWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN
        (variableGeneratedWeightPolicyEntrySource β p variableWeight) -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN
          (variableGeneratedWeightPolicyEntrySource β p variableWeight) *
          variableWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN
            (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  regularApplyEqGeneratedArithmeticSource : ∀ φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ,
    regularWitness.«apply» φ = sourceGeneratedArithmeticSourceLedger.regularSource.«apply» φ
  variableApplyEqGeneratedArithmeticSource : ∀ φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ,
    variableWitness.«apply» φ = sourceGeneratedArithmeticSourceLedger.variableSource.«apply» φ
  regular_apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ,
    regularWitness.«apply» φ = regularWitness.boundaryOperator.mulVec φ
  variable_apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ,
    variableWitness.«apply» φ = variableWitness.boundaryOperator.mulVec φ
  regular_noCutSpecCarrierClaimStatus :
    regularWitness.noCutSpecCarrierClaimStatus =
      LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus.noCutSpecCarrierClaimInLevelHistoryToSchurIndex
  variable_noCutSpecCarrierClaimStatus :
    variableWitness.noCutSpecCarrierClaimStatus =
      LevelHistoryToSchurIndexNoCutSpecCarrierClaimStatus.noCutSpecCarrierClaimInLevelHistoryToSchurIndex
  regular_noSchurIndexBridgeStatus :
    regularWitness.noSchurIndexBridgeStatus = LevelHistoryToSchurIndexNoSchurIndexBridgeStatus.noSchurIndexBridgeInLevelHistoryToSchurIndex
  variable_noSchurIndexBridgeStatus :
    variableWitness.noSchurIndexBridgeStatus = LevelHistoryToSchurIndexNoSchurIndexBridgeStatus.noSchurIndexBridgeInLevelHistoryToSchurIndex
  regular_noLevelHistoryMatrixStatus :
    regularWitness.noLevelHistoryMatrixStatus =
      LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistoryToSchurIndex
  variable_noLevelHistoryMatrixStatus :
    variableWitness.noLevelHistoryMatrixStatus =
      LevelHistoryToSchurIndexNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistoryToSchurIndex
  regular_noCharpolyDiscriminantStatus :
    regularWitness.noCharpolyDiscriminantStatus =
      LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex
  variable_noCharpolyDiscriminantStatus :
    variableWitness.noCharpolyDiscriminantStatus =
      LevelHistoryToSchurIndexNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryToSchurIndex

def generatedLevelStepWitnessGeneratedLevelStepWitnessLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight where
  sourceGeneratedArithmeticSourceLedger := L
  level := level
  levelIndex := levelIndex
  regularWitness := regularGeneratedLevelStepWitnessFromGeneratedArithmeticSource L level levelIndex
  variableWitness := variableGeneratedLevelStepWitnessFromGeneratedArithmeticSource L level levelIndex
  regularSourceEqGeneratedArithmeticSource := by
    rfl
  variableSourceEqGeneratedArithmeticSource := by
    rfl
  regularSourceEqGeneratedMultiSchurLevelStepWitnessRef835F := by
    exact L.regularSourceEqGeneratedMultiSchurLevelStepWitnessRef6D51
  variableSourceEqGeneratedMultiSchurLevelStepWitnessRefFB2D := by
    exact L.variableSourceEqGeneratedMultiSchurLevelStepWitnessRef9E64
  regular_boundaryCarrier_eq_generated := by
    rfl
  variable_boundaryCarrier_eq_generated := by
    rfl
  regularBoundaryOperatorEqGeneratedArithmeticSource := by
    rfl
  variableBoundaryOperatorEqGeneratedArithmeticSource := by
    rfl
  regular_boundaryOperator_eq_schur := by
    exact L.regularSource.boundaryOperator_eq_schur
  variable_boundaryOperator_eq_schur := by
    exact L.variableSource.boundaryOperator_eq_schur
  regularApplyEqGeneratedArithmeticSource := by
    intro φ
    rfl
  variableApplyEqGeneratedArithmeticSource := by
    intro φ
    rfl
  regular_apply_eq_mulVec := by
    intro φ
    exact L.regularSource.apply_eq_mulVec φ
  variable_apply_eq_mulVec := by
    intro φ
    exact L.variableSource.apply_eq_mulVec φ
  regular_noCutSpecCarrierClaimStatus := by
    rfl
  variable_noCutSpecCarrierClaimStatus := by
    rfl
  regular_noSchurIndexBridgeStatus := by
    rfl
  variable_noSchurIndexBridgeStatus := by
    rfl
  regular_noLevelHistoryMatrixStatus := by
    rfl
  variable_noLevelHistoryMatrixStatus := by
    rfl
  regular_noCharpolyDiscriminantStatus := by
    rfl
  variable_noCharpolyDiscriminantStatus := by
    rfl

def generatedLevelStepWitnessGeneratedLevelStepWitnessLedger_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight :=
  generatedLevelStepWitnessGeneratedLevelStepWitnessLedger
    (generatedArithmeticSourceGeneratedArithmeticSourceLedger_from_accumulatedEntryCancellationLedger L)
    level levelIndex

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedgerRegularSourceFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    L.regularWitness.source = L.sourceGeneratedArithmeticSourceLedger.regularSource :=
  L.regularSourceEqGeneratedArithmeticSource

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedgerVariableSourceFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    L.variableWitness.source = L.sourceGeneratedArithmeticSourceLedger.variableSource :=
  L.variableSourceEqGeneratedArithmeticSource

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedgerRegularBoundaryOperatorFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    L.regularWitness.boundaryOperator = L.sourceGeneratedArithmeticSourceLedger.regularSource.boundaryOperator :=
  L.regularBoundaryOperatorEqGeneratedArithmeticSource

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedgerVariableBoundaryOperatorFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    L.variableWitness.boundaryOperator = L.sourceGeneratedArithmeticSourceLedger.variableSource.boundaryOperator :=
  L.variableBoundaryOperatorEqGeneratedArithmeticSource

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedger_regular_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ) :
    L.regularWitness.«apply» φ = L.regularWitness.boundaryOperator.mulVec φ :=
  L.regular_apply_eq_mulVec φ

theorem generatedLevelStepWitnessGeneratedLevelStepWitnessLedger_variable_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ) :
    L.variableWitness.«apply» φ = L.variableWitness.boundaryOperator.mulVec φ :=
  L.variable_apply_eq_mulVec φ

end CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
