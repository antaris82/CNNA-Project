import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree

universe u

inductive DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus where
  | generatedDegreeReciprocalProfileRequired
  | generatedDegreeReciprocalProfileProvided
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceScaleSourceStatus where
  | scaleSourceBuiltFromGeneratedDegreeReciprocalProfile
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoScalarInvStatus where
  | noScalarInvInGeneratedDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoMatrixInvStatus where
  | noMatrixInvInGeneratedDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoExternalScaleOracleStatus where
  | noExternalScaleOracleInGeneratedDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInGeneratedDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInGeneratedDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInDegreePivotScaleSource
  deriving DecidableEq, Repr

inductive DegreePivotScaleSourceNextConsumerStatus where
  | generatedDegreeReciprocalProfileStillRequired
  | interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  deriving DecidableEq, Repr

structure GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T
  generatedDegreePivotScale : GeneratedInteriorIndex A → ℝ
  profileStatus : DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus
  noScalarInvStatus : DegreePivotScaleSourceNoScalarInvStatus
  noMatrixInvStatus : DegreePivotScaleSourceNoMatrixInvStatus
  noExternalScaleOracleStatus : DegreePivotScaleSourceNoExternalScaleOracleStatus
  source_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  generatedDegreePivotScale_mul_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      generatedDegreePivotScale pivot *
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) = 1
  generatedDegree_mul_generatedDegreePivotScale :
    ∀ pivot : GeneratedInteriorIndex A,
      generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) *
          generatedDegreePivotScale pivot = 1
  profileStatus_eq :
    profileStatus =
      DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus.generatedDegreeReciprocalProfileProvided
  noScalarInvStatus_eq :
    noScalarInvStatus =
      DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource

namespace GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromGeneratedDegreeReciprocalProfile
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (generatedDegreePivotScale : GeneratedInteriorIndex A → ℝ)
    (hLeftDegree : ∀ pivot : GeneratedInteriorIndex A,
      generatedDegreePivotScale pivot *
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) = 1)
    (hRightDegree : ∀ pivot : GeneratedInteriorIndex A,
      generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) *
          generatedDegreePivotScale pivot = 1) :
    GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T where
  requirement := R
  generatedDegreePivotScale := generatedDegreePivotScale
  profileStatus :=
    DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus.generatedDegreeReciprocalProfileProvided
  noScalarInvStatus :=
    DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus :=
    DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus :=
    DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource
  source_eq_generatedDegree := by
    intro pivot
    exact R.pivotEntry_eq_generatedDegree pivot
  generatedDegreePivotScale_mul_generatedDegree := hLeftDegree
  generatedDegree_mul_generatedDegreePivotScale := hRightDegree
  profileStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl

theorem leftGeneratedDegreeEquation
    (D : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    D.generatedDegreePivotScale pivot *
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex) = 1 :=
  D.generatedDegreePivotScale_mul_generatedDegree pivot

theorem rightGeneratedDegreeEquation
    (D : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex) *
        D.generatedDegreePivotScale pivot = 1 :=
  D.generatedDegree_mul_generatedDegreePivotScale pivot

theorem source_eq_generatedDegree_of
    (D : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      generatedDirichlet_degree W
        (GeneratedInteriorIndex.toApproximantIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex) :=
  D.source_eq_generatedDegree pivot

end GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource

def generatedDegreePivotScaleSourceFromReciprocalProfileDegreePivotScaleSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T) :
    GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T :=
  GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness.fromGeneratedDegreeScale
    D.requirement
    D.generatedDegreePivotScale
    (by
      intro pivot
      calc
        D.generatedDegreePivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry
            = D.generatedDegreePivotScale pivot *
                generatedDirichlet_degree W
                  (GeneratedInteriorIndex.toApproximantIndex
                    (T.localStepOf pivot).pivotDatum.pivotIndex) := by
              rw [D.source_eq_generatedDegree pivot]
        _ = 1 := D.generatedDegreePivotScale_mul_generatedDegree pivot)
    (by
      intro pivot
      calc
        (T.localStepOf pivot).stepUpdate.pivotEntry * D.generatedDegreePivotScale pivot
            = generatedDirichlet_degree W
                  (GeneratedInteriorIndex.toApproximantIndex
                    (T.localStepOf pivot).pivotDatum.pivotIndex) *
                D.generatedDegreePivotScale pivot := by
              rw [D.source_eq_generatedDegree pivot]
        _ = 1 := D.generatedDegree_mul_generatedDegreePivotScale pivot)

structure GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  reciprocalProfile : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T
  interiorTracePivotScaleScaleSource : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T
  scaleSourceStatus : DegreePivotScaleSourceScaleSourceStatus
  noScalarInvStatus : DegreePivotScaleSourceNoScalarInvStatus
  noMatrixInvStatus : DegreePivotScaleSourceNoMatrixInvStatus
  noExternalScaleOracleStatus : DegreePivotScaleSourceNoExternalScaleOracleStatus
  noProductIdentityProofStatus : DegreePivotScaleSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : DegreePivotScaleSourceNoTwoSidedInvStatus
  noDtnDataStatus : DegreePivotScaleSourceNoDtnDataStatus
  noArithmeticTargetStatus : DegreePivotScaleSourceNoArithmeticTargetStatus
  nextConsumerStatus : DegreePivotScaleSourceNextConsumerStatus
  interiorTracePivotScaleScaleSource_eq_from_reciprocalProfile :
    interiorTracePivotScaleScaleSource =
      generatedDegreePivotScaleSourceFromReciprocalProfileDegreePivotScaleSource reciprocalProfile
  scaleSourceStatus_eq :
    scaleSourceStatus =
      DegreePivotScaleSourceScaleSourceStatus.scaleSourceBuiltFromGeneratedDegreeReciprocalProfile
  noScalarInvStatus_eq :
    noScalarInvStatus =
      DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      DegreePivotScaleSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotScaleSource
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      DegreePivotScaleSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotScaleSource
  noDtnDataStatus_eq :
    noDtnDataStatus =
      DegreePivotScaleSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInDegreePivotScaleSource
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      DegreePivotScaleSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInDegreePivotScaleSource
  nextConsumerStatus_eq :
    nextConsumerStatus =
      DegreePivotScaleSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge

namespace GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromReciprocalProfile
    (D : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T) :
    GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T where
  reciprocalProfile := D
  interiorTracePivotScaleScaleSource := generatedDegreePivotScaleSourceFromReciprocalProfileDegreePivotScaleSource D
  scaleSourceStatus :=
    DegreePivotScaleSourceScaleSourceStatus.scaleSourceBuiltFromGeneratedDegreeReciprocalProfile
  noScalarInvStatus :=
    DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus :=
    DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus :=
    DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource
  noProductIdentityProofStatus :=
    DegreePivotScaleSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotScaleSource
  noTwoSidedInvStatus :=
    DegreePivotScaleSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotScaleSource
  noDtnDataStatus := DegreePivotScaleSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInDegreePivotScaleSource
  noArithmeticTargetStatus :=
    DegreePivotScaleSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInDegreePivotScaleSource
  nextConsumerStatus := DegreePivotScaleSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  interiorTracePivotScaleScaleSource_eq_from_reciprocalProfile := by
    rfl
  scaleSourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem leftScaleEquation
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    S.interiorTracePivotScaleScaleSource.pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  S.interiorTracePivotScaleScaleSource.pivotScale_mul_pivotEntry pivot

theorem rightScaleEquation
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry * S.interiorTracePivotScaleScaleSource.pivotScale pivot = 1 :=
  S.interiorTracePivotScaleScaleSource.pivotEntry_mul_pivotScale pivot

theorem nextClosureIsInteriorBlockFoldKernelResidualBridge
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T) :
    S.nextConsumerStatus =
      DegreePivotScaleSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge :=
  S.nextConsumerStatus_eq

end GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource

def tracePivotScaleWitnessFromGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T :=
  generatedInteriorTracePivotScaleWitnessFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness
    S.interiorTracePivotScaleScaleSource

def tracePivotScaleWitnessFromGeneratedDegreeOfDegreePivotScaleSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness Cell p A P wp W E K T :=
  GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness.fromGeneratedDegreeScaleSource
    S.interiorTracePivotScaleScaleSource

structure GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T
  profileStatus : DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus
  noScalarInvStatus : DegreePivotScaleSourceNoScalarInvStatus
  noMatrixInvStatus : DegreePivotScaleSourceNoMatrixInvStatus
  noExternalScaleOracleStatus : DegreePivotScaleSourceNoExternalScaleOracleStatus
  noProductIdentityProofStatus : DegreePivotScaleSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : DegreePivotScaleSourceNoTwoSidedInvStatus
  noDtnDataStatus : DegreePivotScaleSourceNoDtnDataStatus
  noArithmeticTargetStatus : DegreePivotScaleSourceNoArithmeticTargetStatus
  nextConsumerStatus : DegreePivotScaleSourceNextConsumerStatus
  source_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  profileStatus_eq :
    profileStatus =
      DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus.generatedDegreeReciprocalProfileRequired
  noScalarInvStatus_eq :
    noScalarInvStatus =
      DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      DegreePivotScaleSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotScaleSource
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      DegreePivotScaleSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotScaleSource
  noDtnDataStatus_eq :
    noDtnDataStatus =
      DegreePivotScaleSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInDegreePivotScaleSource
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      DegreePivotScaleSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInDegreePivotScaleSource
  nextConsumerStatus_eq :
    nextConsumerStatus = DegreePivotScaleSourceNextConsumerStatus.generatedDegreeReciprocalProfileStillRequired

namespace GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromRequirement
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource Cell p A P wp W E K T where
  requirement := R
  profileStatus :=
    DegreePivotScaleSourceGeneratedDegreeReciprocalProfileStatus.generatedDegreeReciprocalProfileRequired
  noScalarInvStatus :=
    DegreePivotScaleSourceNoScalarInvStatus.noScalarInvInGeneratedDegreePivotScaleSource
  noMatrixInvStatus :=
    DegreePivotScaleSourceNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotScaleSource
  noExternalScaleOracleStatus :=
    DegreePivotScaleSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotScaleSource
  noProductIdentityProofStatus :=
    DegreePivotScaleSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotScaleSource
  noTwoSidedInvStatus :=
    DegreePivotScaleSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotScaleSource
  noDtnDataStatus := DegreePivotScaleSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInDegreePivotScaleSource
  noArithmeticTargetStatus :=
    DegreePivotScaleSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInDegreePivotScaleSource
  nextConsumerStatus := DegreePivotScaleSourceNextConsumerStatus.generatedDegreeReciprocalProfileStillRequired
  source_eq_generatedDegree := by
    intro pivot
    exact R.pivotEntry_eq_generatedDegree pivot
  profileStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromInteriorEliminationdb2cAudit
    (A0 : GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource Cell p A P wp W E K T :=
  fromRequirement A0.requirement

theorem nextConsumer_requires_generatedDegreeReciprocalProfile
    (A0 : GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource Cell p A P wp W E K T) :
    A0.nextConsumerStatus = DegreePivotScaleSourceNextConsumerStatus.generatedDegreeReciprocalProfileStillRequired :=
  A0.nextConsumerStatus_eq

end GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource

abbrev RegularGeneratedDegreePivotReciprocalProfileDegreePivotScaleSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedDegreePivotReciprocalProfileDegreePivotScaleSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev GeneratedDegreePivotReciprocalProfile :=
  @GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource

namespace GeneratedDegreePivotReciprocalProfile

abbrev fromGeneratedDegreeReciprocalProfile :=
  @GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource.fromGeneratedDegreeReciprocalProfile

abbrev leftGeneratedDegreeEquation :=
  @GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource.leftGeneratedDegreeEquation

abbrev rightGeneratedDegreeEquation :=
  @GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource.rightGeneratedDegreeEquation

abbrev source_eq_generatedDegree_of :=
  @GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource.source_eq_generatedDegree_of

end GeneratedDegreePivotReciprocalProfile

abbrev generatedDegreePivotScaleSourceFromReciprocalProfile :=
  @generatedDegreePivotScaleSourceFromReciprocalProfileDegreePivotScaleSource

abbrev GeneratedInteriorGeneratedDegreePivotScaleSource :=
  @GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource

namespace GeneratedInteriorGeneratedDegreePivotScaleSource

abbrev fromReciprocalProfile :=
  @GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.fromReciprocalProfile

abbrev leftScaleEquation :=
  @GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.leftScaleEquation

abbrev rightScaleEquation :=
  @GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.rightScaleEquation

abbrev nextConsumer_is_blockFoldKernelLocalSchurResidualBridge :=
  @GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.nextClosureIsInteriorBlockFoldKernelResidualBridge

end GeneratedInteriorGeneratedDegreePivotScaleSource

abbrev tracePivotScaleWitness_from_generatedDegreePivotScaleSource :=
  @tracePivotScaleWitnessFromGeneratedDegreePivotScaleSourceDegreePivotScaleSource

abbrev tracePivotScaleWitnessFromGeneratedDegree_from_generatedDegreePivotScaleSource :=
  @tracePivotScaleWitnessFromGeneratedDegreeOfDegreePivotScaleSource

namespace GeneratedDegreePivotScaleSourceAudit

abbrev fromRequirement :=
  @GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource.fromRequirement

abbrev nextConsumer_requires_generatedDegreeReciprocalProfile :=
  @GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource.nextConsumer_requires_generatedDegreeReciprocalProfile

end GeneratedDegreePivotScaleSourceAudit

abbrev RegularGeneratedDegreePivotReciprocalProfile :=
  @RegularGeneratedDegreePivotReciprocalProfileDegreePivotScaleSource

abbrev VariableGeneratedDegreePivotReciprocalProfile :=
  @VariableGeneratedDegreePivotReciprocalProfileDegreePivotScaleSource

abbrev RegularGeneratedInteriorGeneratedDegreePivotScaleSource :=
  @RegularGeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource

abbrev VariableGeneratedInteriorGeneratedDegreePivotScaleSource :=
  @VariableGeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource

end CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
