import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation

universe u

inductive InteriorInverseCandidateMatrixInverseCandidateMatrixExportStatus where
  | inverseCandidateMatrixFromAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus where
  | matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoFreeMatrixStatus where
  | noFreeMatrixOrEntryTable
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoMatrixInvStatus where
  | noMatrixInvInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus where
  | noInteriorEliminationCandidateEntryInteriorBlockFallback
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoProductProofStatus where
  | noProductProofInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixNextGateStatus where
  | interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedgerStatus where
  | generatedInteriorInverseCandidateMatrixExportClosed
  deriving DecidableEq, Repr

def inverseCandidateMatrix_from_accumulatedEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  fun i j => I.entry i j

structure GeneratedInteriorInverseCandidateMatrix
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  sourceCandidateEntry : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W
  accumulatedInverseCandidateEntry :
    GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T
  matrix : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ
  exportStatus : InteriorInverseCandidateMatrixInverseCandidateMatrixExportStatus
  sourceStatus : InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus
  noFreeMatrixStatus : InteriorInverseCandidateMatrixNoFreeMatrixStatus
  noMatrixInvStatus : InteriorInverseCandidateMatrixNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noInteriorEliminationCandidateEntryInteriorBlockFallbackStatus : InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus
  noProductProofStatus : InteriorInverseCandidateMatrixNoProductProofStatus
  noTwoSidedInvStatus : InteriorInverseCandidateMatrixNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorInverseCandidateMatrixNoDtnDataStatus
  noArithmeticTargetStatus : InteriorInverseCandidateMatrixNoArithmeticTargetStatus
  nextGateStatus : InteriorInverseCandidateMatrixNextGateStatus
  sourceCandidateEntry_is_source : sourceCandidateEntry = E
  accumulatedInverseCandidateEntry_is_fromTrace :
    accumulatedInverseCandidateEntry =
      GeneratedInteriorAccumulatedInverseCandidateEntry.fromAccumulatedTraceEvaluation T
  matrixEntry_from_accumulatedEntry :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = accumulatedInverseCandidateEntry.entry i j
  matrixEntry_from_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = generatedInteriorAccumulatedEntryValue T i j
  matrix_from_accumulatedEntry :
    matrix = inverseCandidateMatrix_from_accumulatedEntry accumulatedInverseCandidateEntry
  sourceCandidateEntryProfileEqInteriorBlockInteriorEliminationdRSource :
    sourceCandidateEntry.candidate.profile =
      sourceCandidateEntry.candidate.profileData.profile
  exportStatus_eq :
    exportStatus =
      InteriorInverseCandidateMatrixInverseCandidateMatrixExportStatus.inverseCandidateMatrixFromAccumulatedEntry
  sourceStatus_eq :
    sourceStatus =
      InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus.matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  noFreeMatrixStatus_eq :
    noFreeMatrixStatus = InteriorInverseCandidateMatrixNoFreeMatrixStatus.noFreeMatrixOrEntryTable
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorInverseCandidateMatrixNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateMatrix
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noInteriorEliminationCandidateEntryInteriorBlockFallbackStatusEq :
    noInteriorEliminationCandidateEntryInteriorBlockFallbackStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus.noInteriorEliminationCandidateEntryInteriorBlockFallback
  noProductProofStatus_eq :
    noProductProofStatus = InteriorInverseCandidateMatrixNoProductProofStatus.noProductProofInInteriorInverseCandidateMatrix
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateMatrix
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateMatrix
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorInverseCandidateMatrixNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateMatrix
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorInverseCandidateMatrixNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateMatrix
  nextGateStatus_eq :
    nextGateStatus = InteriorInverseCandidateMatrixNextGateStatus.interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport

namespace GeneratedInteriorInverseCandidateMatrix

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromAccumulatedEntry
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T where
  sourceCandidateEntry := E
  accumulatedInverseCandidateEntry :=
    GeneratedInteriorAccumulatedInverseCandidateEntry.fromAccumulatedTraceEvaluation T
  matrix :=
    inverseCandidateMatrix_from_accumulatedEntry
      (GeneratedInteriorAccumulatedInverseCandidateEntry.fromAccumulatedTraceEvaluation T)
  exportStatus :=
    InteriorInverseCandidateMatrixInverseCandidateMatrixExportStatus.inverseCandidateMatrixFromAccumulatedEntry
  sourceStatus :=
    InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus.matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  noFreeMatrixStatus := InteriorInverseCandidateMatrixNoFreeMatrixStatus.noFreeMatrixOrEntryTable
  noMatrixInvStatus := InteriorInverseCandidateMatrixNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateMatrix
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noInteriorEliminationCandidateEntryInteriorBlockFallbackStatus :=
    InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus.noInteriorEliminationCandidateEntryInteriorBlockFallback
  noProductProofStatus := InteriorInverseCandidateMatrixNoProductProofStatus.noProductProofInInteriorInverseCandidateMatrix
  noTwoSidedInvStatus := InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix
  noInteriorEliminationCertificateStatus :=
    InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateMatrix
  noInteriorEliminationDataStatus :=
    InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateMatrix
  noDtnDataStatus :=
    InteriorInverseCandidateMatrixNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateMatrix
  noArithmeticTargetStatus :=
    InteriorInverseCandidateMatrixNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateMatrix
  nextGateStatus := InteriorInverseCandidateMatrixNextGateStatus.interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport
  sourceCandidateEntry_is_source := by
    rfl
  accumulatedInverseCandidateEntry_is_fromTrace := by
    rfl
  matrixEntry_from_accumulatedEntry := by
    intro i j
    rfl
  matrixEntry_from_accumulatedTraceValue := by
    intro i j
    exact
      (GeneratedInteriorAccumulatedInverseCandidateEntry.fromAccumulatedTraceEvaluation
        T).entry_eq_accumulatedTraceValue i j
  matrix_from_accumulatedEntry := by
    rfl
  sourceCandidateEntryProfileEqInteriorBlockInteriorEliminationdRSource :=
    E.candidateEntryProfileEqInteriorEliminationdRSource
  exportStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noFreeMatrixStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noInteriorEliminationCandidateEntryInteriorBlockFallbackStatusEq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextGateStatus_eq := by
    rfl

end GeneratedInteriorInverseCandidateMatrix

def inverseCandidateMatrix_from_inverseCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  M.matrix

def inverseCandidateMatrix_from_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T :=
  GeneratedInteriorInverseCandidateMatrix.fromAccumulatedEntry T

theorem inverseCandidateMatrix_entry_eq_accumulatedEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    M.matrix i j = M.accumulatedInverseCandidateEntry.entry i j :=
  M.matrixEntry_from_accumulatedEntry i j

theorem inverseCandidateMatrix_entry_eq_accumulatedTraceValue
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    M.matrix i j = generatedInteriorAccumulatedEntryValue T i j :=
  M.matrixEntry_from_accumulatedTraceValue i j

theorem inverseCandidateMatrix_entry_eq_inverseCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    inverseCandidateMatrix_from_inverseCandidateEntry M i j =
      M.accumulatedInverseCandidateEntry.entry i j :=
  M.matrixEntry_from_accumulatedEntry i j

theorem inverseCandidateProfileEqInteriorBlockInteriorEliminationdRSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.sourceCandidateEntry.candidate.profile =
      M.sourceCandidateEntry.candidate.profileData.profile :=
  M.sourceCandidateEntryProfileEqInteriorBlockInteriorEliminationdRSource

theorem noTwoSidedInvForInteriorInverseCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.noTwoSidedInvStatus = InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix :=
  M.noTwoSidedInvStatus_eq

theorem noInteriorEliminationCertificateForInteriorInverseCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateMatrix :=
  M.noInteriorEliminationCertificateStatus_eq

theorem noInteriorEliminationDataForInteriorInverseCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.noInteriorEliminationDataStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateMatrix :=
  M.noInteriorEliminationDataStatus_eq

theorem noMatrixInv_for_inverseCandidateMatrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.noMatrixInvStatus = InteriorInverseCandidateMatrixNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateMatrix :=
  M.noMatrixInvStatus_eq

theorem noFreeMatrix_for_inverseCandidateMatrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    M.noFreeMatrixStatus = InteriorInverseCandidateMatrixNoFreeMatrixStatus.noFreeMatrixOrEntryTable :=
  M.noFreeMatrixStatus_eq

def regularGeneratedInteriorInverseCandidateMatrix
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateMatrix
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp) :=
  inverseCandidateMatrix_from_eliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableGeneratedInteriorInverseCandidateMatrix
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateMatrix
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp) :=
  inverseCandidateMatrix_from_eliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedgerStatus
  interiorTerminalFoldResidualAccumulatedEntryLedger :
    InteriorTerminalFoldResidualGeneratedInteriorAccumulatedEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularMatrix :
    GeneratedInteriorInverseCandidateMatrix
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
  variableMatrix :
    GeneratedInteriorInverseCandidateMatrix
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
  interiorTerminalFoldResidualAccumulatedEntryLedger_eq_main :
    interiorTerminalFoldResidualAccumulatedEntryLedger =
      interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger
        b β p regularWeight variableWeight regularPivot variablePivot
  regularMatrixEntryFromAccumulatedEntry :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      regularMatrix.matrix i j = regularMatrix.accumulatedInverseCandidateEntry.entry i j
  variableMatrixEntryFromAccumulatedEntry :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      variableMatrix.matrix i j = variableMatrix.accumulatedInverseCandidateEntry.entry i j
  regularNoFreeMatrix :
    regularMatrix.noFreeMatrixStatus = InteriorInverseCandidateMatrixNoFreeMatrixStatus.noFreeMatrixOrEntryTable
  variableNoFreeMatrix :
    variableMatrix.noFreeMatrixStatus = InteriorInverseCandidateMatrixNoFreeMatrixStatus.noFreeMatrixOrEntryTable
  regularNoMatrixInv :
    regularMatrix.noMatrixInvStatus = InteriorInverseCandidateMatrixNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateMatrix
  variableNoMatrixInv :
    variableMatrix.noMatrixInvStatus = InteriorInverseCandidateMatrixNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateMatrix
  regularNoInteriorEliminationCandidateEntryFallback :
    regularMatrix.noInteriorEliminationCandidateEntryInteriorBlockFallbackStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus.noInteriorEliminationCandidateEntryInteriorBlockFallback
  variableNoInteriorEliminationCandidateEntryFallback :
    variableMatrix.noInteriorEliminationCandidateEntryInteriorBlockFallbackStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCandidateEntryInteriorBlockFallbackStatus.noInteriorEliminationCandidateEntryInteriorBlockFallback
  regularNoProductProof :
    regularMatrix.noProductProofStatus = InteriorInverseCandidateMatrixNoProductProofStatus.noProductProofInInteriorInverseCandidateMatrix
  variableNoProductProof :
    variableMatrix.noProductProofStatus = InteriorInverseCandidateMatrixNoProductProofStatus.noProductProofInInteriorInverseCandidateMatrix
  regularNoTwoSidedInv :
    regularMatrix.noTwoSidedInvStatus = InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix
  variableNoTwoSidedInv :
    variableMatrix.noTwoSidedInvStatus = InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix
  regularNoInteriorEliminationCertificate :
    regularMatrix.noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateMatrix
  variableNoInteriorEliminationCertificate :
    variableMatrix.noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateMatrix
  regularNoInteriorEliminationData :
    regularMatrix.noInteriorEliminationDataStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateMatrix
  variableNoInteriorEliminationData :
    variableMatrix.noInteriorEliminationDataStatus =
      InteriorInverseCandidateMatrixNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateMatrix
  regularNextGate :
    regularMatrix.nextGateStatus = InteriorInverseCandidateMatrixNextGateStatus.interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport
  variableNextGate :
    variableMatrix.nextGateStatus = InteriorInverseCandidateMatrixNextGateStatus.interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport
  status_eq_closed :
    status =
      InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedgerStatus.generatedInteriorInverseCandidateMatrixExportClosed

def interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status :=
    InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedgerStatus.generatedInteriorInverseCandidateMatrixExportClosed
  interiorTerminalFoldResidualAccumulatedEntryLedger :=
    interiorTerminalFoldResidualAccumulatedEntryGeneratedInteriorAccumulatedEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularMatrix := regularGeneratedInteriorInverseCandidateMatrix b p regularWeight
  variableMatrix := variableGeneratedInteriorInverseCandidateMatrix β p variableWeight
  interiorTerminalFoldResidualAccumulatedEntryLedger_eq_main := by
    rfl
  regularMatrixEntryFromAccumulatedEntry := by
    intro i j
    rfl
  variableMatrixEntryFromAccumulatedEntry := by
    intro i j
    rfl
  regularNoFreeMatrix := by
    rfl
  variableNoFreeMatrix := by
    rfl
  regularNoMatrixInv := by
    rfl
  variableNoMatrixInv := by
    rfl
  regularNoInteriorEliminationCandidateEntryFallback := by
    rfl
  variableNoInteriorEliminationCandidateEntryFallback := by
    rfl
  regularNoProductProof := by
    rfl
  variableNoProductProof := by
    rfl
  regularNoTwoSidedInv := by
    rfl
  variableNoTwoSidedInv := by
    rfl
  regularNoInteriorEliminationCertificate := by
    rfl
  variableNoInteriorEliminationCertificate := by
    rfl
  regularNoInteriorEliminationData := by
    rfl
  variableNoInteriorEliminationData := by
    rfl
  regularNextGate := by
    rfl
  variableNextGate := by
    rfl
  status_eq_closed := by
    rfl

theorem interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedgerStatus.generatedInteriorInverseCandidateMatrixExportClosed := by
  rfl

theorem interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger_regularNoTwoSidedInv
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularMatrix.noTwoSidedInvStatus =
      InteriorInverseCandidateMatrixNoTwoSidedInvStatus.noTwoSidedInvInInteriorInverseCandidateMatrix := by
  rfl

theorem interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger_regularNextGate
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularMatrix.nextGateStatus =
      InteriorInverseCandidateMatrixNextGateStatus.interiorInverseCandidateShapeSeparationShapeSeparationAfterMatrixExport := by
  rfl


end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
