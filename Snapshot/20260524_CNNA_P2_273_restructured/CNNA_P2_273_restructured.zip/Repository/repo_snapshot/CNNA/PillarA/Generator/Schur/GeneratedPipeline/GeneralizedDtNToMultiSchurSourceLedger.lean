import CNNA.PillarA.Generator.DtN.GeneratedPipeline.GeneralizedTopBoundaryDtN

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN

universe u

structure GeneratedResetInteriorEliminationLedgerMultiSchur
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  sourcePartition : GeneratedBoundaryInteriorPartition Cell p A
  sourcePartition_eq_current : sourcePartition = P
  sourceDirichletEntrySource : GeneratedDirichletEntrySource Cell p A P wp
  sourceInteriorBlockProfile : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  sourceInteriorEliminationCertificate :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H
  sourceTwoSidedInv :
    TwoSidedInv (generatedInteriorBlock W) sourceInteriorEliminationCertificate.inverseMatrix
  sourceTopBoundaryDtN : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H
  sourceGeneralizedTopBoundaryDtN :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H
  topBoundary_sourceCertificate_eq_certificate :
    sourceTopBoundaryDtN.sourceCertificate = sourceInteriorEliminationCertificate
  generalized_sourceTopBoundary_eq_topBoundary :
    sourceGeneralizedTopBoundaryDtN.sourceTopBoundaryDtN = sourceTopBoundaryDtN
  generalized_boundaryOperator_eq_topBoundary :
    sourceGeneralizedTopBoundaryDtN.boundaryOperator = sourceTopBoundaryDtN.boundaryOperator
  topBoundary_boundaryOperator_eq_certificate :
    sourceTopBoundaryDtN.boundaryOperator = sourceInteriorEliminationCertificate.boundaryOperator
  topBoundary_boundaryOperator_eq_schur :
    sourceTopBoundaryDtN.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  certificate_inverseMatrix_eq_handoffCandidate :
    sourceInteriorEliminationCertificate.inverseMatrix = H.candidateMatrix
  certificate_boundaryOperator_eq_schur :
    sourceInteriorEliminationCertificate.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  sourceInteriorBlockProfile_from_dirichlet :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorBlock W i j =
        generatedDirichletMatrix W
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j)
  noExternalDtN_from_generalized :
    sourceGeneralizedTopBoundaryDtN.noExternalDtNStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger
  noMultiSchur_from_generalized :
    sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  noArithmeticTarget_from_generalized :
    sourceGeneralizedTopBoundaryDtN.noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger

namespace GeneratedResetInteriorEliminationLedgerMultiSchur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromGeneralizedTopBoundaryDtN
    (D : GeneratedDirichletEntrySource Cell p A P wp)
    (B : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H where
  sourcePartition := P
  sourcePartition_eq_current := by
    rfl
  sourceDirichletEntrySource := D
  sourceInteriorBlockProfile := B
  sourceInteriorEliminationCertificate := G.sourceTopBoundaryDtN.sourceCertificate
  sourceTwoSidedInv := G.sourceTopBoundaryDtN.sourceCertificate.inverseWitness
  sourceTopBoundaryDtN := G.sourceTopBoundaryDtN
  sourceGeneralizedTopBoundaryDtN := G
  topBoundary_sourceCertificate_eq_certificate := by
    rfl
  generalized_sourceTopBoundary_eq_topBoundary := by
    rfl
  generalized_boundaryOperator_eq_topBoundary := by
    exact G.boundaryOperatorEqGeneralizedDtNSource
  topBoundary_boundaryOperator_eq_certificate := by
    exact G.sourceTopBoundaryDtN.boundaryOperatorEqGeneralizedTopBoundaryDtN
  topBoundary_boundaryOperator_eq_schur := by
    exact G.sourceTopBoundaryDtN.boundaryOperator_eq_schur
  certificate_inverseMatrix_eq_handoffCandidate := by
    exact G.sourceTopBoundaryDtN.sourceCertificate.inverseMatrix_eq_handoffCandidate
  certificate_boundaryOperator_eq_schur := by
    exact G.sourceTopBoundaryDtN.sourceCertificate.boundaryOperator_eq_schur
  sourceInteriorBlockProfile_from_dirichlet := by
    intro i j
    exact B.block_from_dirichlet i j
  noExternalDtN_from_generalized := by
    exact G.noExternalDtNStatus_eq
  noMultiSchur_from_generalized := by
    exact G.noMultiSchurStatus_eq
  noArithmeticTarget_from_generalized := by
    exact G.noArithmeticTargetStatus_eq

theorem generalized_boundaryOperator_from_topBoundary
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    L.sourceGeneralizedTopBoundaryDtN.boundaryOperator = L.sourceTopBoundaryDtN.boundaryOperator :=
  L.generalized_boundaryOperator_eq_topBoundary

theorem topBoundary_boundaryOperator_from_certificate
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    L.sourceTopBoundaryDtN.boundaryOperator =
      L.sourceInteriorEliminationCertificate.boundaryOperator :=
  L.topBoundary_boundaryOperator_eq_certificate

theorem certificate_inverseMatrix_from_handoffCandidate
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    L.sourceInteriorEliminationCertificate.inverseMatrix = H.candidateMatrix :=
  L.certificate_inverseMatrix_eq_handoffCandidate

theorem generalized_noMultiSchur
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    L.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger :=
  L.noMultiSchur_from_generalized

theorem generalized_noArithmeticTarget
    (L : GeneratedResetInteriorEliminationLedgerMultiSchur Cell p A P wp W E K T M S H) :
    L.sourceGeneralizedTopBoundaryDtN.noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger :=
  L.noArithmeticTarget_from_generalized

end GeneratedResetInteriorEliminationLedgerMultiSchur

def regularGeneratedResetInteriorEliminationLedgerFromAccumulatedEntryCancellationLedgerMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedResetInteriorEliminationLedgerMultiSchur
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  GeneratedResetInteriorEliminationLedgerMultiSchur.fromGeneralizedTopBoundaryDtN
    (regularGeneratedDirichletEntrySource b p regularWeight)
    (regularGeneratedInteriorBlockStructureProfile b p regularWeight)
    (regularGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger L)

def variableGeneratedResetInteriorEliminationLedgerFromAccumulatedEntryCancellationLedgerMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedResetInteriorEliminationLedgerMultiSchur
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  GeneratedResetInteriorEliminationLedgerMultiSchur.fromGeneralizedTopBoundaryDtN
    (variableGeneratedDirichletEntrySource β p variableWeight)
    (variableGeneratedInteriorBlockStructureProfile β p variableWeight)
    (variableGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger L)

structure MultiSchurGeneratedResetLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceAccumulatedEntryCancellationLedger :
    InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight
  sourceInteriorEliminationaPartitionLedger : InteriorEliminationaRGeneratedPartitionLedger b β p
  sourceInteriorEliminationbDirichletEntryLedger :
    DirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  sourceInteriorEliminationcInteriorBlockLedger :
    InteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularLedger :
    GeneratedResetInteriorEliminationLedgerMultiSchur
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableLedger :
    GeneratedResetInteriorEliminationLedgerMultiSchur
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  sourceInteriorEliminationaPartitionLedgerEqMain :
    sourceInteriorEliminationaPartitionLedger = generatedPartitionGeneratedPartitionLedger b β p
  sourceInteriorEliminationbDirichletEntryLedgerEqMain :
    sourceInteriorEliminationbDirichletEntryLedger =
      generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  sourceInteriorEliminationcInteriorBlockLedgerEqMain :
    sourceInteriorEliminationcInteriorBlockLedger =
      generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN :
    regularLedger.sourceInteriorEliminationCertificate =
      regularGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        sourceAccumulatedEntryCancellationLedger
  variableInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN :
    variableLedger.sourceInteriorEliminationCertificate =
      variableGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        sourceAccumulatedEntryCancellationLedger
  regularTopBoundaryDtNEqGeneralizedDtNSource :
    regularLedger.sourceTopBoundaryDtN =
      regularGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource
        sourceAccumulatedEntryCancellationLedger
  variableTopBoundaryDtNEqGeneralizedDtNSource :
    variableLedger.sourceTopBoundaryDtN =
      variableGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource
        sourceAccumulatedEntryCancellationLedger
  regularGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger :
    regularLedger.sourceGeneralizedTopBoundaryDtN =
      regularGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
        sourceAccumulatedEntryCancellationLedger
  variableGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger :
    variableLedger.sourceGeneralizedTopBoundaryDtN =
      variableGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
        sourceAccumulatedEntryCancellationLedger
  regularNoMultiSchur :
    regularLedger.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  variableNoMultiSchur :
    variableLedger.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  regularNoArithmeticTarget :
    regularLedger.sourceGeneralizedTopBoundaryDtN.noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger
  variableNoArithmeticTarget :
    variableLedger.sourceGeneralizedTopBoundaryDtN.noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger

def generatedResetGeneratedResetLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    MultiSchurGeneratedResetLedger b β p regularWeight variableWeight where
  sourceAccumulatedEntryCancellationLedger := L
  sourceInteriorEliminationaPartitionLedger := generatedPartitionGeneratedPartitionLedger b β p
  sourceInteriorEliminationbDirichletEntryLedger :=
    generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  sourceInteriorEliminationcInteriorBlockLedger :=
    generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularLedger :=
    regularGeneratedResetInteriorEliminationLedgerFromAccumulatedEntryCancellationLedgerMultiSchur L
  variableLedger :=
    variableGeneratedResetInteriorEliminationLedgerFromAccumulatedEntryCancellationLedgerMultiSchur L
  sourceInteriorEliminationaPartitionLedgerEqMain := by
    rfl
  sourceInteriorEliminationbDirichletEntryLedgerEqMain := by
    rfl
  sourceInteriorEliminationcInteriorBlockLedgerEqMain := by
    rfl
  regularInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN := by
    rfl
  variableInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN := by
    rfl
  regularTopBoundaryDtNEqGeneralizedDtNSource := by
    rfl
  variableTopBoundaryDtNEqGeneralizedDtNSource := by
    rfl
  regularGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger := by
    rfl
  variableGeneralizedTopBoundaryDtNEqGeneralizedDtNToMultiSchurSourceLedger := by
    rfl
  regularNoMultiSchur := by
    rfl
  variableNoMultiSchur := by
    rfl
  regularNoArithmeticTarget := by
    rfl
  variableNoArithmeticTarget := by
    rfl

theorem generatedResetGeneratedResetLedger_regular_noMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    L.regularLedger.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger :=
  L.regularNoMultiSchur

theorem generatedResetGeneratedResetLedger_variable_noMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    L.variableLedger.sourceGeneralizedTopBoundaryDtN.noMultiSchurStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger :=
  L.variableNoMultiSchur

theorem generatedResetGeneratedResetLedgerRegularCertificateFromGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    L.regularLedger.sourceInteriorEliminationCertificate =
      regularGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        L.sourceAccumulatedEntryCancellationLedger :=
  L.regularInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN

theorem generatedResetGeneratedResetLedgerVariableCertificateFromGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : MultiSchurGeneratedResetLedger b β p regularWeight variableWeight) :
    L.variableLedger.sourceInteriorEliminationCertificate =
      variableGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
        L.sourceAccumulatedEntryCancellationLedger :=
  L.variableInteriorEliminationCertificateEqGeneralizedTopBoundaryDtN

end CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
