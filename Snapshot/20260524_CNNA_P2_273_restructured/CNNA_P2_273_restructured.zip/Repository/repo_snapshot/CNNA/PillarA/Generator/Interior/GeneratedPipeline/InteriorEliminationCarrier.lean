import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateStart
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart


universe u

inductive InteriorEliminationCarrierNodeOriginStatus where
  | nodeFromGeneratedInteriorIndexAndPartition
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierProfileSourceStatus where
  | profileFromInteriorBlockInteriorBlockStructure
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierCandidateSourceStatus where
  | candidateFromInteriorEliminationdRStructureDependentCandidate
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierDepthStatus where
  | depthFromGeneratedInteriorLevel
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierMeasureStatus where
  | measureFromCutoffMinusInteriorDepth
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierCarrierStatus where
  | generatedInteriorEliminationCarrierClosed
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoFreeEliminationCarrierStatus where
  | noFreeEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus where
  | noExternalEliminationOrderOracle
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoFreePivotListStatus where
  | noFreePivotList
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoInverseEntryFunctionStatus where
  | noInverseEntryFunctionInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoMatrixExportStatus where
  | noMatrixExportInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoEliminationTraceStatus where
  | noEliminationTraceInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoMatrixInvStatus where
  | noMatrixInvInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierNextPositiveConstructionGate where
  | generatedInteriorEliminationStepGeneratedInteriorEliminationStep
  deriving DecidableEq, Repr

inductive InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedgerStatus where
  | generatedInteriorEliminationCarrierClosed
  deriving DecidableEq, Repr

structure GeneratedInteriorEliminationNode
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) where
  index : GeneratedInteriorIndex A
  approximantIndex : GeneratedApproximantIndex A
  approximantIndex_eq_index :
    approximantIndex = GeneratedInteriorIndex.toApproximantIndex index
  interiorMembership : approximantIndex ∈ P.interiorCarrier
  profileData : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  nodeOriginStatus : InteriorEliminationCarrierNodeOriginStatus
  profileSourceStatus : InteriorEliminationCarrierProfileSourceStatus
  candidateSourceStatus : InteriorEliminationCarrierCandidateSourceStatus
  profileData_eq_candidateProfileData : profileData = C.profileData
  candidate_eq : candidate = C
  candidate_profile_eq_profileData : candidate.profile = profileData.profile
  candidate_sourceCompatible :
    GeneratedInteriorEliminationCandidateSourceCompatible
      candidate.source profileData.profile
  nodeOriginStatus_eq :
    nodeOriginStatus =
      InteriorEliminationCarrierNodeOriginStatus.nodeFromGeneratedInteriorIndexAndPartition
  profileSourceStatus_eq :
    profileSourceStatus =
      InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure
  candidateSourceStatus_eq :
    candidateSourceStatus =
      InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate

namespace GeneratedInteriorEliminationNode

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {C : GeneratedInteriorEliminationCandidate Cell p A P wp W}

def fromInteriorIndex
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorEliminationNode Cell p A P wp W C where
  index := i
  approximantIndex := GeneratedInteriorIndex.toApproximantIndex i
  approximantIndex_eq_index := by
    rfl
  interiorMembership := by
    rw [P.interiorCarrier_eq]
    exact interior_mem_interiorCarrier i
  profileData := C.profileData
  candidate := C
  nodeOriginStatus :=
    InteriorEliminationCarrierNodeOriginStatus.nodeFromGeneratedInteriorIndexAndPartition
  profileSourceStatus :=
    InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure
  candidateSourceStatus :=
    InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate
  profileData_eq_candidateProfileData := by
    rfl
  candidate_eq := by
    rfl
  candidate_profile_eq_profileData :=
    C.profileEqInteriorBlockProfile
  candidate_sourceCompatible :=
    C.sourceCompatible
  nodeOriginStatus_eq := by
    rfl
  profileSourceStatus_eq := by
    rfl
  candidateSourceStatus_eq := by
    rfl

theorem index_membership
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) :
    N.approximantIndex ∈ P.interiorCarrier :=
  N.interiorMembership

theorem candidate_profile_eq_nodeProfileData
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) :
    N.candidate.profile = N.profileData.profile :=
  N.candidate_profile_eq_profileData

theorem nodeFromInteriorBlockInteriorEliminationdR
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) :
    N.profileSourceStatus =
        InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure ∧
      N.candidateSourceStatus =
        InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate :=
  And.intro N.profileSourceStatus_eq N.candidateSourceStatus_eq

end GeneratedInteriorEliminationNode

structure GeneratedInteriorEliminationDepth
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) where
  depth : Nat
  depthStatus : InteriorEliminationCarrierDepthStatus
  depth_eq_index_level :
    depth = (GeneratedInteriorIndex.level N.index).val
  depth_lt_cutoff : depth < p.L_max
  depthStatus_eq :
    depthStatus = InteriorEliminationCarrierDepthStatus.depthFromGeneratedInteriorLevel

namespace GeneratedInteriorEliminationDepth

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {C : GeneratedInteriorEliminationCandidate Cell p A P wp W}
variable {N : GeneratedInteriorEliminationNode Cell p A P wp W C}

def fromNode
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) :
    GeneratedInteriorEliminationDepth Cell p A P wp W C N where
  depth := (GeneratedInteriorIndex.level N.index).val
  depthStatus := InteriorEliminationCarrierDepthStatus.depthFromGeneratedInteriorLevel
  depth_eq_index_level := by
    rfl
  depth_lt_cutoff :=
    GeneratedInteriorIndex.level_lt_cutoff N.index
  depthStatus_eq := by
    rfl

theorem depth_from_index_level
    (D : GeneratedInteriorEliminationDepth Cell p A P wp W C N) :
    D.depth = (GeneratedInteriorIndex.level N.index).val :=
  D.depth_eq_index_level

theorem depth_is_interior
    (D : GeneratedInteriorEliminationDepth Cell p A P wp W C N) :
    D.depth < p.L_max :=
  D.depth_lt_cutoff

end GeneratedInteriorEliminationDepth

structure GeneratedInteriorEliminationMeasure
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C)
    (D : GeneratedInteriorEliminationDepth Cell p A P wp W C N) where
  measure : Nat
  measureStatus : InteriorEliminationCarrierMeasureStatus
  measure_eq_cutoff_sub_depth : measure = p.L_max - D.depth
  depth_lt_cutoff : D.depth < p.L_max
  measureStatus_eq :
    measureStatus = InteriorEliminationCarrierMeasureStatus.measureFromCutoffMinusInteriorDepth

namespace GeneratedInteriorEliminationMeasure

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {C : GeneratedInteriorEliminationCandidate Cell p A P wp W}
variable {N : GeneratedInteriorEliminationNode Cell p A P wp W C}
variable {D : GeneratedInteriorEliminationDepth Cell p A P wp W C N}

def fromDepth
    (D : GeneratedInteriorEliminationDepth Cell p A P wp W C N) :
    GeneratedInteriorEliminationMeasure Cell p A P wp W C N D where
  measure := p.L_max - D.depth
  measureStatus := InteriorEliminationCarrierMeasureStatus.measureFromCutoffMinusInteriorDepth
  measure_eq_cutoff_sub_depth := by
    rfl
  depth_lt_cutoff :=
    D.depth_lt_cutoff
  measureStatus_eq := by
    rfl

theorem measure_from_depth
    (M : GeneratedInteriorEliminationMeasure Cell p A P wp W C N D) :
    M.measure = p.L_max - D.depth :=
  M.measure_eq_cutoff_sub_depth

end GeneratedInteriorEliminationMeasure

def generatedInteriorEliminationNode_fromIndex
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorEliminationNode Cell p A P wp W C :=
  GeneratedInteriorEliminationNode.fromInteriorIndex C i

def generatedInteriorEliminationDepth_fromNode
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {C : GeneratedInteriorEliminationCandidate Cell p A P wp W}
    (N : GeneratedInteriorEliminationNode Cell p A P wp W C) :
    GeneratedInteriorEliminationDepth Cell p A P wp W C N :=
  GeneratedInteriorEliminationDepth.fromNode N

def generatedInteriorEliminationMeasure_fromDepth
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {C : GeneratedInteriorEliminationCandidate Cell p A P wp W}
    {N : GeneratedInteriorEliminationNode Cell p A P wp W C}
    (D : GeneratedInteriorEliminationDepth Cell p A P wp W C N) :
    GeneratedInteriorEliminationMeasure Cell p A P wp W C N D :=
  GeneratedInteriorEliminationMeasure.fromDepth D

structure GeneratedInteriorEliminationCarrier
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) where
  startContract :
    CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart.InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  profileData : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  indexCarrier : Finset (GeneratedInteriorIndex A)
  nodeOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationNode Cell p A P wp W candidate
  depthOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationDepth Cell p A P wp W candidate (nodeOf i)
  measureOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationMeasure Cell p A P wp W candidate
        (nodeOf i) (depthOf i)
  carrierStatus : InteriorEliminationCarrierCarrierStatus
  noFreeEliminationCarrierStatus : InteriorEliminationCarrierNoFreeEliminationCarrierStatus
  noExternalEliminationOrderOracleStatus :
    InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus
  noFreePivotListStatus : InteriorEliminationCarrierNoFreePivotListStatus
  noInverseEntryFunctionStatus : InteriorEliminationCarrierNoInverseEntryFunctionStatus
  noMatrixExportStatus : InteriorEliminationCarrierNoMatrixExportStatus
  noEliminationTraceStatus : InteriorEliminationCarrierNoEliminationTraceStatus
  noTwoSidedInvStatus : InteriorEliminationCarrierNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorEliminationCarrierNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorEliminationCarrierNoInteriorEliminationDataStatus
  noMatrixInvStatus : InteriorEliminationCarrierNoMatrixInvStatus
  noDtnDataStatus : InteriorEliminationCarrierNoDtnDataStatus
  noArithmeticTargetStatus : InteriorEliminationCarrierNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorEliminationCarrierNextPositiveConstructionGate
  startContract_eq_main :
    startContract = CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart.interiorInverseCandidatePositiveFirstContract E
  candidate_eq_candidateEntry : candidate = E.candidate
  profileData_eq_candidateProfileData : profileData = candidate.profileData
  indexCarrier_eq_generatedInteriorIndex : indexCarrier = Finset.univ
  index_mem_carrier : ∀ i : GeneratedInteriorIndex A, i ∈ indexCarrier
  node_index_eq : ∀ i : GeneratedInteriorIndex A, (nodeOf i).index = i
  node_membership_from_partition :
    ∀ i : GeneratedInteriorIndex A, (nodeOf i).approximantIndex ∈ P.interiorCarrier
  node_profileData_eq :
    ∀ i : GeneratedInteriorIndex A, (nodeOf i).profileData = profileData
  node_candidate_eq :
    ∀ i : GeneratedInteriorIndex A, (nodeOf i).candidate = candidate
  depth_eq_index_level :
    ∀ i : GeneratedInteriorIndex A,
      (depthOf i).depth =
        (GeneratedInteriorIndex.level (nodeOf i).index).val
  measure_eq_cutoff_sub_depth :
    ∀ i : GeneratedInteriorIndex A,
      (measureOf i).measure = p.L_max - (depthOf i).depth
  startContract_nextConsumer_eq :
    startContract.nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier
  carrierStatus_eq :
    carrierStatus = InteriorEliminationCarrierCarrierStatus.generatedInteriorEliminationCarrierClosed
  noFreeEliminationCarrierStatus_eq :
    noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier
  noExternalEliminationOrderOracleStatus_eq :
    noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle
  noFreePivotListStatus_eq :
    noFreePivotListStatus = InteriorEliminationCarrierNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus_eq :
    noInverseEntryFunctionStatus =
      InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier
  noEliminationTraceStatus_eq :
    noEliminationTraceStatus =
      InteriorEliminationCarrierNoEliminationTraceStatus.noEliminationTraceInInteriorEliminationCarrier
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorEliminationCarrierNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationCarrier
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorEliminationCarrierNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorEliminationCarrier
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorEliminationCarrierNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorEliminationCarrier
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorEliminationCarrierNoMatrixInvStatus.noMatrixInvInInteriorEliminationCarrier
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorEliminationCarrierNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationCarrier
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorEliminationCarrierNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCarrier
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate =
      InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep

namespace GeneratedInteriorEliminationCarrier

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}

def fromCandidateEntry
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    GeneratedInteriorEliminationCarrier Cell p A P wp W E where
  startContract := CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart.interiorInverseCandidatePositiveFirstContract E
  candidate := E.candidate
  profileData := E.candidate.profileData
  indexCarrier := Finset.univ
  nodeOf := fun i => generatedInteriorEliminationNode_fromIndex E.candidate i
  depthOf := fun i =>
    generatedInteriorEliminationDepth_fromNode
      (generatedInteriorEliminationNode_fromIndex E.candidate i)
  measureOf := fun i =>
    generatedInteriorEliminationMeasure_fromDepth
      (generatedInteriorEliminationDepth_fromNode
        (generatedInteriorEliminationNode_fromIndex E.candidate i))
  carrierStatus := InteriorEliminationCarrierCarrierStatus.generatedInteriorEliminationCarrierClosed
  noFreeEliminationCarrierStatus :=
    InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier
  noExternalEliminationOrderOracleStatus :=
    InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle
  noFreePivotListStatus := InteriorEliminationCarrierNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus :=
    InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier
  noMatrixExportStatus := InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier
  noEliminationTraceStatus :=
    InteriorEliminationCarrierNoEliminationTraceStatus.noEliminationTraceInInteriorEliminationCarrier
  noTwoSidedInvStatus := InteriorEliminationCarrierNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationCarrier
  noInteriorEliminationCertificateStatus :=
    InteriorEliminationCarrierNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorEliminationCarrier
  noInteriorEliminationDataStatus :=
    InteriorEliminationCarrierNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorEliminationCarrier
  noMatrixInvStatus := InteriorEliminationCarrierNoMatrixInvStatus.noMatrixInvInInteriorEliminationCarrier
  noDtnDataStatus :=
    InteriorEliminationCarrierNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationCarrier
  noArithmeticTargetStatus :=
    InteriorEliminationCarrierNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCarrier
  nextPositiveConstructionGate :=
    InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep
  startContract_eq_main := by
    rfl
  candidate_eq_candidateEntry := by
    rfl
  profileData_eq_candidateProfileData := by
    rfl
  indexCarrier_eq_generatedInteriorIndex := by
    rfl
  index_mem_carrier := by
    intro i
    exact Finset.mem_univ i
  node_index_eq := by
    intro i
    rfl
  node_membership_from_partition := by
    intro i
    exact (generatedInteriorEliminationNode_fromIndex E.candidate i).interiorMembership
  node_profileData_eq := by
    intro i
    rfl
  node_candidate_eq := by
    intro i
    rfl
  depth_eq_index_level := by
    intro i
    rfl
  measure_eq_cutoff_sub_depth := by
    intro i
    rfl
  startContract_nextConsumer_eq := by
    rfl
  carrierStatus_eq := by
    rfl
  noFreeEliminationCarrierStatus_eq := by
    rfl
  noExternalEliminationOrderOracleStatus_eq := by
    rfl
  noFreePivotListStatus_eq := by
    rfl
  noInverseEntryFunctionStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noEliminationTraceStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextPositiveConstructionGate_eq := by
    rfl

theorem noFreeEliminationCarrier
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier :=
  K.noFreeEliminationCarrierStatus_eq

theorem noExternalEliminationOrderOracle
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle :=
  K.noExternalEliminationOrderOracleStatus_eq

theorem noFreePivotList
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noFreePivotListStatus = InteriorEliminationCarrierNoFreePivotListStatus.noFreePivotList :=
  K.noFreePivotListStatus_eq

theorem noInverseEntryFunction
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noInverseEntryFunctionStatus =
      InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier :=
  K.noInverseEntryFunctionStatus_eq

theorem noMatrixExport
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noMatrixExportStatus =
      InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier :=
  K.noMatrixExportStatus_eq

theorem noEliminationTrace
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noEliminationTraceStatus =
      InteriorEliminationCarrierNoEliminationTraceStatus.noEliminationTraceInInteriorEliminationCarrier :=
  K.noEliminationTraceStatus_eq

theorem noTwoSidedInv
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noTwoSidedInvStatus =
      InteriorEliminationCarrierNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationCarrier :=
  K.noTwoSidedInvStatus_eq

theorem noInteriorEliminationCertificate
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noInteriorEliminationCertificateStatus =
      InteriorEliminationCarrierNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorEliminationCarrier :=
  K.noInteriorEliminationCertificateStatus_eq

theorem noInteriorEliminationData
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noInteriorEliminationDataStatus =
      InteriorEliminationCarrierNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorEliminationCarrier :=
  K.noInteriorEliminationDataStatus_eq

theorem noMatrixInv
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noMatrixInvStatus = InteriorEliminationCarrierNoMatrixInvStatus.noMatrixInvInInteriorEliminationCarrier :=
  K.noMatrixInvStatus_eq

theorem noDtnData
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noDtnDataStatus =
      InteriorEliminationCarrierNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationCarrier :=
  K.noDtnDataStatus_eq

theorem next_construction_gate_is_step
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.nextPositiveConstructionGate =
      InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep :=
  K.nextPositiveConstructionGate_eq

end GeneratedInteriorEliminationCarrier

def generatedInteriorEliminationCarrierFromInteriorBlockInteriorEliminationdR
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    GeneratedInteriorEliminationCarrier Cell p A P wp W E :=
  GeneratedInteriorEliminationCarrier.fromCandidateEntry E

theorem noFreeEliminationCarrier
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier :=
  K.noFreeEliminationCarrierStatus_eq

theorem noExternalEliminationOrderOracle
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    K.noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle :=
  K.noExternalEliminationOrderOracleStatus_eq

def regularGeneratedInteriorEliminationCarrier
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCarrier
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp) :=
  generatedInteriorEliminationCarrierFromInteriorBlockInteriorEliminationdR
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)

def variableGeneratedInteriorEliminationCarrier
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCarrier
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp) :=
  generatedInteriorEliminationCarrierFromInteriorBlockInteriorEliminationdR
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)

structure InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedgerStatus
  interiorInverseCandidatePositiveFirstLedger : InteriorInverseCandidateStartPositiveFirstLedger b β p regularWeight variableWeight
  regularCarrier :
    GeneratedInteriorEliminationCarrier
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
  variableCarrier :
    GeneratedInteriorEliminationCarrier
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
  interiorInverseCandidatePositiveFirstLedger_eq_main :
    interiorInverseCandidatePositiveFirstLedger = interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight
  regularCarrier_eq_main :
    regularCarrier = regularGeneratedInteriorEliminationCarrier b p regularWeight
  variableCarrier_eq_main :
    variableCarrier = variableGeneratedInteriorEliminationCarrier β p variableWeight
  regularNoFreeCarrier :
    regularCarrier.noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier
  variableNoFreeCarrier :
    variableCarrier.noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier
  regularNoExternalOrderOracle :
    regularCarrier.noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle
  variableNoExternalOrderOracle :
    variableCarrier.noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle
  regularNoInverseEntryFunction :
    regularCarrier.noInverseEntryFunctionStatus =
      InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier
  variableNoInverseEntryFunction :
    variableCarrier.noInverseEntryFunctionStatus =
      InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier
  regularNoMatrixExport :
    regularCarrier.noMatrixExportStatus =
      InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier
  variableNoMatrixExport :
    variableCarrier.noMatrixExportStatus =
      InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier
  regularNoEliminationTrace :
    regularCarrier.noEliminationTraceStatus =
      InteriorEliminationCarrierNoEliminationTraceStatus.noEliminationTraceInInteriorEliminationCarrier
  variableNoEliminationTrace :
    variableCarrier.noEliminationTraceStatus =
      InteriorEliminationCarrierNoEliminationTraceStatus.noEliminationTraceInInteriorEliminationCarrier
  regularNextPositiveConstructionGate :
    regularCarrier.nextPositiveConstructionGate =
      InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep
  variableNextPositiveConstructionGate :
    variableCarrier.nextPositiveConstructionGate =
      InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep
  status_eq_closed :
    status =
      InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedgerStatus.generatedInteriorEliminationCarrierClosed

def generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight where
  status :=
    InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedgerStatus.generatedInteriorEliminationCarrierClosed
  interiorInverseCandidatePositiveFirstLedger := interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight
  regularCarrier := regularGeneratedInteriorEliminationCarrier b p regularWeight
  variableCarrier := variableGeneratedInteriorEliminationCarrier β p variableWeight
  interiorInverseCandidatePositiveFirstLedger_eq_main := by
    rfl
  regularCarrier_eq_main := by
    rfl
  variableCarrier_eq_main := by
    rfl
  regularNoFreeCarrier := by
    rfl
  variableNoFreeCarrier := by
    rfl
  regularNoExternalOrderOracle := by
    rfl
  variableNoExternalOrderOracle := by
    rfl
  regularNoInverseEntryFunction := by
    rfl
  variableNoInverseEntryFunction := by
    rfl
  regularNoMatrixExport := by
    rfl
  variableNoMatrixExport := by
    rfl
  regularNoEliminationTrace := by
    rfl
  variableNoEliminationTrace := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).status =
      InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedgerStatus.generatedInteriorEliminationCarrierClosed := by
  rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_regularNoFreeCarrier
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).regularCarrier.noFreeEliminationCarrierStatus =
      InteriorEliminationCarrierNoFreeEliminationCarrierStatus.noFreeEliminationCarrier := by
  rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_variableNoExternalOrderOracle
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).variableCarrier.noExternalEliminationOrderOracleStatus =
      InteriorEliminationCarrierNoExternalEliminationOrderOracleStatus.noExternalEliminationOrderOracle := by
  rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_regularNoInverseEntryFunction
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).regularCarrier.noInverseEntryFunctionStatus =
      InteriorEliminationCarrierNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationCarrier := by
  rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_variableNoMatrixExport
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).variableCarrier.noMatrixExportStatus =
      InteriorEliminationCarrierNoMatrixExportStatus.noMatrixExportInInteriorEliminationCarrier := by
  rfl

theorem generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight).regularCarrier.nextPositiveConstructionGate =
      InteriorEliminationCarrierNextPositiveConstructionGate.generatedInteriorEliminationStepGeneratedInteriorEliminationStep := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
