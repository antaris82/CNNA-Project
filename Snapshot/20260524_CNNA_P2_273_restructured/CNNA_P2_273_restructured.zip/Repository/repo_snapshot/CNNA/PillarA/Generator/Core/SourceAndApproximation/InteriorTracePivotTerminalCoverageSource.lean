import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
import CNNA.PillarA.Generator.Schur.GeneratedPipeline.MultiSchur

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTracePivotTerminalCoverageSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage

universe u

abbrev GeneratedInteriorTracePivotTerminalCoverageSource :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage

namespace GeneratedInteriorTracePivotTerminalCoverageSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev fromTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.fromTrace T

abbrev pivotCoverage_source_eq_tracePivotTerminalCoverage
    (C : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    C.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.pivotCoverageSourceEqInteriorAccumulatedTraceEvaluation C

abbrev pivotCoverage_noTwoSidedInv
    (C : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    C.noTwoSidedInvStatus =
      InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.pivotCoverage_noTwoSidedInv C

end GeneratedInteriorTracePivotTerminalCoverageSource

abbrev GeneratedInteriorTerminalFoldResidualCoverageRequirement :=
  GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage

namespace GeneratedInteriorTerminalFoldResidualCoverageRequirement

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T :=
  GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage.fromInvariance I

abbrev nextConsumer_is_terminalFoldResidualCoverage
    (R : GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    R.nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage :=
  GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage.nextClosureIsInteriorTerminalCoverageSource R

end GeneratedInteriorTerminalFoldResidualCoverageRequirement

namespace GeneratedInteriorTracePivotTerminalCoverageAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T :=
  GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage.fromInvariance I

end GeneratedInteriorTracePivotTerminalCoverageAudit

abbrev RegularGeneratedInteriorTracePivotTerminalCoverageSource :=
  RegularGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage

abbrev VariableGeneratedInteriorTracePivotTerminalCoverageSource :=
  VariableGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage

abbrev regularTracePivotTerminalCoverageSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage b p wp :=
  regularTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage b p wp

abbrev variableTracePivotTerminalCoverageSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage β p wp :=
  variableTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage β p wp

namespace TracePivotTerminalCoverageSourceLedger

abbrev fromRegularAndVariableInvariance
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularInvariance : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p regularWeight)
    (variableInvariance : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p variableWeight) :
    InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger b β p regularWeight variableWeight :=
  InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger.fromRegularAndVariableInvariance
    regularInvariance variableInvariance

end TracePivotTerminalCoverageSourceLedger

end CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTracePivotTerminalCoverageSource
