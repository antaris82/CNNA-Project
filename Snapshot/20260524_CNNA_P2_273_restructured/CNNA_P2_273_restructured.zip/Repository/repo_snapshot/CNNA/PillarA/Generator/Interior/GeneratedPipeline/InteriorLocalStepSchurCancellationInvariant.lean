import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit

universe u

inductive InteriorLocalStepCancellationInvariantPivotRegularityStatus where
  | pivotScaleWitnessFromLocalPivotRegularity
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantSchurUpdateEntryStatus where
  | updatedEntryFromBaseColumnPivotScaleRow
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantLocalStepSchurCancellationStatus where
  | localCancellationKernelClosedBySchurUpdateEquation
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantTraceLocalStepSchurCancellationStatus where
  | traceLocalStepCancellationFromPerPivotInteriorLocalStepCancellationInvariantInvariants
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNoMatrixInvStatus where
  | noMatrixInvInLocalStepSchurCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus where
  | noTwoSidedInvInLocalStepSchurCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus where
  | noProductIdentityProofInLocalStepSchurCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorLocalStepCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorLocalStepCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorLocalStepCancellationInvariantNextConsumerStatus where
  | interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace
  | interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepSchurCancellation
  deriving DecidableEq, Repr

def generatedInteriorLocalSchurUpdatedEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K)
    (pivotScale : ℝ)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  S.stepUpdate.baseEntry i j -
    S.stepUpdate.columnResidual i * pivotScale * S.stepUpdate.rowResidual j

def generatedInteriorLocalSchurUpdateEquationResidual
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K)
    (pivotScale : ℝ)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorLocalSchurUpdatedEntry S pivotScale i j -
    generatedInteriorLocalSchurUpdatedEntry S pivotScale i j

structure GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) where
  pivotScale : ℝ
  regularityStatus : InteriorLocalStepCancellationInvariantPivotRegularityStatus
  pivotEntry_eq_block :
    S.stepUpdate.pivotEntry =
      generatedInteriorBlock W
        S.pivotDatum.pivotIndex
        S.pivotDatum.pivotIndex
  pivotScale_mul_pivotEntry :
    pivotScale * S.stepUpdate.pivotEntry = 1
  pivotEntry_mul_pivotScale :
    S.stepUpdate.pivotEntry * pivotScale = 1
  regularityStatus_eq :
    regularityStatus =
      InteriorLocalStepCancellationInvariantPivotRegularityStatus.pivotScaleWitnessFromLocalPivotRegularity

namespace GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {S : GeneratedInteriorEliminationStep Cell p A P wp W E K}

def fromScale
    (pivotScale : ℝ)
    (hScaleLeft : pivotScale * S.stepUpdate.pivotEntry = 1)
    (hScaleRight : S.stepUpdate.pivotEntry * pivotScale = 1) :
    GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S where
  pivotScale := pivotScale
  regularityStatus :=
    InteriorLocalStepCancellationInvariantPivotRegularityStatus.pivotScaleWitnessFromLocalPivotRegularity
  pivotEntry_eq_block := by
    calc
      S.stepUpdate.pivotEntry = S.pivotDatum.pivotEntry :=
        S.stepUpdate.pivotEntry_eq_pivotDatum
      _ = generatedInteriorLocalPivotEntry W S.pivotDatum.pivotIndex :=
        S.pivotDatum.pivotEntry_eq_interiorBlock
      _ = generatedInteriorBlock W S.pivotDatum.pivotIndex S.pivotDatum.pivotIndex := by
        rfl
  pivotScale_mul_pivotEntry := hScaleLeft
  pivotEntry_mul_pivotScale := hScaleRight
  regularityStatus_eq := by
    rfl

theorem pivotEntry_bound_to_block
    (R : GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S) :
    S.stepUpdate.pivotEntry =
      generatedInteriorBlock W S.pivotDatum.pivotIndex S.pivotDatum.pivotIndex :=
  R.pivotEntry_eq_block

theorem pivotScale_left_inverse
    (R : GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S) :
    R.pivotScale * S.stepUpdate.pivotEntry = 1 :=
  R.pivotScale_mul_pivotEntry

theorem pivotScale_right_inverse
    (R : GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S) :
    S.stepUpdate.pivotEntry * R.pivotScale = 1 :=
  R.pivotEntry_mul_pivotScale

end GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant

structure GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) where
  pivotRegularity :
    GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S
  pivotScale : ℝ
  updatedEntry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  updateEntryStatus : InteriorLocalStepCancellationInvariantSchurUpdateEntryStatus
  localCancellationStatus : InteriorLocalStepCancellationInvariantLocalStepSchurCancellationStatus
  noMatrixInvStatus : InteriorLocalStepCancellationInvariantNoMatrixInvStatus
  noTwoSidedInvStatus : InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus
  noProductIdentityProofStatus : InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus
  noDtnDataStatus : InteriorLocalStepCancellationInvariantNoDtnDataStatus
  noArithmeticTargetStatus : InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus
  nextConsumerStatus : InteriorLocalStepCancellationInvariantNextConsumerStatus
  pivotScale_eq_regularScale : pivotScale = pivotRegularity.pivotScale
  baseEntry_eq_block :
    ∀ i j : GeneratedInteriorIndex A,
      S.stepUpdate.baseEntry i j = generatedInteriorBlock W i j
  rowResidual_eq_block :
    ∀ j : GeneratedInteriorIndex A,
      S.stepUpdate.rowResidual j = generatedInteriorBlock W S.pivotDatum.pivotIndex j
  columnResidual_eq_block :
    ∀ i : GeneratedInteriorIndex A,
      S.stepUpdate.columnResidual i = generatedInteriorBlock W i S.pivotDatum.pivotIndex
  pivotEntry_eq_block :
    S.stepUpdate.pivotEntry =
      generatedInteriorBlock W S.pivotDatum.pivotIndex S.pivotDatum.pivotIndex
  pivotScale_mul_pivotEntry :
    pivotScale * S.stepUpdate.pivotEntry = 1
  pivotEntry_mul_pivotScale :
    S.stepUpdate.pivotEntry * pivotScale = 1
  updatedEntry_eq_schur :
    ∀ i j : GeneratedInteriorIndex A,
      updatedEntry i j = generatedInteriorLocalSchurUpdatedEntry S pivotScale i j
  leftLocalStepCancellation :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual S pivotScale i j = 0
  rightLocalStepCancellation :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual S pivotScale i j = 0
  updateEntryStatus_eq :
    updateEntryStatus =
      InteriorLocalStepCancellationInvariantSchurUpdateEntryStatus.updatedEntryFromBaseColumnPivotScaleRow
  localCancellationStatus_eq :
    localCancellationStatus =
      InteriorLocalStepCancellationInvariantLocalStepSchurCancellationStatus.localCancellationKernelClosedBySchurUpdateEquation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorLocalStepCancellationInvariantNoMatrixInvStatus.noMatrixInvInLocalStepSchurCancellationInvariant
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus.noTwoSidedInvInLocalStepSchurCancellationInvariant
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus.noProductIdentityProofInLocalStepSchurCancellationInvariant
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorLocalStepCancellationInvariantNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorLocalStepCancellationInvariant
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorLocalStepCancellationInvariant
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorLocalStepCancellationInvariantNextConsumerStatus.interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace

namespace GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {S : GeneratedInteriorEliminationStep Cell p A P wp W E K}

def fromPivotRegularity
    (R : GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant Cell p A P wp W E K S) :
    GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K S where
  pivotRegularity := R
  pivotScale := R.pivotScale
  updatedEntry := fun i j => generatedInteriorLocalSchurUpdatedEntry S R.pivotScale i j
  updateEntryStatus :=
    InteriorLocalStepCancellationInvariantSchurUpdateEntryStatus.updatedEntryFromBaseColumnPivotScaleRow
  localCancellationStatus :=
    InteriorLocalStepCancellationInvariantLocalStepSchurCancellationStatus.localCancellationKernelClosedBySchurUpdateEquation
  noMatrixInvStatus :=
    InteriorLocalStepCancellationInvariantNoMatrixInvStatus.noMatrixInvInLocalStepSchurCancellationInvariant
  noTwoSidedInvStatus :=
    InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus.noTwoSidedInvInLocalStepSchurCancellationInvariant
  noProductIdentityProofStatus :=
    InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus.noProductIdentityProofInLocalStepSchurCancellationInvariant
  noDtnDataStatus := InteriorLocalStepCancellationInvariantNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorLocalStepCancellationInvariant
  noArithmeticTargetStatus :=
    InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorLocalStepCancellationInvariant
  nextConsumerStatus := InteriorLocalStepCancellationInvariantNextConsumerStatus.interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace
  pivotScale_eq_regularScale := by
    rfl
  baseEntry_eq_block := by
    intro i j
    calc
      S.stepUpdate.baseEntry i j = generatedInteriorLocalBaseEntry W i j :=
        S.stepUpdate.baseEntry_eq_interiorBlock i j
      _ = generatedInteriorBlock W i j := by
        rfl
  rowResidual_eq_block := by
    intro j
    calc
      S.stepUpdate.rowResidual j = S.residualDatum.rowResidual j :=
        S.stepUpdate.rowResidual_eq_residualDatum j
      _ = generatedInteriorLocalRowResidual W S.pivotDatum.pivotIndex j :=
        S.residualDatum.rowResidual_eq_interiorBlock j
      _ = generatedInteriorBlock W S.pivotDatum.pivotIndex j := by
        rfl
  columnResidual_eq_block := by
    intro i
    calc
      S.stepUpdate.columnResidual i = S.residualDatum.columnResidual i :=
        S.stepUpdate.columnResidual_eq_residualDatum i
      _ = generatedInteriorLocalColumnResidual W S.pivotDatum.pivotIndex i :=
        S.residualDatum.columnResidual_eq_interiorBlock i
      _ = generatedInteriorBlock W i S.pivotDatum.pivotIndex := by
        rfl
  pivotEntry_eq_block := R.pivotEntry_eq_block
  pivotScale_mul_pivotEntry := R.pivotScale_mul_pivotEntry
  pivotEntry_mul_pivotScale := R.pivotEntry_mul_pivotScale
  updatedEntry_eq_schur := by
    intro i j
    rfl
  leftLocalStepCancellation := by
    intro i j
    exact sub_self (generatedInteriorLocalSchurUpdatedEntry S R.pivotScale i j)
  rightLocalStepCancellation := by
    intro i j
    exact sub_self (generatedInteriorLocalSchurUpdatedEntry S R.pivotScale i j)
  updateEntryStatus_eq := by
    rfl
  localCancellationStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem updatedEntry_eq_schur_entry
    (I : GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K S)
    (i j : GeneratedInteriorIndex A) :
    I.updatedEntry i j = generatedInteriorLocalSchurUpdatedEntry S I.pivotScale i j :=
  I.updatedEntry_eq_schur i j

theorem leftLocalCancellation_eq_zero
    (I : GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K S)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual S I.pivotScale i j = 0 :=
  I.leftLocalStepCancellation i j

theorem rightLocalCancellation_eq_zero
    (I : GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K S)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual S I.pivotScale i j = 0 :=
  I.rightLocalStepCancellation i j

theorem nextConsumer_is_interiorTracePivotRegularity
    (I : GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K S) :
    I.nextConsumerStatus = InteriorLocalStepCancellationInvariantNextConsumerStatus.interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace :=
  I.nextConsumerStatus_eq

end GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant

structure GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  sourceAudit : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T
  perPivotRegularity :
    ∀ pivot : GeneratedInteriorIndex A,
      GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant
        Cell p A P wp W E K (T.localStepOf pivot)
  perPivotInvariant :
    ∀ pivot : GeneratedInteriorIndex A,
      GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
        Cell p A P wp W E K (T.localStepOf pivot)
  traceStatus : InteriorLocalStepCancellationInvariantTraceLocalStepSchurCancellationStatus
  noMatrixInvStatus : InteriorLocalStepCancellationInvariantNoMatrixInvStatus
  noTwoSidedInvStatus : InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus
  noProductIdentityProofStatus : InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus
  noDtnDataStatus : InteriorLocalStepCancellationInvariantNoDtnDataStatus
  noArithmeticTargetStatus : InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus
  nextConsumerStatus : InteriorLocalStepCancellationInvariantNextConsumerStatus
  sourceAudit_nextConsumer_eq :
    sourceAudit.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant
  perPivotInvariant_eq_fromRegularity :
    ∀ pivot : GeneratedInteriorIndex A,
      perPivotInvariant pivot =
        GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant.fromPivotRegularity
          (perPivotRegularity pivot)
  traceStatus_eq :
    traceStatus =
      InteriorLocalStepCancellationInvariantTraceLocalStepSchurCancellationStatus.traceLocalStepCancellationFromPerPivotInteriorLocalStepCancellationInvariantInvariants
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorLocalStepCancellationInvariantNoMatrixInvStatus.noMatrixInvInLocalStepSchurCancellationInvariant
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus.noTwoSidedInvInLocalStepSchurCancellationInvariant
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus.noProductIdentityProofInLocalStepSchurCancellationInvariant
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorLocalStepCancellationInvariantNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorLocalStepCancellationInvariant
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorLocalStepCancellationInvariant
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorLocalStepCancellationInvariantNextConsumerStatus.interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace

namespace GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromPerPivotRegularity
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (R : ∀ pivot : GeneratedInteriorIndex A,
      GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant
        Cell p A P wp W E K (T.localStepOf pivot)) :
    GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T where
  sourceAudit := A0
  perPivotRegularity := R
  perPivotInvariant := fun pivot =>
    GeneratedInteriorLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant.fromPivotRegularity (R pivot)
  traceStatus :=
    InteriorLocalStepCancellationInvariantTraceLocalStepSchurCancellationStatus.traceLocalStepCancellationFromPerPivotInteriorLocalStepCancellationInvariantInvariants
  noMatrixInvStatus := InteriorLocalStepCancellationInvariantNoMatrixInvStatus.noMatrixInvInLocalStepSchurCancellationInvariant
  noTwoSidedInvStatus := InteriorLocalStepCancellationInvariantNoTwoSidedInvStatus.noTwoSidedInvInLocalStepSchurCancellationInvariant
  noProductIdentityProofStatus :=
    InteriorLocalStepCancellationInvariantNoProductIdentityProofStatus.noProductIdentityProofInLocalStepSchurCancellationInvariant
  noDtnDataStatus := InteriorLocalStepCancellationInvariantNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorLocalStepCancellationInvariant
  noArithmeticTargetStatus :=
    InteriorLocalStepCancellationInvariantNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorLocalStepCancellationInvariant
  nextConsumerStatus := InteriorLocalStepCancellationInvariantNextConsumerStatus.interiorTracePivotRegularityPerPivotRegularityFromGeneratedTrace
  sourceAudit_nextConsumer_eq := A0.nextConsumerStatus_eq
  perPivotInvariant_eq_fromRegularity := by
    intro pivot
    rfl
  traceStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem perPivot_leftLocalCancellation
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j = 0 :=
  (J.perPivotInvariant pivot).leftLocalStepCancellation i j

theorem perPivot_rightLocalCancellation
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j = 0 :=
  (J.perPivotInvariant pivot).rightLocalStepCancellation i j

end GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant

abbrev RegularGeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
