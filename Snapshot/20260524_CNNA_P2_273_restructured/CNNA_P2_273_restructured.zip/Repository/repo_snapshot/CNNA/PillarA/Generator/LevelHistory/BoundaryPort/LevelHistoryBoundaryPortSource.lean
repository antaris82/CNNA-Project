import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev LevelHistoryBoundaryPortOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.levelHistoryBoundaryPort

def levelHistoryBoundaryPortOutputKind : DerivedOutputKind :=
  DerivedOutputKind.levelHistoryBoundaryPort

theorem levelHistoryBoundaryPort_kind_eq (profile : LevelHistoryBoundaryPortOutputProfile) :
    profile.profile.kind = levelHistoryBoundaryPortOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
