import CNNA.PillarA.Generator.Boundary.GeneratedSubstrateRoute

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

namespace BranchAddressSubstrate

def ledger : GeneratedSubstrateCandidateLedger :=
  GeneratedSubstrateCandidateLedger.branchAddress

theorem ledger_kind :
    ledger.kind = GeneratedSubstrateCandidateKind.branchAddress := by
  rfl

theorem ledger_status :
    ledger.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem ledger_blocker :
    ledger.blocker =
      GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate := by
  rfl

theorem ledger_noFreeCarrier :
    ledger.obligations.carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

theorem ledger_noFinCarrier :
    ledger.obligations.indexPolicy =
      GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier := by
  rfl

theorem ledger_portsDoNotCreateCarrierPoints :
    ledger.obligations.boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints := by
  rfl

end BranchAddressSubstrate

end BoundarySource

namespace StrengtheningBoundaryStateSubstrate

def boundarySubstrateRouteBranchAddressSubstrateLedger :
    BoundarySource.GeneratedSubstrateCandidateLedger :=
  BoundarySource.BranchAddressSubstrate.ledger

theorem boundarySubstrateRouteBranchAddressSubstrate_status :
    boundarySubstrateRouteBranchAddressSubstrateLedger.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteBranchAddressSubstrate_noFreeCarrier :
    boundarySubstrateRouteBranchAddressSubstrateLedger.obligations.carrierPolicy =
      BoundarySource.GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

end StrengtheningBoundaryStateSubstrate

end CNNA.PillarA.Arithmetic
