import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev GeneralizedTopBoundaryDtNOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.generalizedTopBoundaryDtN

def generalizedTopBoundaryDtNOutputKind : DerivedOutputKind :=
  DerivedOutputKind.generalizedTopBoundaryDtN

theorem generalizedTopBoundaryDtN_kind_eq (profile : GeneralizedTopBoundaryDtNOutputProfile) :
    profile.profile.kind = generalizedTopBoundaryDtNOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
