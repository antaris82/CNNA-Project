import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreeFormulaFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.OperationalDegreeReciprocalSource
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge

universe u

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus where
  | localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullBridgeSourceStatus where
  | sourceFromBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalResidualSourceStatus where
  | sourceFromInteriorLocalStepCancellationInvariantTraceLocalStepCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus where
  | noFoldInductionInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus where
  | noTerminalCoverageOrIdentityGateInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus where
  | noProductIdentityProofInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus where
  | noTwoSidedInvInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInLocalStepCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance
  deriving DecidableEq, Repr

structure GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  bridge : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T
  cancellationStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus
  bridgeSourceStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullBridgeSourceStatus
  localResidualSourceStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalResidualSourceStatus
  noFoldInductionStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus
  noTerminalIdentityStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus
  bridgeStatusEqInteriorBlockFoldKernelResidualBridge :
    bridge.bridgeStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  bridgeNextConsumerEqInteriorBlockFoldbFull :
    bridge.nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation
  leftLocalSchurResidual_eq_zero_consumed :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (bridge.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0
  rightLocalSchurResidual_eq_zero_consumed :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (bridge.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0
  leftBridge_eq_kernel_from_residual_zero :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T bridge.traceLocalStepInvariant pivot i j =
        generatedInteriorLeftBlockFoldKernel W T i j pivot
  rightBridge_eq_kernel_from_residual_zero :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T bridge.traceLocalStepInvariant pivot i j =
        generatedInteriorRightBlockFoldKernel W T i j pivot
  leftLocalStepCancellation_from_bridge :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T bridge.traceLocalStepInvariant pivot i j -
        generatedInteriorLeftBlockFoldKernel W T i j pivot = 0
  rightLocalStepCancellation_from_bridge :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T bridge.traceLocalStepInvariant pivot i j -
        generatedInteriorRightBlockFoldKernel W T i j pivot = 0
  cancellationStatus_eq :
    cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  bridgeSourceStatus_eq :
    bridgeSourceStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullBridgeSourceStatus.sourceFromBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
  localResidualSourceStatus_eq :
    localResidualSourceStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalResidualSourceStatus.sourceFromInteriorLocalStepCancellationInvariantTraceLocalStepCancellationInvariant
  noFoldInductionStatus_eq :
    noFoldInductionStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus.noFoldInductionInLocalStepCancellation
  noTerminalIdentityStatus_eq :
    noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus.noTerminalCoverageOrIdentityGateInLocalStepCancellation
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus.noProductIdentityProofInLocalStepCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus.noTwoSidedInvInLocalStepCancellation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoInteriorEliminationDataStatus.noInteriorEliminationDataInLocalStepCancellation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInLocalStepCancellation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInLocalStepCancellation
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance

namespace GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromBridge
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T) :
    GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T where
  bridge := B
  cancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  bridgeSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullBridgeSourceStatus.sourceFromBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
  localResidualSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalResidualSourceStatus.sourceFromInteriorLocalStepCancellationInvariantTraceLocalStepCancellationInvariant
  noFoldInductionStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus.noFoldInductionInLocalStepCancellation
  noTerminalIdentityStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus.noTerminalCoverageOrIdentityGateInLocalStepCancellation
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus.noProductIdentityProofInLocalStepCancellation
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus.noTwoSidedInvInLocalStepCancellation
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoInteriorEliminationDataStatus.noInteriorEliminationDataInLocalStepCancellation
  noDtnDataStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInLocalStepCancellation
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInLocalStepCancellation
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance
  bridgeStatusEqInteriorBlockFoldKernelResidualBridge := B.bridgeStatus_eq
  bridgeNextConsumerEqInteriorBlockFoldbFull := B.nextConsumerStatus_eq
  leftLocalSchurResidual_eq_zero_consumed := by
    intro pivot i j
    exact B.leftLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant pivot i j
  rightLocalSchurResidual_eq_zero_consumed := by
    intro pivot i j
    exact B.rightLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant pivot i j
  leftBridge_eq_kernel_from_residual_zero := by
    intro pivot i j
    exact B.leftKernelLocalSchurResidualBridge_eq_kernel pivot i j
  rightBridge_eq_kernel_from_residual_zero := by
    intro pivot i j
    exact B.rightKernelLocalSchurResidualBridge_eq_kernel pivot i j
  leftLocalStepCancellation_from_bridge := by
    intro pivot i j
    calc
      generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
            W T B.traceLocalStepInvariant pivot i j -
          generatedInteriorLeftBlockFoldKernel W T i j pivot =
          generatedInteriorLeftBlockFoldKernel W T i j pivot -
            generatedInteriorLeftBlockFoldKernel W T i j pivot := by
        exact congrArg
          (fun x => x - generatedInteriorLeftBlockFoldKernel W T i j pivot)
          (B.leftKernelLocalSchurResidualBridge_eq_kernel pivot i j)
      _ = 0 := by
        exact sub_self (generatedInteriorLeftBlockFoldKernel W T i j pivot)
  rightLocalStepCancellation_from_bridge := by
    intro pivot i j
    calc
      generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
            W T B.traceLocalStepInvariant pivot i j -
          generatedInteriorRightBlockFoldKernel W T i j pivot =
          generatedInteriorRightBlockFoldKernel W T i j pivot -
            generatedInteriorRightBlockFoldKernel W T i j pivot := by
        exact congrArg
          (fun x => x - generatedInteriorRightBlockFoldKernel W T i j pivot)
          (B.rightKernelLocalSchurResidualBridge_eq_kernel pivot i j)
      _ = 0 := by
        exact sub_self (generatedInteriorRightBlockFoldKernel W T i j pivot)
  cancellationStatus_eq := by
    rfl
  bridgeSourceStatus_eq := by
    rfl
  localResidualSourceStatus_eq := by
    rfl
  noFoldInductionStatus_eq := by
    rfl
  noTerminalIdentityStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromOperationalDegreeReciprocalSource
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T :=
  fromBridge (GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge.fromOperationalDegreeReciprocalSource S)

theorem leftLocalSchurResidual_eq_zero
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (C.bridge.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0 :=
  C.leftLocalSchurResidual_eq_zero_consumed pivot i j

theorem rightLocalSchurResidual_eq_zero
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (C.bridge.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0 :=
  C.rightLocalSchurResidual_eq_zero_consumed pivot i j

theorem leftBridge_eq_kernel
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T C.bridge.traceLocalStepInvariant pivot i j =
      generatedInteriorLeftBlockFoldKernel W T i j pivot :=
  C.leftBridge_eq_kernel_from_residual_zero pivot i j

theorem rightBridge_eq_kernel
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T C.bridge.traceLocalStepInvariant pivot i j =
      generatedInteriorRightBlockFoldKernel W T i j pivot :=
  C.rightBridge_eq_kernel_from_residual_zero pivot i j

theorem leftLocalStepCancellation
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T C.bridge.traceLocalStepInvariant pivot i j -
      generatedInteriorLeftBlockFoldKernel W T i j pivot = 0 :=
  C.leftLocalStepCancellation_from_bridge pivot i j

theorem rightLocalStepCancellation
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T C.bridge.traceLocalStepInvariant pivot i j -
      generatedInteriorRightBlockFoldKernel W T i j pivot = 0 :=
  C.rightLocalStepCancellation_from_bridge pivot i j

theorem nextClosureIsInteriorBlockFoldInvariance
    (C : GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull Cell p A P wp W E K T) :
    C.nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance :=
  C.nextConsumerStatus_eq

end GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull

abbrev RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularLocalStepCancellationInteriorLocalStepCancellationFull
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (B : RegularGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge b p wp) :
    RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull b p wp :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull.fromBridge B

def variableLocalStepCancellationInteriorLocalStepCancellationFull
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (B : VariableGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge β p wp) :
    VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull β p wp :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull.fromBridge B

def regularLocalStepCancellationInteriorLocalStepCancellationFullFromOperationalDegreeReciprocalSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p wp) :
    RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull b p wp :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull.fromOperationalDegreeReciprocalSource S

def variableLocalStepCancellationInteriorLocalStepCancellationFullFromOperationalDegreeReciprocalSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p wp) :
    VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull β p wp :=
  GeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull.fromOperationalDegreeReciprocalSource S

structure InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularCancellation : RegularGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull b p regularWeight
  variableCancellation : VariableGeneratedInteriorLocalStepCancellationInteriorLocalStepCancellationFull β p variableWeight
  cancellationStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus
  regularCancellationStatus_eq :
    regularCancellation.cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  variableCancellationStatus_eq :
    variableCancellation.cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  regularNoFoldInductionStatus_eq :
    regularCancellation.noFoldInductionStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus.noFoldInductionInLocalStepCancellation
  variableNoFoldInductionStatus_eq :
    variableCancellation.noFoldInductionStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoFoldInductionStatus.noFoldInductionInLocalStepCancellation
  regularNoTerminalIdentityStatus_eq :
    regularCancellation.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus.noTerminalCoverageOrIdentityGateInLocalStepCancellation
  variableNoTerminalIdentityStatus_eq :
    variableCancellation.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTerminalIdentityStatus.noTerminalCoverageOrIdentityGateInLocalStepCancellation
  regularNoProductIdentityProofStatus_eq :
    regularCancellation.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus.noProductIdentityProofInLocalStepCancellation
  variableNoProductIdentityProofStatus_eq :
    variableCancellation.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoProductIdentityProofStatus.noProductIdentityProofInLocalStepCancellation
  regularNoTwoSidedInvStatus_eq :
    regularCancellation.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus.noTwoSidedInvInLocalStepCancellation
  variableNoTwoSidedInvStatus_eq :
    variableCancellation.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNoTwoSidedInvStatus.noTwoSidedInvInLocalStepCancellation
  cancellationStatus_eq :
    cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance

namespace InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationLedger

def fromRegularAndVariableBridges
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularBridge : RegularGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge b p regularWeight)
    (variableBridge : VariableGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationLedger b β p regularWeight variableWeight where
  regularCancellation := regularLocalStepCancellationInteriorLocalStepCancellationFull regularBridge
  variableCancellation := variableLocalStepCancellationInteriorLocalStepCancellationFull variableBridge
  cancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationStatus.localStepCancellationFromInteriorBlockFoldKernelResidualBridgeBridgeAndInteriorLocalStepCancellationInvariantResidualZero
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvariance
  regularCancellationStatus_eq := by
    rfl
  variableCancellationStatus_eq := by
    rfl
  regularNoFoldInductionStatus_eq := by
    rfl
  variableNoFoldInductionStatus_eq := by
    rfl
  regularNoTerminalIdentityStatus_eq := by
    rfl
  variableNoTerminalIdentityStatus_eq := by
    rfl
  regularNoProductIdentityProofStatus_eq := by
    rfl
  variableNoProductIdentityProofStatus_eq := by
    rfl
  regularNoTwoSidedInvStatus_eq := by
    rfl
  variableNoTwoSidedInvStatus_eq := by
    rfl
  cancellationStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromOperationalDegreeReciprocalSources
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p regularWeight)
    (variableSource : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationLedger b β p regularWeight variableWeight :=
  fromRegularAndVariableBridges
    (regularBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge regularSource)
    (variableBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge variableSource)

end InteriorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellationLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
