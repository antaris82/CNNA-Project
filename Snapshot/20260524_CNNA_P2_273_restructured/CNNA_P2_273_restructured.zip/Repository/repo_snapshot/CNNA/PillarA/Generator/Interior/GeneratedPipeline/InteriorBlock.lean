import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry


universe u

inductive InteriorBlockInteriorRestrictionStatus where
  | interiorRestrictionFromDirichletEntryDirichletMatrix
  deriving DecidableEq, Repr

inductive InteriorBlockEntryClassificationStatus where
  | interiorEntriesClassifiedFromGeneratedDirichletEntries
  deriving DecidableEq, Repr

inductive InteriorBlockNoFreeInteriorBlockStatus where
  | noFreeInteriorBlockTable
  deriving DecidableEq, Repr

inductive InteriorBlockZeroRuleStatus where
  | zeroRuleInheritedFromGeneratedAdjacency
  deriving DecidableEq, Repr

inductive InteriorBlockOffdiagRuleStatus where
  | offdiagRuleInheritedFromParentChildOrCouplingAdjacency
  deriving DecidableEq, Repr

inductive InteriorBlockDiagRuleStatus where
  | diagonalRuleInheritedFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorBlockStructureProfile where
  | diagonalOnly
  | degreeDiagonal
  | offdiagCoupled
  | treeRecursive
  | generalFiniteEliminationNeeded
  | obstructed
  deriving DecidableEq, Repr

inductive InteriorBlockNoInverseStatus where
  | noInverseOrEliminationFormulaInInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorBlockNoDtnStatus where
  | noDtnGeneralizedDtnOrMultiSchurInInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorBlockNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorBlockGeneratedInteriorBlockLedgerStatus where
  | generatedInteriorBlockEntriesClassified
  deriving DecidableEq, Repr

def generatedInteriorBlock_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  generatedDirichlet_entry W
    (GeneratedInteriorIndex.toApproximantIndex i)
    (GeneratedInteriorIndex.toApproximantIndex j)

def generatedInteriorBlock
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  fun i j => generatedInteriorBlock_entry W i j

theorem generatedInteriorBlock_entry_eq_dirichlet
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorBlock_entry W i j =
      generatedDirichlet_entry W
        (GeneratedInteriorIndex.toApproximantIndex i)
        (GeneratedInteriorIndex.toApproximantIndex j) := by
  rfl

theorem generatedInteriorBlock_from_dirichlet
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorBlock W i j =
      generatedDirichletMatrix W
        (GeneratedInteriorIndex.toApproximantIndex i)
        (GeneratedInteriorIndex.toApproximantIndex j) := by
  rfl

theorem generatedInteriorBlock_zero_of_not_adjacent
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedInteriorIndex A}
    (hij : GeneratedInteriorIndex.toApproximantIndex i ≠
      GeneratedInteriorIndex.toApproximantIndex j)
    (hadj : ¬ generatedAdjacent
      (GeneratedInteriorIndex.toApproximantIndex i)
      (GeneratedInteriorIndex.toApproximantIndex j)) :
    generatedInteriorBlock W i j = 0 := by
  calc
    generatedInteriorBlock W i j =
        generatedDirichletMatrix W
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j) :=
      generatedInteriorBlock_from_dirichlet W i j
    _ = 0 :=
      zero_of_not_adjacent W hij hadj

theorem generatedInteriorBlock_offdiag_of_parent_child_or_coupling
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {i j : GeneratedInteriorIndex A}
    (hij : GeneratedInteriorIndex.toApproximantIndex i ≠
      GeneratedInteriorIndex.toApproximantIndex j)
    (hadj : generatedAdjacent
      (GeneratedInteriorIndex.toApproximantIndex i)
      (GeneratedInteriorIndex.toApproximantIndex j)) :
    generatedInteriorBlock W i j =
      - W.policy.constantWeight
        (GeneratedInteriorIndex.toApproximantIndex i)
        (GeneratedInteriorIndex.toApproximantIndex j) := by
  calc
    generatedInteriorBlock W i j =
        generatedDirichletMatrix W
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j) :=
      generatedInteriorBlock_from_dirichlet W i j
    _ = - W.policy.constantWeight
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j) :=
      offdiag_of_adjacent W hij hadj

theorem generatedInteriorBlock_diag_degree_or_regularized_degree
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedInteriorIndex A) :
    generatedInteriorBlock W i i =
      generatedDirichlet_degree W (GeneratedInteriorIndex.toApproximantIndex i) := by
  calc
    generatedInteriorBlock W i i =
        generatedDirichletMatrix W
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex i) :=
      generatedInteriorBlock_from_dirichlet W i i
    _ = generatedDirichlet_degree W (GeneratedInteriorIndex.toApproximantIndex i) :=
      diag_degree_or_regularized_degree W (GeneratedInteriorIndex.toApproximantIndex i)

structure GeneratedInteriorBlockStructureProfile
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) where
  profile : InteriorBlockStructureProfile
  restrictionStatus : InteriorBlockInteriorRestrictionStatus
  entryClassificationStatus : InteriorBlockEntryClassificationStatus
  noFreeInteriorBlockStatus : InteriorBlockNoFreeInteriorBlockStatus
  zeroRuleStatus : InteriorBlockZeroRuleStatus
  offdiagRuleStatus : InteriorBlockOffdiagRuleStatus
  diagRuleStatus : InteriorBlockDiagRuleStatus
  noInverseStatus : InteriorBlockNoInverseStatus
  noDtnStatus : InteriorBlockNoDtnStatus
  noArithmeticTargetStatus : InteriorBlockNoArithmeticTargetStatus
  profile_eq_treeRecursive : profile = InteriorBlockStructureProfile.treeRecursive
  restrictionStatus_eq :
    restrictionStatus =
      InteriorBlockInteriorRestrictionStatus.interiorRestrictionFromDirichletEntryDirichletMatrix
  entryClassificationStatus_eq :
    entryClassificationStatus =
      InteriorBlockEntryClassificationStatus.interiorEntriesClassifiedFromGeneratedDirichletEntries
  noFreeInteriorBlockStatus_eq :
    noFreeInteriorBlockStatus = InteriorBlockNoFreeInteriorBlockStatus.noFreeInteriorBlockTable
  zeroRuleStatus_eq :
    zeroRuleStatus = InteriorBlockZeroRuleStatus.zeroRuleInheritedFromGeneratedAdjacency
  offdiagRuleStatus_eq :
    offdiagRuleStatus =
      InteriorBlockOffdiagRuleStatus.offdiagRuleInheritedFromParentChildOrCouplingAdjacency
  diagRuleStatus_eq :
    diagRuleStatus = InteriorBlockDiagRuleStatus.diagonalRuleInheritedFromGeneratedDegree
  noInverseStatus_eq :
    noInverseStatus = InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock
  noDtnStatus_eq :
    noDtnStatus = InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorBlockNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlock
  block_from_dirichlet :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorBlock W i j =
        generatedDirichletMatrix W
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j)
  block_zero_of_not_adjacent :
    ∀ {i j : GeneratedInteriorIndex A},
      GeneratedInteriorIndex.toApproximantIndex i ≠
        GeneratedInteriorIndex.toApproximantIndex j →
      ¬ generatedAdjacent
        (GeneratedInteriorIndex.toApproximantIndex i)
        (GeneratedInteriorIndex.toApproximantIndex j) →
      generatedInteriorBlock W i j = 0
  block_offdiag_of_parent_child_or_coupling :
    ∀ {i j : GeneratedInteriorIndex A},
      GeneratedInteriorIndex.toApproximantIndex i ≠
        GeneratedInteriorIndex.toApproximantIndex j →
      generatedAdjacent
        (GeneratedInteriorIndex.toApproximantIndex i)
        (GeneratedInteriorIndex.toApproximantIndex j) →
      generatedInteriorBlock W i j =
        - W.policy.constantWeight
          (GeneratedInteriorIndex.toApproximantIndex i)
          (GeneratedInteriorIndex.toApproximantIndex j)
  block_diag_degree_or_regularized_degree :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorBlock W i i =
        generatedDirichlet_degree W (GeneratedInteriorIndex.toApproximantIndex i)

namespace GeneratedInteriorBlockStructureProfile

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable (W : GeneratedWeightPolicyEntrySource Cell p A P wp)

def fromEntryLemmas :
    GeneratedInteriorBlockStructureProfile Cell p A P wp W where
  profile := InteriorBlockStructureProfile.treeRecursive
  restrictionStatus :=
    InteriorBlockInteriorRestrictionStatus.interiorRestrictionFromDirichletEntryDirichletMatrix
  entryClassificationStatus :=
    InteriorBlockEntryClassificationStatus.interiorEntriesClassifiedFromGeneratedDirichletEntries
  noFreeInteriorBlockStatus := InteriorBlockNoFreeInteriorBlockStatus.noFreeInteriorBlockTable
  zeroRuleStatus := InteriorBlockZeroRuleStatus.zeroRuleInheritedFromGeneratedAdjacency
  offdiagRuleStatus :=
    InteriorBlockOffdiagRuleStatus.offdiagRuleInheritedFromParentChildOrCouplingAdjacency
  diagRuleStatus := InteriorBlockDiagRuleStatus.diagonalRuleInheritedFromGeneratedDegree
  noInverseStatus := InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock
  noDtnStatus := InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock
  noArithmeticTargetStatus :=
    InteriorBlockNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlock
  profile_eq_treeRecursive := by
    rfl
  restrictionStatus_eq := by
    rfl
  entryClassificationStatus_eq := by
    rfl
  noFreeInteriorBlockStatus_eq := by
    rfl
  zeroRuleStatus_eq := by
    rfl
  offdiagRuleStatus_eq := by
    rfl
  diagRuleStatus_eq := by
    rfl
  noInverseStatus_eq := by
    rfl
  noDtnStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  block_from_dirichlet := by
    intro i j
    exact generatedInteriorBlock_from_dirichlet W i j
  block_zero_of_not_adjacent := by
    intro i j hij hadj
    exact generatedInteriorBlock_zero_of_not_adjacent W hij hadj
  block_offdiag_of_parent_child_or_coupling := by
    intro i j hij hadj
    exact generatedInteriorBlock_offdiag_of_parent_child_or_coupling W hij hadj
  block_diag_degree_or_regularized_degree := by
    intro i
    exact generatedInteriorBlock_diag_degree_or_regularized_degree W i

theorem profile_treeRecursive
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W) :
    G.profile = InteriorBlockStructureProfile.treeRecursive :=
  G.profile_eq_treeRecursive

theorem no_inverse
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W) :
    G.noInverseStatus = InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock :=
  G.noInverseStatus_eq

theorem no_dtn
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W) :
    G.noDtnStatus = InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock :=
  G.noDtnStatus_eq

end GeneratedInteriorBlockStructureProfile

def regularGeneratedInteriorBlock
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    Matrix
      (GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
      (GeneratedInteriorIndex (regularGeneratedApproximantStrong b p)) ℝ :=
  generatedInteriorBlock (regularGeneratedWeightPolicyEntrySource b p wp)

def variableGeneratedInteriorBlock
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    Matrix
      (GeneratedInteriorIndex (variableGeneratedApproximantStrong β p))
      (GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) ℝ :=
  generatedInteriorBlock (variableGeneratedWeightPolicyEntrySource β p wp)

def regularGeneratedInteriorBlockStructureProfile
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorBlockStructureProfile
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp) :=
  GeneratedInteriorBlockStructureProfile.fromEntryLemmas
    (regularGeneratedWeightPolicyEntrySource b p wp)

def variableGeneratedInteriorBlockStructureProfile
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorBlockStructureProfile
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp) :=
  GeneratedInteriorBlockStructureProfile.fromEntryLemmas
    (variableGeneratedWeightPolicyEntrySource β p wp)

structure InteriorBlockGeneratedInteriorBlockLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorBlockGeneratedInteriorBlockLedgerStatus
  dirichletEntryLedger : DirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  regularProfile :
    GeneratedInteriorBlockStructureProfile
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variableProfile :
    GeneratedInteriorBlockStructureProfile
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  dirichletEntryLedger_eq_main :
    dirichletEntryLedger = generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  regularProfile_eq_main :
    regularProfile = regularGeneratedInteriorBlockStructureProfile b p regularWeight
  variableProfile_eq_main :
    variableProfile = variableGeneratedInteriorBlockStructureProfile β p variableWeight
  regularProfile_treeRecursive :
    regularProfile.profile = InteriorBlockStructureProfile.treeRecursive
  variableProfile_treeRecursive :
    variableProfile.profile = InteriorBlockStructureProfile.treeRecursive
  regularNoFreeInteriorBlock :
    regularProfile.noFreeInteriorBlockStatus =
      InteriorBlockNoFreeInteriorBlockStatus.noFreeInteriorBlockTable
  variableNoFreeInteriorBlock :
    variableProfile.noFreeInteriorBlockStatus =
      InteriorBlockNoFreeInteriorBlockStatus.noFreeInteriorBlockTable
  regularNoInverse :
    regularProfile.noInverseStatus =
      InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock
  variableNoInverse :
    variableProfile.noInverseStatus =
      InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock
  regularNoDtn :
    regularProfile.noDtnStatus =
      InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock
  variableNoDtn :
    variableProfile.noDtnStatus =
      InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock
  regularNoArithmeticTarget :
    regularProfile.noArithmeticTargetStatus =
      InteriorBlockNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlock
  variableNoArithmeticTarget :
    variableProfile.noArithmeticTargetStatus =
      InteriorBlockNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlock
  status_eq_closed :
    status = InteriorBlockGeneratedInteriorBlockLedgerStatus.generatedInteriorBlockEntriesClassified

def generatedInteriorBlockGeneratedInteriorBlockLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight where
  status := InteriorBlockGeneratedInteriorBlockLedgerStatus.generatedInteriorBlockEntriesClassified
  dirichletEntryLedger := generatedDirichletEntryGeneratedDirichletEntryLedger b β p regularWeight variableWeight
  regularProfile := regularGeneratedInteriorBlockStructureProfile b p regularWeight
  variableProfile := variableGeneratedInteriorBlockStructureProfile β p variableWeight
  dirichletEntryLedger_eq_main := by
    rfl
  regularProfile_eq_main := by
    rfl
  variableProfile_eq_main := by
    rfl
  regularProfile_treeRecursive := by
    rfl
  variableProfile_treeRecursive := by
    rfl
  regularNoFreeInteriorBlock := by
    rfl
  variableNoFreeInteriorBlock := by
    rfl
  regularNoInverse := by
    rfl
  variableNoInverse := by
    rfl
  regularNoDtn := by
    rfl
  variableNoDtn := by
    rfl
  regularNoArithmeticTarget := by
    rfl
  variableNoArithmeticTarget := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorBlockGeneratedInteriorBlockLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight).status =
      InteriorBlockGeneratedInteriorBlockLedgerStatus.generatedInteriorBlockEntriesClassified := by
  rfl

theorem generatedInteriorBlockGeneratedInteriorBlockLedger_regularProfile_treeRecursive
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight).regularProfile.profile =
      InteriorBlockStructureProfile.treeRecursive := by
  rfl

theorem generatedInteriorBlockGeneratedInteriorBlockLedger_variableProfile_treeRecursive
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight).variableProfile.profile =
      InteriorBlockStructureProfile.treeRecursive := by
  rfl

theorem generatedInteriorBlockGeneratedInteriorBlockLedger_regularNoInverse
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight).regularProfile.noInverseStatus =
      InteriorBlockNoInverseStatus.noInverseOrEliminationFormulaInInteriorBlock := by
  rfl

theorem generatedInteriorBlockGeneratedInteriorBlockLedger_variableNoDtn
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight).variableProfile.noDtnStatus =
      InteriorBlockNoDtnStatus.noDtnGeneralizedDtnOrMultiSchurInInteriorBlock := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
