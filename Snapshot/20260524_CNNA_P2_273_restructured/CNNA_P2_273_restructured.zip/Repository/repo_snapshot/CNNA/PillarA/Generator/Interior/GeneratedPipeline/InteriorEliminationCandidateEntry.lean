import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate


universe u

inductive GeneratedInteriorEliminationCandidateEntrySource where
  | entryFromTreeRecursiveProfile
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryCandidateEntryInterfaceStatus where
  | candidateEntryInterfaceFromInteriorEliminationdRCandidate
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryCandidateEntryValidationStatus where
  | entryNotValidatedUntilInteriorTwoSidedInverseValidationProductProofs
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoMatrixInvStatus where
  | noMatrixInvForCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoFreeEntryTableStatus where
  | noFreeEntryTable
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoExternalInverseOracleStatus where
  | noExternalInverseOracle
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoTwoSidedInvStatus where
  | noTwoSidedInvProofInInteriorEliminationCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus where
  | noExternalInteriorEliminationCertificateAssumption
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataYet
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedgerStatus where
  | generatedCandidateEntryInterfaceBuiltFromInteriorEliminationdRCandidates
  deriving DecidableEq, Repr

def generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  match C.source with
  | GeneratedInteriorEliminationCandidateSource.candidateFromDiagonalOnly =>
      generatedInteriorBlock W i j
  | GeneratedInteriorEliminationCandidateSource.candidateFromDegreeDiagonal =>
      generatedInteriorBlock W i j
  | GeneratedInteriorEliminationCandidateSource.candidateFromOffdiagCoupledProfile =>
      generatedInteriorBlock W i j
  | GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile =>
      generatedInteriorBlock W i j
  | GeneratedInteriorEliminationCandidateSource.candidateFromGeneralFiniteEliminationProfile =>
      generatedInteriorBlock W i j
  | GeneratedInteriorEliminationCandidateSource.candidateObstructed =>
      generatedInteriorBlock W i j

def generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_matrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  fun i j => generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value C i j

structure GeneratedInteriorEliminationCandidateEntry
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) where
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  source : GeneratedInteriorEliminationCandidateEntrySource
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  matrix : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ
  interfaceStatus : InteriorEliminationCandidateEntryCandidateEntryInterfaceStatus
  validationStatus : InteriorEliminationCandidateEntryCandidateEntryValidationStatus
  noMatrixInvStatus : InteriorEliminationCandidateEntryNoMatrixInvStatus
  noFreeEntryTableStatus : InteriorEliminationCandidateEntryNoFreeEntryTableStatus
  noExternalInverseOracleStatus : InteriorEliminationCandidateEntryNoExternalInverseOracleStatus
  noTwoSidedInvStatus : InteriorEliminationCandidateEntryNoTwoSidedInvStatus
  noExternalInteriorEliminationCertificateStatus :
    InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus
  noDtnDataStatus : InteriorEliminationCandidateEntryNoDtnDataStatus
  noArithmeticTargetStatus : InteriorEliminationCandidateEntryNoArithmeticTargetStatus
  candidateSource_treeRecursive :
    candidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
  source_eq_treeRecursive :
    source = GeneratedInteriorEliminationCandidateEntrySource.entryFromTreeRecursiveProfile
  entry_eq_from_treeRecursiveProfile :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j =
        generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
          candidate i j
  matrix_eq_from_candidateEntry :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = entry i j
  candidateEntryProfileEqInteriorEliminationdRSource :
    candidate.profile = candidate.profileData.profile
  interfaceStatus_eq :
    interfaceStatus =
      InteriorEliminationCandidateEntryCandidateEntryInterfaceStatus.candidateEntryInterfaceFromInteriorEliminationdRCandidate
  validationStatus_eq :
    validationStatus =
      InteriorEliminationCandidateEntryCandidateEntryValidationStatus.entryNotValidatedUntilInteriorTwoSidedInverseValidationProductProofs
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry
  noExternalInteriorEliminationCertificateStatus_eq :
    noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorEliminationCandidateEntryNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry

namespace GeneratedInteriorEliminationCandidateEntry

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}

def fromTreeRecursiveCandidate
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (hC : C.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile) :
    GeneratedInteriorEliminationCandidateEntry Cell p A P wp W where
  candidate := C
  source := GeneratedInteriorEliminationCandidateEntrySource.entryFromTreeRecursiveProfile
  entry := fun i j =>
    generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value C i j
  matrix := generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_matrix C
  interfaceStatus :=
    InteriorEliminationCandidateEntryCandidateEntryInterfaceStatus.candidateEntryInterfaceFromInteriorEliminationdRCandidate
  validationStatus :=
    InteriorEliminationCandidateEntryCandidateEntryValidationStatus.entryNotValidatedUntilInteriorTwoSidedInverseValidationProductProofs
  noMatrixInvStatus := InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry
  noFreeEntryTableStatus := InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable
  noExternalInverseOracleStatus := InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle
  noTwoSidedInvStatus := InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry
  noExternalInteriorEliminationCertificateStatus :=
    InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  noDtnDataStatus := InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  noArithmeticTargetStatus :=
    InteriorEliminationCandidateEntryNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry
  candidateSource_treeRecursive := hC
  source_eq_treeRecursive := by
    rfl
  entry_eq_from_treeRecursiveProfile := by
    intro i j
    rfl
  matrix_eq_from_candidateEntry := by
    intro i j
    rfl
  candidateEntryProfileEqInteriorEliminationdRSource :=
    C.profileEqInteriorBlockProfile
  interfaceStatus_eq := by
    rfl
  validationStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noExternalInteriorEliminationCertificateStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

theorem noMatrixInv_for_candidateEntry
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noMatrixInvStatus = InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry :=
  E.noMatrixInvStatus_eq

theorem noFreeEntryTable
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noFreeEntryTableStatus = InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable :=
  E.noFreeEntryTableStatus_eq

theorem noExternalInverseOracle
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle :=
  E.noExternalInverseOracleStatus_eq

theorem noTwoSidedInv
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noTwoSidedInvStatus = InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry :=
  E.noTwoSidedInvStatus_eq

theorem noExternalInteriorEliminationCertificate
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption :=
  E.noExternalInteriorEliminationCertificateStatus_eq

theorem noDtnDataYet
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noDtnDataStatus = InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet :=
  E.noDtnDataStatus_eq

theorem noArithmeticTarget
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noArithmeticTargetStatus =
      InteriorEliminationCandidateEntryNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry :=
  E.noArithmeticTargetStatus_eq

theorem matrix_entry
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    E.matrix i j = E.entry i j :=
  E.matrix_eq_from_candidateEntry i j

end GeneratedInteriorEliminationCandidateEntry

def candidateEntry_from_treeRecursiveProfile
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W)
    (hC : C.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile) :
    GeneratedInteriorEliminationCandidateEntry Cell p A P wp W :=
  GeneratedInteriorEliminationCandidateEntry.fromTreeRecursiveCandidate C hC

def candidateMatrix_from_candidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  E.matrix

theorem candidateMatrix_from_candidateEntry_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    candidateMatrix_from_candidateEntry E i j = E.entry i j :=
  E.matrix_eq_from_candidateEntry i j

theorem candidateEntryProfileEqInteriorEliminationdRSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.candidate.profile = E.candidate.profileData.profile :=
  E.candidateEntryProfileEqInteriorEliminationdRSource

theorem noMatrixInv_for_candidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noMatrixInvStatus = InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry :=
  E.noMatrixInvStatus_eq

theorem noFreeEntryTable
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noFreeEntryTableStatus = InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable :=
  E.noFreeEntryTableStatus_eq

theorem noExternalInverseOracle
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    E.noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle :=
  E.noExternalInverseOracleStatus_eq

def regularGeneratedInteriorEliminationCandidateEntry
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp) :=
  candidateEntry_from_treeRecursiveProfile
    (regularGeneratedInteriorEliminationCandidate b p wp)
    (by rfl)

def variableGeneratedInteriorEliminationCandidateEntry
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp) :=
  candidateEntry_from_treeRecursiveProfile
    (variableGeneratedInteriorEliminationCandidate β p wp)
    (by rfl)

structure InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedgerStatus
  interiorEliminationCandidateLedger : InteriorEliminationdRGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight
  regularCandidateEntry :
    GeneratedInteriorEliminationCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variableCandidateEntry :
    GeneratedInteriorEliminationCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  interiorEliminationCandidateLedger_eq_main :
    interiorEliminationCandidateLedger = generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight
  regularCandidateEntry_eq_main :
    regularCandidateEntry = regularGeneratedInteriorEliminationCandidateEntry b p regularWeight
  variableCandidateEntry_eq_main :
    variableCandidateEntry = variableGeneratedInteriorEliminationCandidateEntry β p variableWeight
  regularCandidateSource_treeRecursive :
    regularCandidateEntry.candidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
  variableCandidateSource_treeRecursive :
    variableCandidateEntry.candidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
  regularCandidateMatrix_from_candidateEntry :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      candidateMatrix_from_candidateEntry regularCandidateEntry i j =
        regularCandidateEntry.entry i j
  variableCandidateMatrix_from_candidateEntry :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      candidateMatrix_from_candidateEntry variableCandidateEntry i j =
        variableCandidateEntry.entry i j
  regularProfileEqInteriorEliminationdRSource :
    regularCandidateEntry.candidate.profile =
      regularCandidateEntry.candidate.profileData.profile
  variableProfileEqInteriorEliminationdRSource :
    variableCandidateEntry.candidate.profile =
      variableCandidateEntry.candidate.profileData.profile
  regularNoMatrixInv :
    regularCandidateEntry.noMatrixInvStatus =
      InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry
  variableNoMatrixInv :
    variableCandidateEntry.noMatrixInvStatus =
      InteriorEliminationCandidateEntryNoMatrixInvStatus.noMatrixInvForCandidateEntry
  regularNoFreeEntryTable :
    regularCandidateEntry.noFreeEntryTableStatus =
      InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable
  variableNoFreeEntryTable :
    variableCandidateEntry.noFreeEntryTableStatus =
      InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable
  regularNoExternalInverseOracle :
    regularCandidateEntry.noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle
  variableNoExternalInverseOracle :
    variableCandidateEntry.noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle
  regularNoTwoSidedInv :
    regularCandidateEntry.noTwoSidedInvStatus =
      InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry
  variableNoTwoSidedInv :
    variableCandidateEntry.noTwoSidedInvStatus =
      InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry
  regularNoExternalInteriorEliminationCertificate :
    regularCandidateEntry.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  variableNoExternalInteriorEliminationCertificate :
    variableCandidateEntry.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationCandidateEntryNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  regularNoDtnDataYet :
    regularCandidateEntry.noDtnDataStatus =
      InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  variableNoDtnDataYet :
    variableCandidateEntry.noDtnDataStatus =
      InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  regularNoArithmeticTarget :
    regularCandidateEntry.noArithmeticTargetStatus =
      InteriorEliminationCandidateEntryNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry
  variableNoArithmeticTarget :
    variableCandidateEntry.noArithmeticTargetStatus =
      InteriorEliminationCandidateEntryNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationCandidateEntry
  status_eq_closed :
    status =
      InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedgerStatus.generatedCandidateEntryInterfaceBuiltFromInteriorEliminationdRCandidates

def generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight where
  status :=
    InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedgerStatus.generatedCandidateEntryInterfaceBuiltFromInteriorEliminationdRCandidates
  interiorEliminationCandidateLedger := generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight
  regularCandidateEntry := regularGeneratedInteriorEliminationCandidateEntry b p regularWeight
  variableCandidateEntry := variableGeneratedInteriorEliminationCandidateEntry β p variableWeight
  interiorEliminationCandidateLedger_eq_main := by
    rfl
  regularCandidateEntry_eq_main := by
    rfl
  variableCandidateEntry_eq_main := by
    rfl
  regularCandidateSource_treeRecursive := by
    rfl
  variableCandidateSource_treeRecursive := by
    rfl
  regularCandidateMatrix_from_candidateEntry := by
    intro i j
    rfl
  variableCandidateMatrix_from_candidateEntry := by
    intro i j
    rfl
  regularProfileEqInteriorEliminationdRSource := by
    rfl
  variableProfileEqInteriorEliminationdRSource := by
    rfl
  regularNoMatrixInv := by
    rfl
  variableNoMatrixInv := by
    rfl
  regularNoFreeEntryTable := by
    rfl
  variableNoFreeEntryTable := by
    rfl
  regularNoExternalInverseOracle := by
    rfl
  variableNoExternalInverseOracle := by
    rfl
  regularNoTwoSidedInv := by
    rfl
  variableNoTwoSidedInv := by
    rfl
  regularNoExternalInteriorEliminationCertificate := by
    rfl
  variableNoExternalInteriorEliminationCertificate := by
    rfl
  regularNoDtnDataYet := by
    rfl
  variableNoDtnDataYet := by
    rfl
  regularNoArithmeticTarget := by
    rfl
  variableNoArithmeticTarget := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight).status =
      InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedgerStatus.generatedCandidateEntryInterfaceBuiltFromInteriorEliminationdRCandidates := by
  rfl

theorem generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger_regularNoFreeEntryTable
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight).regularCandidateEntry.noFreeEntryTableStatus =
      InteriorEliminationCandidateEntryNoFreeEntryTableStatus.noFreeEntryTable := by
  rfl

theorem generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger_variableNoExternalInverseOracle
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight).variableCandidateEntry.noExternalInverseOracleStatus =
      InteriorEliminationCandidateEntryNoExternalInverseOracleStatus.noExternalInverseOracle := by
  rfl

theorem generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger_regularNoTwoSidedInv
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight).regularCandidateEntry.noTwoSidedInvStatus =
      InteriorEliminationCandidateEntryNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationCandidateEntry := by
  rfl

theorem generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger_variableNoDtnDataYet
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight).variableCandidateEntry.noDtnDataStatus =
      InteriorEliminationCandidateEntryNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
