import CNNA.PillarA.Generator.Schur.Arithmetic.HigherLevelPredictionLedger

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

namespace Schur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}
variable {source : ArithmeticSource Cell T} {L : Nat}

inductive HigherLevelQuadraticOrderNormCertificateOutcome where
  | quadraticHeegnerHit
  | quadraticNonHeegner
  | irreducibleOrHigherDegree
  deriving DecidableEq, Repr

inductive HigherLevelHeegnerD where
  | d1
  | d2
  | d3
  | d7
  | d11
  | d19
  | d43
  | d67
  | d163
  deriving DecidableEq, Repr

namespace HigherLevelHeegnerD

def toNat : HigherLevelHeegnerD → Nat
  | d1 => 1
  | d2 => 2
  | d3 => 3
  | d7 => 7
  | d11 => 11
  | d19 => 19
  | d43 => 43
  | d67 => 67
  | d163 => 163

theorem toNat_positive (d : HigherLevelHeegnerD) : 0 < d.toNat := by
  cases d with
  | d1 => exact Nat.succ_pos 0
  | d2 => exact Nat.succ_pos 1
  | d3 => exact Nat.succ_pos 2
  | d7 => exact Nat.succ_pos 6
  | d11 => exact Nat.succ_pos 10
  | d19 => exact Nat.succ_pos 18
  | d43 => exact Nat.succ_pos 42
  | d67 => exact Nat.succ_pos 66
  | d163 => exact Nat.succ_pos 162

end HigherLevelHeegnerD

inductive HigherLevelFactorizationCertificateStatus where
  | factorizationCertificateProvided
  deriving DecidableEq, Repr

inductive HigherLevelMinimalPolynomialCertificateStatus where
  | minimalPolynomialDegreeCertificateProvided
  deriving DecidableEq, Repr

inductive HigherLevelDiscriminantCertificateStatus where
  | discriminantCertificateProvided
  deriving DecidableEq, Repr

inductive HigherLevelFundamentalBridgeStatus where
  | schurToFundamentalDiscriminantCertificateProvided
  | deferredToQuadraticOrderDiscriminantDiscriminantConvention
  deriving DecidableEq, Repr

inductive HigherLevelHeegnerListCertificateStatus where
  | positiveDInHeegnerListCertified
  | positiveDNotInHeegnerListCertified
  | notApplicableForNonQuadraticOutcome
  deriving DecidableEq, Repr

inductive HigherLevelNoNumericalShortcutStatus where
  | noUncertifiedNumericsNoPredictionRowInput
  deriving DecidableEq, Repr

inductive HigherLevelNonQuadraticKind where
  | irreducibleOverQ
  | higherDegreeFactor
  deriving DecidableEq, Repr

structure HigherLevelQuadraticOrderNormCertificateSearchBase
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  predictionLedger : HigherLevelPredictionLedger B b hL
  predictionLedger_eq : predictionLedger = HigherLevelPredictionLedger.fromBoundarySource B b hL
  charpolyLedger : OperativeCharpolyLedger source L z
  charpolyLedger_eq : charpolyLedger = OperativeCharpolyLedger.fromBoundarySource B z
  levelGreaterThanThree : 3 < L
  recurrenceClosed :
    charpolyLedger.recurrenceLedger.recurrenceStatus =
      SchurMobiusRecurrenceStatus.schurMobiusSchurMobiusRecursionClosed
  charpolyClosed :
    charpolyLedger.profile.computationStatus =
      OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed
  numeratorAgreement :
    ∀ k : BoundarySource.LevelHistoryIndex L,
      charpolyLedger.profile.matrix k k =
        charpolyLedger.recurrenceLedger.recursiveSource.numerator k
  noFreeCharpolyAssumptions :
    charpolyLedger.profile.noFreeAssumptionStatus =
      NoFreeAssumptionNoFreeAssumptionStatus.noHCharpolyNoFactorizationNoCharpolyEqAssumption
  predictionOpen :
    predictionLedger.row.predictionStatus = HigherLevelPredictionStatus.openPrediction
  predictionNoDownstreamInput :
    predictionLedger.row.downstreamDisciplineStatus =
      HigherLevelDownstreamDisciplineStatus.noPredictionRowMayServeAsInputForQuadraticNormToDownstreamArithmeticWindow
  predictionNoQuadraticOrderNormCertificateCertificateBeforeSearch :
    predictionLedger.row.quadraticOrderCertificateReferenceStatus =
      HigherLevelQuadraticOrderNormCertificateCertificateReferenceStatus.noQuadraticOrderNormCertificateCertificateYet
  route : B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory
  noCutSpecCarrierClaim :
    ∀ _k : BoundarySource.LevelHistoryIndex L,
      source.toc.approximant source.concretePolicy = T

namespace HigherLevelQuadraticOrderNormCertificateSearchBase

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

def fromBoundarySource
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) :
    HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z where
  predictionLedger := HigherLevelPredictionLedger.fromBoundarySource B b hL
  predictionLedger_eq := by
    rfl
  charpolyLedger := OperativeCharpolyLedger.fromBoundarySource B z
  charpolyLedger_eq := by
    rfl
  levelGreaterThanThree := hL
  recurrenceClosed := by
    rfl
  charpolyClosed := by
    rfl
  numeratorAgreement := by
    intro k
    exact OperativeCharpolyLedger.diagonal_agrees_with_schurNumerator
      (OperativeCharpolyLedger.fromBoundarySource B z) k
  noFreeCharpolyAssumptions := by
    rfl
  predictionOpen := HigherLevelPredictionLedger.row_status_open
    (HigherLevelPredictionLedger.fromBoundarySource B b hL)
  predictionNoDownstreamInput := HigherLevelPredictionLedger.row_no_downstream_input
    (HigherLevelPredictionLedger.fromBoundarySource B b hL)
  predictionNoQuadraticOrderNormCertificateCertificateBeforeSearch := HigherLevelPredictionLedger.row_no_quadraticOrder_certificate
    (HigherLevelPredictionLedger.fromBoundarySource B b hL)
  route := B.route_recursiveHistory
  noCutSpecCarrierClaim := by
    intro k
    exact B.noCutSpecCarrierClaim_at k

theorem charpoly_status_closed
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    S.charpolyLedger.profile.computationStatus =
      OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed :=
  S.charpolyClosed

theorem recurrence_status_closed
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    S.charpolyLedger.recurrenceLedger.recurrenceStatus =
      SchurMobiusRecurrenceStatus.schurMobiusSchurMobiusRecursionClosed :=
  S.recurrenceClosed

theorem prediction_is_open_before_certificate
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    S.predictionLedger.row.predictionStatus = HigherLevelPredictionStatus.openPrediction :=
  S.predictionOpen

theorem prediction_not_downstream_input
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    S.predictionLedger.row.downstreamDisciplineStatus =
      HigherLevelDownstreamDisciplineStatus.noPredictionRowMayServeAsInputForQuadraticNormToDownstreamArithmeticWindow :=
  S.predictionNoDownstreamInput

theorem no_free_charpoly_assumptions
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    S.charpolyLedger.profile.noFreeAssumptionStatus =
      NoFreeAssumptionNoFreeAssumptionStatus.noHCharpolyNoFactorizationNoCharpolyEqAssumption :=
  S.noFreeCharpolyAssumptions

theorem route_recursiveHistory
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z) :
    B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory :=
  S.route

theorem noCutSpecCarrierClaim_at
    (S : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z)
    (k : BoundarySource.LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  S.noCutSpecCarrierClaim k

end HigherLevelQuadraticOrderNormCertificateSearchBase

structure HigherLevelQuadraticHeegnerCertificate
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  base : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z
  factorDegree : Nat
  factorDegree_eq_two : factorDegree = 2
  minimalPolynomialDegree : Nat
  minimalPolynomialDegree_eq_two : minimalPolynomialDegree = 2
  schurDiscriminant : ℤ
  convertedPositiveD : Nat
  heegnerD : HigherLevelHeegnerD
  convertedPositiveD_eq_heegnerD : convertedPositiveD = heegnerD.toNat
  factorizationStatus : HigherLevelFactorizationCertificateStatus
  factorizationStatus_eq :
    factorizationStatus =
      HigherLevelFactorizationCertificateStatus.factorizationCertificateProvided
  minimalPolynomialStatus : HigherLevelMinimalPolynomialCertificateStatus
  minimalPolynomialStatus_eq :
    minimalPolynomialStatus =
      HigherLevelMinimalPolynomialCertificateStatus.minimalPolynomialDegreeCertificateProvided
  discriminantStatus : HigherLevelDiscriminantCertificateStatus
  discriminantStatus_eq :
    discriminantStatus =
      HigherLevelDiscriminantCertificateStatus.discriminantCertificateProvided
  fundamentalBridgeStatus : HigherLevelFundamentalBridgeStatus
  fundamentalBridgeStatus_eq :
    fundamentalBridgeStatus =
      HigherLevelFundamentalBridgeStatus.schurToFundamentalDiscriminantCertificateProvided
  heegnerListStatus : HigherLevelHeegnerListCertificateStatus
  heegnerListStatus_eq :
    heegnerListStatus = HigherLevelHeegnerListCertificateStatus.positiveDInHeegnerListCertified
  noNumericalShortcutStatus : HigherLevelNoNumericalShortcutStatus
  noNumericalShortcutStatus_eq :
    noNumericalShortcutStatus =
      HigherLevelNoNumericalShortcutStatus.noUncertifiedNumericsNoPredictionRowInput
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome
  outcome_eq : outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit

namespace HigherLevelQuadraticHeegnerCertificate

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

theorem outcome_is_quadratic_heegner
    (C : HigherLevelQuadraticHeegnerCertificate B b hL z) :
    C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit :=
  C.outcome_eq

theorem degree_is_two
    (C : HigherLevelQuadraticHeegnerCertificate B b hL z) :
    C.factorDegree = 2 :=
  C.factorDegree_eq_two

theorem positiveD_from_heegner_witness
    (C : HigherLevelQuadraticHeegnerCertificate B b hL z) :
    C.convertedPositiveD = C.heegnerD.toNat :=
  C.convertedPositiveD_eq_heegnerD

theorem charpoly_closed
    (C : HigherLevelQuadraticHeegnerCertificate B b hL z) :
    C.base.charpolyLedger.profile.computationStatus =
      OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed :=
  C.base.charpolyClosed

end HigherLevelQuadraticHeegnerCertificate

structure HigherLevelQuadraticNonHeegnerCertificate
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  base : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z
  factorDegree : Nat
  factorDegree_eq_two : factorDegree = 2
  minimalPolynomialDegree : Nat
  minimalPolynomialDegree_eq_two : minimalPolynomialDegree = 2
  schurDiscriminant : ℤ
  convertedPositiveD : Nat
  factorizationStatus : HigherLevelFactorizationCertificateStatus
  factorizationStatus_eq :
    factorizationStatus =
      HigherLevelFactorizationCertificateStatus.factorizationCertificateProvided
  minimalPolynomialStatus : HigherLevelMinimalPolynomialCertificateStatus
  minimalPolynomialStatus_eq :
    minimalPolynomialStatus =
      HigherLevelMinimalPolynomialCertificateStatus.minimalPolynomialDegreeCertificateProvided
  discriminantStatus : HigherLevelDiscriminantCertificateStatus
  discriminantStatus_eq :
    discriminantStatus =
      HigherLevelDiscriminantCertificateStatus.discriminantCertificateProvided
  fundamentalBridgeStatus : HigherLevelFundamentalBridgeStatus
  fundamentalBridgeStatus_eq :
    fundamentalBridgeStatus =
      HigherLevelFundamentalBridgeStatus.schurToFundamentalDiscriminantCertificateProvided
  heegnerListStatus : HigherLevelHeegnerListCertificateStatus
  heegnerListStatus_eq :
    heegnerListStatus = HigherLevelHeegnerListCertificateStatus.positiveDNotInHeegnerListCertified
  noNumericalShortcutStatus : HigherLevelNoNumericalShortcutStatus
  noNumericalShortcutStatus_eq :
    noNumericalShortcutStatus =
      HigherLevelNoNumericalShortcutStatus.noUncertifiedNumericsNoPredictionRowInput
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome
  outcome_eq : outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner

namespace HigherLevelQuadraticNonHeegnerCertificate

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

theorem outcome_is_quadratic_non_heegner
    (C : HigherLevelQuadraticNonHeegnerCertificate B b hL z) :
    C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner :=
  C.outcome_eq

theorem degree_is_two
    (C : HigherLevelQuadraticNonHeegnerCertificate B b hL z) :
    C.factorDegree = 2 :=
  C.factorDegree_eq_two

theorem charpoly_closed
    (C : HigherLevelQuadraticNonHeegnerCertificate B b hL z) :
    C.base.charpolyLedger.profile.computationStatus =
      OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed :=
  C.base.charpolyClosed

end HigherLevelQuadraticNonHeegnerCertificate

structure HigherLevelIrreducibleOrHigherDegreeCertificate
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  base : HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z
  nonQuadraticKind : HigherLevelNonQuadraticKind
  factorDegree : Nat
  minimalPolynomialDegree : Nat
  schurDiscriminant : Option ℤ
  factorizationStatus : HigherLevelFactorizationCertificateStatus
  factorizationStatus_eq :
    factorizationStatus =
      HigherLevelFactorizationCertificateStatus.factorizationCertificateProvided
  minimalPolynomialStatus : HigherLevelMinimalPolynomialCertificateStatus
  minimalPolynomialStatus_eq :
    minimalPolynomialStatus =
      HigherLevelMinimalPolynomialCertificateStatus.minimalPolynomialDegreeCertificateProvided
  discriminantStatus : HigherLevelDiscriminantCertificateStatus
  discriminantStatus_eq :
    discriminantStatus =
      HigherLevelDiscriminantCertificateStatus.discriminantCertificateProvided
  fundamentalBridgeStatus : HigherLevelFundamentalBridgeStatus
  fundamentalBridgeStatus_eq :
    fundamentalBridgeStatus =
      HigherLevelFundamentalBridgeStatus.deferredToQuadraticOrderDiscriminantDiscriminantConvention
  heegnerListStatus : HigherLevelHeegnerListCertificateStatus
  heegnerListStatus_eq :
    heegnerListStatus = HigherLevelHeegnerListCertificateStatus.notApplicableForNonQuadraticOutcome
  noNumericalShortcutStatus : HigherLevelNoNumericalShortcutStatus
  noNumericalShortcutStatus_eq :
    noNumericalShortcutStatus =
      HigherLevelNoNumericalShortcutStatus.noUncertifiedNumericsNoPredictionRowInput
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome
  outcome_eq : outcome = HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree

namespace HigherLevelIrreducibleOrHigherDegreeCertificate

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

theorem outcome_is_irreducible_or_higher_degree
    (C : HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree :=
  C.outcome_eq

theorem heegner_not_applicable
    (C : HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    C.heegnerListStatus = HigherLevelHeegnerListCertificateStatus.notApplicableForNonQuadraticOutcome :=
  C.heegnerListStatus_eq

theorem charpoly_closed
    (C : HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    C.base.charpolyLedger.profile.computationStatus =
      OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed :=
  C.base.charpolyClosed

end HigherLevelIrreducibleOrHigherDegreeCertificate

structure HigherLevelQuadraticOrderNormCertificateCertificate
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  quadraticHeegnerPayload : Option (HigherLevelQuadraticHeegnerCertificate B b hL z)
  quadraticNonHeegnerPayload : Option (HigherLevelQuadraticNonHeegnerCertificate B b hL z)
  irreducibleOrHigherDegreePayload :
    Option (HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z)
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome

namespace HigherLevelQuadraticOrderNormCertificateCertificate

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

def quadraticHeegner
    (C : HigherLevelQuadraticHeegnerCertificate B b hL z) :
    HigherLevelQuadraticOrderNormCertificateCertificate B b hL z where
  quadraticHeegnerPayload := some C
  quadraticNonHeegnerPayload := none
  irreducibleOrHigherDegreePayload := none
  outcome := HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit

def quadraticNonHeegner
    (C : HigherLevelQuadraticNonHeegnerCertificate B b hL z) :
    HigherLevelQuadraticOrderNormCertificateCertificate B b hL z where
  quadraticHeegnerPayload := none
  quadraticNonHeegnerPayload := some C
  irreducibleOrHigherDegreePayload := none
  outcome := HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner

def irreducibleOrHigherDegree
    (C : HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    HigherLevelQuadraticOrderNormCertificateCertificate B b hL z where
  quadraticHeegnerPayload := none
  quadraticNonHeegnerPayload := none
  irreducibleOrHigherDegreePayload := some C
  outcome := HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree

theorem outcome_three_way
    (C : HigherLevelQuadraticOrderNormCertificateCertificate B b hL z) :
    C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        C.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree := by
  cases C.outcome with
  | quadraticHeegnerHit =>
      exact Or.inl rfl
  | quadraticNonHeegner =>
      exact Or.inr (Or.inl rfl)
  | irreducibleOrHigherDegree =>
      exact Or.inr (Or.inr rfl)

end HigherLevelQuadraticOrderNormCertificateCertificate

end Schur

namespace StrengtheningQuadraticOrderNormCertificate

abbrev QuadraticOrderNormCertificateOutcome := Schur.HigherLevelQuadraticOrderNormCertificateOutcome
abbrev QuadraticOrderNormCertificateHeegnerD := Schur.HigherLevelHeegnerD
abbrev QuadraticOrderNormCertificateFactorizationCertificateStatus :=
  Schur.HigherLevelFactorizationCertificateStatus
abbrev QuadraticOrderNormCertificateMinimalPolynomialCertificateStatus :=
  Schur.HigherLevelMinimalPolynomialCertificateStatus
abbrev QuadraticOrderNormCertificateDiscriminantCertificateStatus :=
  Schur.HigherLevelDiscriminantCertificateStatus
abbrev QuadraticOrderNormCertificateFundamentalBridgeStatus :=
  Schur.HigherLevelFundamentalBridgeStatus
abbrev QuadraticOrderNormCertificateHeegnerListCertificateStatus :=
  Schur.HigherLevelHeegnerListCertificateStatus
abbrev QuadraticOrderNormCertificateNoNumericalShortcutStatus :=
  Schur.HigherLevelNoNumericalShortcutStatus
abbrev QuadraticOrderNormCertificateNonQuadraticKind := Schur.HigherLevelNonQuadraticKind

abbrev QuadraticOrderNormCertificateSearchBase
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : Schur.SpectralParameter) :=
  Schur.HigherLevelQuadraticOrderNormCertificateSearchBase B b hL z

abbrev QuadraticOrderNormCertificateCertificate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : Schur.SpectralParameter) :=
  Schur.HigherLevelQuadraticOrderNormCertificateCertificate B b hL z

def QuadraticOrderNormCertificateSearchBaseFromBoundarySource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : Schur.SpectralParameter) :
    QuadraticOrderNormCertificateSearchBase B b hL z :=
  Schur.HigherLevelQuadraticOrderNormCertificateSearchBase.fromBoundarySource B b hL z

theorem QuadraticOrderNormCertificateSearchBaseCharpolyClosed
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (S : QuadraticOrderNormCertificateSearchBase B b hL z) :
    S.charpolyLedger.profile.computationStatus =
      Schur.OperativeCharpolyComputationStatus.determinantAndPencilEvaluationClosed :=
  Schur.HigherLevelQuadraticOrderNormCertificateSearchBase.charpoly_status_closed S

theorem QuadraticOrderNormCertificateCertificateOutcomeThreeWay
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (C : QuadraticOrderNormCertificateCertificate B b hL z) :
    Schur.HigherLevelQuadraticOrderNormCertificateCertificate.outcome C = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      Schur.HigherLevelQuadraticOrderNormCertificateCertificate.outcome C = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        Schur.HigherLevelQuadraticOrderNormCertificateCertificate.outcome C =
          Schur.HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree :=
  Schur.HigherLevelQuadraticOrderNormCertificateCertificate.outcome_three_way C

end StrengtheningQuadraticOrderNormCertificate

end CNNA.PillarA.Arithmetic
