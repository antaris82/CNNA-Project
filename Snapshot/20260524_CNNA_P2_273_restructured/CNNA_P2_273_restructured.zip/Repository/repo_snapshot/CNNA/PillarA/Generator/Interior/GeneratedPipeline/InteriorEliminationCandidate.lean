import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore


universe u

inductive GeneratedInteriorEliminationCandidateSource where
  | candidateFromDiagonalOnly
  | candidateFromDegreeDiagonal
  | candidateFromOffdiagCoupledProfile
  | candidateFromTreeRecursiveProfile
  | candidateFromGeneralFiniteEliminationProfile
  | candidateObstructed
  deriving DecidableEq, Repr

inductive GeneratedInteriorEliminationCandidateSourceCompatible :
    GeneratedInteriorEliminationCandidateSource → InteriorBlockStructureProfile → Prop where
  | diagonalOnly :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateFromDiagonalOnly
        InteriorBlockStructureProfile.diagonalOnly
  | degreeDiagonal :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateFromDegreeDiagonal
        InteriorBlockStructureProfile.degreeDiagonal
  | offdiagCoupled :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateFromOffdiagCoupledProfile
        InteriorBlockStructureProfile.offdiagCoupled
  | treeRecursive :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
        InteriorBlockStructureProfile.treeRecursive
  | generalFiniteEliminationNeeded :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateFromGeneralFiniteEliminationProfile
        InteriorBlockStructureProfile.generalFiniteEliminationNeeded
  | obstructed :
      GeneratedInteriorEliminationCandidateSourceCompatible
        GeneratedInteriorEliminationCandidateSource.candidateObstructed
        InteriorBlockStructureProfile.obstructed

inductive InteriorEliminationdRProfileOriginStatus where
  | profileFromInteriorBlockInteriorBlockStructureProfile
  deriving DecidableEq, Repr

inductive InteriorEliminationdRCandidateKindStatus where
  | structureDependentCandidateOnly
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoMatrixInvStatus where
  | noMatrixInv
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoFreeInverseStatus where
  | noFreeInverseField
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoTwoSidedInvStatus where
  | noTwoSidedInvProofInInteriorEliminationdR
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus where
  | noExternalInteriorEliminationCertificateAssumption
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataYet
  deriving DecidableEq, Repr

inductive InteriorEliminationdRNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR
  deriving DecidableEq, Repr

inductive InteriorEliminationdRGeneratedInteriorEliminationCandidateLedgerStatus where
  | generatedInteriorEliminationCandidatesBuiltFromInteriorBlockProfiles
  deriving DecidableEq, Repr

structure GeneratedInteriorEliminationCandidate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) where
  profileData : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  profile : InteriorBlockStructureProfile
  source : GeneratedInteriorEliminationCandidateSource
  sourceCompatible :
    GeneratedInteriorEliminationCandidateSourceCompatible source profileData.profile
  profileOriginStatus : InteriorEliminationdRProfileOriginStatus
  candidateKindStatus : InteriorEliminationdRCandidateKindStatus
  noMatrixInvStatus : InteriorEliminationdRNoMatrixInvStatus
  noFreeInverseStatus : InteriorEliminationdRNoFreeInverseStatus
  noTwoSidedInvStatus : InteriorEliminationdRNoTwoSidedInvStatus
  noExternalInteriorEliminationCertificateStatus :
    InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus
  noDtnDataStatus : InteriorEliminationdRNoDtnDataStatus
  noArithmeticTargetStatus : InteriorEliminationdRNoArithmeticTargetStatus
  profileEqInteriorBlockProfile : profile = profileData.profile
  profileOriginStatus_eq :
    profileOriginStatus =
      InteriorEliminationdRProfileOriginStatus.profileFromInteriorBlockInteriorBlockStructureProfile
  candidateKindStatus_eq :
    candidateKindStatus = InteriorEliminationdRCandidateKindStatus.structureDependentCandidateOnly
  noMatrixInvStatus_eq : noMatrixInvStatus = InteriorEliminationdRNoMatrixInvStatus.noMatrixInv
  noFreeInverseStatus_eq :
    noFreeInverseStatus = InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR
  noExternalInteriorEliminationCertificateStatus_eq :
    noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorEliminationdRNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR

namespace GeneratedInteriorEliminationCandidate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}

private def fromProfileWithSource
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (source : GeneratedInteriorEliminationCandidateSource)
    (sourceCompatible :
      GeneratedInteriorEliminationCandidateSourceCompatible source G.profile) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W where
  profileData := G
  profile := G.profile
  source := source
  sourceCompatible := sourceCompatible
  profileOriginStatus :=
    InteriorEliminationdRProfileOriginStatus.profileFromInteriorBlockInteriorBlockStructureProfile
  candidateKindStatus := InteriorEliminationdRCandidateKindStatus.structureDependentCandidateOnly
  noMatrixInvStatus := InteriorEliminationdRNoMatrixInvStatus.noMatrixInv
  noFreeInverseStatus := InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField
  noTwoSidedInvStatus := InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR
  noExternalInteriorEliminationCertificateStatus :=
    InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  noDtnDataStatus := InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  noArithmeticTargetStatus :=
    InteriorEliminationdRNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR
  profileEqInteriorBlockProfile := by
    rfl
  profileOriginStatus_eq := by
    rfl
  candidateKindStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noExternalInteriorEliminationCertificateStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

def candidate_from_diagonalOnly
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.diagonalOnly) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateFromDiagonalOnly
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.diagonalOnly)

def candidate_from_degreeDiagonal
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.degreeDiagonal) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateFromDegreeDiagonal
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.degreeDiagonal)

def candidate_from_offdiagCoupledProfile
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.offdiagCoupled) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateFromOffdiagCoupledProfile
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.offdiagCoupled)

def candidate_from_treeRecursiveProfile
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.treeRecursive) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.treeRecursive)

def candidate_from_generalFiniteEliminationProfile
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.generalFiniteEliminationNeeded) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateFromGeneralFiniteEliminationProfile
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.generalFiniteEliminationNeeded)

def candidate_obstructed
    (G : GeneratedInteriorBlockStructureProfile Cell p A P wp W)
    (hG : G.profile = InteriorBlockStructureProfile.obstructed) :
    GeneratedInteriorEliminationCandidate Cell p A P wp W :=
  fromProfileWithSource G
    GeneratedInteriorEliminationCandidateSource.candidateObstructed
    (hG.symm ▸ GeneratedInteriorEliminationCandidateSourceCompatible.obstructed)

theorem candidateProfileEqInteriorBlockProfile
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.profile = C.profileData.profile :=
  C.profileEqInteriorBlockProfile

theorem candidate_source_compatible
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    GeneratedInteriorEliminationCandidateSourceCompatible C.source C.profileData.profile :=
  C.sourceCompatible

theorem noMatrixInv
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noMatrixInvStatus = InteriorEliminationdRNoMatrixInvStatus.noMatrixInv :=
  C.noMatrixInvStatus_eq

theorem noFreeInverse
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noFreeInverseStatus = InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField :=
  C.noFreeInverseStatus_eq

theorem noTwoSidedInv
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noTwoSidedInvStatus = InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR :=
  C.noTwoSidedInvStatus_eq

theorem noExternalInteriorEliminationCertificate
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption :=
  C.noExternalInteriorEliminationCertificateStatus_eq

theorem noDtnDataYet
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noDtnDataStatus = InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet :=
  C.noDtnDataStatus_eq

theorem noArithmeticTarget
    (C : GeneratedInteriorEliminationCandidate Cell p A P wp W) :
    C.noArithmeticTargetStatus =
      InteriorEliminationdRNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR :=
  C.noArithmeticTargetStatus_eq

end GeneratedInteriorEliminationCandidate

def regularGeneratedInteriorEliminationCandidate
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCandidate
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp) :=
  GeneratedInteriorEliminationCandidate.candidate_from_treeRecursiveProfile
    (regularGeneratedInteriorBlockStructureProfile b p wp)
    (regularGeneratedInteriorBlockStructureProfile b p wp).profile_eq_treeRecursive

def variableGeneratedInteriorEliminationCandidate
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationCandidate
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp) :=
  GeneratedInteriorEliminationCandidate.candidate_from_treeRecursiveProfile
    (variableGeneratedInteriorBlockStructureProfile β p wp)
    (variableGeneratedInteriorBlockStructureProfile β p wp).profile_eq_treeRecursive

structure InteriorEliminationdRGeneratedInteriorEliminationCandidateLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorEliminationdRGeneratedInteriorEliminationCandidateLedgerStatus
  interiorBlockLedger : InteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularCandidate :
    GeneratedInteriorEliminationCandidate
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variableCandidate :
    GeneratedInteriorEliminationCandidate
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  interiorBlockLedger_eq_main :
    interiorBlockLedger = generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularCandidate_eq_main :
    regularCandidate = regularGeneratedInteriorEliminationCandidate b p regularWeight
  variableCandidate_eq_main :
    variableCandidate = variableGeneratedInteriorEliminationCandidate β p variableWeight
  regularProfile_eq_generatedInteriorBlockProfile :
    regularCandidate.profile = regularCandidate.profileData.profile
  variableProfile_eq_generatedInteriorBlockProfile :
    variableCandidate.profile = variableCandidate.profileData.profile
  regularSource_treeRecursive :
    regularCandidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
  variableSource_treeRecursive :
    variableCandidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile
  regularProfile_treeRecursive :
    regularCandidate.profile = InteriorBlockStructureProfile.treeRecursive
  variableProfile_treeRecursive :
    variableCandidate.profile = InteriorBlockStructureProfile.treeRecursive
  regularNoMatrixInv :
    regularCandidate.noMatrixInvStatus = InteriorEliminationdRNoMatrixInvStatus.noMatrixInv
  variableNoMatrixInv :
    variableCandidate.noMatrixInvStatus = InteriorEliminationdRNoMatrixInvStatus.noMatrixInv
  regularNoFreeInverse :
    regularCandidate.noFreeInverseStatus = InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField
  variableNoFreeInverse :
    variableCandidate.noFreeInverseStatus = InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField
  regularNoTwoSidedInv :
    regularCandidate.noTwoSidedInvStatus = InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR
  variableNoTwoSidedInv :
    variableCandidate.noTwoSidedInvStatus = InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR
  regularNoExternalInteriorEliminationCertificate :
    regularCandidate.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  variableNoExternalInteriorEliminationCertificate :
    variableCandidate.noExternalInteriorEliminationCertificateStatus =
      InteriorEliminationdRNoExternalInteriorEliminationCertificateStatus.noExternalInteriorEliminationCertificateAssumption
  regularNoDtnDataYet :
    regularCandidate.noDtnDataStatus =
      InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  variableNoDtnDataYet :
    variableCandidate.noDtnDataStatus =
      InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet
  regularNoArithmeticTarget :
    regularCandidate.noArithmeticTargetStatus =
      InteriorEliminationdRNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR
  variableNoArithmeticTarget :
    variableCandidate.noArithmeticTargetStatus =
      InteriorEliminationdRNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationdR
  status_eq_closed :
    status =
      InteriorEliminationdRGeneratedInteriorEliminationCandidateLedgerStatus.generatedInteriorEliminationCandidatesBuiltFromInteriorBlockProfiles

def generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorEliminationdRGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight where
  status :=
    InteriorEliminationdRGeneratedInteriorEliminationCandidateLedgerStatus.generatedInteriorEliminationCandidatesBuiltFromInteriorBlockProfiles
  interiorBlockLedger := generatedInteriorBlockGeneratedInteriorBlockLedger b β p regularWeight variableWeight
  regularCandidate := regularGeneratedInteriorEliminationCandidate b p regularWeight
  variableCandidate := variableGeneratedInteriorEliminationCandidate β p variableWeight
  interiorBlockLedger_eq_main := by
    rfl
  regularCandidate_eq_main := by
    rfl
  variableCandidate_eq_main := by
    rfl
  regularProfile_eq_generatedInteriorBlockProfile := by
    rfl
  variableProfile_eq_generatedInteriorBlockProfile := by
    rfl
  regularSource_treeRecursive := by
    rfl
  variableSource_treeRecursive := by
    rfl
  regularProfile_treeRecursive := by
    rfl
  variableProfile_treeRecursive := by
    rfl
  regularNoMatrixInv := by
    rfl
  variableNoMatrixInv := by
    rfl
  regularNoFreeInverse := by
    rfl
  variableNoFreeInverse := by
    rfl
  regularNoTwoSidedInv := by
    rfl
  variableNoTwoSidedInv := by
    rfl
  regularNoExternalInteriorEliminationCertificate := by
    rfl
  variableNoExternalInteriorEliminationCertificate := by
    rfl
  regularNoDtnDataYet := by
    rfl
  variableNoDtnDataYet := by
    rfl
  regularNoArithmeticTarget := by
    rfl
  variableNoArithmeticTarget := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).status =
      InteriorEliminationdRGeneratedInteriorEliminationCandidateLedgerStatus.generatedInteriorEliminationCandidatesBuiltFromInteriorBlockProfiles := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_regularSource_treeRecursive
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).regularCandidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_variableSource_treeRecursive
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).variableCandidate.source =
      GeneratedInteriorEliminationCandidateSource.candidateFromTreeRecursiveProfile := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_regularNoMatrixInv
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).regularCandidate.noMatrixInvStatus =
      InteriorEliminationdRNoMatrixInvStatus.noMatrixInv := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_variableNoFreeInverse
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).variableCandidate.noFreeInverseStatus =
      InteriorEliminationdRNoFreeInverseStatus.noFreeInverseField := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_regularNoTwoSidedInv
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).regularCandidate.noTwoSidedInvStatus =
      InteriorEliminationdRNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorEliminationdR := by
  rfl

theorem generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger_variableNoDtnDataYet
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (generatedInteriorEliminationCandidateGeneratedInteriorEliminationCandidateLedger b β p regularWeight variableWeight).variableCandidate.noDtnDataStatus =
      InteriorEliminationdRNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataYet := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
