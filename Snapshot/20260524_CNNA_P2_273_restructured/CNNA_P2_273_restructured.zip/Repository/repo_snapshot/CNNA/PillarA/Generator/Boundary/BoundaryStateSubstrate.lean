import CNNA.PillarA.Generator.Boundary.GeneratedSubstrateRoute

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

namespace BoundaryStateSubstrate

def ledger : GeneratedSubstrateCandidateLedger :=
  GeneratedSubstrateCandidateLedger.boundaryState

theorem ledger_kind :
    ledger.kind = GeneratedSubstrateCandidateKind.boundaryState := by
  rfl

theorem ledger_status :
    ledger.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem ledger_blocker :
    ledger.blocker =
      GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate := by
  rfl

theorem ledger_noFreeCarrier :
    ledger.obligations.carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

theorem ledger_noFinCarrier :
    ledger.obligations.indexPolicy =
      GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier := by
  rfl

theorem ledger_portsDoNotCreateCarrierPoints :
    ledger.obligations.boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints := by
  rfl

end BoundaryStateSubstrate

end BoundarySource

namespace StrengtheningBoundaryStateSubstrate

def boundarySubstrateRouteBoundaryStateSubstrateLedger :
    BoundarySource.GeneratedSubstrateCandidateLedger :=
  BoundarySource.BoundaryStateSubstrate.ledger

theorem boundarySubstrateRouteBoundaryStateSubstrate_status :
    boundarySubstrateRouteBoundaryStateSubstrateLedger.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteBoundaryStateSubstrate_noFreeCarrier :
    boundarySubstrateRouteBoundaryStateSubstrateLedger.obligations.carrierPolicy =
      BoundarySource.GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

end StrengtheningBoundaryStateSubstrate

end CNNA.PillarA.Arithmetic
