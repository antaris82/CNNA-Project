import CNNA.PillarA.ToC.GeneratedBranchFamily

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.Source

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

inductive GeneratedSourceStatus where
  | scaffoldedFromGeneratedBranchBaseline
  deriving DecidableEq, Repr

inductive CutSpecCoreStatus where
  | noCutSpecFullImportedInSourceCore
  deriving DecidableEq, Repr

inductive CarrierOriginStatus where
  | substrateClassLevelCarrier
  deriving DecidableEq, Repr

inductive MatrixDataStatus where
  | noMatrixDataBeforeEntryLemmas
  deriving DecidableEq, Repr

inductive PreviousPipelineContinuityStatus where
  | noPreviousPositivePipelineImport
  deriving DecidableEq, Repr

def regularGeneratedCarrier (b L : Nat) :
    Finset (ConcreteSubstrate.RegularCell b L) :=
  (regularGeneratedFamily b).carrier L

def variableGeneratedCarrier (β : Nat → Nat) (L : Nat) :
    Finset (LevelVariableSubstrate.LevelVariableCell β L) :=
  (variableGeneratedFamily β).carrier L

theorem regularGeneratedCarrier_eq_univ (b L : Nat) :
    regularGeneratedCarrier b L = Finset.univ := by
  rfl

theorem variableGeneratedCarrier_eq_univ (β : Nat → Nat) (L : Nat) :
    variableGeneratedCarrier β L = Finset.univ := by
  rfl

def regularGeneratedCarrier_nonSingletonAtSucc
    {b L : Nat} (hb : 0 < b) :
    GeneratedBranchFamily.NonSingletonWitness
      (ConcreteSubstrate.RegularCell b) (L + 1) :=
  regularGeneratedFamily_nonSingletonAtSucc (b := b) (L := L) hb

def variableGeneratedCarrier_nonSingletonAtSucc
    {β : Nat → Nat} {L : Nat} (hβ : 0 < β L) :
    GeneratedBranchFamily.NonSingletonWitness
      (LevelVariableSubstrate.LevelVariableCell β) (L + 1) :=
  variableGeneratedFamily_nonSingletonAtSucc (β := β) (L := L) hβ

structure GeneratedSourceLedger where
  status : GeneratedSourceStatus
  cutSpecCoreStatus : CutSpecCoreStatus
  carrierOriginStatus : CarrierOriginStatus
  matrixDataStatus : MatrixDataStatus
  previousPipelineContinuityStatus : PreviousPipelineContinuityStatus
  regularCarrier_eq_univ : ∀ b L : Nat,
    regularGeneratedCarrier b L = Finset.univ
  variableCarrier_eq_univ : ∀ β : Nat → Nat, ∀ L : Nat,
    variableGeneratedCarrier β L = Finset.univ
  regularNonSingletonAtSucc : ∀ {b L : Nat}, 0 < b →
    GeneratedBranchFamily.NonSingletonWitness
      (ConcreteSubstrate.RegularCell b) (L + 1)
  variableNonSingletonAtSucc : ∀ {β : Nat → Nat} {L : Nat}, 0 < β L →
    GeneratedBranchFamily.NonSingletonWitness
      (LevelVariableSubstrate.LevelVariableCell β) (L + 1)

def generatedSourceLedger : GeneratedSourceLedger where
  status := GeneratedSourceStatus.scaffoldedFromGeneratedBranchBaseline
  cutSpecCoreStatus := CutSpecCoreStatus.noCutSpecFullImportedInSourceCore
  carrierOriginStatus := CarrierOriginStatus.substrateClassLevelCarrier
  matrixDataStatus := MatrixDataStatus.noMatrixDataBeforeEntryLemmas
  previousPipelineContinuityStatus := PreviousPipelineContinuityStatus.noPreviousPositivePipelineImport
  regularCarrier_eq_univ := regularGeneratedCarrier_eq_univ
  variableCarrier_eq_univ := variableGeneratedCarrier_eq_univ
  regularNonSingletonAtSucc := by
    intro b L hb
    exact regularGeneratedCarrier_nonSingletonAtSucc (b := b) (L := L) hb
  variableNonSingletonAtSucc := by
    intro β L hβ
    exact variableGeneratedCarrier_nonSingletonAtSucc (β := β) (L := L) hβ

theorem generatedSourceLedger_status :
    generatedSourceLedger.status =
      GeneratedSourceStatus.scaffoldedFromGeneratedBranchBaseline := by
  rfl

theorem generatedSourceLedger_cutSpecCoreStatus :
    generatedSourceLedger.cutSpecCoreStatus =
      CutSpecCoreStatus.noCutSpecFullImportedInSourceCore := by
  rfl

theorem generatedSourceLedger_carrierOriginStatus :
    generatedSourceLedger.carrierOriginStatus =
      CarrierOriginStatus.substrateClassLevelCarrier := by
  rfl

theorem generatedSourceLedger_matrixDataStatus :
    generatedSourceLedger.matrixDataStatus =
      MatrixDataStatus.noMatrixDataBeforeEntryLemmas := by
  rfl

theorem generatedSourceLedger_previousPipelineContinuityStatus :
    generatedSourceLedger.previousPipelineContinuityStatus =
      PreviousPipelineContinuityStatus.noPreviousPositivePipelineImport := by
  rfl

end CNNA.PillarA.Arithmetic.SourceAndApproximation.Source
