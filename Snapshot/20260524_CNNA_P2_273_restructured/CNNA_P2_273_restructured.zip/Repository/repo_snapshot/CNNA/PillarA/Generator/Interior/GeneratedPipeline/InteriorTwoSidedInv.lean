import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTwoSidedInvCore
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateHandoff
import CNNA.PillarA.Generator.DtN.Core.DtN

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

open scoped BigOperators

universe u

inductive InteriorTwoSidedInverseValidationHandoffShapeAuditStatus where
  | handoffShapeAuditedFromInteriorTwoSidedInverse
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationLeftProductStatus where
  | leftProductFromInteriorBlockAndHandoffCandidate
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationRightProductStatus where
  | rightProductFromHandoffCandidateAndInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationProductNormalFormStatus where
  | productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationTraceCancellationStatus where
  | traceCancellationFromInteriorTerminalFoldResidualAccumulatedEntryAndR3aNormalForms
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationProductCancellationLedgerStatus where
  | productCancellationLedgerFromTraceCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoProductIdentityProofStatus where
  | noProductIdentityProofConstructedInR3b
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationR4GateStatus where
  | r4ReadyAfterR3bCancellationFields
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationDiagonalOffdiagStatus where
  | diagonalOffdiagGoalsProofCarrying
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationProofGateStatus where
  | waitingForLeftAndRightProductIdentityProofs
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus where
  | interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoInteriorEliminationCandidateEntryFallbackStatus where
  | noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseValidation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoFreeEntryTableStatus where
  | noFreeEntryTableInInteriorTwoSidedInverseValidation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoMatrixInvStatus where
  | noMatrixInvInInteriorTwoSidedInverseValidation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus where
  | noExternalInverseOracleInInteriorTwoSidedInverseValidation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F where
  | noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55 where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationLedgerStatus where
  | handoffProductCalculusPrepared
  deriving DecidableEq, Repr

def GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (generatedInteriorBlock W * H.candidateMatrix) i j

def GeneratedInteriorInteriorTwoSidedInverseRightProductEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (H.candidateMatrix * generatedInteriorBlock W) i j

theorem generatedInteriorInteriorTwoSidedInverseLeftProductEntryEqMatrixProduct
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
      (generatedInteriorBlock W * H.candidateMatrix) i j := by
  rfl

theorem generatedInteriorInteriorTwoSidedInverseRightProductEntryEqMatrixProduct
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
      (H.candidateMatrix * generatedInteriorBlock W) i j := by
  rfl

structure GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  status : InteriorTwoSidedInverseValidationHandoffShapeAuditStatus
  mayConsumeOnlyHandoff : InteriorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidate H
  noInteriorEliminationCandidateEntryFallbackStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCandidateEntryFallbackStatus
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  noMatrixInvStatus : InteriorTwoSidedInverseValidationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus
  candidateMatrixEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix : H.candidateMatrix = S.matrix
  candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport :
    ∀ i j : GeneratedInteriorIndex A, H.candidateMatrix i j = M.matrix i j
  candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry :
    ∀ i j : GeneratedInteriorIndex A,
      H.candidateMatrix i j = S.accumulatedInverseCandidateEntry.entry i j
  candidateMatrixEntry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      H.candidateMatrix i j = generatedInteriorAccumulatedEntryValue T i j
  handoff_noLeftProductStatus :
    H.noLeftProductStatus = InteriorTwoSidedInverseNoLeftProductStatus.noLeftProductInInteriorTwoSidedInverseHandoff
  handoff_noRightProductStatus :
    H.noRightProductStatus = InteriorTwoSidedInverseNoRightProductStatus.noRightProductInInteriorTwoSidedInverseHandoff
  handoff_noTwoSidedInvStatus :
    H.noTwoSidedInvStatus = InteriorTwoSidedInverseNoTwoSidedInvStatus.noTwoSidedInvInInteriorTwoSidedInverseHandoff
  status_eq :
    status = InteriorTwoSidedInverseValidationHandoffShapeAuditStatus.handoffShapeAuditedFromInteriorTwoSidedInverse
  noInteriorEliminationCandidateEntryFallbackStatusEq :
    noInteriorEliminationCandidateEntryFallbackStatus = InteriorTwoSidedInverseValidationNoInteriorEliminationCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseValidation
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation

namespace GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromHandoff
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit Cell p A P wp W E K T M S H where
  status := InteriorTwoSidedInverseValidationHandoffShapeAuditStatus.handoffShapeAuditedFromInteriorTwoSidedInverse
  mayConsumeOnlyHandoff := interiorTwoSidedInverseValidationMayConsumeOnlyInteriorInverseCandidateInverseCandidateForHandoff H
  noInteriorEliminationCandidateEntryFallbackStatus := InteriorTwoSidedInverseValidationNoInteriorEliminationCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryFallbackInInteriorTwoSidedInverseValidation
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus := InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus :=
    InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  candidateMatrixEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix :=
    handoffCandidateEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix H
  candidateMatrixEntryEqInteriorInverseCandidateMatrixMatrixExport := by
    intro i j
    exact handoffCandidateSourceEqInteriorInverseCandidateMatrixMatrixExport H i j
  candidateMatrixEntryEqInteriorTerminalFoldResidualAccumulatedEntry := by
    intro i j
    exact handoffCandidateSourceEqInteriorTerminalFoldResidualAccumulatedEntry H i j
  candidateMatrixEntry_eq_accumulatedTraceValue := by
    intro i j
    exact H.candidateMatrixEntry_eq_accumulatedTraceValue i j
  handoff_noLeftProductStatus := noLeftProductForInteriorTwoSidedInverse H
  handoff_noRightProductStatus := noRightProductForInteriorTwoSidedInverse H
  handoff_noTwoSidedInvStatus := noTwoSidedInvForInteriorTwoSidedInverse H
  status_eq := by
    rfl
  noInteriorEliminationCandidateEntryFallbackStatusEq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit

structure GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  shapeAudit : GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationLeftProductStatus
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  entry_eq_matrixProduct :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        (generatedInteriorBlock W * H.candidateMatrix) i j
  status_eq :
    status = InteriorTwoSidedInverseValidationLeftProductStatus.leftProductFromInteriorBlockAndHandoffCandidate
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation

namespace GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromHandoff
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit Cell p A P wp W E K T M S H where
  shapeAudit := GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit.fromHandoff H
  status := InteriorTwoSidedInverseValidationLeftProductStatus.leftProductFromInteriorBlockAndHandoffCandidate
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  entry_eq_matrixProduct := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseLeftProductEntryEqMatrixProduct H i j
  status_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit

structure GeneratedInteriorInteriorTwoSidedInverseRightProductAudit
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  shapeAudit : GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationRightProductStatus
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  entry_eq_matrixProduct :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        (H.candidateMatrix * generatedInteriorBlock W) i j
  status_eq :
    status = InteriorTwoSidedInverseValidationRightProductStatus.rightProductFromHandoffCandidateAndInteriorBlock
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation

namespace GeneratedInteriorInteriorTwoSidedInverseRightProductAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromHandoff
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductAudit Cell p A P wp W E K T M S H where
  shapeAudit := GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit.fromHandoff H
  status := InteriorTwoSidedInverseValidationRightProductStatus.rightProductFromHandoffCandidateAndInteriorBlock
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  entry_eq_matrixProduct := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseRightProductEntryEqMatrixProduct H i j
  status_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseRightProductAudit

def GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorBlock W i k * generatedInteriorAccumulatedEntryValue T k j

def GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorAccumulatedEntryValue T i k * generatedInteriorBlock W k j

theorem leftProductEntry_expand_handoffCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
      ∑ k : GeneratedInteriorIndex A,
        generatedInteriorBlock W i k * H.candidateMatrix k j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        (generatedInteriorBlock W * H.candidateMatrix) i j := by
          rfl
    _ = ∑ k : GeneratedInteriorIndex A,
          generatedInteriorBlock W i k * H.candidateMatrix k j := by
          rw [Matrix.mul_apply]

theorem rightProductEntry_expand_handoffCandidate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
      ∑ k : GeneratedInteriorIndex A,
        H.candidateMatrix i k * generatedInteriorBlock W k j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        (H.candidateMatrix * generatedInteriorBlock W) i j := by
          rfl
    _ = ∑ k : GeneratedInteriorIndex A,
          H.candidateMatrix i k * generatedInteriorBlock W k j := by
          rw [Matrix.mul_apply]

theorem generatedInteriorInteriorTwoSidedInverseLeftProductEntryEqSumAccumulated
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
      GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        ∑ k : GeneratedInteriorIndex A,
          generatedInteriorBlock W i k * H.candidateMatrix k j :=
          leftProductEntry_expand_handoffCandidate H i j
    _ = ∑ k : GeneratedInteriorIndex A,
          generatedInteriorBlock W i k * generatedInteriorAccumulatedEntryValue T k j := by
          refine Finset.sum_congr rfl ?_
          intro k _
          exact congrArg
            (fun x : ℝ => generatedInteriorBlock W i k * x)
            (H.candidateMatrixEntry_eq_accumulatedTraceValue k j)

theorem generatedInteriorInteriorTwoSidedInverseRightProductEntryEqSumAccumulated
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
      GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        ∑ k : GeneratedInteriorIndex A,
          H.candidateMatrix i k * generatedInteriorBlock W k j :=
          rightProductEntry_expand_handoffCandidate H i j
    _ = ∑ k : GeneratedInteriorIndex A,
          generatedInteriorAccumulatedEntryValue T i k * generatedInteriorBlock W k j := by
          refine Finset.sum_congr rfl ?_
          intro k _
          exact congrArg
            (fun x : ℝ => x * generatedInteriorBlock W k j)
            (H.candidateMatrixEntry_eq_accumulatedTraceValue i k)

structure GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  leftProductAudit : GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit Cell p A P wp W E K T M S H
  rightProductAudit : GeneratedInteriorInteriorTwoSidedInverseRightProductAudit Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationProductNormalFormStatus
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  noMatrixInvStatus : InteriorTwoSidedInverseValidationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  leftProduct_expand_handoffCandidate :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        ∑ k : GeneratedInteriorIndex A,
          generatedInteriorBlock W i k * H.candidateMatrix k j
  rightProduct_expand_handoffCandidate :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        ∑ k : GeneratedInteriorIndex A,
          H.candidateMatrix i k * generatedInteriorBlock W k j
  leftProductEntry_eq_sum_accumulated :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j
  rightProductEntry_eq_sum_accumulated :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j
  candidateMatrixEntry_eq_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      H.candidateMatrix i j = generatedInteriorAccumulatedEntryValue T i j
  status_eq :
    status =
      InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation

namespace GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromHandoff
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger Cell p A P wp W E K T M S H where
  leftProductAudit := GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit.fromHandoff H
  rightProductAudit := GeneratedInteriorInteriorTwoSidedInverseRightProductAudit.fromHandoff H
  status :=
    InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  noFreeEntryTableStatus := InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus := InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus :=
    InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  leftProduct_expand_handoffCandidate := by
    intro i j
    exact leftProductEntry_expand_handoffCandidate H i j
  rightProduct_expand_handoffCandidate := by
    intro i j
    exact rightProductEntry_expand_handoffCandidate H i j
  leftProductEntry_eq_sum_accumulated := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseLeftProductEntryEqSumAccumulated H i j
  rightProductEntry_eq_sum_accumulated := by
    intro i j
    exact generatedInteriorInteriorTwoSidedInverseRightProductEntryEqSumAccumulated H i j
  candidateMatrixEntry_eq_accumulatedTraceValue := by
    intro i j
    exact H.candidateMatrixEntry_eq_accumulatedTraceValue i j
  status_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger


structure GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  productNormalFormLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationTraceCancellationStatus
  noFreeEntryTableStatus : InteriorTwoSidedInverseValidationNoFreeEntryTableStatus
  noMatrixInvStatus : InteriorTwoSidedInverseValidationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :
    H.sourceAccumulatedEntry.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  productNormalFormStatus_eq :
    productNormalFormLedger.status =
      InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  leftNormalForm_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightNormalForm_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftNormalForm_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i i = 1
  leftNormalForm_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j = 0
  rightNormalForm_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i i = 1
  rightNormalForm_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j = 0
  status_eq :
    status =
      InteriorTwoSidedInverseValidationTraceCancellationStatus.traceCancellationFromInteriorTerminalFoldResidualAccumulatedEntryAndR3aNormalForms
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorTwoSidedInverseValidationNoFreeEntryTableStatus.noFreeEntryTableInInteriorTwoSidedInverseValidation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTwoSidedInverseValidationNoMatrixInvStatus.noMatrixInvInInteriorTwoSidedInverseValidation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorTwoSidedInverseValidationNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorTwoSidedInverseValidation
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation

namespace GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}


theorem leftProduct_entry_eq_identity
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j :=
          C.productNormalFormLedger.leftProductEntry_eq_sum_accumulated i j
    _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
          C.leftNormalForm_entry_eq_identity i j

theorem rightProduct_entry_eq_identity
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j :=
          C.productNormalFormLedger.rightProductEntry_eq_sum_accumulated i j
    _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
          C.rightNormalForm_entry_eq_identity i j

theorem leftProduct_diagonal_entry
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i i = 1 := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i i =
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i i :=
          C.productNormalFormLedger.leftProductEntry_eq_sum_accumulated i i
    _ = 1 := C.leftNormalForm_diagonal_entry i

theorem leftProduct_offdiag_entry
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j = 0 := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j :=
          C.productNormalFormLedger.leftProductEntry_eq_sum_accumulated i j
    _ = 0 := C.leftNormalForm_offdiag_entry i j hij

theorem rightProduct_diagonal_entry
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i i = 1 := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i i =
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i i :=
          C.productNormalFormLedger.rightProductEntry_eq_sum_accumulated i i
    _ = 1 := C.rightNormalForm_diagonal_entry i

theorem rightProduct_offdiag_entry
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j = 0 := by
  calc
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j :=
          C.productNormalFormLedger.rightProductEntry_eq_sum_accumulated i j
    _ = 0 := C.rightNormalForm_offdiag_entry i j hij

end GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant

structure GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  productNormalFormLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger Cell p A P wp W E K T M S H
  traceCancellationInvariant :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H
  status : InteriorTwoSidedInverseValidationProductCancellationLedgerStatus
  r4GateStatus : InteriorTwoSidedInverseValidationR4GateStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationNoProductIdentityProofStatus
  interiorEliminationFinalGateGateStatus : InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B
  leftProduct_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightProduct_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftProduct_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i i = 1
  leftProduct_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j = 0
  rightProduct_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i i = 1
  rightProduct_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j = 0
  status_eq :
    status =
      InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation
  r4GateStatus_eq :
    r4GateStatus = InteriorTwoSidedInverseValidationR4GateStatus.r4ReadyAfterR3bCancellationFields
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus_eq :
    interiorEliminationFinalGateGateStatus = InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720

namespace GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}


def fromTraceCancellationInvariant
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H where
  productNormalFormLedger := C.productNormalFormLedger
  traceCancellationInvariant := C
  status :=
    InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation
  r4GateStatus := InteriorTwoSidedInverseValidationR4GateStatus.r4ReadyAfterR3bCancellationFields
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus := InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  leftProduct_entry_eq_identity := by
    intro i j
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.leftProduct_entry_eq_identity C i j
  rightProduct_entry_eq_identity := by
    intro i j
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.rightProduct_entry_eq_identity C i j
  leftProduct_diagonal_entry := by
    intro i
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.leftProduct_diagonal_entry C i
  leftProduct_offdiag_entry := by
    intro i j hij
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.leftProduct_offdiag_entry C i j hij
  rightProduct_diagonal_entry := by
    intro i
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.rightProduct_diagonal_entry C i
  rightProduct_offdiag_entry := by
    intro i j hij
    exact GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant.rightProduct_offdiag_entry C i j hij
  status_eq := by
    rfl
  r4GateStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  interiorEliminationFinalGateGateStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

theorem leftProduct_entry_eq_identity_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  L.leftProduct_entry_eq_identity i j

theorem rightProduct_entry_eq_identity_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  L.rightProduct_entry_eq_identity i j

theorem leftProduct_diagonal_entry_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i i = 1 :=
  L.leftProduct_diagonal_entry i

theorem leftProduct_offdiag_entry_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j = 0 :=
  L.leftProduct_offdiag_entry i j hij

theorem rightProduct_diagonal_entry_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i i = 1 :=
  L.rightProduct_diagonal_entry i

theorem rightProduct_offdiag_entry_of_ledger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j = 0 :=
  L.rightProduct_offdiag_entry i j hij

end GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger

structure GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) : Prop where
  leftProduct_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightProduct_entry_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftProduct_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i i = 1
  leftProduct_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j = 0
  rightProduct_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i i = 1
  rightProduct_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j = 0

theorem generatedInteriorInteriorTwoSidedInverseLeftProductMatrixEqIdentity
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (Q : GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H) :
    generatedInteriorBlock W * H.candidateMatrix =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) := by
  funext i j
  change GeneratedInteriorInteriorTwoSidedInverseLeftProductEntry H i j =
    (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  exact Q.leftProduct_entry_eq_identity i j

theorem generatedInteriorInteriorTwoSidedInverseRightProductMatrixEqIdentity
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (Q : GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H) :
    H.candidateMatrix * generatedInteriorBlock W =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) := by
  funext i j
  change GeneratedInteriorInteriorTwoSidedInverseRightProductEntry H i j =
    (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  exact Q.rightProduct_entry_eq_identity i j

def provenTwoSidedInvFromInteriorTwoSidedInverse
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (Q : GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H) :
    TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix where
  left_inv := generatedInteriorInteriorTwoSidedInverseLeftProductMatrixEqIdentity Q
  right_inv := generatedInteriorInteriorTwoSidedInverseRightProductMatrixEqIdentity Q

structure GeneratedInteriorInteriorTwoSidedInverseProductProofGate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  leftProductAudit : GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit Cell p A P wp W E K T M S H
  rightProductAudit : GeneratedInteriorInteriorTwoSidedInverseRightProductAudit Cell p A P wp W E K T M S H
  diagonalOffdiagStatus : InteriorTwoSidedInverseValidationDiagonalOffdiagStatus
  proofGateStatus : InteriorTwoSidedInverseValidationProofGateStatus
  interiorEliminationFinalGateGateStatus : InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B
  diagonalOffdiagStatus_eq :
    diagonalOffdiagStatus = InteriorTwoSidedInverseValidationDiagonalOffdiagStatus.diagonalOffdiagGoalsProofCarrying
  proofGateStatus_eq :
    proofGateStatus = InteriorTwoSidedInverseValidationProofGateStatus.waitingForLeftAndRightProductIdentityProofs
  interiorEliminationFinalGateGateStatus_eq :
    interiorEliminationFinalGateGateStatus = InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720

namespace GeneratedInteriorInteriorTwoSidedInverseProductProofGate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromHandoff
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    GeneratedInteriorInteriorTwoSidedInverseProductProofGate Cell p A P wp W E K T M S H where
  leftProductAudit := GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit.fromHandoff H
  rightProductAudit := GeneratedInteriorInteriorTwoSidedInverseRightProductAudit.fromHandoff H
  diagonalOffdiagStatus := InteriorTwoSidedInverseValidationDiagonalOffdiagStatus.diagonalOffdiagGoalsProofCarrying
  proofGateStatus := InteriorTwoSidedInverseValidationProofGateStatus.waitingForLeftAndRightProductIdentityProofs
  interiorEliminationFinalGateGateStatus := InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTraceCancellationDerivationRef0B9F.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef8DF3
  noInteriorEliminationDataStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTwoSidedInverseValidation
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTraceCancellationDerivationRefCF55.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef29BA
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTraceCancellationDerivationRef9F3B.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTraceCancellationDerivationRef3720
  diagonalOffdiagStatus_eq := by
    rfl
  proofGateStatus_eq := by
    rfl
  interiorEliminationFinalGateGateStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

end GeneratedInteriorInteriorTwoSidedInverseProductProofGate

def regularGeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit.fromHandoff
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableGeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit.fromHandoff
    (variableInteriorInverseCandidateValidationHandoff β p wp)

def regularGeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit.fromHandoff
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableGeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit.fromHandoff
    (variableInteriorInverseCandidateValidationHandoff β p wp)

def regularGeneratedInteriorInteriorTwoSidedInverseRightProductAudit
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseRightProductAudit.fromHandoff
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableGeneratedInteriorInteriorTwoSidedInverseRightProductAudit
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseRightProductAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseRightProductAudit.fromHandoff
    (variableInteriorInverseCandidateValidationHandoff β p wp)

def regularGeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger.fromHandoff
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableGeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger.fromHandoff
    (variableInteriorInverseCandidateValidationHandoff β p wp)


def regularGeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp)) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger.fromTraceCancellationInvariant C

def variableGeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp)) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger.fromTraceCancellationInvariant C

def regularGeneratedInteriorInteriorTwoSidedInverseProductProofGate
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseProductProofGate
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductProofGate.fromHandoff
    (regularInteriorInverseCandidateValidationHandoff b p wp)

def variableGeneratedInteriorInteriorTwoSidedInverseProductProofGate
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInteriorTwoSidedInverseProductProofGate
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  GeneratedInteriorInteriorTwoSidedInverseProductProofGate.fromHandoff
    (variableInteriorInverseCandidateValidationHandoff β p wp)

structure InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerInteriorTwoSidedInvRef1AF0
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorTwoSidedInverseValidationLedgerStatus
  regularShapeAudit :
    GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableShapeAudit :
    GeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularLeftProductAudit :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableLeftProductAudit :
    GeneratedInteriorInteriorTwoSidedInverseLeftProductAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularRightProductAudit :
    GeneratedInteriorInteriorTwoSidedInverseRightProductAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableRightProductAudit :
    GeneratedInteriorInteriorTwoSidedInverseRightProductAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularProductProofGate :
    GeneratedInteriorInteriorTwoSidedInverseProductProofGate
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableProductProofGate :
    GeneratedInteriorInteriorTwoSidedInverseProductProofGate
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularCandidateFromInteriorTwoSidedInverseHandoff :
    (regularInteriorInverseCandidateValidationHandoff b p regularWeight).candidateMatrix =
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight).matrix
  variableCandidateFromInteriorTwoSidedInverseHandoff :
    (variableInteriorInverseCandidateValidationHandoff β p variableWeight).candidateMatrix =
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight).matrix
  regularLeftProductStatus_eq :
    regularLeftProductAudit.status =
      InteriorTwoSidedInverseValidationLeftProductStatus.leftProductFromInteriorBlockAndHandoffCandidate
  variableLeftProductStatus_eq :
    variableLeftProductAudit.status =
      InteriorTwoSidedInverseValidationLeftProductStatus.leftProductFromInteriorBlockAndHandoffCandidate
  regularRightProductStatus_eq :
    regularRightProductAudit.status =
      InteriorTwoSidedInverseValidationRightProductStatus.rightProductFromHandoffCandidateAndInteriorBlock
  variableRightProductStatus_eq :
    variableRightProductAudit.status =
      InteriorTwoSidedInverseValidationRightProductStatus.rightProductFromHandoffCandidateAndInteriorBlock
  regularProofGate_eq :
    regularProductProofGate.proofGateStatus =
      InteriorTwoSidedInverseValidationProofGateStatus.waitingForLeftAndRightProductIdentityProofs
  variableProofGate_eq :
    variableProductProofGate.proofGateStatus =
      InteriorTwoSidedInverseValidationProofGateStatus.waitingForLeftAndRightProductIdentityProofs
  regularInteriorEliminationfGateEq :
    regularProductProofGate.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  variableInteriorEliminationfGateEq :
    variableProductProofGate.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  status_eq : status = InteriorTwoSidedInverseValidationLedgerStatus.handoffProductCalculusPrepared

def interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerInteriorTwoSidedInvRef1AF0 b β p regularWeight variableWeight where
  status := InteriorTwoSidedInverseValidationLedgerStatus.handoffProductCalculusPrepared
  regularShapeAudit := regularGeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit b p regularWeight
  variableShapeAudit := variableGeneratedInteriorInteriorTwoSidedInverseHandoffShapeAudit β p variableWeight
  regularLeftProductAudit := regularGeneratedInteriorInteriorTwoSidedInverseLeftProductAudit b p regularWeight
  variableLeftProductAudit := variableGeneratedInteriorInteriorTwoSidedInverseLeftProductAudit β p variableWeight
  regularRightProductAudit := regularGeneratedInteriorInteriorTwoSidedInverseRightProductAudit b p regularWeight
  variableRightProductAudit := variableGeneratedInteriorInteriorTwoSidedInverseRightProductAudit β p variableWeight
  regularProductProofGate := regularGeneratedInteriorInteriorTwoSidedInverseProductProofGate b p regularWeight
  variableProductProofGate := variableGeneratedInteriorInteriorTwoSidedInverseProductProofGate β p variableWeight
  regularCandidateFromInteriorTwoSidedInverseHandoff :=
    handoffCandidateEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableCandidateFromInteriorTwoSidedInverseHandoff :=
    handoffCandidateEqInteriorInverseCandidateShapeSeparationShapeSeparationMatrix
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularLeftProductStatus_eq := by
    rfl
  variableLeftProductStatus_eq := by
    rfl
  regularRightProductStatus_eq := by
    rfl
  variableRightProductStatus_eq := by
    rfl
  regularProofGate_eq := by
    rfl
  variableProofGate_eq := by
    rfl
  regularInteriorEliminationfGateEq := by
    rfl
  variableInteriorEliminationfGateEq := by
    rfl
  status_eq := by
    rfl

theorem interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger b β p regularWeight variableWeight).status =
      InteriorTwoSidedInverseValidationLedgerStatus.handoffProductCalculusPrepared := by
  rfl

theorem interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger_regularProofGate
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger
      b β p regularWeight variableWeight).regularProductProofGate.proofGateStatus =
      InteriorTwoSidedInverseValidationProofGateStatus.waitingForLeftAndRightProductIdentityProofs := by
  rfl

theorem interiorTwoSidedInverseValidationValidationGeneratedTwoSidedInvLedgerVariableInteriorEliminationfBlocked
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationReRunGeneratedTwoSidedInvLedger
      b β p regularWeight variableWeight).variableProductProofGate.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv := by
  rfl

structure InteriorTwoSidedInverseValidationGeneratedProductNormalFormLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularProductNormalFormLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableProductNormalFormLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularStatus_eq :
    regularProductNormalFormLedger.status =
      InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  variableStatus_eq :
    variableProductNormalFormLedger.status =
      InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry
  regularInteriorEliminationfStillBlocked :
    (regularGeneratedInteriorInteriorTwoSidedInverseProductProofGate b p regularWeight).interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  variableInteriorEliminationfStillBlocked :
    (variableGeneratedInteriorInteriorTwoSidedInverseProductProofGate β p variableWeight).interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv

def interiorTwoSidedInverseValidationReRunGeneratedProductNormalFormLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidationGeneratedProductNormalFormLedger b β p regularWeight variableWeight where
  regularProductNormalFormLedger :=
    regularGeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger b p regularWeight
  variableProductNormalFormLedger :=
    variableGeneratedInteriorInteriorTwoSidedInverseProductNormalFormLedger β p variableWeight
  regularStatus_eq := by
    rfl
  variableStatus_eq := by
    rfl
  regularInteriorEliminationfStillBlocked := by
    rfl
  variableInteriorEliminationfStillBlocked := by
    rfl

theorem interiorTwoSidedInverseValidationReRunGeneratedProductNormalFormLedger_regularStatus
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationReRunGeneratedProductNormalFormLedger
      b β p regularWeight variableWeight).regularProductNormalFormLedger.status =
      InteriorTwoSidedInverseValidationProductNormalFormStatus.productNormalFormsFromInteriorTwoSidedInverseHandoffAccumulatedEntry := by
  rfl

theorem interiorTwoSidedInverseValidationValidationGeneratedProductNormalFormLedgerVariableInteriorEliminationfBlocked
    (β : Nat → Nat) (p : ConcretePolicyOf) (variableWeight : WeightPolicy) :
    (variableGeneratedInteriorInteriorTwoSidedInverseProductProofGate β p variableWeight).interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv := by
  rfl


structure InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularProductCancellationLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
  variableProductCancellationLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
  regularStatus_eq :
    regularProductCancellationLedger.status =
      InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation
  variableStatus_eq :
    variableProductCancellationLedger.status =
      InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation
  regularR4Gate_eq :
    regularProductCancellationLedger.r4GateStatus =
      InteriorTwoSidedInverseValidationR4GateStatus.r4ReadyAfterR3bCancellationFields
  variableR4Gate_eq :
    variableProductCancellationLedger.r4GateStatus =
      InteriorTwoSidedInverseValidationR4GateStatus.r4ReadyAfterR3bCancellationFields
  regularNoProductIdentityProof_eq :
    regularProductCancellationLedger.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  variableNoProductIdentityProof_eq :
    variableProductCancellationLedger.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  regularInteriorEliminationfStillBlocked :
    regularProductCancellationLedger.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  variableInteriorEliminationfStillBlocked :
    variableProductCancellationLedger.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv

def interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight))
    (variableCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)) :
    InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight where
  regularProductCancellationLedger :=
    regularGeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      b p regularWeight regularCancellation
  variableProductCancellationLedger :=
    variableGeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      β p variableWeight variableCancellation
  regularStatus_eq := by
    rfl
  variableStatus_eq := by
    rfl
  regularR4Gate_eq := by
    rfl
  variableR4Gate_eq := by
    rfl
  regularNoProductIdentityProof_eq := by
    rfl
  variableNoProductIdentityProof_eq := by
    rfl
  regularInteriorEliminationfStillBlocked := by
    rfl
  variableInteriorEliminationfStillBlocked := by
    rfl

theorem interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_regularR4Gate
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight))
    (variableCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)) :
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger
      b β p regularWeight variableWeight regularCancellation variableCancellation).regularProductCancellationLedger.r4GateStatus =
      InteriorTwoSidedInverseValidationR4GateStatus.r4ReadyAfterR3bCancellationFields := by
  rfl

theorem interiorTwoSidedInverseValidationValidationGeneratedProductCancellationLedgerVariableInteriorEliminationfBlocked
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight))
    (variableCancellation : GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)) :
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger
      b β p regularWeight variableWeight regularCancellation variableCancellation).variableProductCancellationLedger.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
