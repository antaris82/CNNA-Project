import CNNA.PillarA.Generator.Boundary.GeneratedSubstrateRoute

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

namespace HistoryExpandedSubstrate

def ledger : GeneratedSubstrateCandidateLedger :=
  GeneratedSubstrateCandidateLedger.historyExpanded

theorem ledger_kind :
    ledger.kind = GeneratedSubstrateCandidateKind.historyExpanded := by
  rfl

theorem ledger_status :
    ledger.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem ledger_blocker :
    ledger.blocker =
      GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate := by
  rfl

theorem ledger_noFreeCarrier :
    ledger.obligations.carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

theorem ledger_noFinCarrier :
    ledger.obligations.indexPolicy =
      GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier := by
  rfl

theorem ledger_portsDoNotCreateCarrierPoints :
    ledger.obligations.boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints := by
  rfl

end HistoryExpandedSubstrate

end BoundarySource

namespace StrengtheningBoundaryStateSubstrate

def boundarySubstrateRouteHistoryExpandedSubstrateLedger :
    BoundarySource.GeneratedSubstrateCandidateLedger :=
  BoundarySource.HistoryExpandedSubstrate.ledger

theorem boundarySubstrateRouteHistoryExpandedSubstrate_status :
    boundarySubstrateRouteHistoryExpandedSubstrateLedger.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteHistoryExpandedSubstrate_noFreeCarrier :
    boundarySubstrateRouteHistoryExpandedSubstrateLedger.obligations.carrierPolicy =
      BoundarySource.GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

end StrengtheningBoundaryStateSubstrate

end CNNA.PillarA.Arithmetic
