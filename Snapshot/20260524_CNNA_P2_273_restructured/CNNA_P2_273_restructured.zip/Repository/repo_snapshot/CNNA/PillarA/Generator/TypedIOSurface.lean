import CNNA.PillarA.Generator.NamespaceSkeleton
import CNNA.PillarA.Generator.OutputReleaseCertificate

set_option autoImplicit false

namespace CNNA.PillarA.Generator

inductive NeutralGeneratorTypedIOPortKind where
  | request
  | output
  | release
  deriving DecidableEq, Repr

inductive NeutralGeneratorTypedIOStatus where
  | typedSurfaceOnly
  | sourceImplemented
  deriving DecidableEq, Repr

inductive NeutralGeneratorTypedIOExposureStatus where
  | generatorInternalSurface
  | compatibilityRouteRetained
  deriving DecidableEq, Repr

structure NeutralGeneratorTypedRequest where
  surface : NeutralGeneratorNamespaceBuildSurface
  lock : SinglePreparationLock
  request : GeneratorRequestProfile
  portKind : NeutralGeneratorTypedIOPortKind
  status : NeutralGeneratorTypedIOStatus
  exposure : NeutralGeneratorTypedIOExposureStatus
  request_global_eq : request.global = lock.state
  portKind_eq : portKind = NeutralGeneratorTypedIOPortKind.request
  status_eq : status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly
  exposure_eq :
    exposure = NeutralGeneratorTypedIOExposureStatus.generatorInternalSurface
  surface_status_eq :
    surface.status = NeutralGeneratorNamespaceStatus.skeletonOnly
  surface_compatibilityRoute_eq :
    surface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface

namespace NeutralGeneratorTypedRequest

def state (typedRequest : NeutralGeneratorTypedRequest) :
    GlobalTheoryApproximationState :=
  typedRequest.lock.state

def requestedTier (typedRequest : NeutralGeneratorTypedRequest) :
    RequestedDataTier :=
  typedRequest.request.requestedDataTier

def levelWindow (typedRequest : NeutralGeneratorTypedRequest) : LevelWindow :=
  typedRequest.state.levelWindow

theorem request_global_eq_state
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.request.global = typedRequest.state :=
  typedRequest.request_global_eq

theorem portKind_is_request
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.portKind = NeutralGeneratorTypedIOPortKind.request :=
  typedRequest.portKind_eq

theorem status_is_typedSurfaceOnly
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  typedRequest.status_eq

theorem exposure_is_generatorInternalSurface
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.exposure =
      NeutralGeneratorTypedIOExposureStatus.generatorInternalSurface :=
  typedRequest.exposure_eq

theorem surface_status_is_skeletonOnly
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.surface.status = NeutralGeneratorNamespaceStatus.skeletonOnly :=
  typedRequest.surface_status_eq

theorem surface_compatibilityRoute_is_retained
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.surface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface :=
  typedRequest.surface_compatibilityRoute_eq

theorem levelWindow_valid
    (typedRequest : NeutralGeneratorTypedRequest) :
    typedRequest.levelWindow.L_min ≤ typedRequest.levelWindow.L_max :=
  typedRequest.state.L_min_le_L_max

end NeutralGeneratorTypedRequest

structure NeutralGeneratorTypedOutput where
  typedRequest : NeutralGeneratorTypedRequest
  output : GeneratorOutputProfile
  portKind : NeutralGeneratorTypedIOPortKind
  status : NeutralGeneratorTypedIOStatus
  exposure : NeutralGeneratorTypedIOExposureStatus
  output_request_eq : output.request = typedRequest.request
  output_lock_eq : output.lock = typedRequest.lock
  output_state_eq : output.state = typedRequest.state
  output_tier_eq : output.requiredTier = typedRequest.requestedTier
  portKind_eq : portKind = NeutralGeneratorTypedIOPortKind.output
  status_eq : status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly
  exposure_eq :
    exposure = NeutralGeneratorTypedIOExposureStatus.generatorInternalSurface

namespace NeutralGeneratorTypedOutput

def state (typedOutput : NeutralGeneratorTypedOutput) :
    GlobalTheoryApproximationState :=
  typedOutput.typedRequest.state

def request (typedOutput : NeutralGeneratorTypedOutput) : GeneratorRequestProfile :=
  typedOutput.typedRequest.request

def lock (typedOutput : NeutralGeneratorTypedOutput) : SinglePreparationLock :=
  typedOutput.typedRequest.lock

def requestedTier (typedOutput : NeutralGeneratorTypedOutput) :
    RequestedDataTier :=
  typedOutput.typedRequest.requestedTier

theorem output_request_matches
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.output.request = typedOutput.request :=
  typedOutput.output_request_eq

theorem output_lock_matches
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.output.lock = typedOutput.lock :=
  typedOutput.output_lock_eq

theorem output_state_matches
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.output.state = typedOutput.state :=
  typedOutput.output_state_eq

theorem output_requiredTier_matches
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.output.requiredTier = typedOutput.requestedTier :=
  typedOutput.output_tier_eq

theorem portKind_is_output
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.portKind = NeutralGeneratorTypedIOPortKind.output :=
  typedOutput.portKind_eq

theorem status_is_typedSurfaceOnly
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  typedOutput.status_eq

theorem exposure_is_generatorInternalSurface
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.exposure =
      NeutralGeneratorTypedIOExposureStatus.generatorInternalSurface :=
  typedOutput.exposure_eq

theorem request_global_eq_state
    (typedOutput : NeutralGeneratorTypedOutput) :
    typedOutput.request.global = typedOutput.state :=
  typedOutput.typedRequest.request_global_eq_state

end NeutralGeneratorTypedOutput

structure NeutralGeneratorTypedRelease where
  typedOutput : NeutralGeneratorTypedOutput
  certificate : GeneratorOutputReleaseCertificate
  portKind : NeutralGeneratorTypedIOPortKind
  status : NeutralGeneratorTypedIOStatus
  exposure : NeutralGeneratorTypedIOExposureStatus
  certificate_source_eq : certificate.source = typedOutput.output.source
  certificate_state_eq : certificate.state = typedOutput.state
  portKind_eq : portKind = NeutralGeneratorTypedIOPortKind.release
  status_eq : status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly
  exposure_eq :
    exposure = NeutralGeneratorTypedIOExposureStatus.compatibilityRouteRetained
  certificate_scope_eq :
    certificate.releasedScope =
      GeneratorOutputReleaseScope.generatorOutputLayerOnly

namespace NeutralGeneratorTypedRelease

def state (typedRelease : NeutralGeneratorTypedRelease) :
    GlobalTheoryApproximationState :=
  typedRelease.typedOutput.state

def request (typedRelease : NeutralGeneratorTypedRelease) : GeneratorRequestProfile :=
  typedRelease.typedOutput.request

theorem certificate_source_matches
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.certificate.source = typedRelease.typedOutput.output.source :=
  typedRelease.certificate_source_eq

theorem certificate_state_matches
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.certificate.state = typedRelease.state :=
  typedRelease.certificate_state_eq

theorem portKind_is_release
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.portKind = NeutralGeneratorTypedIOPortKind.release :=
  typedRelease.portKind_eq

theorem status_is_typedSurfaceOnly
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  typedRelease.status_eq

theorem exposure_is_compatibilityRouteRetained
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.exposure =
      NeutralGeneratorTypedIOExposureStatus.compatibilityRouteRetained :=
  typedRelease.exposure_eq

theorem certificate_scope_is_generatorOutputLayerOnly
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.certificate.releasedScope =
      GeneratorOutputReleaseScope.generatorOutputLayerOnly :=
  typedRelease.certificate_scope_eq

theorem certificate_transition_status_is_neutral_import_target
    (typedRelease : NeutralGeneratorTypedRelease) :
    typedRelease.certificate.transition.status =
      GeneratorOutputImportTransitionStatus.neutralGeneratorImportsCarryTarget :=
  typedRelease.certificate.transition_status_is_neutral_import_target

end NeutralGeneratorTypedRelease

structure NeutralGeneratorTypedIOSurface where
  namespaceSurface : NeutralGeneratorNamespaceBuildSurface
  typedRequest : NeutralGeneratorTypedRequest
  typedOutput : NeutralGeneratorTypedOutput
  typedRelease : NeutralGeneratorTypedRelease
  status : NeutralGeneratorTypedIOStatus
  namespaceSurface_eq : typedRequest.surface = namespaceSurface
  output_request_eq : typedOutput.typedRequest = typedRequest
  release_output_eq : typedRelease.typedOutput = typedOutput
  status_eq : status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly
  request_global_eq : typedRequest.request.global = typedRequest.state
  output_state_eq : typedOutput.output.state = typedRequest.state
  release_state_eq : typedRelease.certificate.state = typedRequest.state

namespace NeutralGeneratorTypedIOSurface

def state (typedSurface : NeutralGeneratorTypedIOSurface) :
    GlobalTheoryApproximationState :=
  typedSurface.typedRequest.state

def request (typedSurface : NeutralGeneratorTypedIOSurface) :
    GeneratorRequestProfile :=
  typedSurface.typedRequest.request

def output (typedSurface : NeutralGeneratorTypedIOSurface) :
    GeneratorOutputProfile :=
  typedSurface.typedOutput.output

def certificate (typedSurface : NeutralGeneratorTypedIOSurface) :
    GeneratorOutputReleaseCertificate :=
  typedSurface.typedRelease.certificate

theorem typedRequest_surface_matches
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.typedRequest.surface = typedSurface.namespaceSurface :=
  typedSurface.namespaceSurface_eq

theorem typedOutput_request_matches
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.typedOutput.typedRequest = typedSurface.typedRequest :=
  typedSurface.output_request_eq

theorem typedRelease_output_matches
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.typedRelease.typedOutput = typedSurface.typedOutput :=
  typedSurface.release_output_eq

theorem status_is_typedSurfaceOnly
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  typedSurface.status_eq

theorem request_global_matches_state
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.request.global = typedSurface.state :=
  typedSurface.request_global_eq

theorem output_state_matches_state
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.output.state = typedSurface.state :=
  typedSurface.output_state_eq

theorem release_state_matches_state
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.certificate.state = typedSurface.state :=
  typedSurface.release_state_eq

theorem namespaceSurface_status_is_skeletonOnly
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.namespaceSurface.status =
      NeutralGeneratorNamespaceStatus.skeletonOnly :=
  typedSurface.namespaceSurface_eq ▸
    typedSurface.typedRequest.surface_status_is_skeletonOnly

theorem namespaceSurface_compatibilityRoute_is_retained
    (typedSurface : NeutralGeneratorTypedIOSurface) :
    typedSurface.namespaceSurface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface :=
  typedSurface.namespaceSurface_eq ▸
    typedSurface.typedRequest.surface_compatibilityRoute_is_retained

end NeutralGeneratorTypedIOSurface

end CNNA.PillarA.Generator
