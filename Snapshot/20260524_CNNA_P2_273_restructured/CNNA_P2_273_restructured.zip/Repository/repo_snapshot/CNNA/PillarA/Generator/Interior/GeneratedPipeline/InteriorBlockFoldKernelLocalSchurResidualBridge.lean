import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreeFormulaFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.OperationalDegreeReciprocalSource

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource

universe u

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus where
  | blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeKernelSourceStatus where
  | kernelSourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeLocalSchurResidualSourceStatus where
  | localSchurResidualFromInteriorLocalStepCancellationInvariantViaOperationalDegreeReciprocalSourceScaleWitness
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewScaleStatus where
  | noNewScaleInBlockFoldKernelLocalSchurResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewReciprocalStatus where
  | noNewReciprocalInBlockFoldKernelLocalSchurResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus where
  | noProductIdentityProofInBlockFoldKernelLocalSchurResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus where
  | noTwoSidedInvInBlockFoldKernelLocalSchurResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInBlockFoldKernelLocalSchurResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorBlockFoldKernelResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorBlockFoldKernelResidualBridge
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation
  deriving DecidableEq, Repr

def generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorLeftBlockFoldKernel W T i j pivot +
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j

def generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorRightBlockFoldKernel W T i j pivot +
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j

structure GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  blockFoldNormalForm : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T
  operationalDegreeReciprocalSource :
    GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T
  tracePivotScaleWitness : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T
  perPivotRegularity : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T
  traceLocalStepInvariant : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T
  bridgeStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus
  kernelSourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeKernelSourceStatus
  localSchurResidualSourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeLocalSchurResidualSourceStatus
  noNewScaleStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewScaleStatus
  noNewReciprocalStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewReciprocalStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus
  blockFoldNormalForm_is_fromTrace :
    blockFoldNormalForm = GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm.fromEliminationTrace T
  tracePivotScaleWitnessEqFromOperationalDegreeReciprocalSource :
    tracePivotScaleWitness =
      tracePivotScaleWitnessFromGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
        operationalDegreeReciprocalSource
  perPivotRegularity_eq_from_tracePivotScaleWitness :
    perPivotRegularity =
      GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity.fromTracePivotScaleWitness
        tracePivotScaleWitness
  traceLocalStepInvariant_eq_from_perPivotRegularity :
    traceLocalStepInvariant = perPivotRegularity.traceLocalStepInvariant
  leftKernelEqInteriorBlockFoldNormalFormComponents :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernel W T i j pivot =
        generatedInteriorBlock W i pivot *
          (generatedInteriorTracePivotContribution T pivot j +
            generatedInteriorTraceLocalStepContribution T pivot j +
              generatedInteriorTraceResidualContribution T pivot j +
                generatedInteriorTraceFoldUpdateOrderContribution T pivot j)
  rightKernelEqInteriorBlockFoldNormalFormComponents :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernel W T i j pivot =
        (generatedInteriorTracePivotContribution T i pivot +
            generatedInteriorTraceLocalStepContribution T i pivot +
              generatedInteriorTraceResidualContribution T i pivot +
                generatedInteriorTraceFoldUpdateOrderContribution T i pivot) *
          generatedInteriorBlock W pivot j
  leftLocalSchurResidualEqInteriorLocalStepCancellationInvariant :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j =
        generatedInteriorLocalSchurUpdateEquationResidual
          (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j
  rightLocalSchurResidualEqInteriorLocalStepCancellationInvariant :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j =
        generatedInteriorLocalSchurUpdateEquationResidual
          (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j
  leftLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0
  rightLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLocalSchurUpdateEquationResidual
        (T.localStepOf pivot) (traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0
  leftKernelLocalSchurResidualBridge_eq_kernel :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T traceLocalStepInvariant pivot i j =
        generatedInteriorLeftBlockFoldKernel W T i j pivot
  rightKernelLocalSchurResidualBridge_eq_kernel :
    ∀ pivot i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
        W T traceLocalStepInvariant pivot i j =
        generatedInteriorRightBlockFoldKernel W T i j pivot
  bridgeStatus_eq :
    bridgeStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  kernelSourceStatus_eq :
    kernelSourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeKernelSourceStatus.kernelSourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
  localSchurResidualSourceStatus_eq :
    localSchurResidualSourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeLocalSchurResidualSourceStatus.localSchurResidualFromInteriorLocalStepCancellationInvariantViaOperationalDegreeReciprocalSourceScaleWitness
  noNewScaleStatus_eq :
    noNewScaleStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewScaleStatus.noNewScaleInBlockFoldKernelLocalSchurResidualBridge
  noNewReciprocalStatus_eq :
    noNewReciprocalStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewReciprocalStatus.noNewReciprocalInBlockFoldKernelLocalSchurResidualBridge
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus.noProductIdentityProofInBlockFoldKernelLocalSchurResidualBridge
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus.noTwoSidedInvInBlockFoldKernelLocalSchurResidualBridge
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoInteriorEliminationDataStatus.noInteriorEliminationDataInBlockFoldKernelLocalSchurResidualBridge
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorBlockFoldKernelResidualBridge
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlockFoldKernelResidualBridge
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation

namespace GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromOperationalDegreeReciprocalSource
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T :=
  let N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T :=
    GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm.fromEliminationTrace T
  let Q : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T :=
    tracePivotScaleWitnessFromGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource S
  let R : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T :=
    GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity.fromTracePivotScaleWitness Q
  let J : GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T :=
    R.traceLocalStepInvariant
  { blockFoldNormalForm := N
    operationalDegreeReciprocalSource := S
    tracePivotScaleWitness := Q
    perPivotRegularity := R
    traceLocalStepInvariant := J
    bridgeStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
    kernelSourceStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeKernelSourceStatus.kernelSourceFromInteriorBlockFoldNormalFormBlockFoldNormalForm
    localSchurResidualSourceStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeLocalSchurResidualSourceStatus.localSchurResidualFromInteriorLocalStepCancellationInvariantViaOperationalDegreeReciprocalSourceScaleWitness
    noNewScaleStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewScaleStatus.noNewScaleInBlockFoldKernelLocalSchurResidualBridge
    noNewReciprocalStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoNewReciprocalStatus.noNewReciprocalInBlockFoldKernelLocalSchurResidualBridge
    noProductIdentityProofStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus.noProductIdentityProofInBlockFoldKernelLocalSchurResidualBridge
    noTwoSidedInvStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus.noTwoSidedInvInBlockFoldKernelLocalSchurResidualBridge
    noInteriorEliminationDataStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoInteriorEliminationDataStatus.noInteriorEliminationDataInBlockFoldKernelLocalSchurResidualBridge
    noDtnDataStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorBlockFoldKernelResidualBridge
    noArithmeticTargetStatus :=
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorBlockFoldKernelResidualBridge
    nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation
    blockFoldNormalForm_is_fromTrace := by
      rfl
    tracePivotScaleWitnessEqFromOperationalDegreeReciprocalSource := by
      rfl
    perPivotRegularity_eq_from_tracePivotScaleWitness := by
      rfl
    traceLocalStepInvariant_eq_from_perPivotRegularity := by
      rfl
    leftKernelEqInteriorBlockFoldNormalFormComponents := by
      intro pivot i j
      exact N.leftKernel_eq_components i j pivot
    rightKernelEqInteriorBlockFoldNormalFormComponents := by
      intro pivot i j
      exact N.rightKernel_eq_components i j pivot
    leftLocalSchurResidualEqInteriorLocalStepCancellationInvariant := by
      intro pivot i j
      rfl
    rightLocalSchurResidualEqInteriorLocalStepCancellationInvariant := by
      intro pivot i j
      rfl
    leftLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant := by
      intro pivot i j
      exact (J.perPivotInvariant pivot).leftLocalStepCancellation i j
    rightLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant := by
      intro pivot i j
      exact (J.perPivotInvariant pivot).rightLocalStepCancellation i j
    leftKernelLocalSchurResidualBridge_eq_kernel := by
      intro pivot i j
      calc
        generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge W T J pivot i j =
            generatedInteriorLeftBlockFoldKernel W T i j pivot +
              generatedInteriorLocalSchurUpdateEquationResidual
                (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j := by
          rfl
        _ = generatedInteriorLeftBlockFoldKernel W T i j pivot + 0 := by
          exact congrArg
            (fun x => generatedInteriorLeftBlockFoldKernel W T i j pivot + x)
            ((J.perPivotInvariant pivot).leftLocalStepCancellation i j)
        _ = generatedInteriorLeftBlockFoldKernel W T i j pivot := by
          exact add_zero (generatedInteriorLeftBlockFoldKernel W T i j pivot)
    rightKernelLocalSchurResidualBridge_eq_kernel := by
      intro pivot i j
      calc
        generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge W T J pivot i j =
            generatedInteriorRightBlockFoldKernel W T i j pivot +
              generatedInteriorLocalSchurUpdateEquationResidual
                (T.localStepOf pivot) (J.perPivotInvariant pivot).pivotScale i j := by
          rfl
        _ = generatedInteriorRightBlockFoldKernel W T i j pivot + 0 := by
          exact congrArg
            (fun x => generatedInteriorRightBlockFoldKernel W T i j pivot + x)
            ((J.perPivotInvariant pivot).rightLocalStepCancellation i j)
        _ = generatedInteriorRightBlockFoldKernel W T i j pivot := by
          exact add_zero (generatedInteriorRightBlockFoldKernel W T i j pivot)
    bridgeStatus_eq := by
      rfl
    kernelSourceStatus_eq := by
      rfl
    localSchurResidualSourceStatus_eq := by
      rfl
    noNewScaleStatus_eq := by
      rfl
    noNewReciprocalStatus_eq := by
      rfl
    noProductIdentityProofStatus_eq := by
      rfl
    noTwoSidedInvStatus_eq := by
      rfl
    noInteriorEliminationDataStatus_eq := by
      rfl
    noDtnDataStatus_eq := by
      rfl
    noArithmeticTargetStatus_eq := by
      rfl
    nextConsumerStatus_eq := by
      rfl }

theorem leftBridge_eq_kernel
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T B.traceLocalStepInvariant pivot i j =
      generatedInteriorLeftBlockFoldKernel W T i j pivot :=
  B.leftKernelLocalSchurResidualBridge_eq_kernel pivot i j

theorem rightBridge_eq_kernel
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
      W T B.traceLocalStepInvariant pivot i j =
      generatedInteriorRightBlockFoldKernel W T i j pivot :=
  B.rightKernelLocalSchurResidualBridge_eq_kernel pivot i j

theorem leftLocalSchurResidual_eq_zero
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (B.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0 :=
  B.leftLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant pivot i j

theorem rightLocalSchurResidual_eq_zero
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    generatedInteriorLocalSchurUpdateEquationResidual
      (T.localStepOf pivot) (B.traceLocalStepInvariant.perPivotInvariant pivot).pivotScale i j = 0 :=
  B.rightLocalSchurResidualEqZeroFromInteriorLocalStepCancellationInvariant pivot i j

theorem nextClosureIsInteriorBlockFoldbFull
    (B : GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge Cell p A P wp W E K T) :
    B.nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation :=
  B.nextConsumerStatus_eq

end GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge

abbrev RegularGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p wp) :
    RegularGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge b p wp :=
  GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge.fromOperationalDegreeReciprocalSource S

def variableBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p wp) :
    VariableGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge β p wp :=
  GeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge.fromOperationalDegreeReciprocalSource S

structure InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelLocalSchurResidualBridgeLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularBridge : RegularGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge b p regularWeight
  variableBridge : VariableGeneratedInteriorBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge β p variableWeight
  bridgeStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus
  regularBridgeStatus_eq :
    regularBridge.bridgeStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  variableBridgeStatus_eq :
    variableBridge.bridgeStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  regularNoProductIdentityProofStatus_eq :
    regularBridge.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus.noProductIdentityProofInBlockFoldKernelLocalSchurResidualBridge
  variableNoProductIdentityProofStatus_eq :
    variableBridge.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoProductIdentityProofStatus.noProductIdentityProofInBlockFoldKernelLocalSchurResidualBridge
  regularNoTwoSidedInvStatus_eq :
    regularBridge.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus.noTwoSidedInvInBlockFoldKernelLocalSchurResidualBridge
  variableNoTwoSidedInvStatus_eq :
    variableBridge.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNoTwoSidedInvStatus.noTwoSidedInvInBlockFoldKernelLocalSchurResidualBridge
  bridgeStatus_eq :
    bridgeStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation

namespace InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelLocalSchurResidualBridgeLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p regularWeight)
    (variableSource : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelLocalSchurResidualBridgeLedger
      b β p regularWeight variableWeight where
  regularBridge := regularBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge regularSource
  variableBridge := variableBlockFoldKernelLocalSchurResidualBridgeInteriorBlockFoldKernelResidualBridge variableSource
  bridgeStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBridgeStatus.blockFoldKernelLocalSchurResidualBridgeFromInteriorBlockFoldNormalFormAndInteriorLocalStepCancellationInvariant
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationFullLocalStepCancellation
  regularBridgeStatus_eq := by
    rfl
  variableBridgeStatus_eq := by
    rfl
  regularNoProductIdentityProofStatus_eq := by
    rfl
  variableNoProductIdentityProofStatus_eq := by
    rfl
  regularNoTwoSidedInvStatus_eq := by
    rfl
  variableNoTwoSidedInvStatus_eq := by
    rfl
  bridgeStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelLocalSchurResidualBridgeLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
