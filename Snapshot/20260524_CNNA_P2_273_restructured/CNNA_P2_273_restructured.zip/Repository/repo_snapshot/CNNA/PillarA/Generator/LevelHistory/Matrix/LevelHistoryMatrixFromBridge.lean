import CNNA.PillarA.Generator.OutputProfile
import CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistorySchurIndexBridgeConsistency

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev LevelHistoryMatrixOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.levelHistoryMatrix

def levelHistoryMatrixOutputKind : DerivedOutputKind :=
  DerivedOutputKind.levelHistoryMatrix

theorem levelHistoryMatrix_kind_eq (profile : LevelHistoryMatrixOutputProfile) :
    profile.profile.kind = levelHistoryMatrixOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryMatrixFromBridge

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryToSchurIndex
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistorySchurIndexBridgeConsistency
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource
open CNNA.PillarA.Arithmetic.SourceAndApproximation.LevelHistoryBoundaryPortSource

universe u v

inductive LevelHistoryMatrixFromBridgeBridgeSourceStatus where
  | consumedLevelHistorySchurIndexBridge
  deriving DecidableEq, Repr

namespace LevelHistoryMatrixFromBridgeBridgeSourceStatus

def consumedLevelHistorySchurIndexBridgeConsistencyBridge :
    LevelHistoryMatrixFromBridgeBridgeSourceStatus :=
  LevelHistoryMatrixFromBridgeBridgeSourceStatus.consumedLevelHistorySchurIndexBridge

def consumedLevelHistorySchurIndexBridgeBridgeRecheckBridge :
    LevelHistoryMatrixFromBridgeBridgeSourceStatus :=
  consumedLevelHistorySchurIndexBridgeConsistencyBridge

end LevelHistoryMatrixFromBridgeBridgeSourceStatus

inductive LevelHistoryMatrixFromBridgeMatrixProvenanceStatus where
  | pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus where
  | noNewBoundaryPortSourceInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus where
  | noFreeFintypeEnumerationInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoFreeTableStatus where
  | noFreeTableInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus where
  | noFreeLevelHistoryMatrixPackageMatrixInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoChoiceStatus where
  | noChoiceInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoMatrixInvStatus where
  | noMatrixInvIntroducedInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus where
  | noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus where
  | noHigherLevelScanInLevelHistoryMatrixFromBridge
  deriving DecidableEq, Repr

inductive LevelHistoryMatrixFromBridgeNextConsumerStatus where
  | matrixSurfaceOnlyBeforeArithmeticTargets
  deriving DecidableEq, Repr

theorem matrix_entry_of_eq
    {ι κ : Type u} {R : Type v} {A B : Matrix ι κ R}
    (h : A = B) (i : ι) (j : κ) :
    A i j = B i j :=
  congrArg (fun M => M i j) h

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

abbrev GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :=
  GeneratedLevelHistoryIndexLevelHistoryToSchurIndex B.sourceLevelHistorySchurIndexWitness.level

def generatedSchurEntryLevelHistoryMatrixFromBridge
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) : ℝ :=
  B.sourceLevelHistorySchurIndexWitness.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j)

def generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    Matrix (GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) (GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) ℝ :=
  fun i j => generatedSchurEntryLevelHistoryMatrixFromBridge B i j

theorem generatedSchurEntryLevelHistoryMatrixFromBridgeEqBoundaryOperator
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedSchurEntryLevelHistoryMatrixFromBridge B i j =
      B.sourceLevelHistorySchurIndexWitness.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  rfl

theorem generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeApply
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge B i j = generatedSchurEntryLevelHistoryMatrixFromBridge B i j := by
  rfl

theorem generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeEntryEqBoundaryOperator
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge B i j =
      B.sourceLevelHistorySchurIndexWitness.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  rfl

theorem generatedSchurEntryLevelHistoryMatrixFromBridgeEqLevelHistoryToSchurIndex
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedSchurEntryLevelHistoryMatrixFromBridge B i j =
      B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  change
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) =
      B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j)
  exact matrix_entry_of_eq B.boundaryOperatorFromLevelHistoryToSchurIndex (B.toBoundaryIndex i) (B.toBoundaryIndex j)

theorem generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeEntryEqLevelHistoryToSchurIndex
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge B i j =
      B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  change generatedSchurEntryLevelHistoryMatrixFromBridge B i j =
    B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j)
  exact generatedSchurEntryLevelHistoryMatrixFromBridgeEqLevelHistoryToSchurIndex B i j

theorem generatedSchurEntryLevelHistoryMatrixFromBridgeEqSchur
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedSchurEntryLevelHistoryMatrixFromBridge B i j =
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
        (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  change
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator (B.toBoundaryIndex i) (B.toBoundaryIndex j) =
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
        (B.toBoundaryIndex i) (B.toBoundaryIndex j)
  exact matrix_entry_of_eq B.boundaryOperator_from_schur (B.toBoundaryIndex i) (B.toBoundaryIndex j)

theorem generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeEntryEqSchur
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge B) :
    generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge B i j =
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
        (B.toBoundaryIndex i) (B.toBoundaryIndex j) := by
  change generatedSchurEntryLevelHistoryMatrixFromBridge B i j =
    (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
      generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
        B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
        generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
      (B.toBoundaryIndex i) (B.toBoundaryIndex j)
  exact generatedSchurEntryLevelHistoryMatrixFromBridgeEqSchur B i j

structure GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  sourceBridge : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G
  matrix : Matrix (GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge sourceBridge)
    (GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge sourceBridge) ℝ
  matrix_eq_generatedLevelHistoryMatrix : matrix = generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge sourceBridge
  entry_eq_boundaryOperator : ∀ i j,
    matrix i j =
      sourceBridge.sourceLevelHistorySchurIndexWitness.boundaryOperator
        (sourceBridge.toBoundaryIndex i) (sourceBridge.toBoundaryIndex j)
  entryEqLevelHistoryToSchurIndex : ∀ i j,
    matrix i j =
      sourceBridge.sourceLevelHistorySchurIndexWitness.source.boundaryOperator
        (sourceBridge.toBoundaryIndex i) (sourceBridge.toBoundaryIndex j)
  entry_eq_schur : ∀ i j,
    matrix i j =
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceBridge.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
        (sourceBridge.toBoundaryIndex i) (sourceBridge.toBoundaryIndex j)
  bridgeSourceStatus : LevelHistoryMatrixFromBridgeBridgeSourceStatus
  bridgeSourceStatus_eq :
    bridgeSourceStatus = LevelHistoryMatrixFromBridgeBridgeSourceStatus.consumedLevelHistorySchurIndexBridge
  matrixProvenanceStatus : LevelHistoryMatrixFromBridgeMatrixProvenanceStatus
  matrixProvenanceStatus_eq :
    matrixProvenanceStatus = LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  noNewBoundaryPortSourceStatus : LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus
  noNewBoundaryPortSourceStatus_eq :
    noNewBoundaryPortSourceStatus = LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus.noNewBoundaryPortSourceInLevelHistoryMatrixFromBridge
  noFreeFintypeEnumerationStatus : LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus = LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistoryMatrixFromBridge
  noFreeTableStatus : LevelHistoryMatrixFromBridgeNoFreeTableStatus
  noFreeTableStatus_eq : noFreeTableStatus = LevelHistoryMatrixFromBridgeNoFreeTableStatus.noFreeTableInLevelHistoryMatrixFromBridge
  noFreeLevelHistoryMatrixPackageStatus : LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus
  noFreeLevelHistoryMatrixPackageStatus_eq :
    noFreeLevelHistoryMatrixPackageStatus =
      LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus.noFreeLevelHistoryMatrixPackageMatrixInLevelHistoryMatrixFromBridge
  noChoiceStatus : LevelHistoryMatrixFromBridgeNoChoiceStatus
  noChoiceStatus_eq : noChoiceStatus = LevelHistoryMatrixFromBridgeNoChoiceStatus.noChoiceInLevelHistoryMatrixFromBridge
  noMatrixInvStatus : LevelHistoryMatrixFromBridgeNoMatrixInvStatus
  noMatrixInvStatus_eq : noMatrixInvStatus = LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge
  noCharpolyDiscriminantStatus : LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge
  noHigherLevelScanStatus : LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus
  noHigherLevelScanStatus_eq :
    noHigherLevelScanStatus = LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus.noHigherLevelScanInLevelHistoryMatrixFromBridge
  nextConsumerStatus : LevelHistoryMatrixFromBridgeNextConsumerStatus
  nextConsumerStatus_eq :
    nextConsumerStatus = LevelHistoryMatrixFromBridgeNextConsumerStatus.matrixSurfaceOnlyBeforeArithmeticTargets

namespace GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromBridge
    (B : GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G where
  sourceBridge := B
  matrix := generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge B
  matrix_eq_generatedLevelHistoryMatrix := by
    rfl
  entry_eq_boundaryOperator := by
    intro i j
    rfl
  entryEqLevelHistoryToSchurIndex := by
    intro i j
    exact generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeEntryEqLevelHistoryToSchurIndex B i j
  entry_eq_schur := by
    intro i j
    exact generatedLevelHistoryMatrixLevelHistoryMatrixFromBridgeEntryEqSchur B i j
  bridgeSourceStatus := LevelHistoryMatrixFromBridgeBridgeSourceStatus.consumedLevelHistorySchurIndexBridge
  bridgeSourceStatus_eq := by
    rfl
  matrixProvenanceStatus := LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  matrixProvenanceStatus_eq := by
    rfl
  noNewBoundaryPortSourceStatus := LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus.noNewBoundaryPortSourceInLevelHistoryMatrixFromBridge
  noNewBoundaryPortSourceStatus_eq := by
    rfl
  noFreeFintypeEnumerationStatus := LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistoryMatrixFromBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noFreeTableStatus := LevelHistoryMatrixFromBridgeNoFreeTableStatus.noFreeTableInLevelHistoryMatrixFromBridge
  noFreeTableStatus_eq := by
    rfl
  noFreeLevelHistoryMatrixPackageStatus :=
    LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus.noFreeLevelHistoryMatrixPackageMatrixInLevelHistoryMatrixFromBridge
  noFreeLevelHistoryMatrixPackageStatus_eq := by
    rfl
  noChoiceStatus := LevelHistoryMatrixFromBridgeNoChoiceStatus.noChoiceInLevelHistoryMatrixFromBridge
  noChoiceStatus_eq := by
    rfl
  noMatrixInvStatus := LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge
  noMatrixInvStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl
  noHigherLevelScanStatus := LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus.noHigherLevelScanInLevelHistoryMatrixFromBridge
  noHigherLevelScanStatus_eq := by
    rfl
  nextConsumerStatus := LevelHistoryMatrixFromBridgeNextConsumerStatus.matrixSurfaceOnlyBeforeArithmeticTargets
  nextConsumerStatus_eq := by
    rfl

theorem matrix_from_bridge
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G) :
    X.matrix = generatedLevelHistoryMatrixLevelHistoryMatrixFromBridge X.sourceBridge :=
  X.matrix_eq_generatedLevelHistoryMatrix

theorem matrix_entry_eq_boundaryOperator
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge X.sourceBridge) :
    X.matrix i j =
      X.sourceBridge.sourceLevelHistorySchurIndexWitness.boundaryOperator
        (X.sourceBridge.toBoundaryIndex i) (X.sourceBridge.toBoundaryIndex j) :=
  X.entry_eq_boundaryOperator i j

theorem matrixEntryEqLevelHistoryToSchurIndex
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge X.sourceBridge) :
    X.matrix i j =
      X.sourceBridge.sourceLevelHistorySchurIndexWitness.source.boundaryOperator
        (X.sourceBridge.toBoundaryIndex i) (X.sourceBridge.toBoundaryIndex j) :=
  X.entryEqLevelHistoryToSchurIndex i j

theorem matrix_entry_eq_schur
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G)
    (i j : GeneratedLevelHistoryMatrixIndexLevelHistoryMatrixFromBridge X.sourceBridge) :
    X.matrix i j =
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          X.sourceBridge.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W)
        (X.sourceBridge.toBoundaryIndex i) (X.sourceBridge.toBoundaryIndex j) :=
  X.entry_eq_schur i j

theorem noMatrixInvForLevelHistoryMatrixFromBridge
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G) :
    X.noMatrixInvStatus = LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge :=
  X.noMatrixInvStatus_eq

theorem noCharpolyDiscriminantForLevelHistoryMatrixFromBridge
    (X : GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge Cell p A P wp W E K T M S H G) :
    X.noCharpolyDiscriminantStatus =
      LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge :=
  X.noCharpolyDiscriminantStatus_eq

end GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge

def regularGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge.fromBridge L.regularBridge

def variableGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge.fromBridge L.variableBridge

structure LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceLevelHistorySchurIndexBridgeConsistencyLedger : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight
  regularMatrix :
    GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceLevelHistorySchurIndexBridgeConsistencyLedger.sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableMatrix :
    GeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceLevelHistorySchurIndexBridgeConsistencyLedger.sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularMatrix_eq_from_bridge :
    regularMatrix = regularGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge sourceLevelHistorySchurIndexBridgeConsistencyLedger
  variableMatrix_eq_from_bridge :
    variableMatrix = variableGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge sourceLevelHistorySchurIndexBridgeConsistencyLedger
  regularBridgeOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  regularBridgeOutcome_eq : regularBridgeOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  variableBridgeOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  variableBridgeOutcome_eq : variableBridgeOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  regularMatrixProvenanceStatus : LevelHistoryMatrixFromBridgeMatrixProvenanceStatus
  regularMatrixProvenanceStatus_eq :
    regularMatrixProvenanceStatus =
      LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  variableMatrixProvenanceStatus : LevelHistoryMatrixFromBridgeMatrixProvenanceStatus
  variableMatrixProvenanceStatus_eq :
    variableMatrixProvenanceStatus =
      LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  noNewBoundaryPortSourceStatus : LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus
  noNewBoundaryPortSourceStatus_eq :
    noNewBoundaryPortSourceStatus = LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus.noNewBoundaryPortSourceInLevelHistoryMatrixFromBridge
  noFreeFintypeEnumerationStatus : LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus = LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistoryMatrixFromBridge
  noFreeTableStatus : LevelHistoryMatrixFromBridgeNoFreeTableStatus
  noFreeTableStatus_eq : noFreeTableStatus = LevelHistoryMatrixFromBridgeNoFreeTableStatus.noFreeTableInLevelHistoryMatrixFromBridge
  noFreeLevelHistoryMatrixPackageStatus : LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus
  noFreeLevelHistoryMatrixPackageStatus_eq :
    noFreeLevelHistoryMatrixPackageStatus =
      LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus.noFreeLevelHistoryMatrixPackageMatrixInLevelHistoryMatrixFromBridge
  noChoiceStatus : LevelHistoryMatrixFromBridgeNoChoiceStatus
  noChoiceStatus_eq : noChoiceStatus = LevelHistoryMatrixFromBridgeNoChoiceStatus.noChoiceInLevelHistoryMatrixFromBridge
  noMatrixInvStatus : LevelHistoryMatrixFromBridgeNoMatrixInvStatus
  noMatrixInvStatus_eq : noMatrixInvStatus = LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge
  noCharpolyDiscriminantStatus : LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge
  noHigherLevelScanStatus : LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus
  noHigherLevelScanStatus_eq :
    noHigherLevelScanStatus = LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus.noHigherLevelScanInLevelHistoryMatrixFromBridge
  nextConsumerStatus : LevelHistoryMatrixFromBridgeNextConsumerStatus
  nextConsumerStatus_eq :
    nextConsumerStatus = LevelHistoryMatrixFromBridgeNextConsumerStatus.matrixSurfaceOnlyBeforeArithmeticTargets

namespace LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger

def sourceLevelHistorySchurIndexBridgeBridgeRecheckLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight :=
  L.sourceLevelHistorySchurIndexBridgeConsistencyLedger

end LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger

def levelHistoryMatrixGeneratedLevelHistoryMatrixLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight where
  sourceLevelHistorySchurIndexBridgeConsistencyLedger := L
  regularMatrix := regularGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge L
  variableMatrix := variableGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge L
  regularMatrix_eq_from_bridge := by
    rfl
  variableMatrix_eq_from_bridge := by
    rfl
  regularBridgeOutcome := L.regularOutcome
  regularBridgeOutcome_eq := by
    exact L.regularOutcome_eq
  variableBridgeOutcome := L.variableOutcome
  variableBridgeOutcome_eq := by
    exact L.variableOutcome_eq
  regularMatrixProvenanceStatus := LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  regularMatrixProvenanceStatus_eq := by
    rfl
  variableMatrixProvenanceStatus := LevelHistoryMatrixFromBridgeMatrixProvenanceStatus.pullbackOfLevelHistoryToSchurIndexGeneratedArithmeticSourceSchurBoundaryOperator
  variableMatrixProvenanceStatus_eq := by
    rfl
  noNewBoundaryPortSourceStatus := LevelHistoryMatrixFromBridgeNoNewBoundaryPortSourceStatus.noNewBoundaryPortSourceInLevelHistoryMatrixFromBridge
  noNewBoundaryPortSourceStatus_eq := by
    rfl
  noFreeFintypeEnumerationStatus := LevelHistoryMatrixFromBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistoryMatrixFromBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noFreeTableStatus := LevelHistoryMatrixFromBridgeNoFreeTableStatus.noFreeTableInLevelHistoryMatrixFromBridge
  noFreeTableStatus_eq := by
    rfl
  noFreeLevelHistoryMatrixPackageStatus :=
    LevelHistoryMatrixFromBridgeNoFreeLevelHistoryMatrixPackageStatus.noFreeLevelHistoryMatrixPackageMatrixInLevelHistoryMatrixFromBridge
  noFreeLevelHistoryMatrixPackageStatus_eq := by
    rfl
  noChoiceStatus := LevelHistoryMatrixFromBridgeNoChoiceStatus.noChoiceInLevelHistoryMatrixFromBridge
  noChoiceStatus_eq := by
    rfl
  noMatrixInvStatus := LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge
  noMatrixInvStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl
  noHigherLevelScanStatus := LevelHistoryMatrixFromBridgeNoHigherLevelScanStatus.noHigherLevelScanInLevelHistoryMatrixFromBridge
  noHigherLevelScanStatus_eq := by
    rfl
  nextConsumerStatus := LevelHistoryMatrixFromBridgeNextConsumerStatus.matrixSurfaceOnlyBeforeArithmeticTargets
  nextConsumerStatus_eq := by
    rfl

def levelHistoryMatrixGeneratedLevelHistoryMatrixLedgerFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight :=
  levelHistoryMatrixGeneratedLevelHistoryMatrixLedger
    (levelHistorySchurIndexBridgeConsistencyLedgerFromGeneratedArithmeticSource L level levelIndex)

theorem levelHistoryMatrix_regularBridgeOutcome_success
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.regularBridgeOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  L.regularBridgeOutcome_eq

theorem levelHistoryMatrix_variableBridgeOutcome_success
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.variableBridgeOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  L.variableBridgeOutcome_eq

theorem levelHistoryMatrix_regularMatrix_from_bridge
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.regularMatrix = regularGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge L.sourceLevelHistorySchurIndexBridgeConsistencyLedger :=
  L.regularMatrix_eq_from_bridge

theorem levelHistoryMatrix_variableMatrix_from_bridge
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.variableMatrix = variableGeneratedLevelHistoryMatrixFromBridgeLevelHistoryMatrixFromBridge L.sourceLevelHistorySchurIndexBridgeConsistencyLedger :=
  L.variableMatrix_eq_from_bridge

theorem levelHistoryMatrix_noMatrixInv
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.noMatrixInvStatus = LevelHistoryMatrixFromBridgeNoMatrixInvStatus.noMatrixInvIntroducedInLevelHistoryMatrixFromBridge :=
  L.noMatrixInvStatus_eq

theorem levelHistoryMatrix_noCharpolyDiscriminant
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryMatrixFromBridgeGeneratedLevelHistoryMatrixLedger b β p regularWeight variableWeight) :
    L.noCharpolyDiscriminantStatus =
      LevelHistoryMatrixFromBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryMatrixFromBridge :=
  L.noCharpolyDiscriminantStatus_eq

end CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryMatrixFromBridge
