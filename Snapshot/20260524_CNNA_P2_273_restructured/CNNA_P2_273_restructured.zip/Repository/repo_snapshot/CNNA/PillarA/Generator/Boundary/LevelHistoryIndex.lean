import CNNA.PillarA.Generator.Core.Source

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

abbrev LevelHistoryIndex (L : Nat) := Fin (L + 1)

namespace LevelHistoryIndex

variable (L : Nat)

def equivFin : LevelHistoryIndex L ≃ Fin (L + 1) :=
  Equiv.refl (Fin (L + 1))

theorem equivFin_apply (k : LevelHistoryIndex L) :
    equivFin L k = k := by
  rfl

theorem equivFin_symm_apply (k : Fin (L + 1)) :
    (equivFin L).symm k = k := by
  rfl

end LevelHistoryIndex

end BoundarySource

namespace StrengtheningRecursiveHistoryBoundarySource

abbrev RecursiveHistoryBoundarySourceLevelHistoryIndexOf (L : Nat) :=
  BoundarySource.LevelHistoryIndex L

def boundarySourceDecisionLevelHistoryIndexEquivFin (L : Nat) :
    RecursiveHistoryBoundarySourceLevelHistoryIndexOf L ≃ Fin (L + 1) :=
  BoundarySource.LevelHistoryIndex.equivFin L

theorem boundarySourceDecisionLevelHistoryIndexEquivFin_apply
    (L : Nat) (k : RecursiveHistoryBoundarySourceLevelHistoryIndexOf L) :
    boundarySourceDecisionLevelHistoryIndexEquivFin L k = k := by
  rfl

end StrengtheningRecursiveHistoryBoundarySource

end CNNA.PillarA.Arithmetic
