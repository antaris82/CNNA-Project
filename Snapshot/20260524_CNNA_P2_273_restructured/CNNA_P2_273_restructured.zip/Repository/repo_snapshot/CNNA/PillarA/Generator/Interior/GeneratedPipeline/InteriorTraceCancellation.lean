import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTraceCancellationDerivation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open scoped BigOperators
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation


universe u

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefEB4C where
  | traceCancellationDerivationFromInteriorBlockFoldAccumulatedInvariant
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefF7DD where
  | productCancellationLedgerFromInteriorBlockFoldAccumulatedInvariant
  deriving DecidableEq, Repr

namespace GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}

def fromAccumulatedEntryCancellationInvariant
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H :=
  GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation.fromSource
    (GeneratedInteriorInteriorTwoSidedInverseTraceCancellationSource.fromInteriorEliminationdbChain H)
    (by
      intro i j
      calc
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
            generatedInteriorAccumulatedLeftConvolution W T i j := by
          rfl
        _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
          C.leftAccumulatedConvolution_eq_identity i j)
    (by
      intro i j
      calc
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
            generatedInteriorAccumulatedRightConvolution W T i j := by
          rfl
        _ = (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
          C.rightAccumulatedConvolution_eq_identity i j)
    (by
      intro i
      calc
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i i =
            generatedInteriorAccumulatedLeftConvolution W T i i := by
          rfl
        _ = 1 := C.leftAccumulatedConvolution_diagonal i)
    (by
      intro i j hij
      calc
        GeneratedInteriorInteriorTwoSidedInverseLeftProductNormalForm T i j =
            generatedInteriorAccumulatedLeftConvolution W T i j := by
          rfl
        _ = 0 := C.leftAccumulatedConvolution_offdiag i j hij)
    (by
      intro i
      calc
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i i =
            generatedInteriorAccumulatedRightConvolution W T i i := by
          rfl
        _ = 1 := C.rightAccumulatedConvolution_diagonal i)
    (by
      intro i j hij
      calc
        GeneratedInteriorInteriorTwoSidedInverseRightProductNormalForm T i j =
            generatedInteriorAccumulatedRightConvolution W T i j := by
          rfl
        _ = 0 := C.rightAccumulatedConvolution_offdiag i j hij)

end GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation

def traceCancellationDerivation_from_accumulatedEntryCancellationInvariant
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H :=
  GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation.fromAccumulatedEntryCancellationInvariant H C

def traceCancellationInvariant_from_accumulatedEntryCancellationInvariant
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H :=
  traceCancellationInvariantFromInteriorEliminationdbChain
    (traceCancellationDerivation_from_accumulatedEntryCancellationInvariant H C)

def productCancellationLedger_from_accumulatedEntryCancellationInvariant
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H :=
  productCancellationLedger_from_traceCancellationDerivation
    (traceCancellationDerivation_from_accumulatedEntryCancellationInvariant H C)

structure InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  accumulatedEntryCancellation :
    GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T
  traceCancellationDerivation :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation Cell p A P wp W E K T M S H
  traceCancellationInvariant :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant Cell p A P wp W E K T M S H
  productCancellationLedger :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H
  derivationStatus : InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefEB4C
  ledgerStatus : InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefF7DD
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationNoProductIdentityProofStatus
  interiorEliminationFinalGateGateStatus : InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus
  traceCancellationDerivation_eq :
    traceCancellationDerivation =
      traceCancellationDerivation_from_accumulatedEntryCancellationInvariant H accumulatedEntryCancellation
  traceCancellationInvariant_eq :
    traceCancellationInvariant =
      traceCancellationInvariant_from_accumulatedEntryCancellationInvariant H accumulatedEntryCancellation
  productCancellationLedger_eq :
    productCancellationLedger =
      productCancellationLedger_from_accumulatedEntryCancellationInvariant H accumulatedEntryCancellation
  derivationStatus_eq :
    derivationStatus =
      InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefEB4C.traceCancellationDerivationFromInteriorBlockFoldAccumulatedInvariant
  ledgerStatus_eq :
    ledgerStatus =
      InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefF7DD.productCancellationLedgerFromInteriorBlockFoldAccumulatedInvariant
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus_eq :
    interiorEliminationFinalGateGateStatus = InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv

namespace InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}


def fromAccumulatedEntryCancellationInvariant
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T) :
    InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger Cell p A P wp W E K T M S H where
  accumulatedEntryCancellation := C
  traceCancellationDerivation :=
    traceCancellationDerivation_from_accumulatedEntryCancellationInvariant H C
  traceCancellationInvariant :=
    traceCancellationInvariant_from_accumulatedEntryCancellationInvariant H C
  productCancellationLedger :=
    productCancellationLedger_from_accumulatedEntryCancellationInvariant H C
  derivationStatus :=
    InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefEB4C.traceCancellationDerivationFromInteriorBlockFoldAccumulatedInvariant
  ledgerStatus :=
    InteriorTwoSidedInverseValidationInteriorTraceCancellationStatusInteriorTraceCancellationRefF7DD.productCancellationLedgerFromInteriorBlockFoldAccumulatedInvariant
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationNoProductIdentityProofStatus.noProductIdentityProofConstructedInR3b
  interiorEliminationFinalGateGateStatus := InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv
  traceCancellationDerivation_eq := by
    rfl
  traceCancellationInvariant_eq := by
    rfl
  productCancellationLedger_eq := by
    rfl
  derivationStatus_eq := by
    rfl
  ledgerStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  interiorEliminationFinalGateGateStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger

def regularTraceCancellationDerivation_from_accumulatedEntryCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p wp) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  traceCancellationDerivation_from_accumulatedEntryCancellationInvariant
    (regularInteriorInverseCandidateValidationHandoff b p wp) C

def variableTraceCancellationDerivation_from_accumulatedEntryCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p wp) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationDerivation
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  traceCancellationDerivation_from_accumulatedEntryCancellationInvariant
    (variableInteriorInverseCandidateValidationHandoff β p wp) C


def regularTraceCancellationInvariant_from_accumulatedEntryCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p wp) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  traceCancellationInvariant_from_accumulatedEntryCancellationInvariant
    (regularInteriorInverseCandidateValidationHandoff b p wp) C

def variableTraceCancellationInvariant_from_accumulatedEntryCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p wp) :
    GeneratedInteriorInteriorTwoSidedInverseTraceCancellationInvariant
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  traceCancellationInvariant_from_accumulatedEntryCancellationInvariant
    (variableInteriorInverseCandidateValidationHandoff β p wp) C

def regularProductCancellationLedger_from_accumulatedEntryCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p wp) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  productCancellationLedger_from_accumulatedEntryCancellationInvariant
    (regularInteriorInverseCandidateValidationHandoff b p wp) C

def variableProductCancellationLedger_from_accumulatedEntryCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p wp) :
    GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  productCancellationLedger_from_accumulatedEntryCancellationInvariant
    (variableInteriorInverseCandidateValidationHandoff β p wp) C

def regularTraceCancellationLedger_from_accumulatedEntryCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p wp) :
    InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p wp)
      (regularInteriorInverseCandidateValidationHandoff b p wp) :=
  InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger.fromAccumulatedEntryCancellationInvariant
    (regularInteriorInverseCandidateValidationHandoff b p wp) C

def variableTraceCancellationLedger_from_accumulatedEntryCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (C : VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p wp) :
    InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p wp)
      (variableInteriorInverseCandidateValidationHandoff β p wp) :=
  InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger.fromAccumulatedEntryCancellationInvariant
    (variableInteriorInverseCandidateValidationHandoff β p wp) C


def interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight :=
  interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger
    b β p regularWeight variableWeight
    (regularTraceCancellationInvariant_from_accumulatedEntryCancellationInvariant
      b p regularWeight L.regularCancellation)
    (variableTraceCancellationInvariant_from_accumulatedEntryCancellationInvariant
      β p variableWeight L.variableCancellation)

def interiorTwoSidedInverseValidationValidationGeneratedProductCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentity
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger b β p regularWeight variableWeight) :
    InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight :=
  interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger
    (accumulatedEntryCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentity L)

theorem interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulated_regular_status
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger
      L).regularProductCancellationLedger.status =
      InteriorTwoSidedInverseValidationProductCancellationLedgerStatus.productCancellationLedgerFromTraceCancellation := by
  rfl

theorem interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulated_variable_interiorEliminationFinalGate_blocked
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger
      L).variableProductCancellationLedger.interiorEliminationFinalGateGateStatus =
      InteriorTwoSidedInverseValidationInteriorEliminationfGateStatus.interiorEliminationFinalGateBlockedUntilHandoffTwoSidedInv := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
