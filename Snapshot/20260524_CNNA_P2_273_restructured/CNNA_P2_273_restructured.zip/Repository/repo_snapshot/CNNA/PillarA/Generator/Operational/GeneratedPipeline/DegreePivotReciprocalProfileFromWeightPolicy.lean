import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreeFormulaFromWeightPolicy

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy

universe u

inductive GeneratedDegreeFormulaUnitDegreeCaseStatus where
  | noDefinitionalUnitDegreeCaseInCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaWeightPolicyReciprocalDatumStatus where
  | noOperationalWeightPolicyReciprocalDatumInCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaGeneratedReciprocalSourceStatus where
  | noGeneratedReciprocalSourceInCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaProfileConstructionStatus where
  | generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoScalarInvStatus where
  | noScalarInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoMatrixInvStatus where
  | noMatrixInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoExternalScaleOracleStatus where
  | noExternalScaleOracleInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoFreeScaleTableStatus where
  | noFreeScaleTableInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoProductIdentityProofStatus where
  | noProductIdentityProofInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoTwoSidedInvStatus where
  | noTwoSidedInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormula
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormula
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaNextConsumerStatus where
  | generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

structure GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  audit : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T
  unitDegreeCaseStatus : GeneratedDegreeFormulaUnitDegreeCaseStatus
  weightPolicyReciprocalDatumStatus : GeneratedDegreeFormulaWeightPolicyReciprocalDatumStatus
  generatedReciprocalSourceStatus : GeneratedDegreeFormulaGeneratedReciprocalSourceStatus
  profileConstructionStatus : GeneratedDegreeFormulaProfileConstructionStatus
  noScalarInvStatus : GeneratedDegreeFormulaNoScalarInvStatus
  noMatrixInvStatus : GeneratedDegreeFormulaNoMatrixInvStatus
  noExternalScaleOracleStatus : GeneratedDegreeFormulaNoExternalScaleOracleStatus
  noFreeScaleTableStatus : GeneratedDegreeFormulaNoFreeScaleTableStatus
  noProductIdentityProofStatus : GeneratedDegreeFormulaNoProductIdentityProofStatus
  noTwoSidedInvStatus : GeneratedDegreeFormulaNoTwoSidedInvStatus
  noDtnDataStatus : GeneratedDegreeFormulaNoDtnDataStatus
  noArithmeticTargetStatus : GeneratedDegreeFormulaNoArithmeticTargetStatus
  nextConsumerStatus : GeneratedDegreeFormulaNextConsumerStatus
  degree_eq_inputPolicyAdjacencyWeight_sum :
    ∀ i : GeneratedApproximantIndex A,
      generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then wp.constantWeight i j else 0
  pivotEntry_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j then
            wp.constantWeight
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j
          else 0
  audit_operationalReciprocalSourceStatus_eq :
    audit.operationalReciprocalSourceStatus =
      GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  unitDegreeCaseStatus_eq :
    unitDegreeCaseStatus =
      GeneratedDegreeFormulaUnitDegreeCaseStatus.noDefinitionalUnitDegreeCaseInCurrentGeneratedDegreeAPI
  weightPolicyReciprocalDatumStatus_eq :
    weightPolicyReciprocalDatumStatus =
      GeneratedDegreeFormulaWeightPolicyReciprocalDatumStatus.noOperationalWeightPolicyReciprocalDatumInCurrentGeneratedDegreeAPI
  generatedReciprocalSourceStatus_eq :
    generatedReciprocalSourceStatus =
      GeneratedDegreeFormulaGeneratedReciprocalSourceStatus.noGeneratedReciprocalSourceInCurrentGeneratedDegreeAPI
  profileConstructionStatus_eq :
    profileConstructionStatus =
      GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  noScalarInvStatus_eq :
    noScalarInvStatus =
      GeneratedDegreeFormulaNoScalarInvStatus.noScalarInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      GeneratedDegreeFormulaNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      GeneratedDegreeFormulaNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noFreeScaleTableStatus_eq :
    noFreeScaleTableStatus =
      GeneratedDegreeFormulaNoFreeScaleTableStatus.noFreeScaleTableInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      GeneratedDegreeFormulaNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      GeneratedDegreeFormulaNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noDtnDataStatus_eq :
    noDtnDataStatus = GeneratedDegreeFormulaNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormula
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      GeneratedDegreeFormulaNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormula
  nextConsumerStatus_eq :
    nextConsumerStatus = GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource

namespace GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromFormulaAudit
    (A0 : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T) :
    GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T where
  audit := A0
  unitDegreeCaseStatus :=
    GeneratedDegreeFormulaUnitDegreeCaseStatus.noDefinitionalUnitDegreeCaseInCurrentGeneratedDegreeAPI
  weightPolicyReciprocalDatumStatus :=
    GeneratedDegreeFormulaWeightPolicyReciprocalDatumStatus.noOperationalWeightPolicyReciprocalDatumInCurrentGeneratedDegreeAPI
  generatedReciprocalSourceStatus :=
    GeneratedDegreeFormulaGeneratedReciprocalSourceStatus.noGeneratedReciprocalSourceInCurrentGeneratedDegreeAPI
  profileConstructionStatus :=
    GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  noScalarInvStatus :=
    GeneratedDegreeFormulaNoScalarInvStatus.noScalarInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noMatrixInvStatus :=
    GeneratedDegreeFormulaNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noExternalScaleOracleStatus :=
    GeneratedDegreeFormulaNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noFreeScaleTableStatus :=
    GeneratedDegreeFormulaNoFreeScaleTableStatus.noFreeScaleTableInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noProductIdentityProofStatus :=
    GeneratedDegreeFormulaNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noTwoSidedInvStatus :=
    GeneratedDegreeFormulaNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  noDtnDataStatus := GeneratedDegreeFormulaNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormula
  noArithmeticTargetStatus :=
    GeneratedDegreeFormulaNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormula
  nextConsumerStatus := GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource
  degree_eq_inputPolicyAdjacencyWeight_sum := by
    intro i
    exact A0.degree_eq_inputPolicyAdjacencyWeight_sum i
  pivotEntry_eq_generatedDegree := by
    intro pivot
    exact A0.pivotEntry_eq_generatedDegree pivot
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum := by
    intro pivot
    exact A0.pivotEntry_eq_inputPolicyAdjacencyWeight_sum pivot
  audit_operationalReciprocalSourceStatus_eq := A0.operationalReciprocalSourceStatus_eq
  unitDegreeCaseStatus_eq := by
    rfl
  weightPolicyReciprocalDatumStatus_eq := by
    rfl
  generatedReciprocalSourceStatus_eq := by
    rfl
  profileConstructionStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noFreeScaleTableStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem degree_formula_from_weightPolicy_sum
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent i j then wp.constantWeight i j else 0 :=
  D.degree_eq_inputPolicyAdjacencyWeight_sum i

theorem pivotEntry_formula_from_weightPolicy_sum
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex)
            j then
          wp.constantWeight
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex)
            j
        else 0 :=
  D.pivotEntry_eq_inputPolicyAdjacencyWeight_sum pivot

theorem profileConstructionStatus_notConstructed
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T) :
    D.profileConstructionStatus =
      GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI :=
  D.profileConstructionStatus_eq

theorem nextClosureIsOperationalDegreeReciprocalSource
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T) :
    D.nextConsumerStatus = GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource :=
  D.nextConsumerStatus_eq

end GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula

abbrev RegularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula b p wp :=
  GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula.fromFormulaAudit
    (regularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed b p wp)

def variableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula β p wp :=
  GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula.fromFormulaAudit
    (variableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed β p wp)

structure GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAttempt : RegularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula b p regularWeight
  variableAttempt : VariableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula β p variableWeight
  regularProfileConstructionStatus_eq :
    regularAttempt.profileConstructionStatus =
      GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  variableProfileConstructionStatus_eq :
    variableAttempt.profileConstructionStatus =
      GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  regularNoFreeScaleTableStatus_eq :
    regularAttempt.noFreeScaleTableStatus =
      GeneratedDegreeFormulaNoFreeScaleTableStatus.noFreeScaleTableInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoFreeScaleTableStatus_eq :
    variableAttempt.noFreeScaleTableStatus =
      GeneratedDegreeFormulaNoFreeScaleTableStatus.noFreeScaleTableInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoScalarInvStatus_eq :
    regularAttempt.noScalarInvStatus =
      GeneratedDegreeFormulaNoScalarInvStatus.noScalarInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoScalarInvStatus_eq :
    variableAttempt.noScalarInvStatus =
      GeneratedDegreeFormulaNoScalarInvStatus.noScalarInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoMatrixInvStatus_eq :
    regularAttempt.noMatrixInvStatus =
      GeneratedDegreeFormulaNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoMatrixInvStatus_eq :
    variableAttempt.noMatrixInvStatus =
      GeneratedDegreeFormulaNoMatrixInvStatus.noMatrixInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoExternalScaleOracleStatus_eq :
    regularAttempt.noExternalScaleOracleStatus =
      GeneratedDegreeFormulaNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoExternalScaleOracleStatus_eq :
    variableAttempt.noExternalScaleOracleStatus =
      GeneratedDegreeFormulaNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoProductIdentityProofStatus_eq :
    regularAttempt.noProductIdentityProofStatus =
      GeneratedDegreeFormulaNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoProductIdentityProofStatus_eq :
    variableAttempt.noProductIdentityProofStatus =
      GeneratedDegreeFormulaNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoTwoSidedInvStatus_eq :
    regularAttempt.noTwoSidedInvStatus =
      GeneratedDegreeFormulaNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNoTwoSidedInvStatus_eq :
    variableAttempt.noTwoSidedInvStatus =
      GeneratedDegreeFormulaNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  regularNoDtnDataStatus_eq :
    regularAttempt.noDtnDataStatus = GeneratedDegreeFormulaNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormula
  variableNoDtnDataStatus_eq :
    variableAttempt.noDtnDataStatus = GeneratedDegreeFormulaNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormula
  regularNoArithmeticTargetStatus_eq :
    regularAttempt.noArithmeticTargetStatus =
      GeneratedDegreeFormulaNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormula
  variableNoArithmeticTargetStatus_eq :
    variableAttempt.noArithmeticTargetStatus =
      GeneratedDegreeFormulaNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormula
  regularNextConsumerStatus_eq :
    regularAttempt.nextConsumerStatus = GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource
  variableNextConsumerStatus_eq :
    variableAttempt.nextConsumerStatus = GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource

namespace GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularAttempt : RegularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula b p regularWeight)
    (variableAttempt : VariableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula β p variableWeight) :
    GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger b β p regularWeight variableWeight where
  regularAttempt := regularAttempt
  variableAttempt := variableAttempt
  regularProfileConstructionStatus_eq := regularAttempt.profileConstructionStatus_eq
  variableProfileConstructionStatus_eq := variableAttempt.profileConstructionStatus_eq
  regularNoFreeScaleTableStatus_eq := regularAttempt.noFreeScaleTableStatus_eq
  variableNoFreeScaleTableStatus_eq := variableAttempt.noFreeScaleTableStatus_eq
  regularNoScalarInvStatus_eq := regularAttempt.noScalarInvStatus_eq
  variableNoScalarInvStatus_eq := variableAttempt.noScalarInvStatus_eq
  regularNoMatrixInvStatus_eq := regularAttempt.noMatrixInvStatus_eq
  variableNoMatrixInvStatus_eq := variableAttempt.noMatrixInvStatus_eq
  regularNoExternalScaleOracleStatus_eq := regularAttempt.noExternalScaleOracleStatus_eq
  variableNoExternalScaleOracleStatus_eq := variableAttempt.noExternalScaleOracleStatus_eq
  regularNoProductIdentityProofStatus_eq := regularAttempt.noProductIdentityProofStatus_eq
  variableNoProductIdentityProofStatus_eq := variableAttempt.noProductIdentityProofStatus_eq
  regularNoTwoSidedInvStatus_eq := regularAttempt.noTwoSidedInvStatus_eq
  variableNoTwoSidedInvStatus_eq := variableAttempt.noTwoSidedInvStatus_eq
  regularNoDtnDataStatus_eq := regularAttempt.noDtnDataStatus_eq
  variableNoDtnDataStatus_eq := variableAttempt.noDtnDataStatus_eq
  regularNoArithmeticTargetStatus_eq := regularAttempt.noArithmeticTargetStatus_eq
  variableNoArithmeticTargetStatus_eq := variableAttempt.noArithmeticTargetStatus_eq
  regularNextConsumerStatus_eq := regularAttempt.nextConsumerStatus_eq
  variableNextConsumerStatus_eq := variableAttempt.nextConsumerStatus_eq

end GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger

def generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger b β p regularWeight variableWeight :=
  GeneratedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicyLedger.fromRegularAndVariable
    (regularGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula b p regularWeight)
    (variableGeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula β p variableWeight)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
