import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev LevelHistorySchurIndexBridgeConsistencyOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.levelHistorySchurIndexBridgeConsistency

def levelHistorySchurIndexBridgeConsistencyOutputKind : DerivedOutputKind :=
  DerivedOutputKind.levelHistorySchurIndexBridgeConsistency

theorem levelHistorySchurIndexBridgeConsistency_kind_eq (profile : LevelHistorySchurIndexBridgeConsistencyOutputProfile) :
    profile.profile.kind = levelHistorySchurIndexBridgeConsistencyOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
