import CNNA.PillarA.Generator.DtN.GeneratedPipeline.TopBoundaryDtN
import CNNA.PillarA.Generator.Core.SourceAndApproximation.MainPath
import CNNA.PillarA.Generator.DtN.TopBoundary.GeneralizedTopBoundaryDtN

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN

universe u

inductive GeneralizedDtNToMultiSchurSourceLedgerGeneralizedSourceStatus where
  | generatedFromGeneralizedDtNSourceTopBoundaryDtN
  deriving DecidableEq, Repr

inductive GeneralizedDtNToMultiSchurSourceLedgerSectorProvenanceStatus where
  | carriedByGeneratedMainPathNoPublicSectorSplit
  deriving DecidableEq, Repr

inductive GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus where
  | noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger
  deriving DecidableEq, Repr

inductive GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus where
  | noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  deriving DecidableEq, Repr

inductive GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger
  deriving DecidableEq, Repr

def generatedGeneralizedTopBoundaryOperatorGeneralizedDtNToMultiSchurSourceLedger
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H) :
    Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ :=
  G.boundaryOperator

def generatedGeneralizedTopBoundaryApplyGeneralizedDtNToMultiSchurSourceLedger
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    GeneratedBoundaryIndex A → ℝ :=
  G.«apply» φ

structure GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  sourceTopBoundaryDtN : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H
  sourceStatus : GeneralizedDtNToMultiSchurSourceLedgerGeneralizedSourceStatus
  sourceStatusEqGeneralizedDtNSource :
    sourceStatus = GeneralizedDtNToMultiSchurSourceLedgerGeneralizedSourceStatus.generatedFromGeneralizedDtNSourceTopBoundaryDtN
  mainPathProvenance : GeneratedMainPath Cell p
  source_eq_generatedMainPath : mainPathProvenance = generatedMainPath Cell p
  mainPath_family_eq_generated : mainPathProvenance.family = generatedBranchFamily Cell
  mainPath_toc_eq_generated : mainPathProvenance.toc = generatedBranchToC Cell
  policyHook_eq_generated : mainPathProvenance.policyHook = policyProvenanceHook p
  weightHook_eq_generated : mainPathProvenance.weightHook = weightProvenanceHook
  sectorProvenanceStatus : GeneralizedDtNToMultiSchurSourceLedgerSectorProvenanceStatus
  sectorProvenanceStatus_eq :
    sectorProvenanceStatus =
      GeneralizedDtNToMultiSchurSourceLedgerSectorProvenanceStatus.carriedByGeneratedMainPathNoPublicSectorSplit
  boundaryOperator : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ
  boundaryOperatorEqGeneralizedDtNSource : boundaryOperator = sourceTopBoundaryDtN.boundaryOperator
  «apply» : (GeneratedBoundaryIndex A → ℝ) → GeneratedBoundaryIndex A → ℝ
  applyEqGeneralizedDtNSource : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = sourceTopBoundaryDtN.«apply» φ
  apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = boundaryOperator.mulVec φ
  noExternalDtNStatus : GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus
  noExternalDtNStatus_eq :
    noExternalDtNStatus = GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger
  noMultiSchurStatus : GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus
  noMultiSchurStatus_eq :
    noMultiSchurStatus = GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  noArithmeticTargetStatus : GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger

namespace GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromTopBoundaryDtN
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H where
  sourceTopBoundaryDtN := G
  sourceStatus := GeneralizedDtNToMultiSchurSourceLedgerGeneralizedSourceStatus.generatedFromGeneralizedDtNSourceTopBoundaryDtN
  sourceStatusEqGeneralizedDtNSource := by
    rfl
  mainPathProvenance := generatedMainPath Cell p
  source_eq_generatedMainPath := by
    rfl
  mainPath_family_eq_generated := by
    rfl
  mainPath_toc_eq_generated := by
    rfl
  policyHook_eq_generated := by
    rfl
  weightHook_eq_generated := by
    rfl
  sectorProvenanceStatus :=
    GeneralizedDtNToMultiSchurSourceLedgerSectorProvenanceStatus.carriedByGeneratedMainPathNoPublicSectorSplit
  sectorProvenanceStatus_eq := by
    rfl
  boundaryOperator := G.boundaryOperator
  boundaryOperatorEqGeneralizedDtNSource := by
    rfl
  «apply» := fun φ => G.«apply» φ
  applyEqGeneralizedDtNSource := by
    intro φ
    rfl
  apply_eq_mulVec := by
    intro φ
    exact G.apply_eq_mulVec φ
  noExternalDtNStatus := GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger
  noExternalDtNStatus_eq := by
    rfl
  noMultiSchurStatus := GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger
  noMultiSchurStatus_eq := by
    rfl
  noArithmeticTargetStatus :=
    GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger
  noArithmeticTargetStatus_eq := by
    rfl

theorem sourceFromGeneralizedDtNSource
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.sourceStatus = GeneralizedDtNToMultiSchurSourceLedgerGeneralizedSourceStatus.generatedFromGeneralizedDtNSourceTopBoundaryDtN :=
  G.sourceStatusEqGeneralizedDtNSource

theorem mainPath_from_generated
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.mainPathProvenance = generatedMainPath Cell p :=
  G.source_eq_generatedMainPath

theorem mainPath_family_from_generated
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.mainPathProvenance.family = generatedBranchFamily Cell :=
  G.mainPath_family_eq_generated

theorem mainPath_toc_from_generated
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.mainPathProvenance.toc = generatedBranchToC Cell :=
  G.mainPath_toc_eq_generated

theorem boundaryOperatorFromGeneralizedDtNSource
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.boundaryOperator = G.sourceTopBoundaryDtN.boundaryOperator :=
  G.boundaryOperatorEqGeneralizedDtNSource

theorem boundaryOperator_from_schur
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          G.sourceTopBoundaryDtN.sourceCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W := by
  calc
    G.boundaryOperator = G.sourceTopBoundaryDtN.boundaryOperator :=
      G.boundaryOperatorEqGeneralizedDtNSource
    _ = generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
          generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
            G.sourceTopBoundaryDtN.sourceCertificate.inverseMatrix *
            generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
      G.sourceTopBoundaryDtN.boundaryOperator_eq_schur

theorem applyFromGeneralizedDtNSource
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    G.«apply» φ = G.sourceTopBoundaryDtN.«apply» φ :=
  G.applyEqGeneralizedDtNSource φ

theorem apply_from_mulVec
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    G.«apply» φ = G.boundaryOperator.mulVec φ :=
  G.apply_eq_mulVec φ

theorem boundaryFluxFromGeneralizedDtNSource
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ +
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (G.sourceTopBoundaryDtN.sourceCertificate.interiorSolve φ) =
      G.«apply» φ := by
  calc
    (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ +
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (G.sourceTopBoundaryDtN.sourceCertificate.interiorSolve φ)
        = G.sourceTopBoundaryDtN.«apply» φ :=
      G.sourceTopBoundaryDtN.boundaryFlux_spec φ
    _ = G.«apply» φ := by
      exact (G.applyEqGeneralizedDtNSource φ).symm

theorem noExternalDtNFromGeneralizedDtNToMultiSchurSourceLedger
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.noExternalDtNStatus = GeneralizedDtNToMultiSchurSourceLedgerNoExternalDtNStatus.noExternalDtNSourceInGeneralizedDtNToMultiSchurSourceLedger :=
  G.noExternalDtNStatus_eq

theorem noMultiSchurFromGeneralizedDtNToMultiSchurSourceLedger
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.noMultiSchurStatus = GeneralizedDtNToMultiSchurSourceLedgerNoMultiSchurStatus.noMultiSchurDataInGeneralizedDtNToMultiSchurSourceLedger :=
  G.noMultiSchurStatus_eq

theorem noArithmeticTargetFromGeneralizedDtNToMultiSchurSourceLedger
    (G : GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H) :
    G.noArithmeticTargetStatus =
      GeneralizedDtNToMultiSchurSourceLedgerNoArithmeticTargetStatus.noCharpolyFactorDiscriminantDataInGeneralizedDtNToMultiSchurSourceLedger :=
  G.noArithmeticTargetStatus_eq

end GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger

def generatedGeneralizedTopBoundaryDtNFromGeneralizedDtNSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger Cell p A P wp W E K T M S H :=
  GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger.fromTopBoundaryDtN G

theorem generatedGeneralizedTopBoundaryOperatorEqGeneralizedDtNSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H) :
    generatedGeneralizedTopBoundaryOperatorGeneralizedDtNToMultiSchurSourceLedger G = G.boundaryOperator := by
  rfl

theorem generatedGeneralizedTopBoundaryApplyEqGeneralizedDtNSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (G : GeneratedTopBoundaryDtNGeneralizedDtNSource Cell p A P wp W E K T M S H)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    generatedGeneralizedTopBoundaryApplyGeneralizedDtNToMultiSchurSourceLedger G φ = G.«apply» φ := by
  rfl

def regularGeneratedGeneralizedTopBoundaryDtNFromReRunProductCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger.fromTopBoundaryDtN
    (regularGeneratedTopBoundaryDtNFromReRunProductCancellationLedgerGeneralizedDtNSource L)

def variableGeneratedGeneralizedTopBoundaryDtNFromReRunProductCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger.fromTopBoundaryDtN
    (variableGeneratedTopBoundaryDtNFromReRunProductCancellationLedgerGeneralizedDtNSource L)

def regularGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger.fromTopBoundaryDtN
    (regularGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource L)

def variableGeneratedGeneralizedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNToMultiSchurSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  GeneratedGeneralizedTopBoundaryDtNGeneralizedDtNToMultiSchurSourceLedger.fromTopBoundaryDtN
    (variableGeneratedTopBoundaryDtNFromAccumulatedEntryCancellationLedgerGeneralizedDtNSource L)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
