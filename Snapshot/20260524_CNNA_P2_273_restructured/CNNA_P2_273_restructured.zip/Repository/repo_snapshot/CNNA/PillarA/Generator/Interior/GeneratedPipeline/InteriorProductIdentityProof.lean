import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTraceCancellation

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open scoped BigOperators
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation


universe u

namespace GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromProductCancellationLedger
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H where
  leftProduct_entry_eq_identity := by
    intro i j
    exact L.leftProduct_entry_eq_identity i j
  rightProduct_entry_eq_identity := by
    intro i j
    exact L.rightProduct_entry_eq_identity i j
  leftProduct_diagonal_entry := by
    intro i
    exact L.leftProduct_diagonal_entry i
  leftProduct_offdiag_entry := by
    intro i j hij
    exact L.leftProduct_offdiag_entry i j hij
  rightProduct_diagonal_entry := by
    intro i
    exact L.rightProduct_diagonal_entry i
  rightProduct_offdiag_entry := by
    intro i j hij
    exact L.rightProduct_offdiag_entry i j hij

end GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof

def productIdentityProof_from_productCancellationLedger
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H :=
  GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof.fromProductCancellationLedger L

def productIdentityProofFromInteriorProductIdentityProofLedger
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger Cell p A P wp W E K T M S H) :
    GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H :=
  productIdentityProof_from_productCancellationLedger L.productCancellationLedger

def regularProductIdentityProof_from_reRunProductCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :=
  productIdentityProof_from_productCancellationLedger L.regularProductCancellationLedger

def variableProductIdentityProof_from_reRunProductCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :=
  productIdentityProof_from_productCancellationLedger L.variableProductCancellationLedger

def regularProductIdentityProof_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :=
  regularProductIdentityProof_from_reRunProductCancellationLedger
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger L)

def variableProductIdentityProof_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :=
  variableProductIdentityProof_from_reRunProductCancellationLedger
    (interiorTwoSidedInverseValidationReRunGeneratedProductCancellationLedger_from_accumulatedEntryCancellationLedger L)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
