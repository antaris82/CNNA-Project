import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart


universe u

inductive InteriorAccumulatedTraceEvaluationTraceStepStatus where
  | traceStepFromInteriorEliminationTraceLocalEliminationStep
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationTraceStatus where
  | generatedInteriorEliminationTraceClosed
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationTerminationStatus where
  | terminatesByFiniteInteriorCarrier
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationTraceSourceStatus where
  | traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus where
  | noExternalTraceOracle
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus where
  | noExternalOrderOracle
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoFreePivotListStatus where
  | noFreePivotList
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus where
  | noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoMatrixExportStatus where
  | noMatrixExportInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoProductProofStatus where
  | noProductProofInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoMatrixInvStatus where
  | noMatrixInvInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate where
  | generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedgerStatus where
  | generatedInteriorEliminationTraceClosed
  deriving DecidableEq, Repr

structure GeneratedInteriorEliminationTraceStep
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) where
  localStep : GeneratedInteriorEliminationStep Cell p A P wp W E K
  pivotDatum : GeneratedInteriorPivotDatum Cell p A P wp W E K
  pivotIndex : GeneratedInteriorIndex A
  pivotNode : GeneratedInteriorEliminationNode Cell p A P wp W K.candidate
  residualDatum : GeneratedInteriorResidualDatum Cell p A P wp W E K S.pivotDatum
  stepUpdate : GeneratedInteriorStepUpdate Cell p A P wp W E K S.pivotDatum S.residualDatum
  traceStepStatus : InteriorAccumulatedTraceEvaluationTraceStepStatus
  noExternalTraceOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus
  noExternalOrderOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus
  noFreePivotListStatus : InteriorAccumulatedTraceEvaluationNoFreePivotListStatus
  noInverseEntryFunctionStatus : InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus
  noMatrixExportStatus : InteriorAccumulatedTraceEvaluationNoMatrixExportStatus
  noTwoSidedInvStatus : InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus
  noProductProofStatus : InteriorAccumulatedTraceEvaluationNoProductProofStatus
  localStepEqInteriorEliminationTraceStep : localStep = S
  pivotDatum_eq_localStepPivot : pivotDatum = S.pivotDatum
  pivotIndex_eq_localStepPivotIndex : pivotIndex = S.pivotDatum.pivotIndex
  pivotNode_eq_localStepPivotNode : pivotNode = S.pivotDatum.node
  residualDatum_eq_localStepResidual : residualDatum = S.residualDatum
  stepUpdate_eq_localStepUpdate : stepUpdate = S.stepUpdate
  localStepFromInteriorEliminationTrace :
    localStep.stepStatus =
      InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed
  pivotBoundToInteriorEliminationCarrierNode :
    S.pivotDatum.node = K.nodeOf S.pivotDatum.pivotIndex
  residualEqInteriorBlockInteriorBlock :
    ∀ j : GeneratedInteriorIndex A,
      S.residualDatum.rowResidual j =
        generatedInteriorLocalRowResidual W S.pivotDatum.pivotIndex j
  columnResidualEqInteriorBlockInteriorBlock :
    ∀ i : GeneratedInteriorIndex A,
      S.residualDatum.columnResidual i =
        generatedInteriorLocalColumnResidual W S.pivotDatum.pivotIndex i
  traceStepStatus_eq :
    traceStepStatus =
      InteriorAccumulatedTraceEvaluationTraceStepStatus.traceStepFromInteriorEliminationTraceLocalEliminationStep
  noExternalTraceOracleStatus_eq :
    noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  noExternalOrderOracleStatus_eq :
    noExternalOrderOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus.noExternalOrderOracle
  noFreePivotListStatus_eq :
    noFreePivotListStatus = InteriorAccumulatedTraceEvaluationNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus_eq :
    noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedTraceEvaluationNoProductProofStatus.noProductProofInInteriorAccumulatedTraceEvaluation

namespace GeneratedInteriorEliminationTraceStep

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {S : GeneratedInteriorEliminationStep Cell p A P wp W E K}

def fromLocalEliminationStep
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S where
  localStep := S
  pivotDatum := S.pivotDatum
  pivotIndex := S.pivotDatum.pivotIndex
  pivotNode := S.pivotDatum.node
  residualDatum := S.residualDatum
  stepUpdate := S.stepUpdate
  traceStepStatus :=
    InteriorAccumulatedTraceEvaluationTraceStepStatus.traceStepFromInteriorEliminationTraceLocalEliminationStep
  noExternalTraceOracleStatus :=
    InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  noExternalOrderOracleStatus :=
    InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus.noExternalOrderOracle
  noFreePivotListStatus := InteriorAccumulatedTraceEvaluationNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus :=
    InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  noMatrixExportStatus := InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  noTwoSidedInvStatus := InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  noProductProofStatus := InteriorAccumulatedTraceEvaluationNoProductProofStatus.noProductProofInInteriorAccumulatedTraceEvaluation
  localStepEqInteriorEliminationTraceStep := by
    rfl
  pivotDatum_eq_localStepPivot := by
    rfl
  pivotIndex_eq_localStepPivotIndex := by
    rfl
  pivotNode_eq_localStepPivotNode := by
    rfl
  residualDatum_eq_localStepResidual := by
    rfl
  stepUpdate_eq_localStepUpdate := by
    rfl
  localStepFromInteriorEliminationTrace :=
    S.stepStatus_eq
  pivotBoundToInteriorEliminationCarrierNode :=
    S.pivot_from_carrierNode
  residualEqInteriorBlockInteriorBlock := by
    intro j
    exact S.residualDatum.rowResidual_eq_interiorBlock j
  columnResidualEqInteriorBlockInteriorBlock := by
    intro i
    exact S.residualDatum.columnResidual_eq_interiorBlock i
  traceStepStatus_eq := by
    rfl
  noExternalTraceOracleStatus_eq := by
    rfl
  noExternalOrderOracleStatus_eq := by
    rfl
  noFreePivotListStatus_eq := by
    rfl
  noInverseEntryFunctionStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl

theorem traceStep_from_localEliminationStep
    (T : GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S) :
    T.localStep = S :=
  T.localStepEqInteriorEliminationTraceStep

theorem traceStepLocalStepEqInteriorEliminationTraceStep
    (T : GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S) :
    T.localStep.stepStatus =
      InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed :=
  T.localStepFromInteriorEliminationTrace

theorem traceStepPivotBoundToInteriorEliminationCarrierNode
    (T : GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S) :
    S.pivotDatum.node = K.nodeOf S.pivotDatum.pivotIndex :=
  T.pivotBoundToInteriorEliminationCarrierNode

theorem traceStepResidualEqInteriorBlockInteriorBlock
    (T : GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S)
    (j : GeneratedInteriorIndex A) :
    S.residualDatum.rowResidual j =
      generatedInteriorLocalRowResidual W S.pivotDatum.pivotIndex j :=
  T.residualEqInteriorBlockInteriorBlock j

end GeneratedInteriorEliminationTraceStep

structure GeneratedInteriorEliminationTrace
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) where
  carrier : GeneratedInteriorEliminationCarrier Cell p A P wp W E
  traceIndexCarrier : Finset (GeneratedInteriorIndex A)
  localStepOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationStep Cell p A P wp W E K
  traceStepOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationTraceStep Cell p A P wp W E K (localStepOf i)
  traceLength : Nat
  traceStatus : InteriorAccumulatedTraceEvaluationTraceStatus
  terminationStatus : InteriorAccumulatedTraceEvaluationTerminationStatus
  sourceStatus : InteriorAccumulatedTraceEvaluationTraceSourceStatus
  noExternalTraceOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus
  noExternalOrderOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus
  noFreePivotListStatus : InteriorAccumulatedTraceEvaluationNoFreePivotListStatus
  noInverseEntryFunctionStatus : InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus
  noMatrixExportStatus : InteriorAccumulatedTraceEvaluationNoMatrixExportStatus
  noTwoSidedInvStatus : InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus
  noProductProofStatus : InteriorAccumulatedTraceEvaluationNoProductProofStatus
  noMatrixInvStatus : InteriorAccumulatedTraceEvaluationNoMatrixInvStatus
  noDtnDataStatus : InteriorAccumulatedTraceEvaluationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorAccumulatedTraceEvaluationNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate
  carrier_eq : carrier = K
  traceIndexCarrier_eq_carrierIndexCarrier : traceIndexCarrier = K.indexCarrier
  traceLength_eq_traceIndexCarrier_card : traceLength = traceIndexCarrier.card
  localStepOfEqInteriorEliminationTraceStep :
    ∀ i : GeneratedInteriorIndex A,
      localStepOf i = localStepFromInteriorEliminationCarrierNode K i
  traceStepLocalStepEqInteriorEliminationTraceStep :
    ∀ i : GeneratedInteriorIndex A,
      (traceStepOf i).localStep = localStepOf i
  traceStepPivotBoundToInteriorEliminationCarrierNode :
    ∀ i : GeneratedInteriorIndex A,
      (localStepOf i).pivotDatum.node =
        K.nodeOf (localStepOf i).pivotDatum.pivotIndex
  traceStepResidualEqInteriorBlockInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (localStepOf i).residualDatum.rowResidual j =
        generatedInteriorLocalRowResidual W (localStepOf i).pivotDatum.pivotIndex j
  traceStepColumnResidualEqInteriorBlockInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (localStepOf i).residualDatum.columnResidual j =
        generatedInteriorLocalColumnResidual W (localStepOf i).pivotDatum.pivotIndex j
  traceStatus_eq :
    traceStatus = InteriorAccumulatedTraceEvaluationTraceStatus.generatedInteriorEliminationTraceClosed
  terminationStatus_eq :
    terminationStatus = InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier
  sourceStatus_eq :
    sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  noExternalTraceOracleStatus_eq :
    noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  noExternalOrderOracleStatus_eq :
    noExternalOrderOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus.noExternalOrderOracle
  noFreePivotListStatus_eq :
    noFreePivotListStatus = InteriorAccumulatedTraceEvaluationNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus_eq :
    noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedTraceEvaluationNoProductProofStatus.noProductProofInInteriorAccumulatedTraceEvaluation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedTraceEvaluationNoMatrixInvStatus.noMatrixInvInInteriorAccumulatedTraceEvaluation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorAccumulatedTraceEvaluationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedTraceEvaluation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorAccumulatedTraceEvaluationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedTraceEvaluation
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate =
      InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate.generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry

namespace GeneratedInteriorEliminationTrace

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromFiniteCarrier
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    GeneratedInteriorEliminationTrace Cell p A P wp W E K where
  carrier := K
  traceIndexCarrier := K.indexCarrier
  localStepOf := fun i => localStepFromInteriorEliminationCarrierNode K i
  traceStepOf := fun i =>
    GeneratedInteriorEliminationTraceStep.fromLocalEliminationStep
      (localStepFromInteriorEliminationCarrierNode K i)
  traceLength := K.indexCarrier.card
  traceStatus := InteriorAccumulatedTraceEvaluationTraceStatus.generatedInteriorEliminationTraceClosed
  terminationStatus := InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier
  sourceStatus :=
    InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  noExternalTraceOracleStatus :=
    InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  noExternalOrderOracleStatus :=
    InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus.noExternalOrderOracle
  noFreePivotListStatus := InteriorAccumulatedTraceEvaluationNoFreePivotListStatus.noFreePivotList
  noInverseEntryFunctionStatus :=
    InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  noMatrixExportStatus := InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  noTwoSidedInvStatus := InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  noProductProofStatus := InteriorAccumulatedTraceEvaluationNoProductProofStatus.noProductProofInInteriorAccumulatedTraceEvaluation
  noMatrixInvStatus := InteriorAccumulatedTraceEvaluationNoMatrixInvStatus.noMatrixInvInInteriorAccumulatedTraceEvaluation
  noDtnDataStatus :=
    InteriorAccumulatedTraceEvaluationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedTraceEvaluation
  noArithmeticTargetStatus :=
    InteriorAccumulatedTraceEvaluationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedTraceEvaluation
  nextPositiveConstructionGate :=
    InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate.generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry
  carrier_eq := by
    rfl
  traceIndexCarrier_eq_carrierIndexCarrier := by
    rfl
  traceLength_eq_traceIndexCarrier_card := by
    rfl
  localStepOfEqInteriorEliminationTraceStep := by
    intro i
    rfl
  traceStepLocalStepEqInteriorEliminationTraceStep := by
    intro i
    rfl
  traceStepPivotBoundToInteriorEliminationCarrierNode := by
    intro i
    exact (localStepFromInteriorEliminationCarrierNode K i).pivot_from_carrierNode
  traceStepResidualEqInteriorBlockInteriorBlock := by
    intro i j
    exact (localStepFromInteriorEliminationCarrierNode K i).residualDatum.rowResidual_eq_interiorBlock j
  traceStepColumnResidualEqInteriorBlockInteriorBlock := by
    intro i j
    exact (localStepFromInteriorEliminationCarrierNode K i).residualDatum.columnResidual_eq_interiorBlock j
  traceStatus_eq := by
    rfl
  terminationStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noExternalTraceOracleStatus_eq := by
    rfl
  noExternalOrderOracleStatus_eq := by
    rfl
  noFreePivotListStatus_eq := by
    rfl
  noInverseEntryFunctionStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextPositiveConstructionGate_eq := by
    rfl


def fromTreeRecursiveProfile
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    GeneratedInteriorEliminationTrace Cell p A P wp W E K :=
  fromFiniteCarrier K

theorem terminates
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.terminationStatus = InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier :=
  T.terminationStatus_eq

theorem sourceEqInteriorBlockInteriorEliminationdR
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  T.sourceStatus_eq

theorem noExternalTraceOracle
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle :=
  T.noExternalTraceOracleStatus_eq

theorem noInverseEntryFunction
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation :=
  T.noInverseEntryFunctionStatus_eq

theorem noMatrixExport
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noMatrixExportStatus = InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation :=
  T.noMatrixExportStatus_eq

theorem noTwoSidedInv
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noTwoSidedInvStatus = InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation :=
  T.noTwoSidedInvStatus_eq

end GeneratedInteriorEliminationTrace

def traceStep_from_localEliminationStep
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    GeneratedInteriorEliminationTraceStep Cell p A P wp W E K S :=
  GeneratedInteriorEliminationTraceStep.fromLocalEliminationStep S

def GeneratedInteriorEliminationTrace_from_finiteCarrier
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    GeneratedInteriorEliminationTrace Cell p A P wp W E K :=
  GeneratedInteriorEliminationTrace.fromFiniteCarrier K

def GeneratedInteriorEliminationTrace_from_treeRecursiveProfile
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) :
    GeneratedInteriorEliminationTrace Cell p A P wp W E K :=
  GeneratedInteriorEliminationTrace.fromTreeRecursiveProfile K

theorem generatedInteriorEliminationTrace_terminates
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.terminationStatus = InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier :=
  T.terminationStatus_eq

theorem generatedInteriorEliminationTraceSourceEqInteriorBlockInteriorEliminationdR
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  T.sourceStatus_eq

theorem noExternalTraceOracle
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle :=
  T.noExternalTraceOracleStatus_eq

theorem trace_noInverseEntryFunction
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation :=
  T.noInverseEntryFunctionStatus_eq

theorem trace_noMatrixExport
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noMatrixExportStatus = InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation :=
  T.noMatrixExportStatus_eq

theorem trace_noTwoSidedInv
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    T.noTwoSidedInvStatus = InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation :=
  T.noTwoSidedInvStatus_eq

def regularGeneratedInteriorEliminationTrace
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationTrace
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp) :=
  GeneratedInteriorEliminationTrace_from_finiteCarrier
    (regularGeneratedInteriorEliminationCarrier b p wp)

def variableGeneratedInteriorEliminationTrace
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorEliminationTrace
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp) :=
  GeneratedInteriorEliminationTrace_from_finiteCarrier
    (variableGeneratedInteriorEliminationCarrier β p wp)

structure InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedgerStatus
  interiorEliminationStepLedger :
    InteriorEliminationTraceGeneratedInteriorEliminationStepLedger b β p regularWeight variableWeight
      regularPivot variablePivot
  regularTrace :
    GeneratedInteriorEliminationTrace
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
  variableTrace :
    GeneratedInteriorEliminationTrace
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
  interiorEliminationStepLedger_eq_main :
    interiorEliminationStepLedger = generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularTrace_eq_main :
    regularTrace = regularGeneratedInteriorEliminationTrace b p regularWeight
  variableTrace_eq_main :
    variableTrace = variableGeneratedInteriorEliminationTrace β p variableWeight
  regularTerminates :
    regularTrace.terminationStatus =
      InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier
  variableTerminates :
    variableTrace.terminationStatus =
      InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier
  regularSourceEqInteriorBlockInteriorEliminationdR :
    regularTrace.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  variableSourceEqInteriorBlockInteriorEliminationdR :
    variableTrace.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  regularNoExternalTraceOracle :
    regularTrace.noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  variableNoExternalTraceOracle :
    variableTrace.noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  regularNoInverseEntryFunction :
    regularTrace.noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  variableNoInverseEntryFunction :
    variableTrace.noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation
  regularNoMatrixExport :
    regularTrace.noMatrixExportStatus =
      InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  variableNoMatrixExport :
    variableTrace.noMatrixExportStatus =
      InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation
  regularNoTwoSidedInv :
    regularTrace.noTwoSidedInvStatus =
      InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  variableNoTwoSidedInv :
    variableTrace.noTwoSidedInvStatus =
      InteriorAccumulatedTraceEvaluationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedTraceEvaluation
  regularNextPositiveConstructionGate :
    regularTrace.nextPositiveConstructionGate =
      InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate.generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry
  variableNextPositiveConstructionGate :
    variableTrace.nextPositiveConstructionGate =
      InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate.generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry
  status_eq_closed :
    status =
      InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedgerStatus.generatedInteriorEliminationTraceClosed

def generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status :=
    InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedgerStatus.generatedInteriorEliminationTraceClosed
  interiorEliminationStepLedger :=
    generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger b β p regularWeight variableWeight
      regularPivot variablePivot
  regularTrace := regularGeneratedInteriorEliminationTrace b p regularWeight
  variableTrace := variableGeneratedInteriorEliminationTrace β p variableWeight
  interiorEliminationStepLedger_eq_main := by
    rfl
  regularTrace_eq_main := by
    rfl
  variableTrace_eq_main := by
    rfl
  regularTerminates := by
    rfl
  variableTerminates := by
    rfl
  regularSourceEqInteriorBlockInteriorEliminationdR := by
    rfl
  variableSourceEqInteriorBlockInteriorEliminationdR := by
    rfl
  regularNoExternalTraceOracle := by
    rfl
  variableNoExternalTraceOracle := by
    rfl
  regularNoInverseEntryFunction := by
    rfl
  variableNoInverseEntryFunction := by
    rfl
  regularNoMatrixExport := by
    rfl
  variableNoMatrixExport := by
    rfl
  regularNoTwoSidedInv := by
    rfl
  variableNoTwoSidedInv := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedgerStatus.generatedInteriorEliminationTraceClosed := by
  rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_regularTerminates
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularTrace.terminationStatus =
      InteriorAccumulatedTraceEvaluationTerminationStatus.terminatesByFiniteInteriorCarrier := by
  rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_variableNoExternalTraceOracle
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).variableTrace.noExternalTraceOracleStatus =
      InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle := by
  rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_regularNoInverseEntryFunction
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularTrace.noInverseEntryFunctionStatus =
      InteriorAccumulatedTraceEvaluationNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorAccumulatedTraceEvaluation := by
  rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_variableNoMatrixExport
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).variableTrace.noMatrixExportStatus =
      InteriorAccumulatedTraceEvaluationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedTraceEvaluation := by
  rfl

theorem generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularTrace.nextPositiveConstructionGate =
      InteriorAccumulatedTraceEvaluationNextPositiveConstructionGate.generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntry := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
