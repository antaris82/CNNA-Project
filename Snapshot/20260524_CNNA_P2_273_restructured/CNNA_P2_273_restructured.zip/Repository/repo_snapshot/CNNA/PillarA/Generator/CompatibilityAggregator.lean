import CNNA.PillarA.Generator.TypedIOSurface

set_option autoImplicit false

namespace CNNA.PillarA.Generator

inductive NeutralGeneratorCompatibilityAggregatorStatus where
  | neutralSurfaceExposed
  deriving DecidableEq, Repr

inductive NeutralGeneratorCompatibilityCutoverStatus where
  | noCutover
  deriving DecidableEq, Repr

inductive NeutralGeneratorCompatibilityRouteExposure where
  | retainedCompatibilityRoute
  | typedIOSurfaceVisible
  deriving DecidableEq, Repr

structure NeutralGeneratorCompatibilityAggregator where
  typedSurface : NeutralGeneratorTypedIOSurface
  releaseCertificate : GeneratorOutputReleaseCertificate
  facade : GeneratorOutputCompatibilityFacade
  transition : GeneratorOutputImportTransitionCertificate
  status : NeutralGeneratorCompatibilityAggregatorStatus
  cutoverStatus : NeutralGeneratorCompatibilityCutoverStatus
  routeExposure : NeutralGeneratorCompatibilityRouteExposure
  releaseCertificate_eq : typedSurface.certificate = releaseCertificate
  facade_eq : releaseCertificate.compatibility = facade
  transition_eq : releaseCertificate.transition = transition
  status_eq :
    status = NeutralGeneratorCompatibilityAggregatorStatus.neutralSurfaceExposed
  cutoverStatus_eq :
    cutoverStatus = NeutralGeneratorCompatibilityCutoverStatus.noCutover
  routeExposure_eq :
    routeExposure =
      NeutralGeneratorCompatibilityRouteExposure.retainedCompatibilityRoute
  namespaceRoute_retained :
    typedSurface.namespaceSurface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface

namespace NeutralGeneratorCompatibilityAggregator

def state (aggregator : NeutralGeneratorCompatibilityAggregator) :
    GlobalTheoryApproximationState :=
  aggregator.typedSurface.state

def request (aggregator : NeutralGeneratorCompatibilityAggregator) :
    GeneratorRequestProfile :=
  aggregator.typedSurface.request

def output (aggregator : NeutralGeneratorCompatibilityAggregator) :
    GeneratorOutputProfile :=
  aggregator.typedSurface.output

theorem releaseCertificate_matches
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.typedSurface.certificate = aggregator.releaseCertificate :=
  aggregator.releaseCertificate_eq

theorem facade_matches_release
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.releaseCertificate.compatibility = aggregator.facade :=
  aggregator.facade_eq

theorem transition_matches_release
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.releaseCertificate.transition = aggregator.transition :=
  aggregator.transition_eq

theorem status_is_neutralSurfaceExposed
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.status =
      NeutralGeneratorCompatibilityAggregatorStatus.neutralSurfaceExposed :=
  aggregator.status_eq

theorem cutoverStatus_is_noCutover
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.cutoverStatus =
      NeutralGeneratorCompatibilityCutoverStatus.noCutover :=
  aggregator.cutoverStatus_eq

theorem routeExposure_is_retainedCompatibilityRoute
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.routeExposure =
      NeutralGeneratorCompatibilityRouteExposure.retainedCompatibilityRoute :=
  aggregator.routeExposure_eq

theorem namespaceRoute_is_retained
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.typedSurface.namespaceSurface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface :=
  aggregator.namespaceRoute_retained

theorem typedSurface_status_is_typedSurfaceOnly
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.typedSurface.status = NeutralGeneratorTypedIOStatus.typedSurfaceOnly :=
  aggregator.typedSurface.status_is_typedSurfaceOnly

theorem release_scope_is_generatorOutputLayerOnly
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.releaseCertificate.releasedScope =
      GeneratorOutputReleaseScope.generatorOutputLayerOnly :=
  aggregator.releaseCertificate.releasedScope_is_generator_output_layer_only

theorem transition_status_is_neutral_import_target
    (aggregator : NeutralGeneratorCompatibilityAggregator) :
    aggregator.transition.status =
      GeneratorOutputImportTransitionStatus.neutralGeneratorImportsCarryTarget := by
  rw [← aggregator.transition_matches_release]
  exact aggregator.releaseCertificate.transition_status_is_neutral_import_target

end NeutralGeneratorCompatibilityAggregator

end CNNA.PillarA.Generator
