import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldInvariance
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateHandoff

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

universe u

inductive InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageStatus where
  | tracePivotTerminalCoverageFromInteriorAccumulatedTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus where
  | terminalFoldResidualCoverageRequiredFromInteriorTerminalFoldResidual
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus where
  | terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoAccumulatedEntryCancellationStatus where
  | noAccumulatedEntryCancellationInvariantInTracePivotTerminalCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus where
  | noProductIdentityProofInTracePivotTerminalCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus where
  | noTwoSidedInvInTracePivotTerminalCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInTracePivotTerminalCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageNextConsumerStatus where
  | interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus where
  | tracePivotTerminalCoverageSourceAudited
  deriving DecidableEq, Repr

structure GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  traceIndexCarrier : Finset (GeneratedInteriorIndex A)
  localStepOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationStep Cell p A P wp W E K
  traceStepOf :
    (i : GeneratedInteriorIndex A) →
      GeneratedInteriorEliminationTraceStep Cell p A P wp W E K (localStepOf i)
  pivotOf : GeneratedInteriorIndex A → GeneratedInteriorIndex A
  coverageStatus : InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageStatus
  sourceStatus : InteriorAccumulatedTraceEvaluationTraceSourceStatus
  noExternalTraceOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus
  noExternalOrderOracleStatus : InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus
  noFreePivotListStatus : InteriorAccumulatedTraceEvaluationNoFreePivotListStatus
  noProductIdentityProofStatus : InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalFoldResidualCoverageNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus
  trace_eq : trace = T
  traceIndexCarrier_eq_trace : traceIndexCarrier = T.traceIndexCarrier
  traceIndexCarrier_eq_carrierIndexCarrier : traceIndexCarrier = K.indexCarrier
  localStepOf_eq_trace : ∀ i : GeneratedInteriorIndex A, localStepOf i = T.localStepOf i
  traceStepOf_localStep_eq :
    ∀ i : GeneratedInteriorIndex A, (traceStepOf i).localStep = localStepOf i
  pivotOf_eq_traceStepPivotIndex :
    ∀ i : GeneratedInteriorIndex A, pivotOf i = (traceStepOf i).pivotIndex
  pivotOf_eq_localStepPivotIndex :
    ∀ i : GeneratedInteriorIndex A, pivotOf i = (localStepOf i).pivotDatum.pivotIndex
  localStepOfEqInteriorEliminationTraceStep :
    ∀ i : GeneratedInteriorIndex A,
      localStepOf i = localStepFromInteriorEliminationCarrierNode K i
  pivotBoundToInteriorEliminationCarrierNode :
    ∀ i : GeneratedInteriorIndex A,
      (localStepOf i).pivotDatum.node = K.nodeOf (localStepOf i).pivotDatum.pivotIndex
  rowResidualEqInteriorBlockInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (localStepOf i).residualDatum.rowResidual j =
        generatedInteriorLocalRowResidual W (localStepOf i).pivotDatum.pivotIndex j
  columnResidualEqInteriorBlockInteriorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      (localStepOf i).residualDatum.columnResidual j =
        generatedInteriorLocalColumnResidual W (localStepOf i).pivotDatum.pivotIndex j
  sourceStatus_eq :
    sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  coverageStatus_eq :
    coverageStatus =
      InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageStatus.tracePivotTerminalCoverageFromInteriorAccumulatedTraceEvaluation
  noExternalTraceOracleStatus_eq :
    noExternalTraceOracleStatus = InteriorAccumulatedTraceEvaluationNoExternalTraceOracleStatus.noExternalTraceOracle
  noExternalOrderOracleStatus_eq :
    noExternalOrderOracleStatus = InteriorAccumulatedTraceEvaluationNoExternalOrderOracleStatus.noExternalOrderOracle
  noFreePivotListStatus_eq :
    noFreePivotListStatus = InteriorAccumulatedTraceEvaluationNoFreePivotListStatus.noFreePivotList
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus.noProductIdentityProofInTracePivotTerminalCoverage
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus.noInteriorEliminationDataInTracePivotTerminalCoverage
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTerminalFoldResidualCoverageNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalFoldResidualCoverage
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalFoldResidualCoverage

namespace GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T where
  trace := T
  traceIndexCarrier := T.traceIndexCarrier
  localStepOf := T.localStepOf
  traceStepOf := T.traceStepOf
  pivotOf := fun i => (T.traceStepOf i).pivotIndex
  coverageStatus :=
    InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageStatus.tracePivotTerminalCoverageFromInteriorAccumulatedTraceEvaluation
  sourceStatus := T.sourceStatus
  noExternalTraceOracleStatus := T.noExternalTraceOracleStatus
  noExternalOrderOracleStatus := T.noExternalOrderOracleStatus
  noFreePivotListStatus := T.noFreePivotListStatus
  noProductIdentityProofStatus :=
    InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus.noProductIdentityProofInTracePivotTerminalCoverage
  noTwoSidedInvStatus :=
    InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage
  noInteriorEliminationDataStatus :=
    InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus.noInteriorEliminationDataInTracePivotTerminalCoverage
  noDtnDataStatus :=
    InteriorTerminalFoldResidualCoverageNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalFoldResidualCoverage
  noArithmeticTargetStatus :=
    InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalFoldResidualCoverage
  trace_eq := by
    rfl
  traceIndexCarrier_eq_trace := by
    rfl
  traceIndexCarrier_eq_carrierIndexCarrier :=
    T.traceIndexCarrier_eq_carrierIndexCarrier
  localStepOf_eq_trace := by
    intro i
    rfl
  traceStepOf_localStep_eq :=
    T.traceStepLocalStepEqInteriorEliminationTraceStep
  pivotOf_eq_traceStepPivotIndex := by
    intro i
    rfl
  pivotOf_eq_localStepPivotIndex := by
    intro i
    exact (T.traceStepOf i).pivotIndex_eq_localStepPivotIndex
  localStepOfEqInteriorEliminationTraceStep :=
    T.localStepOfEqInteriorEliminationTraceStep
  pivotBoundToInteriorEliminationCarrierNode :=
    T.traceStepPivotBoundToInteriorEliminationCarrierNode
  rowResidualEqInteriorBlockInteriorBlock :=
    T.traceStepResidualEqInteriorBlockInteriorBlock
  columnResidualEqInteriorBlockInteriorBlock :=
    T.traceStepColumnResidualEqInteriorBlockInteriorBlock
  sourceStatus_eq :=
    T.sourceStatus_eq
  coverageStatus_eq := by
    rfl
  noExternalTraceOracleStatus_eq :=
    T.noExternalTraceOracleStatus_eq
  noExternalOrderOracleStatus_eq :=
    T.noExternalOrderOracleStatus_eq
  noFreePivotListStatus_eq :=
    T.noFreePivotListStatus_eq
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

theorem pivotCoverageSourceEqInteriorAccumulatedTraceEvaluation
    (C : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    C.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  C.sourceStatus_eq

theorem pivotCoverage_noTwoSidedInv
    (C : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    C.noTwoSidedInvStatus =
      InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage :=
  C.noTwoSidedInvStatus_eq

end GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage

structure GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  tracePivotCoverage :
    GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  accumulatedTraceEvaluation : GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T
  accumulatedEntryFold : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  requirementStatus : InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus
  exportStatus : InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus
  noAccumulatedEntryCancellationStatus : InteriorTerminalFoldResidualCoverageNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalFoldResidualCoverageNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalFoldResidualCoverageNextConsumerStatus
  invarianceStatus_eq :
    invariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :
    tracePivotCoverage.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceEvaluation_eq_invariance :
    accumulatedTraceEvaluation = invariance.blockFoldNormalForm.accumulatedTraceEvaluation
  accumulatedEntryFold_eq_invariance :
    accumulatedEntryFold = invariance.blockFoldNormalForm.accumulatedEntryFold
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  requirementStatus_eq :
    requirementStatus =
      InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus.terminalFoldResidualCoverageRequiredFromInteriorTerminalFoldResidual
  exportStatus_eq :
    exportStatus =
      InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTerminalFoldResidualCoverageNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTracePivotTerminalCoverage
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus.noProductIdentityProofInTracePivotTerminalCoverage
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus.noInteriorEliminationDataInTracePivotTerminalCoverage
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTerminalFoldResidualCoverageNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalFoldResidualCoverage
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalFoldResidualCoverage
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage

namespace GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T where
  invariance := I
  tracePivotCoverage :=
    GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.fromTrace T
  accumulatedTraceEvaluation := I.blockFoldNormalForm.accumulatedTraceEvaluation
  accumulatedEntryFold := I.blockFoldNormalForm.accumulatedEntryFold
  requirementStatus :=
    InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus.terminalFoldResidualCoverageRequiredFromInteriorTerminalFoldResidual
  exportStatus :=
    InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  noAccumulatedEntryCancellationStatus :=
    InteriorTerminalFoldResidualCoverageNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTracePivotTerminalCoverage
  noProductIdentityProofStatus :=
    InteriorTerminalFoldResidualCoverageNoProductIdentityProofStatus.noProductIdentityProofInTracePivotTerminalCoverage
  noTwoSidedInvStatus :=
    InteriorTerminalFoldResidualCoverageNoTwoSidedInvStatus.noTwoSidedInvInTracePivotTerminalCoverage
  noInteriorEliminationDataStatus :=
    InteriorTerminalFoldResidualCoverageNoInteriorEliminationDataStatus.noInteriorEliminationDataInTracePivotTerminalCoverage
  noDtnDataStatus :=
    InteriorTerminalFoldResidualCoverageNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalFoldResidualCoverage
  noArithmeticTargetStatus :=
    InteriorTerminalFoldResidualCoverageNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalFoldResidualCoverage
  nextConsumerStatus := InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  invarianceStatus_eq :=
    I.invarianceStatus_eq
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :=
    (GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.fromTrace T).sourceStatus_eq
  accumulatedTraceEvaluation_eq_invariance := by
    rfl
  accumulatedEntryFold_eq_invariance := by
    rfl
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    I.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    I.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  requirementStatus_eq := by
    rfl
  exportStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem nextClosureIsInteriorTerminalCoverageSource
    (R : GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    R.nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage :=
  R.nextConsumerStatus_eq

end GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage

structure GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  auditStatus : InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus
  terminalCoverageExportStatus : InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus
  nextConsumerStatus : InteriorTerminalFoldResidualCoverageNextConsumerStatus
  tracePivotCoverageStatus_eq :
    requirement.tracePivotCoverage.coverageStatus =
      InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageStatus.tracePivotTerminalCoverageFromInteriorAccumulatedTraceEvaluation
  terminalRequirementStatus_eq :
    requirement.requirementStatus =
      InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus.terminalFoldResidualCoverageRequiredFromInteriorTerminalFoldResidual
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  auditStatus_eq :
    auditStatus = InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus.tracePivotTerminalCoverageSourceAudited
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage

namespace GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T where
  requirement :=
    GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage.fromInvariance I
  auditStatus := InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus.tracePivotTerminalCoverageSourceAudited
  terminalCoverageExportStatus :=
    InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  nextConsumerStatus := InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  tracePivotCoverageStatus_eq := by
    rfl
  terminalRequirementStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  auditStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage

abbrev RegularGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage b p wp :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.fromTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage β p wp :=
  GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage.fromTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p wp) :
    RegularGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage b p wp :=
  GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage.fromInvariance I

def variableTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p wp) :
    VariableGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage β p wp :=
  GeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage.fromInvariance I

structure InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage b p regularWeight
  variableAudit : VariableGeneratedInteriorTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage β p variableWeight
  status : InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus
  terminalCoverageExportStatus : InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus
  nextConsumerStatus : InteriorTerminalFoldResidualCoverageNextConsumerStatus
  regularNextConsumerStatus_eq :
    regularAudit.nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  variableNextConsumerStatus_eq :
    variableAudit.nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  status_eq :
    status = InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus.tracePivotTerminalCoverageSourceAudited
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage

namespace InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger

def fromRegularAndVariableInvariance
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularInvariance : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p regularWeight)
    (variableInvariance : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p variableWeight) :
    InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger b β p regularWeight variableWeight where
  regularAudit := regularTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage regularInvariance
  variableAudit := variableTracePivotTerminalCoverageAuditInteriorTerminalFoldResidualCoverage variableInvariance
  status := InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageLedgerStatus.tracePivotTerminalCoverageSourceAudited
  terminalCoverageExportStatus :=
    InteriorTerminalFoldResidualCoverageTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilInteriorTerminalFoldResidualTerminalResidualCoverage
  nextConsumerStatus := InteriorTerminalFoldResidualCoverageNextConsumerStatus.interiorTerminalFoldResidualCoverageTerminalFoldResidualCoverage
  regularNextConsumerStatus_eq := by
    rfl
  variableNextConsumerStatus_eq := by
    rfl
  status_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalFoldResidualCoverageTracePivotTerminalCoverageSourceLedger

inductive InteriorTerminalCoverageSourceTerminalFoldStateStatus where
  | terminalFoldStateFromAccumulatedEntryFold
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceTerminalResidualCoverageStatus where
  | terminalResidualCoverageFromAccumulatedResidualAndFoldOrder
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceTerminalCoverageExportStatus where
  | terminalCoverageSourceBlockedUntilTerminalIdentityFields
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceTerminalIdentityFieldStatus where
  | terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoAccumulatedEntryCancellationStatus where
  | noAccumulatedEntryCancellationInvariantInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualCoverage
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceNextConsumerStatus where
  | interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields
  deriving DecidableEq, Repr

inductive InteriorTerminalCoverageSourceLedgerStatus where
  | terminalFoldResidualCoverageAuditClosed
  deriving DecidableEq, Repr

structure GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  accumulatedTraceEvaluation : GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T
  accumulatedEntryFold : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  terminalFoldState : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  terminalResidualContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  terminalFoldUpdateOrderContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  terminalFoldStateStatus : InteriorTerminalCoverageSourceTerminalFoldStateStatus
  terminalResidualCoverageStatus : InteriorTerminalCoverageSourceTerminalResidualCoverageStatus
  leftTerminalIdentityFieldStatus : InteriorTerminalCoverageSourceTerminalIdentityFieldStatus
  rightTerminalIdentityFieldStatus : InteriorTerminalCoverageSourceTerminalIdentityFieldStatus
  terminalCoverageExportStatus : InteriorTerminalCoverageSourceTerminalCoverageExportStatus
  noAccumulatedEntryCancellationStatus : InteriorTerminalCoverageSourceNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTerminalCoverageSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalCoverageSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalCoverageSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalCoverageSourceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalCoverageSourceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalCoverageSourceNextConsumerStatus
  invariance_eq_requirement : invariance = requirement.invariance
  accumulatedTraceEvaluation_eq_requirement :
    accumulatedTraceEvaluation = requirement.accumulatedTraceEvaluation
  accumulatedEntryFold_eq_requirement :
    accumulatedEntryFold = requirement.accumulatedEntryFold
  terminalFoldState_eq_accumulatedEntryFold : terminalFoldState = accumulatedEntryFold
  terminalResidualContribution_eq_accumulatedFold :
    ∀ i j : GeneratedInteriorIndex A,
      terminalResidualContribution i j = accumulatedEntryFold.residualContribution i j
  terminalResidualContribution_eq_trace :
    ∀ i j : GeneratedInteriorIndex A,
      terminalResidualContribution i j = generatedInteriorTraceResidualContribution T i j
  terminalFoldUpdateOrderContribution_eq_accumulatedFold :
    ∀ i j : GeneratedInteriorIndex A,
      terminalFoldUpdateOrderContribution i j =
        accumulatedEntryFold.foldUpdateOrderContribution i j
  terminalFoldUpdateOrderContribution_eq_trace :
    ∀ i j : GeneratedInteriorIndex A,
      terminalFoldUpdateOrderContribution i j =
        generatedInteriorTraceFoldUpdateOrderContribution T i j
  invarianceStatus_eq :
    invariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  requirementStatus_eq :
    requirement.requirementStatus =
      InteriorTerminalFoldResidualCoverageTerminalFoldResidualCoverageRequirementStatus.terminalFoldResidualCoverageRequiredFromInteriorTerminalFoldResidual
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :
    requirement.tracePivotCoverage.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  terminalFoldStateSourceEqInteriorTerminalFoldResidual :
    terminalFoldState.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  terminalFoldStateFoldStatus_eq :
    terminalFoldState.foldStatus =
      InteriorTerminalFoldResidualAccumulatedEntryFoldStatus.accumulatedEntryFoldFromTracePivotStepResidualAndOrder
  terminalFoldStateFoldUpdateOrderStatus_eq :
    terminalFoldState.foldUpdateOrderStatus =
      InteriorTerminalFoldResidualFoldUpdateOrderStatus.foldUpdateOrderRecordedFromTraceStepPair
  terminalFoldStateStatus_eq :
    terminalFoldStateStatus =
      InteriorTerminalCoverageSourceTerminalFoldStateStatus.terminalFoldStateFromAccumulatedEntryFold
  terminalResidualCoverageStatus_eq :
    terminalResidualCoverageStatus =
      InteriorTerminalCoverageSourceTerminalResidualCoverageStatus.terminalResidualCoverageFromAccumulatedResidualAndFoldOrder
  leftTerminalIdentityFieldStatus_eq :
    leftTerminalIdentityFieldStatus =
      InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  rightTerminalIdentityFieldStatus_eq :
    rightTerminalIdentityFieldStatus =
      InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTerminalCoverageSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalFoldResidualCoverage
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalCoverageSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualCoverage
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalCoverageSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualCoverage
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalCoverageSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalFoldResidualCoverage
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTerminalCoverageSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualCoverage
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalCoverageSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualCoverage
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalCoverageSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields

namespace GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromRequirement
    (R : GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T where
  requirement := R
  invariance := R.invariance
  accumulatedTraceEvaluation := R.accumulatedTraceEvaluation
  accumulatedEntryFold := R.accumulatedEntryFold
  terminalFoldState := R.accumulatedEntryFold
  terminalResidualContribution := R.accumulatedEntryFold.residualContribution
  terminalFoldUpdateOrderContribution := R.accumulatedEntryFold.foldUpdateOrderContribution
  terminalFoldStateStatus :=
    InteriorTerminalCoverageSourceTerminalFoldStateStatus.terminalFoldStateFromAccumulatedEntryFold
  terminalResidualCoverageStatus :=
    InteriorTerminalCoverageSourceTerminalResidualCoverageStatus.terminalResidualCoverageFromAccumulatedResidualAndFoldOrder
  leftTerminalIdentityFieldStatus :=
    InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  rightTerminalIdentityFieldStatus :=
    InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  terminalCoverageExportStatus :=
    InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  noAccumulatedEntryCancellationStatus :=
    InteriorTerminalCoverageSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalFoldResidualCoverage
  noProductIdentityProofStatus :=
    InteriorTerminalCoverageSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualCoverage
  noTwoSidedInvStatus :=
    InteriorTerminalCoverageSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualCoverage
  noInteriorEliminationDataStatus :=
    InteriorTerminalCoverageSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalFoldResidualCoverage
  noDtnDataStatus :=
    InteriorTerminalCoverageSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualCoverage
  noArithmeticTargetStatus :=
    InteriorTerminalCoverageSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualCoverage
  nextConsumerStatus :=
    InteriorTerminalCoverageSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields
  invariance_eq_requirement := by
    rfl
  accumulatedTraceEvaluation_eq_requirement := by
    rfl
  accumulatedEntryFold_eq_requirement := by
    rfl
  terminalFoldState_eq_accumulatedEntryFold := by
    rfl
  terminalResidualContribution_eq_accumulatedFold := by
    intro i j
    rfl
  terminalResidualContribution_eq_trace := by
    intro i j
    exact R.accumulatedEntryFold.residualContribution_from_traceResidualData i j
  terminalFoldUpdateOrderContribution_eq_accumulatedFold := by
    intro i j
    rfl
  terminalFoldUpdateOrderContribution_eq_trace := by
    intro i j
    exact R.accumulatedEntryFold.foldUpdateOrderContribution_from_traceStepOrder i j
  invarianceStatus_eq :=
    R.invarianceStatus_eq
  requirementStatus_eq :=
    R.requirementStatus_eq
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :=
    R.tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    R.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    R.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  terminalFoldStateSourceEqInteriorTerminalFoldResidual :=
    R.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  terminalFoldStateFoldStatus_eq :=
    R.accumulatedEntryFold.foldStatus_eq
  terminalFoldStateFoldUpdateOrderStatus_eq :=
    R.accumulatedEntryFold.foldUpdateOrderStatus_eq
  terminalFoldStateStatus_eq := by
    rfl
  terminalResidualCoverageStatus_eq := by
    rfl
  leftTerminalIdentityFieldStatus_eq := by
    rfl
  rightTerminalIdentityFieldStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T :=
  fromRequirement (GeneratedInteriorTerminalFoldResidualCoverageRequirementInteriorTerminalFoldResidualCoverage.fromInvariance I)

theorem terminalResidualContribution_from_trace
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    C.terminalResidualContribution i j = generatedInteriorTraceResidualContribution T i j :=
  C.terminalResidualContribution_eq_trace i j

theorem terminalFoldUpdateOrderContribution_from_trace
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    C.terminalFoldUpdateOrderContribution i j =
      generatedInteriorTraceFoldUpdateOrderContribution T i j :=
  C.terminalFoldUpdateOrderContribution_eq_trace i j

theorem terminalCoverageSource_still_blocked
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    C.terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields :=
  C.terminalCoverageExportStatus_eq

theorem noProductIdentityProof
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    C.noProductIdentityProofStatus =
      InteriorTerminalCoverageSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualCoverage :=
  C.noProductIdentityProofStatus_eq

theorem noTwoSidedInv
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    C.noTwoSidedInvStatus =
      InteriorTerminalCoverageSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualCoverage :=
  C.noTwoSidedInvStatus_eq

theorem nextClosureIsInteriorTerminalIdentityFieldSource
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    C.nextConsumerStatus =
      InteriorTerminalCoverageSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields :=
  C.nextConsumerStatus_eq

end GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource

abbrev RegularGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource b p wp :=
  GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource.fromInvariance I

def variableTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (I : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource β p wp :=
  GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource.fromInvariance I

structure InteriorTerminalCoverageSourceTerminalFoldResidualCoverageLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularCoverageAudit : RegularGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource b p regularWeight
  variableCoverageAudit : VariableGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource β p variableWeight
  ledgerStatus : InteriorTerminalCoverageSourceLedgerStatus
  terminalFoldStateStatus : InteriorTerminalCoverageSourceTerminalFoldStateStatus
  terminalResidualCoverageStatus : InteriorTerminalCoverageSourceTerminalResidualCoverageStatus
  terminalCoverageExportStatus : InteriorTerminalCoverageSourceTerminalCoverageExportStatus
  nextConsumerStatus : InteriorTerminalCoverageSourceNextConsumerStatus
  regularExportStatus_eq :
    regularCoverageAudit.terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  variableExportStatus_eq :
    variableCoverageAudit.terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  regularNoTwoSidedInvStatus_eq :
    regularCoverageAudit.noTwoSidedInvStatus =
      InteriorTerminalCoverageSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualCoverage
  variableNoTwoSidedInvStatus_eq :
    variableCoverageAudit.noTwoSidedInvStatus =
      InteriorTerminalCoverageSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualCoverage
  ledgerStatus_eq :
    ledgerStatus = InteriorTerminalCoverageSourceLedgerStatus.terminalFoldResidualCoverageAuditClosed
  terminalFoldStateStatus_eq :
    terminalFoldStateStatus =
      InteriorTerminalCoverageSourceTerminalFoldStateStatus.terminalFoldStateFromAccumulatedEntryFold
  terminalResidualCoverageStatus_eq :
    terminalResidualCoverageStatus =
      InteriorTerminalCoverageSourceTerminalResidualCoverageStatus.terminalResidualCoverageFromAccumulatedResidualAndFoldOrder
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalCoverageSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields

namespace InteriorTerminalCoverageSourceTerminalFoldResidualCoverageLedger

def fromRegularAndVariableInvariance
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularInvariance : RegularGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance b p regularWeight)
    (variableInvariance : VariableGeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance β p variableWeight) :
    InteriorTerminalCoverageSourceTerminalFoldResidualCoverageLedger b β p regularWeight variableWeight where
  regularCoverageAudit := regularTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource regularInvariance
  variableCoverageAudit := variableTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource variableInvariance
  ledgerStatus := InteriorTerminalCoverageSourceLedgerStatus.terminalFoldResidualCoverageAuditClosed
  terminalFoldStateStatus :=
    InteriorTerminalCoverageSourceTerminalFoldStateStatus.terminalFoldStateFromAccumulatedEntryFold
  terminalResidualCoverageStatus :=
    InteriorTerminalCoverageSourceTerminalResidualCoverageStatus.terminalResidualCoverageFromAccumulatedResidualAndFoldOrder
  terminalCoverageExportStatus :=
    InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  nextConsumerStatus :=
    InteriorTerminalCoverageSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityFieldsExposeTerminalFoldResidualIdentityFields
  regularExportStatus_eq := by
    rfl
  variableExportStatus_eq := by
    rfl
  regularNoTwoSidedInvStatus_eq := by
    rfl
  variableNoTwoSidedInvStatus_eq := by
    rfl
  ledgerStatus_eq := by
    rfl
  terminalFoldStateStatus_eq := by
    rfl
  terminalResidualCoverageStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalCoverageSourceTerminalFoldResidualCoverageLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
