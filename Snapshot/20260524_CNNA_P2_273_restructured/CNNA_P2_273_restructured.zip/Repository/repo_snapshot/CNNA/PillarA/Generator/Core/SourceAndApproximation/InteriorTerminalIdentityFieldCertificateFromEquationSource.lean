import CNNA.PillarA.Generator.Core.SourceAndApproximation.InteriorTerminalFoldResidualIdentityEquationSource
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
import CNNA.PillarA.Generator.Schur.GeneratedPipeline.MultiSchur

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTerminalIdentityFieldCertificateFromEquationSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTerminalFoldResidualIdentityEquationSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity

universe u

inductive InteriorTerminalIdentityFieldCertificateSourceCertificateSourceStatus where
  | terminalIdentityFieldCertificateFromInteriorTerminalIdentityEquationSourceEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceTerminalCoverageExportStatus where
  | terminalCoverageSourceFromInteriorTerminalIdentityFieldSourceCertificate
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceEquationDatumSourceStatus where
  | equationDatumCarriedOnlyByInteriorTerminalIdentityEquationSourceSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoFreeIdentityFieldStatus where
  | noFreeIdentityFieldsInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalIdentityFieldCertificateSourceExport
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldCertificateSourceLedgerStatus where
  | terminalIdentityFieldCertificateAndCoverageExportFromEquationSource
  deriving DecidableEq, Repr

def terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T :=
  terminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

def blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T :=
  GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity.fromInteriorTerminalIdentityFieldSourceTerminalIdentityFieldCertificate
    (terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S)

structure GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  equationSource : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T
  equationDatum : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T
  terminalIdentityFieldCertificate : GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T
  terminalCoverageSource : GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T
  certificateSourceStatus : InteriorTerminalIdentityFieldCertificateSourceCertificateSourceStatus
  terminalCoverageExportStatus : InteriorTerminalIdentityFieldCertificateSourceTerminalCoverageExportStatus
  equationDatumSourceStatus : InteriorTerminalIdentityFieldCertificateSourceEquationDatumSourceStatus
  noFreeIdentityFieldStatus : InteriorTerminalIdentityFieldCertificateSourceNoFreeIdentityFieldStatus
  noProductIdentityProofStatus : InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalIdentityFieldCertificateSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalIdentityFieldCertificateSourceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalIdentityFieldCertificateSourceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus
  equationDatum_eq_source : equationDatum = equationSource.equationDatum
  terminalIdentityFieldCertificate_eq_source :
    terminalIdentityFieldCertificate =
      terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource equationSource
  terminalCoverageSource_eq_certificate :
    terminalCoverageSource =
      GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity.fromInteriorTerminalIdentityFieldSourceTerminalIdentityFieldCertificate
        terminalIdentityFieldCertificate
  terminalCoverageSource_eq_source :
    terminalCoverageSource =
      blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource equationSource
  equationSourceStatus_eq :
    equationSource.equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceCarriedByDatum
  equationSourceCertificateExportStatus_eq :
    equationSource.certificateExportStatus =
      InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificatePreparedFromEquationSource
  certificateNextConsumerStatus_eq :
    terminalIdentityFieldCertificate.nextConsumerStatus =
      InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  terminalCoverageTracePivotCoverageStatus_eq :
    terminalCoverageSource.tracePivotCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTracePivotCoverageStatus.sourceFromInteriorAccumulatedTraceEvaluationTracePivotCoverage
  terminalCoverageFoldResidualCoverageStatus_eq :
    terminalCoverageSource.terminalFoldResidualCoverageStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalFoldResidualCoverageStatus.sourceFromInteriorTerminalFoldResidualTerminalFoldResidualCoverage
  certificateSourceStatus_eq :
    certificateSourceStatus =
      InteriorTerminalIdentityFieldCertificateSourceCertificateSourceStatus.terminalIdentityFieldCertificateFromInteriorTerminalIdentityEquationSourceEquationSource
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldCertificateSourceTerminalCoverageExportStatus.terminalCoverageSourceFromInteriorTerminalIdentityFieldSourceCertificate
  equationDatumSourceStatus_eq :
    equationDatumSourceStatus =
      InteriorTerminalIdentityFieldCertificateSourceEquationDatumSourceStatus.equationDatumCarriedOnlyByInteriorTerminalIdentityEquationSourceSource
  noFreeIdentityFieldStatus_eq :
    noFreeIdentityFieldStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoFreeIdentityFieldStatus.noFreeIdentityFieldsInInteriorTerminalIdentityFieldCertificateSourceExport
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus.noProductIdentityProofInInteriorTerminalIdentityFieldCertificateSourceExport
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus.noTwoSidedInvInInteriorTerminalIdentityFieldCertificateSourceExport
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTerminalIdentityFieldCertificateSourceExport
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTerminalIdentityFieldCertificateSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalIdentityFieldCertificateSourceExport
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalIdentityFieldCertificateSourceExport
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer

namespace GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromEquationSource
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T where
  equationSource := S
  equationDatum := S.equationDatum
  terminalIdentityFieldCertificate :=
    terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S
  terminalCoverageSource := blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S
  certificateSourceStatus :=
    InteriorTerminalIdentityFieldCertificateSourceCertificateSourceStatus.terminalIdentityFieldCertificateFromInteriorTerminalIdentityEquationSourceEquationSource
  terminalCoverageExportStatus :=
    InteriorTerminalIdentityFieldCertificateSourceTerminalCoverageExportStatus.terminalCoverageSourceFromInteriorTerminalIdentityFieldSourceCertificate
  equationDatumSourceStatus :=
    InteriorTerminalIdentityFieldCertificateSourceEquationDatumSourceStatus.equationDatumCarriedOnlyByInteriorTerminalIdentityEquationSourceSource
  noFreeIdentityFieldStatus :=
    InteriorTerminalIdentityFieldCertificateSourceNoFreeIdentityFieldStatus.noFreeIdentityFieldsInInteriorTerminalIdentityFieldCertificateSourceExport
  noProductIdentityProofStatus :=
    InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus.noProductIdentityProofInInteriorTerminalIdentityFieldCertificateSourceExport
  noTwoSidedInvStatus := InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus.noTwoSidedInvInInteriorTerminalIdentityFieldCertificateSourceExport
  noInteriorEliminationDataStatus :=
    InteriorTerminalIdentityFieldCertificateSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorTerminalIdentityFieldCertificateSourceExport
  noDtnDataStatus := InteriorTerminalIdentityFieldCertificateSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTerminalIdentityFieldCertificateSourceExport
  noArithmeticTargetStatus :=
    InteriorTerminalIdentityFieldCertificateSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTerminalIdentityFieldCertificateSourceExport
  nextConsumerStatus := InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  equationDatum_eq_source := by
    rfl
  terminalIdentityFieldCertificate_eq_source := by
    rfl
  terminalCoverageSource_eq_certificate := by
    rfl
  terminalCoverageSource_eq_source := by
    rfl
  equationSourceStatus_eq :=
    S.equationSourceStatus_eq
  equationSourceCertificateExportStatus_eq :=
    S.certificateExportStatus_eq
  certificateNextConsumerStatus_eq := by
    rfl
  terminalCoverageTracePivotCoverageStatus_eq := by
    rfl
  terminalCoverageFoldResidualCoverageStatus_eq := by
    rfl
  certificateSourceStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  equationDatumSourceStatus_eq := by
    rfl
  noFreeIdentityFieldStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem noProductIdentityProof
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus.noProductIdentityProofInInteriorTerminalIdentityFieldCertificateSourceExport :=
  X.noProductIdentityProofStatus_eq

theorem noTwoSidedInv
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.noTwoSidedInvStatus = InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus.noTwoSidedInvInInteriorTerminalIdentityFieldCertificateSourceExport :=
  X.noTwoSidedInvStatus_eq

theorem terminalCoverageSource_from_source
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.terminalCoverageSource = blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource X.equationSource :=
  X.terminalCoverageSource_eq_source

end GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource

abbrev RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p wp :=
  terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

def variableTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p wp :=
  terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

def regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p wp :=
  regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldSource
    (regularTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S)

def variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p wp :=
  variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldSource
    (variableTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S)

def regularTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource b p wp :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.fromEquationSource S

def variableTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource β p wp :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.fromEquationSource S

structure InteriorTerminalIdentityFieldCertificateSourceTerminalIdentityFieldCertificateFromEquationSourceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  equationSourceLedger : InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger b β p regularWeight variableWeight
  regularExport : RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource b p regularWeight
  variableExport : VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource β p variableWeight
  regularCertificate : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p regularWeight
  variableCertificate : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p variableWeight
  regularTerminalCoverageSource : RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p regularWeight
  variableTerminalCoverageSource : VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p variableWeight
  ledgerStatus : InteriorTerminalIdentityFieldCertificateSourceLedgerStatus
  nextConsumerStatus : InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus
  regularExport_eq_source :
    regularExport =
      regularTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource equationSourceLedger.regularSource
  variableExport_eq_source :
    variableExport =
      variableTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource equationSourceLedger.variableSource
  regularCertificate_eq_export :
    regularCertificate = regularExport.terminalIdentityFieldCertificate
  variableCertificate_eq_export :
    variableCertificate = variableExport.terminalIdentityFieldCertificate
  regularCoverage_eq_export :
    regularTerminalCoverageSource = regularExport.terminalCoverageSource
  variableCoverage_eq_export :
    variableTerminalCoverageSource = variableExport.terminalCoverageSource
  regularCertificate_eq_VLedger :
    regularCertificate = equationSourceLedger.regularCertificate
  variableCertificate_eq_VLedger :
    variableCertificate = equationSourceLedger.variableCertificate
  regularCoverage_eq_source :
    regularTerminalCoverageSource =
      regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource equationSourceLedger.regularSource
  variableCoverage_eq_source :
    variableTerminalCoverageSource =
      variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource equationSourceLedger.variableSource
  ledgerStatus_eq :
    ledgerStatus =
      InteriorTerminalIdentityFieldCertificateSourceLedgerStatus.terminalIdentityFieldCertificateAndCoverageExportFromEquationSource
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer

namespace InteriorTerminalIdentityFieldCertificateSourceTerminalIdentityFieldCertificateFromEquationSourceLedger

def fromInteriorTerminalIdentityEquationSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger b β p regularWeight variableWeight) :
    InteriorTerminalIdentityFieldCertificateSourceTerminalIdentityFieldCertificateFromEquationSourceLedger b β p regularWeight variableWeight where
  equationSourceLedger := L
  regularExport := regularTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource L.regularSource
  variableExport := variableTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource L.variableSource
  regularCertificate := L.regularCertificate
  variableCertificate := L.variableCertificate
  regularTerminalCoverageSource := regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource L.regularSource
  variableTerminalCoverageSource := variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource L.variableSource
  ledgerStatus := InteriorTerminalIdentityFieldCertificateSourceLedgerStatus.terminalIdentityFieldCertificateAndCoverageExportFromEquationSource
  nextConsumerStatus := InteriorTerminalIdentityFieldCertificateSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  regularExport_eq_source := by
    rfl
  variableExport_eq_source := by
    rfl
  regularCertificate_eq_export := by
    exact L.regularCertificate_eq_source
  variableCertificate_eq_export := by
    exact L.variableCertificate_eq_source
  regularCoverage_eq_export := by
    rfl
  variableCoverage_eq_export := by
    rfl
  regularCertificate_eq_VLedger := by
    rfl
  variableCertificate_eq_VLedger := by
    rfl
  regularCoverage_eq_source := by
    rfl
  variableCoverage_eq_source := by
    rfl
  ledgerStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalIdentityFieldCertificateSourceTerminalIdentityFieldCertificateFromEquationSourceLedger

abbrev terminalFoldResidualIdentityFieldCertificateFromEquationSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T :=
  terminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

abbrev blockFoldTerminalCoverageSourceFromEquationSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T :=
  blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

abbrev GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSource :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource

namespace GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev fromEquationSource
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.fromEquationSource S

abbrev noProductIdentityProof
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldCertificateSourceNoProductIdentityProofStatus.noProductIdentityProofInInteriorTerminalIdentityFieldCertificateSourceExport :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.noProductIdentityProof X

abbrev noTwoSidedInv
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.noTwoSidedInvStatus = InteriorTerminalIdentityFieldCertificateSourceNoTwoSidedInvStatus.noTwoSidedInvInInteriorTerminalIdentityFieldCertificateSourceExport :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.noTwoSidedInv X

abbrev terminalCoverageSource_from_source
    (X : GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource Cell p A P wp W E K T) :
    X.terminalCoverageSource = blockFoldTerminalCoverageSourceFromEquationSourceInteriorTerminalIdentityFieldCertificateSource X.equationSource :=
  GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource.terminalCoverageSource_from_source X

end GeneratedInteriorTerminalIdentityFieldCertificateFromEquationSource

abbrev RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSource :=
  RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource

abbrev VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSource :=
  VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource

abbrev regularTerminalFoldResidualIdentityFieldCertificateFromEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p wp :=
  regularTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

abbrev variableTerminalFoldResidualIdentityFieldCertificateFromEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p wp :=
  variableTerminalFoldResidualIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

abbrev regularBlockFoldTerminalCoverageSourceFromEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity b p wp :=
  regularBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource S

abbrev variableBlockFoldTerminalCoverageSourceFromEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentity β p wp :=
  variableBlockFoldTerminalCoverageSourceInteriorBlockFoldTerminalIdentityFromInteriorTerminalIdentityFieldCertificateSource S

abbrev regularTerminalIdentityFieldCertificateFromEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource b p wp :=
  regularTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

abbrev variableTerminalIdentityFieldCertificateFromEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource β p wp :=
  variableTerminalIdentityFieldCertificateFromEquationSourceInteriorTerminalIdentityFieldCertificateSource S

end CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTerminalIdentityFieldCertificateFromEquationSource
