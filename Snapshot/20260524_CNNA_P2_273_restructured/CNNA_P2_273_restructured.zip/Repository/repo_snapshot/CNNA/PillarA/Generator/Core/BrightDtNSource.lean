import CNNA.PillarA.Generator.Core.MatrixTransport

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u v

namespace BoundarySource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}

inductive BoundaryMatrixProfileProfileMatrixKind where
  | brightBrightSchur
  | dtn
  | char
  deriving DecidableEq, Repr

structure BoundaryMatrixProfileBoundaryTransportAnchors
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySourceSurface source L) where
  dtnContribution : source.dtn = source.multiSchur.binary
  generalizedDtNContribution : source.generalizedDtN = source.multiSchur.generalized
  brightBrightSchurContribution : source.coupling = source.multiSchur
  matrixDerivedFromSource :
    MatrixDerivedFrom source L B.interface.provenance.carrier
      B.interface.provenance.matrixPackage.matrix
  noCutSpecCarrierClaim :
    ∀ _k : LevelHistoryIndex L,
      source.toc.approximant source.concretePolicy = T
  route : B.interface.route = BoundarySourceRoute.recursiveHistory
  consumptionPolicy :
    B.consumptionPolicy = BoundarySourceConsumptionPolicy.boundarySourceOnly

namespace BoundaryMatrixProfileBoundaryTransportAnchors

variable {source : ArithmeticSource Cell T} {L : Nat}

def fromBoundarySource (B : BoundarySourceSurface source L) :
    BoundaryMatrixProfileBoundaryTransportAnchors B where
  dtnContribution := B.dtnContribution_eq
  generalizedDtNContribution := B.generalizedDtNContribution_eq
  brightBrightSchurContribution := B.schurContribution_eq
  matrixDerivedFromSource := B.matrixDerivedFromSource
  noCutSpecCarrierClaim := by
    intro k
    exact B.noCutSpecCarrierClaim_at k
  route := B.route_recursiveHistory
  consumptionPolicy := B.consumptionPolicy_is_interfaceOnly

theorem dtnContribution_eq
    {B : BoundarySourceSurface source L}
    (A : BoundaryMatrixProfileBoundaryTransportAnchors B) :
    source.dtn = source.multiSchur.binary :=
  A.dtnContribution

theorem generalizedDtNContribution_eq
    {B : BoundarySourceSurface source L}
    (A : BoundaryMatrixProfileBoundaryTransportAnchors B) :
    source.generalizedDtN = source.multiSchur.generalized :=
  A.generalizedDtNContribution

theorem brightBrightSchurContribution_eq
    {B : BoundarySourceSurface source L}
    (A : BoundaryMatrixProfileBoundaryTransportAnchors B) :
    source.coupling = source.multiSchur :=
  A.brightBrightSchurContribution

theorem noCutSpecCarrierClaim_at
    {B : BoundarySourceSurface source L}
    (A : BoundaryMatrixProfileBoundaryTransportAnchors B) (k : LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  A.noCutSpecCarrierClaim k

end BoundaryMatrixProfileBoundaryTransportAnchors

structure BoundaryMatrixProfileBrightDtNSourceRef16BB
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySourceSurface source L) where
  kind : BoundaryMatrixProfileProfileMatrixKind
  matrix : Matrix B.interface.index B.interface.index ExecComplex
  matrix_eq_boundarySource : matrix = B.interface.matrix
  anchors : BoundaryMatrixProfileBoundaryTransportAnchors B

namespace BoundaryMatrixProfileBrightDtNSourceRef16BB

variable {source : ArithmeticSource Cell T} {L : Nat}

def fromBoundarySource
    (B : BoundarySourceSurface source L) (kind : BoundaryMatrixProfileProfileMatrixKind) :
    BoundaryMatrixProfileBrightDtNSourceRef16BB B where
  kind := kind
  matrix := B.interface.matrix
  matrix_eq_boundarySource := by
    rfl
  anchors := BoundaryMatrixProfileBoundaryTransportAnchors.fromBoundarySource B

def brightBrightSchur (B : BoundarySourceSurface source L) :
    BoundaryMatrixProfileBrightDtNSourceRef16BB B :=
  fromBoundarySource B BoundaryMatrixProfileProfileMatrixKind.brightBrightSchur

def dtn (B : BoundarySourceSurface source L) :
    BoundaryMatrixProfileBrightDtNSourceRef16BB B :=
  fromBoundarySource B BoundaryMatrixProfileProfileMatrixKind.dtn

def char (B : BoundarySourceSurface source L) :
    BoundaryMatrixProfileBrightDtNSourceRef16BB B :=
  fromBoundarySource B BoundaryMatrixProfileProfileMatrixKind.char

theorem matrix_eq_boundarySource_holds
    {B : BoundarySourceSurface source L}
    (P : BoundaryMatrixProfileBrightDtNSourceRef16BB B) :
    P.matrix = B.interface.matrix :=
  P.matrix_eq_boundarySource

theorem component_identity
    {B : BoundarySourceSurface source L}
    (P : BoundaryMatrixProfileBrightDtNSourceRef16BB B)
    (i j : B.interface.index) :
    P.matrix i j = B.interface.matrix i j := by
  rw [P.matrix_eq_boundarySource]

theorem route_recursiveHistory
    {B : BoundarySourceSurface source L}
    (P : BoundaryMatrixProfileBrightDtNSourceRef16BB B) :
    B.interface.route = BoundarySourceRoute.recursiveHistory :=
  P.anchors.route

theorem matrixDerivedFromSource
    {B : BoundarySourceSurface source L}
    (P : BoundaryMatrixProfileBrightDtNSourceRef16BB B) :
    MatrixDerivedFrom source L B.interface.provenance.carrier
      B.interface.provenance.matrixPackage.matrix :=
  P.anchors.matrixDerivedFromSource

theorem noCutSpecCarrierClaim_at
    {B : BoundarySourceSurface source L}
    (P : BoundaryMatrixProfileBrightDtNSourceRef16BB B) (k : LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  P.anchors.noCutSpecCarrierClaim k

end BoundaryMatrixProfileBrightDtNSourceRef16BB

structure BoundaryMatrixProfileBoundaryPullbackProfile
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySourceSurface source L)
    (kind : BoundaryMatrixProfileProfileMatrixKind)
    (κ : Type v) where
  sourceIndexEquiv : B.interface.index ≃ κ
  sourceMatrix : Matrix κ κ ExecComplex
  matrix : Matrix B.interface.index B.interface.index ExecComplex
  matrix_eq_pullback :
    matrix = MatrixTransport.pullback sourceIndexEquiv sourceMatrix
  anchors : BoundaryMatrixProfileBoundaryTransportAnchors B

namespace BoundaryMatrixProfileBoundaryPullbackProfile

variable {source : ArithmeticSource Cell T} {L : Nat}
variable {B : BoundarySourceSurface source L}
variable {kind : BoundaryMatrixProfileProfileMatrixKind}
variable {κ : Type v}

def fromMatrix
    (B : BoundarySourceSurface source L)
    (kind : BoundaryMatrixProfileProfileMatrixKind)
    (e : B.interface.index ≃ κ)
    (A : Matrix κ κ ExecComplex) :
    BoundaryMatrixProfileBoundaryPullbackProfile B kind κ where
  sourceIndexEquiv := e
  sourceMatrix := A
  matrix := MatrixTransport.pullback e A
  matrix_eq_pullback := by
    rfl
  anchors := BoundaryMatrixProfileBoundaryTransportAnchors.fromBoundarySource B

theorem component_identity
    (P : BoundaryMatrixProfileBoundaryPullbackProfile B kind κ)
    (i j : B.interface.index) :
    P.matrix i j = P.sourceMatrix (P.sourceIndexEquiv i) (P.sourceIndexEquiv j) := by
  rw [P.matrix_eq_pullback]
  rfl

theorem noCutSpecCarrierClaim_at
    (P : BoundaryMatrixProfileBoundaryPullbackProfile B kind κ)
    (k : LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  P.anchors.noCutSpecCarrierClaim k

end BoundaryMatrixProfileBoundaryPullbackProfile

structure BoundaryMatrixProfileBoundaryPushforwardProfile
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySourceSurface source L)
    (kind : BoundaryMatrixProfileProfileMatrixKind)
    (κ : Type v) where
  targetIndexEquiv : B.interface.index ≃ κ
  matrix : Matrix κ κ ExecComplex
  matrix_eq_pushforward :
    matrix = MatrixTransport.pushforward targetIndexEquiv B.interface.matrix
  anchors : BoundaryMatrixProfileBoundaryTransportAnchors B

namespace BoundaryMatrixProfileBoundaryPushforwardProfile

variable {source : ArithmeticSource Cell T} {L : Nat}
variable {B : BoundarySourceSurface source L}
variable {kind : BoundaryMatrixProfileProfileMatrixKind}
variable {κ : Type v}

def fromBoundarySource
    (B : BoundarySourceSurface source L)
    (kind : BoundaryMatrixProfileProfileMatrixKind)
    (e : B.interface.index ≃ κ) :
    BoundaryMatrixProfileBoundaryPushforwardProfile B kind κ where
  targetIndexEquiv := e
  matrix := MatrixTransport.pushforward e B.interface.matrix
  matrix_eq_pushforward := by
    rfl
  anchors := BoundaryMatrixProfileBoundaryTransportAnchors.fromBoundarySource B

theorem component_identity
    (P : BoundaryMatrixProfileBoundaryPushforwardProfile B kind κ)
    (i j : κ) :
    P.matrix i j = B.interface.matrix (P.targetIndexEquiv.symm i)
      (P.targetIndexEquiv.symm j) := by
  rw [P.matrix_eq_pushforward]
  rfl

theorem noCutSpecCarrierClaim_at
    (P : BoundaryMatrixProfileBoundaryPushforwardProfile B kind κ)
    (k : LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  P.anchors.noCutSpecCarrierClaim k

end BoundaryMatrixProfileBoundaryPushforwardProfile

structure BoundaryMatrixProfileMatrixTransportLedger
    (source : ArithmeticSource Cell T) (L : Nat) where
  boundarySource : BoundarySourceSurface source L
  brightBrightSchurProfile : BoundaryMatrixProfileBrightDtNSourceRef16BB boundarySource
  brightBrightSchurProfile_kind :
    brightBrightSchurProfile.kind = BoundaryMatrixProfileProfileMatrixKind.brightBrightSchur
  dtnProfile : BoundaryMatrixProfileBrightDtNSourceRef16BB boundarySource
  dtnProfile_kind : dtnProfile.kind = BoundaryMatrixProfileProfileMatrixKind.dtn
  charProfile : BoundaryMatrixProfileBrightDtNSourceRef16BB boundarySource
  charProfile_kind : charProfile.kind = BoundaryMatrixProfileProfileMatrixKind.char
  route : boundarySource.interface.route = BoundarySourceRoute.recursiveHistory
  consumptionPolicy :
    boundarySource.consumptionPolicy = BoundarySourceConsumptionPolicy.boundarySourceOnly
  noFreeBoundaryData : BoundarySourceNoFreeBoundaryData boundarySource.interface

namespace BoundaryMatrixProfileMatrixTransportLedger

variable {source : ArithmeticSource Cell T} {L : Nat}

def fromBoundarySource (B : BoundarySourceSurface source L) :
    BoundaryMatrixProfileMatrixTransportLedger source L where
  boundarySource := B
  brightBrightSchurProfile := BoundaryMatrixProfileBrightDtNSourceRef16BB.brightBrightSchur B
  brightBrightSchurProfile_kind := by
    rfl
  dtnProfile := BoundaryMatrixProfileBrightDtNSourceRef16BB.dtn B
  dtnProfile_kind := by
    rfl
  charProfile := BoundaryMatrixProfileBrightDtNSourceRef16BB.char B
  charProfile_kind := by
    rfl
  route := B.route_recursiveHistory
  consumptionPolicy := B.consumptionPolicy_is_interfaceOnly
  noFreeBoundaryData := B.noFreeBoundaryData

theorem brightBrightSchur_component_identity
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L)
    (i j : Ldg.boundarySource.interface.index) :
    Ldg.brightBrightSchurProfile.matrix i j =
      Ldg.boundarySource.interface.matrix i j := by
  exact Ldg.brightBrightSchurProfile.component_identity i j

theorem dtn_component_identity
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L)
    (i j : Ldg.boundarySource.interface.index) :
    Ldg.dtnProfile.matrix i j =
      Ldg.boundarySource.interface.matrix i j := by
  exact Ldg.dtnProfile.component_identity i j

theorem char_component_identity
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L)
    (i j : Ldg.boundarySource.interface.index) :
    Ldg.charProfile.matrix i j =
      Ldg.boundarySource.interface.matrix i j := by
  exact Ldg.charProfile.component_identity i j

theorem route_recursiveHistory
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L) :
    Ldg.boundarySource.interface.route = BoundarySourceRoute.recursiveHistory :=
  Ldg.route

theorem consumptionPolicy_boundarySourceOnly
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L) :
    Ldg.boundarySource.consumptionPolicy =
      BoundarySourceConsumptionPolicy.boundarySourceOnly :=
  Ldg.consumptionPolicy

theorem noCutSpecCarrierClaim_at
    (Ldg : BoundaryMatrixProfileMatrixTransportLedger source L)
    (k : LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  Ldg.noFreeBoundaryData.noCutSpecCarrierClaim k

end BoundaryMatrixProfileMatrixTransportLedger

end BoundarySource

namespace StrengtheningBoundaryMatrixProfile

abbrev BoundaryMatrixProfileProfileMatrixKind := BoundarySource.BoundaryMatrixProfileProfileMatrixKind

abbrev BoundaryMatrixProfileBoundaryTransportAnchorsOf
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface (Cell := Cell) (T := T) source L) :=
  BoundarySource.BoundaryMatrixProfileBoundaryTransportAnchors B

abbrev BoundaryMatrixProfileOf
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface (Cell := Cell) (T := T) source L) :=
  BoundarySource.BoundaryMatrixProfileBrightDtNSourceRef16BB B

abbrev BoundaryMatrixProfileBoundaryPullbackProfileOf
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface (Cell := Cell) (T := T) source L)
    (kind : BoundarySource.BoundaryMatrixProfileProfileMatrixKind)
    (κ : Type v) :=
  BoundarySource.BoundaryMatrixProfileBoundaryPullbackProfile B kind κ

abbrev BoundaryMatrixProfileBoundaryPushforwardProfileOf
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface (Cell := Cell) (T := T) source L)
    (kind : BoundarySource.BoundaryMatrixProfileProfileMatrixKind)
    (κ : Type v) :=
  BoundarySource.BoundaryMatrixProfileBoundaryPushforwardProfile B kind κ

abbrev BoundaryMatrixProfileMatrixTransportLedgerOf
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    (source : ArithmeticSource Cell T) (L : Nat) :=
  BoundarySource.BoundaryMatrixProfileMatrixTransportLedger (Cell := Cell) (T := T) source L

def boundaryMatrixMatrixTransportLedgerFromBoundarySource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L) :
    BoundaryMatrixProfileMatrixTransportLedgerOf source L :=
  BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.fromBoundarySource B

theorem boundaryMatrixMatrixTransportLedger_route
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L) :
    (boundaryMatrixMatrixTransportLedgerFromBoundarySource B).boundarySource.interface.route =
      BoundarySource.BoundarySourceRoute.recursiveHistory :=
  BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.route_recursiveHistory
    (boundaryMatrixMatrixTransportLedgerFromBoundarySource B)

theorem boundaryMatrixMatrixTransportLedger_consumptionPolicy
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L) :
    (boundaryMatrixMatrixTransportLedgerFromBoundarySource B).boundarySource.consumptionPolicy =
      BoundarySource.BoundarySourceConsumptionPolicy.boundarySourceOnly :=
  BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.consumptionPolicy_boundarySourceOnly
    (boundaryMatrixMatrixTransportLedgerFromBoundarySource B)

end StrengtheningBoundaryMatrixProfile

end CNNA.PillarA.Arithmetic
