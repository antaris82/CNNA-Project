import CNNA.PillarA.Generator.Boundary.RecursiveLevelHistoryTypeDecision

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

inductive GeneratedSubstrateCandidateKind where
  | branchAddress
  | boundaryState
  | historyExpanded
  | interfaceExposure
  deriving DecidableEq, Repr

inductive GeneratedSubstrateBlocker where
  | missingAInternalNonSingletonSubstrate
  deriving DecidableEq, Repr

inductive GeneratedSubstrateCarrierPolicy where
  | noFreeCarrier
  deriving DecidableEq, Repr

inductive GeneratedSubstrateIndexPolicy where
  | noFinIndexAsSubstrateCarrier
  deriving DecidableEq, Repr

inductive GeneratedSubstrateBoundaryPortsPolicy where
  | portsDoNotCreateCarrierPoints
  deriving DecidableEq, Repr

inductive GeneratedSubstrateExternalGeometryPolicy where
  | noExternalPCFImport
  deriving DecidableEq, Repr

inductive GeneratedSubstrateProvenancePolicy where
  | requireBranchCutoffSectorCouplingOrSchurDtN
  deriving DecidableEq, Repr

structure GeneratedSubstrateCandidateObligations where
  carrierPolicy : GeneratedSubstrateCarrierPolicy
  carrierPolicy_noFreeCarrier :
    carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier
  indexPolicy : GeneratedSubstrateIndexPolicy
  indexPolicy_noFinCarrier :
    indexPolicy = GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier
  boundaryPortsPolicy : GeneratedSubstrateBoundaryPortsPolicy
  boundaryPorts_noGeneratedPoints :
    boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints
  externalGeometryPolicy : GeneratedSubstrateExternalGeometryPolicy
  externalGeometry_noPCFImport :
    externalGeometryPolicy = GeneratedSubstrateExternalGeometryPolicy.noExternalPCFImport
  provenancePolicy : GeneratedSubstrateProvenancePolicy
  provenance_required :
    provenancePolicy =
      GeneratedSubstrateProvenancePolicy.requireBranchCutoffSectorCouplingOrSchurDtN

namespace GeneratedSubstrateCandidateObligations

def strict : GeneratedSubstrateCandidateObligations where
  carrierPolicy := GeneratedSubstrateCarrierPolicy.noFreeCarrier
  carrierPolicy_noFreeCarrier := by
    rfl
  indexPolicy := GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier
  indexPolicy_noFinCarrier := by
    rfl
  boundaryPortsPolicy :=
    GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints
  boundaryPorts_noGeneratedPoints := by
    rfl
  externalGeometryPolicy := GeneratedSubstrateExternalGeometryPolicy.noExternalPCFImport
  externalGeometry_noPCFImport := by
    rfl
  provenancePolicy :=
    GeneratedSubstrateProvenancePolicy.requireBranchCutoffSectorCouplingOrSchurDtN
  provenance_required := by
    rfl

theorem strict_noFreeCarrier :
    strict.carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

theorem strict_noFinCarrier :
    strict.indexPolicy =
      GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier := by
  rfl

theorem strict_portsDoNotCreatePoints :
    strict.boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints := by
  rfl

theorem strict_noPCFImport :
    strict.externalGeometryPolicy =
      GeneratedSubstrateExternalGeometryPolicy.noExternalPCFImport := by
  rfl

theorem strict_provenanceRequired :
    strict.provenancePolicy =
      GeneratedSubstrateProvenancePolicy.requireBranchCutoffSectorCouplingOrSchurDtN := by
  rfl

end GeneratedSubstrateCandidateObligations

structure GeneratedSubstrateCandidateLedger where
  kind : GeneratedSubstrateCandidateKind
  status : GeneratedSubstrateRouteStatus
  status_conditionalOpen : status = GeneratedSubstrateRouteStatus.conditionalOpen
  blocker : GeneratedSubstrateBlocker
  blocker_missingCarrier :
    blocker = GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate
  obligations : GeneratedSubstrateCandidateObligations
  obligations_strict : obligations = GeneratedSubstrateCandidateObligations.strict
  notPositiveBoundarySource : True
  notImplementationBasisForGeneratedSubstrateRoute : True

namespace GeneratedSubstrateCandidateLedger

def conditionalOpen (kind : GeneratedSubstrateCandidateKind) :
    GeneratedSubstrateCandidateLedger where
  kind := kind
  status := GeneratedSubstrateRouteStatus.conditionalOpen
  status_conditionalOpen := by
    rfl
  blocker := GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate
  blocker_missingCarrier := by
    rfl
  obligations := GeneratedSubstrateCandidateObligations.strict
  obligations_strict := by
    rfl
  notPositiveBoundarySource := True.intro
  notImplementationBasisForGeneratedSubstrateRoute := True.intro

def branchAddress : GeneratedSubstrateCandidateLedger :=
  conditionalOpen GeneratedSubstrateCandidateKind.branchAddress

def boundaryState : GeneratedSubstrateCandidateLedger :=
  conditionalOpen GeneratedSubstrateCandidateKind.boundaryState

def historyExpanded : GeneratedSubstrateCandidateLedger :=
  conditionalOpen GeneratedSubstrateCandidateKind.historyExpanded

def interfaceExposure : GeneratedSubstrateCandidateLedger :=
  conditionalOpen GeneratedSubstrateCandidateKind.interfaceExposure

theorem conditionalOpen_status (kind : GeneratedSubstrateCandidateKind) :
    (conditionalOpen kind).status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem conditionalOpen_blocker (kind : GeneratedSubstrateCandidateKind) :
    (conditionalOpen kind).blocker =
      GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate := by
  rfl

theorem conditionalOpen_obligations (kind : GeneratedSubstrateCandidateKind) :
    (conditionalOpen kind).obligations = GeneratedSubstrateCandidateObligations.strict := by
  rfl

theorem branchAddress_kind :
    branchAddress.kind = GeneratedSubstrateCandidateKind.branchAddress := by
  rfl

theorem boundaryState_kind :
    boundaryState.kind = GeneratedSubstrateCandidateKind.boundaryState := by
  rfl

theorem historyExpanded_kind :
    historyExpanded.kind = GeneratedSubstrateCandidateKind.historyExpanded := by
  rfl

theorem interfaceExposure_kind :
    interfaceExposure.kind = GeneratedSubstrateCandidateKind.interfaceExposure := by
  rfl

end GeneratedSubstrateCandidateLedger

structure GeneratedSubstrateRouteLedger where
  status : GeneratedSubstrateRouteStatus
  notImplementationBasisForGeneratedSubstrateRoute : status = GeneratedSubstrateRouteStatus.conditionalOpen

namespace GeneratedSubstrateRouteLedger

def conditionalOpen : GeneratedSubstrateRouteLedger where
  status := GeneratedSubstrateRouteStatus.conditionalOpen
  notImplementationBasisForGeneratedSubstrateRoute := by
    rfl

theorem conditionalOpen_status :
    conditionalOpen.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

end GeneratedSubstrateRouteLedger

structure GeneratedSubstrateRouteInventory where
  routeStatus : GeneratedSubstrateRouteStatus
  routeStatus_conditionalOpen : routeStatus = GeneratedSubstrateRouteStatus.conditionalOpen
  branchAddress : GeneratedSubstrateCandidateLedger
  branchAddress_kind : branchAddress.kind = GeneratedSubstrateCandidateKind.branchAddress
  branchAddress_status : branchAddress.status = GeneratedSubstrateRouteStatus.conditionalOpen
  boundaryState : GeneratedSubstrateCandidateLedger
  boundaryState_kind : boundaryState.kind = GeneratedSubstrateCandidateKind.boundaryState
  boundaryState_status : boundaryState.status = GeneratedSubstrateRouteStatus.conditionalOpen
  historyExpanded : GeneratedSubstrateCandidateLedger
  historyExpanded_kind : historyExpanded.kind = GeneratedSubstrateCandidateKind.historyExpanded
  historyExpanded_status : historyExpanded.status = GeneratedSubstrateRouteStatus.conditionalOpen
  interfaceExposure : GeneratedSubstrateCandidateLedger
  interfaceExposure_kind : interfaceExposure.kind = GeneratedSubstrateCandidateKind.interfaceExposure
  interfaceExposure_status : interfaceExposure.status = GeneratedSubstrateRouteStatus.conditionalOpen
  noCandidateIsPositiveSource : True
  recursiveRouteRemainsImplementationBasis : True

namespace GeneratedSubstrateRouteInventory

def conditionalOpen : GeneratedSubstrateRouteInventory where
  routeStatus := GeneratedSubstrateRouteStatus.conditionalOpen
  routeStatus_conditionalOpen := by
    rfl
  branchAddress := GeneratedSubstrateCandidateLedger.branchAddress
  branchAddress_kind := by
    rfl
  branchAddress_status := by
    rfl
  boundaryState := GeneratedSubstrateCandidateLedger.boundaryState
  boundaryState_kind := by
    rfl
  boundaryState_status := by
    rfl
  historyExpanded := GeneratedSubstrateCandidateLedger.historyExpanded
  historyExpanded_kind := by
    rfl
  historyExpanded_status := by
    rfl
  interfaceExposure := GeneratedSubstrateCandidateLedger.interfaceExposure
  interfaceExposure_kind := by
    rfl
  interfaceExposure_status := by
    rfl
  noCandidateIsPositiveSource := True.intro
  recursiveRouteRemainsImplementationBasis := True.intro

theorem conditionalOpen_status :
    conditionalOpen.routeStatus = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem conditionalOpen_branchAddress_status :
    conditionalOpen.branchAddress.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem conditionalOpen_boundaryState_status :
    conditionalOpen.boundaryState.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem conditionalOpen_historyExpanded_status :
    conditionalOpen.historyExpanded.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem conditionalOpen_interfaceExposure_status :
    conditionalOpen.interfaceExposure.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

end GeneratedSubstrateRouteInventory

end BoundarySource

namespace StrengtheningRecursiveHistoryBoundarySource

abbrev RecursiveHistoryBoundarySourceGeneratedSubstrateRouteLedger :=
  BoundarySource.GeneratedSubstrateRouteLedger

def boundarySourceDecisionGeneratedSubstrateRouteConditionalOpen :
    RecursiveHistoryBoundarySourceGeneratedSubstrateRouteLedger :=
  BoundarySource.GeneratedSubstrateRouteLedger.conditionalOpen

end StrengtheningRecursiveHistoryBoundarySource

namespace StrengtheningBoundaryStateSubstrate

abbrev BoundaryStateSubstrateGeneratedSubstrateCandidateKind :=
  BoundarySource.GeneratedSubstrateCandidateKind

abbrev BoundaryStateSubstrateGeneratedSubstrateCandidateLedger :=
  BoundarySource.GeneratedSubstrateCandidateLedger

abbrev BoundaryStateSubstrateGeneratedSubstrateRouteInventory :=
  BoundarySource.GeneratedSubstrateRouteInventory

def boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen :
    BoundaryStateSubstrateGeneratedSubstrateRouteInventory :=
  BoundarySource.GeneratedSubstrateRouteInventory.conditionalOpen

theorem boundarySubstrateRouteGeneratedSubstrateRouteInventory_status :
    boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen.routeStatus =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteBranchAddress_status :
    boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen.branchAddress.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteBoundaryState_status :
    boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen.boundaryState.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteHistoryExpanded_status :
    boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen.historyExpanded.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteInterfaceExposure_status :
    boundarySubstrateRouteGeneratedSubstrateRouteInventoryConditionalOpen.interfaceExposure.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

end StrengtheningBoundaryStateSubstrate

end CNNA.PillarA.Arithmetic
