import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTwoSidedInvCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv

universe u

inductive InteriorEliminationCandidateEntryPositivePathLockStatus where
  | lockedBecauseCandidateEntryEqualsInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorInverseCandidatePositiveFirstContractStatus where
  | positiveCandidateChainStarted
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoStartObstructionStatus where
  | noObstructionBeforePositiveCarrierStepTraceAndCandidate
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNewInverseCandidateRequirementStatus where
  | needsGeneratedInteriorInverseCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorInverseCandidatePrimaryOutputStatus where
  | noMatrixOptNoneAsPrimaryOutput
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoTwoSidedInvStatus where
  | noTwoSidedInvProofInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoMatrixInvStatus where
  | noMatrixInvInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoFreeInverseEntryTableStatus where
  | noFreeInverseEntryTableInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoExternalInverseOracleStatus where
  | noExternalInverseOracleInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateStart
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateNextPositiveConstructionGate where
  | generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateStartPositiveFirstLedgerStatus where
  | interiorInverseCandidatePositiveFirstPositiveFirstContractClosed
  deriving DecidableEq, Repr

structure InteriorEliminationCandidateEntryPositivePathLocked
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) where
  shapeAudit : GeneratedCandidateEntryShapeAudit Cell p A P wp W
  obstruction : GeneratedInteriorTwoSidedInvObstruction Cell p A P wp W E
  lockStatus : InteriorEliminationCandidateEntryPositivePathLockStatus
  shapeAudit_candidateEntry_eq : shapeAudit.candidateEntry = E
  obstruction_shapeAudit_eq : obstruction.shapeAudit = shapeAudit
  candidateEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      E.entry i j = generatedInteriorBlock W i j
  candidateMatrix_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix_from_candidateEntry E i j = generatedInteriorBlock W i j
  lockStatus_eq :
    lockStatus =
      InteriorEliminationCandidateEntryPositivePathLockStatus.lockedBecauseCandidateEntryEqualsInteriorBlock

namespace InteriorEliminationCandidateEntryPositivePathLocked

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}

def fromInteriorTwoSidedInverseValidationShapeAudit
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E where
  shapeAudit := GeneratedCandidateEntryShapeAudit.fromCandidateEntry E
  obstruction := generatedInteriorTwoSidedInvObstruction_fromShapeAudit E
  lockStatus :=
    InteriorEliminationCandidateEntryPositivePathLockStatus.lockedBecauseCandidateEntryEqualsInteriorBlock
  shapeAudit_candidateEntry_eq := by
    rfl
  obstruction_shapeAudit_eq := by
    rfl
  candidateEntry_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_interiorBlock E i j
  candidateMatrix_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateMatrix_entry_eq_interiorBlock E i j
  lockStatus_eq := by
    rfl

theorem locked_status
    (L : InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E) :
    L.lockStatus =
      InteriorEliminationCandidateEntryPositivePathLockStatus.lockedBecauseCandidateEntryEqualsInteriorBlock :=
  L.lockStatus_eq

theorem entry_eq_interiorBlock
    (L : InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E)
    (i j : GeneratedInteriorIndex A) :
    E.entry i j = generatedInteriorBlock W i j :=
  L.candidateEntry_eq_interiorBlock i j

theorem matrix_eq_interiorBlock
    (L : InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E)
    (i j : GeneratedInteriorIndex A) :
    candidateMatrix_from_candidateEntry E i j = generatedInteriorBlock W i j :=
  L.candidateMatrix_eq_interiorBlock i j

end InteriorEliminationCandidateEntryPositivePathLocked

structure InteriorInverseCandidatePositiveFirstContract
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) where
  generatedInteriorEliminationCandidateEntryLock : InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E
  contractStatus : InteriorInverseCandidatePositiveFirstContractStatus
  noStartObstructionStatus : InteriorInverseCandidateNoStartObstructionStatus
  newInverseCandidateRequirementStatus :
    InteriorInverseCandidateNewInverseCandidateRequirementStatus
  primaryOutputStatus : InteriorInverseCandidatePrimaryOutputStatus
  noTwoSidedInvStatus : InteriorInverseCandidateNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorInverseCandidateNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorInverseCandidateNoInteriorEliminationDataStatus
  noMatrixInvStatus : InteriorInverseCandidateNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorInverseCandidateNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorInverseCandidateNoExternalInverseOracleStatus
  noDtnDataStatus : InteriorInverseCandidateNoDtnDataStatus
  noArithmeticTargetStatus : InteriorInverseCandidateNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorInverseCandidateNextPositiveConstructionGate
  generatedInteriorEliminationCandidateEntryLock_eq_main :
    generatedInteriorEliminationCandidateEntryLock = InteriorEliminationCandidateEntryPositivePathLocked.fromInteriorTwoSidedInverseValidationShapeAudit E
  generatedInteriorEliminationCandidateEntry_entry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      E.entry i j = generatedInteriorBlock W i j
  generatedInteriorEliminationCandidateEntry_matrix_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix_from_candidateEntry E i j = generatedInteriorBlock W i j
  contractStatus_eq :
    contractStatus = InteriorInverseCandidatePositiveFirstContractStatus.positiveCandidateChainStarted
  noStartObstructionStatus_eq :
    noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate
  newInverseCandidateRequirementStatus_eq :
    newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry
  primaryOutputStatus_eq :
    primaryOutputStatus = InteriorInverseCandidatePrimaryOutputStatus.noMatrixOptNoneAsPrimaryOutput
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorInverseCandidateNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorInverseCandidateStart
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateStart
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorInverseCandidateNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateStart
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorInverseCandidateNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateStart
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorInverseCandidateNoFreeInverseEntryTableStatus.noFreeInverseEntryTableInInteriorInverseCandidateStart
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorInverseCandidateNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorInverseCandidateStart
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorInverseCandidateNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateStart
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier

namespace InteriorInverseCandidatePositiveFirstContract

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}

def fromInteriorEliminationCandidateEntryLock
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E where
  generatedInteriorEliminationCandidateEntryLock := InteriorEliminationCandidateEntryPositivePathLocked.fromInteriorTwoSidedInverseValidationShapeAudit E
  contractStatus := InteriorInverseCandidatePositiveFirstContractStatus.positiveCandidateChainStarted
  noStartObstructionStatus :=
    InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate
  newInverseCandidateRequirementStatus :=
    InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry
  primaryOutputStatus := InteriorInverseCandidatePrimaryOutputStatus.noMatrixOptNoneAsPrimaryOutput
  noTwoSidedInvStatus := InteriorInverseCandidateNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorInverseCandidateStart
  noInteriorEliminationCertificateStatus :=
    InteriorInverseCandidateNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateStart
  noInteriorEliminationDataStatus :=
    InteriorInverseCandidateNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorInverseCandidateStart
  noMatrixInvStatus := InteriorInverseCandidateNoMatrixInvStatus.noMatrixInvInInteriorInverseCandidateStart
  noFreeInverseEntryTableStatus :=
    InteriorInverseCandidateNoFreeInverseEntryTableStatus.noFreeInverseEntryTableInInteriorInverseCandidateStart
  noExternalInverseOracleStatus :=
    InteriorInverseCandidateNoExternalInverseOracleStatus.noExternalInverseOracleInInteriorInverseCandidateStart
  noDtnDataStatus :=
    InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart
  noArithmeticTargetStatus :=
    InteriorInverseCandidateNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorInverseCandidateStart
  nextPositiveConstructionGate :=
    InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier
  generatedInteriorEliminationCandidateEntryLock_eq_main := by
    rfl
  generatedInteriorEliminationCandidateEntry_entry_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_interiorBlock E i j
  generatedInteriorEliminationCandidateEntry_matrix_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateMatrix_entry_eq_interiorBlock E i j
  contractStatus_eq := by
    rfl
  noStartObstructionStatus_eq := by
    rfl
  newInverseCandidateRequirementStatus_eq := by
    rfl
  primaryOutputStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextPositiveConstructionGate_eq := by
    rfl

theorem no_obstruction_start
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate :=
  C.noStartObstructionStatus_eq

theorem needs_new_inverse_candidate_entry
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry :=
  C.newInverseCandidateRequirementStatus_eq

theorem no_primary_matrixOpt_none
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.primaryOutputStatus = InteriorInverseCandidatePrimaryOutputStatus.noMatrixOptNoneAsPrimaryOutput :=
  C.primaryOutputStatus_eq

theorem next_construction_gate_is_carrier
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier :=
  C.nextPositiveConstructionGate_eq

theorem noTwoSidedInv
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.noTwoSidedInvStatus =
      InteriorInverseCandidateNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorInverseCandidateStart :=
  C.noTwoSidedInvStatus_eq

theorem noInteriorEliminationCertificate
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorInverseCandidateStart :=
  C.noInteriorEliminationCertificateStatus_eq

theorem noDtnData
    (C : InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E) :
    C.noDtnDataStatus =
      InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart :=
  C.noDtnDataStatus_eq

end InteriorInverseCandidatePositiveFirstContract

def generatedInteriorEliminationCandidateEntryPositivePathLocked
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    InteriorEliminationCandidateEntryPositivePathLocked Cell p A P wp W E :=
  InteriorEliminationCandidateEntryPositivePathLocked.fromInteriorTwoSidedInverseValidationShapeAudit E

def interiorInverseCandidatePositiveFirstContract
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    InteriorInverseCandidatePositiveFirstContract Cell p A P wp W E :=
  InteriorInverseCandidatePositiveFirstContract.fromInteriorEliminationCandidateEntryLock E

def regularInteriorEliminationCandidateEntryPositivePathLocked
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorEliminationCandidateEntryPositivePathLocked
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp) :=
  generatedInteriorEliminationCandidateEntryPositivePathLocked
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)

def variableInteriorEliminationCandidateEntryPositivePathLocked
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorEliminationCandidateEntryPositivePathLocked
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp) :=
  generatedInteriorEliminationCandidateEntryPositivePathLocked
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)

def regularInteriorInverseCandidatePositiveFirstContract
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorInverseCandidatePositiveFirstContract
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp) :=
  interiorInverseCandidatePositiveFirstContract
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)

def variableInteriorInverseCandidatePositiveFirstContract
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    InteriorInverseCandidatePositiveFirstContract
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp) :=
  interiorInverseCandidatePositiveFirstContract
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)

structure InteriorInverseCandidateStartPositiveFirstLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorInverseCandidateStartPositiveFirstLedgerStatus
  interiorTwoSidedInverseValidationLedger : InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerInteriorInverseCandidateStartRefC30F b β p regularWeight variableWeight
  regularLock :
    InteriorEliminationCandidateEntryPositivePathLocked
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
  variableLock :
    InteriorEliminationCandidateEntryPositivePathLocked
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
  regularContract :
    InteriorInverseCandidatePositiveFirstContract
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
  variableContract :
    InteriorInverseCandidatePositiveFirstContract
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
  interiorTwoSidedInverseValidationLedger_eq_main :
    interiorTwoSidedInverseValidationLedger = interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger b β p regularWeight variableWeight
  regularLock_eq_main :
    regularLock = regularInteriorEliminationCandidateEntryPositivePathLocked b p regularWeight
  variableLock_eq_main :
    variableLock = variableInteriorEliminationCandidateEntryPositivePathLocked β p variableWeight
  regularContract_eq_main :
    regularContract = regularInteriorInverseCandidatePositiveFirstContract b p regularWeight
  variableContract_eq_main :
    variableContract = variableInteriorInverseCandidatePositiveFirstContract β p variableWeight
  regularNoStartObstruction :
    regularContract.noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate
  variableNoStartObstruction :
    variableContract.noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate
  regularNeedsNewInverseCandidateEntry :
    regularContract.newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry
  variableNeedsNewInverseCandidateEntry :
    variableContract.newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry
  regularNextPositiveConstructionGate :
    regularContract.nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier
  variableNextPositiveConstructionGate :
    variableContract.nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier
  regularNoTwoSidedInv :
    regularContract.noTwoSidedInvStatus =
      InteriorInverseCandidateNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorInverseCandidateStart
  variableNoTwoSidedInv :
    variableContract.noTwoSidedInvStatus =
      InteriorInverseCandidateNoTwoSidedInvStatus.noTwoSidedInvProofInInteriorInverseCandidateStart
  regularNoDtnData :
    regularContract.noDtnDataStatus =
      InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart
  variableNoDtnData :
    variableContract.noDtnDataStatus =
      InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart
  status_eq_closed :
    status = InteriorInverseCandidateStartPositiveFirstLedgerStatus.interiorInverseCandidatePositiveFirstPositiveFirstContractClosed

def interiorInverseCandidatePositiveFirstPositiveFirstLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorInverseCandidateStartPositiveFirstLedger b β p regularWeight variableWeight where
  status := InteriorInverseCandidateStartPositiveFirstLedgerStatus.interiorInverseCandidatePositiveFirstPositiveFirstContractClosed
  interiorTwoSidedInverseValidationLedger := interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger b β p regularWeight variableWeight
  regularLock := regularInteriorEliminationCandidateEntryPositivePathLocked b p regularWeight
  variableLock := variableInteriorEliminationCandidateEntryPositivePathLocked β p variableWeight
  regularContract := regularInteriorInverseCandidatePositiveFirstContract b p regularWeight
  variableContract := variableInteriorInverseCandidatePositiveFirstContract β p variableWeight
  interiorTwoSidedInverseValidationLedger_eq_main := by
    rfl
  regularLock_eq_main := by
    rfl
  variableLock_eq_main := by
    rfl
  regularContract_eq_main := by
    rfl
  variableContract_eq_main := by
    rfl
  regularNoStartObstruction := by
    rfl
  variableNoStartObstruction := by
    rfl
  regularNeedsNewInverseCandidateEntry := by
    rfl
  variableNeedsNewInverseCandidateEntry := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  regularNoTwoSidedInv := by
    rfl
  variableNoTwoSidedInv := by
    rfl
  regularNoDtnData := by
    rfl
  variableNoDtnData := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationCandidateEntryPositivePathLocked_status
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    (generatedInteriorEliminationCandidateEntryPositivePathLocked E).lockStatus =
      InteriorEliminationCandidateEntryPositivePathLockStatus.lockedBecauseCandidateEntryEqualsInteriorBlock := by
  rfl

theorem noInteriorInverseCandidateStartsWithObstruction
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    (interiorInverseCandidatePositiveFirstContract E).noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate := by
  rfl

theorem InteriorInverseCandidateNeedsNewInverseCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    (interiorInverseCandidatePositiveFirstContract E).newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry := by
  rfl

theorem interiorInverseCandidatePositiveFirstPositiveFirstLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight).status =
      InteriorInverseCandidateStartPositiveFirstLedgerStatus.interiorInverseCandidatePositiveFirstPositiveFirstContractClosed := by
  rfl

theorem interiorInverseCandidatePositiveFirstPositiveFirstLedger_regularNoStartObstruction
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight).regularContract.noStartObstructionStatus =
      InteriorInverseCandidateNoStartObstructionStatus.noObstructionBeforePositiveCarrierStepTraceAndCandidate := by
  rfl

theorem interiorInverseCandidatePositiveFirstPositiveFirstLedger_variableNeedsNewInverseCandidateEntry
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight).variableContract.newInverseCandidateRequirementStatus =
      InteriorInverseCandidateNewInverseCandidateRequirementStatus.needsGeneratedInteriorInverseCandidateEntry := by
  rfl

theorem interiorInverseCandidatePositiveFirstPositiveFirstLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight).regularContract.nextPositiveConstructionGate =
      InteriorInverseCandidateNextPositiveConstructionGate.generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrier := by
  rfl

theorem interiorInverseCandidatePositiveFirstPositiveFirstLedger_variableNoDtnData
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorInverseCandidatePositiveFirstPositiveFirstLedger b β p regularWeight variableWeight).variableContract.noDtnDataStatus =
      InteriorInverseCandidateNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorInverseCandidateStart := by
  rfl


end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart
