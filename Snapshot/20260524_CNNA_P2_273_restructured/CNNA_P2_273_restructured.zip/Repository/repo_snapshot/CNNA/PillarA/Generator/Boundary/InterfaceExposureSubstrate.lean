import CNNA.PillarA.Generator.Boundary.GeneratedSubstrateRoute

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

namespace InterfaceExposureSubstrate

def ledger : GeneratedSubstrateCandidateLedger :=
  GeneratedSubstrateCandidateLedger.interfaceExposure

theorem ledger_kind :
    ledger.kind = GeneratedSubstrateCandidateKind.interfaceExposure := by
  rfl

theorem ledger_status :
    ledger.status = GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem ledger_blocker :
    ledger.blocker =
      GeneratedSubstrateBlocker.missingAInternalNonSingletonSubstrate := by
  rfl

theorem ledger_noFreeCarrier :
    ledger.obligations.carrierPolicy = GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

theorem ledger_noFinCarrier :
    ledger.obligations.indexPolicy =
      GeneratedSubstrateIndexPolicy.noFinIndexAsSubstrateCarrier := by
  rfl

theorem ledger_portsDoNotCreateCarrierPoints :
    ledger.obligations.boundaryPortsPolicy =
      GeneratedSubstrateBoundaryPortsPolicy.portsDoNotCreateCarrierPoints := by
  rfl

end InterfaceExposureSubstrate

end BoundarySource

namespace StrengtheningBoundaryStateSubstrate

def boundarySubstrateRouteInterfaceExposureSubstrateLedger :
    BoundarySource.GeneratedSubstrateCandidateLedger :=
  BoundarySource.InterfaceExposureSubstrate.ledger

theorem boundarySubstrateRouteInterfaceExposureSubstrate_status :
    boundarySubstrateRouteInterfaceExposureSubstrateLedger.status =
      BoundarySource.GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem boundarySubstrateRouteInterfaceExposureSubstrate_noFreeCarrier :
    boundarySubstrateRouteInterfaceExposureSubstrateLedger.obligations.carrierPolicy =
      BoundarySource.GeneratedSubstrateCarrierPolicy.noFreeCarrier := by
  rfl

end StrengtheningBoundaryStateSubstrate

end CNNA.PillarA.Arithmetic
