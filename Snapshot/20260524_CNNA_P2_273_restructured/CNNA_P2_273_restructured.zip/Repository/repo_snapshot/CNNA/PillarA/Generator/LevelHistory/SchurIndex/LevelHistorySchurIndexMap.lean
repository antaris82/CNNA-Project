import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev LevelHistorySchurIndexMapOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.levelHistorySchurIndexMap

def levelHistorySchurIndexMapOutputKind : DerivedOutputKind :=
  DerivedOutputKind.levelHistorySchurIndexMap

theorem levelHistorySchurIndexMap_kind_eq (profile : LevelHistorySchurIndexMapOutputProfile) :
    profile.profile.kind = levelHistorySchurIndexMapOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
