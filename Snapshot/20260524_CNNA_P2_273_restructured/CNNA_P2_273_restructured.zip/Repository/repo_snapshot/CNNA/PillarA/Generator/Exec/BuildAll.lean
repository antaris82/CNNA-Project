import CNNA.PillarA.Generator.Exec.GeneratedPipeline.BuildAll
