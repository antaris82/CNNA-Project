import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTerminalFoldResidualCoverage

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

universe u

open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage

inductive InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus where
  | terminalIdentityFieldsNotYetDerivedFromCurrentInteriorTerminalFoldResidualAPI
  | terminalIdentityFieldsProvidedByExplicitCertificate
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus where
  | terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  | terminalIdentityFieldSourceCarriedByCertificate
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceTerminalFoldInductionEquationStatus where
  | foldInvarianceAvailableButTerminalIdentityEquationMissing
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceResidualClosureEquationStatus where
  | residualContributionAvailableButNoIdentityClosureEquation
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceFoldOrderCoverageEquationStatus where
  | foldUpdateOrderAvailableButNoIdentityClosureEquation
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceLeftRightTerminalIdentityStatus where
  | separateLeftAndRightTerminalIdentityFieldsRequired
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus where
  | terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  | terminalCoverageSourcePreparedFromTerminalIdentityFieldCertificate
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus where
  | noAccumulatedEntryCancellationInvariantInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentityFieldExpose
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceNextConsumerStatus where
  | interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource
  | interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityFieldSourceLedgerStatus where
  | terminalIdentityFieldMissingSourceAuditClosed
  | terminalIdentityFieldCertificateReady
  deriving DecidableEq, Repr

structure GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  coverageAudit : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  tracePivotCoverage : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  terminalFoldState : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  terminalResidualContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  terminalFoldUpdateOrderContribution : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  exposureStatus : InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus
  leftTerminalIdentityFieldSourceStatus : InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus
  rightTerminalIdentityFieldSourceStatus : InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus
  terminalFoldInductionEquationStatus : InteriorTerminalIdentityFieldSourceTerminalFoldInductionEquationStatus
  residualClosureEquationStatus : InteriorTerminalIdentityFieldSourceResidualClosureEquationStatus
  foldOrderCoverageEquationStatus : InteriorTerminalIdentityFieldSourceFoldOrderCoverageEquationStatus
  leftRightTerminalIdentityStatus : InteriorTerminalIdentityFieldSourceLeftRightTerminalIdentityStatus
  terminalCoverageExportStatus : InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus
  noAccumulatedEntryCancellationStatus : InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalIdentityFieldSourceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalIdentityFieldSourceNextConsumerStatus
  invariance_eq_coverageAudit : invariance = coverageAudit.invariance
  tracePivotCoverage_eq_coverageAuditRequirement :
    tracePivotCoverage = coverageAudit.requirement.tracePivotCoverage
  terminalFoldState_eq_coverageAudit : terminalFoldState = coverageAudit.terminalFoldState
  terminalResidualContribution_eq_coverageAudit :
    ∀ i j : GeneratedInteriorIndex A,
      terminalResidualContribution i j = coverageAudit.terminalResidualContribution i j
  terminalResidualContribution_eq_trace :
    ∀ i j : GeneratedInteriorIndex A,
      terminalResidualContribution i j = generatedInteriorTraceResidualContribution T i j
  terminalFoldUpdateOrderContribution_eq_coverageAudit :
    ∀ i j : GeneratedInteriorIndex A,
      terminalFoldUpdateOrderContribution i j =
        coverageAudit.terminalFoldUpdateOrderContribution i j
  terminalFoldUpdateOrderContribution_eq_trace :
    ∀ i j : GeneratedInteriorIndex A,
      terminalFoldUpdateOrderContribution i j =
        generatedInteriorTraceFoldUpdateOrderContribution T i j
  coverageAuditLeftIdentityField_missing :
    coverageAudit.leftTerminalIdentityFieldStatus =
      InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  coverageAuditRightIdentityField_missing :
    coverageAudit.rightTerminalIdentityFieldStatus =
      InteriorTerminalCoverageSourceTerminalIdentityFieldStatus.terminalIdentityFieldMissingFromCurrentInteriorTerminalFoldResidualAPI
  coverageAuditExport_blocked :
    coverageAudit.terminalCoverageExportStatus =
      InteriorTerminalCoverageSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFields
  invarianceNoTerminalIdentity_eq :
    invariance.noTerminalIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceNoTerminalIdentityStatus.noTerminalIdentityInFoldInvariance
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :
    tracePivotCoverage.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    coverageAudit.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    coverageAudit.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  exposureStatus_eq :
    exposureStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus.terminalIdentityFieldsNotYetDerivedFromCurrentInteriorTerminalFoldResidualAPI
  leftTerminalIdentityFieldSourceStatus_eq :
    leftTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  rightTerminalIdentityFieldSourceStatus_eq :
    rightTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  terminalFoldInductionEquationStatus_eq :
    terminalFoldInductionEquationStatus =
      InteriorTerminalIdentityFieldSourceTerminalFoldInductionEquationStatus.foldInvarianceAvailableButTerminalIdentityEquationMissing
  residualClosureEquationStatus_eq :
    residualClosureEquationStatus =
      InteriorTerminalIdentityFieldSourceResidualClosureEquationStatus.residualContributionAvailableButNoIdentityClosureEquation
  foldOrderCoverageEquationStatus_eq :
    foldOrderCoverageEquationStatus =
      InteriorTerminalIdentityFieldSourceFoldOrderCoverageEquationStatus.foldUpdateOrderAvailableButNoIdentityClosureEquation
  leftRightTerminalIdentityStatus_eq :
    leftRightTerminalIdentityStatus =
      InteriorTerminalIdentityFieldSourceLeftRightTerminalIdentityStatus.separateLeftAndRightTerminalIdentityFieldsRequired
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentityFieldExpose
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentityFieldExpose
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentityFieldExpose
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentityFieldExpose
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTerminalIdentityFieldSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentityFieldExpose
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentityFieldExpose
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource

namespace GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTerminalFoldResidualCoverageAudit
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T where
  coverageAudit := C
  invariance := C.invariance
  tracePivotCoverage := C.requirement.tracePivotCoverage
  terminalFoldState := C.terminalFoldState
  terminalResidualContribution := C.terminalResidualContribution
  terminalFoldUpdateOrderContribution := C.terminalFoldUpdateOrderContribution
  exposureStatus :=
    InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus.terminalIdentityFieldsNotYetDerivedFromCurrentInteriorTerminalFoldResidualAPI
  leftTerminalIdentityFieldSourceStatus :=
    InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  rightTerminalIdentityFieldSourceStatus :=
    InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  terminalFoldInductionEquationStatus :=
    InteriorTerminalIdentityFieldSourceTerminalFoldInductionEquationStatus.foldInvarianceAvailableButTerminalIdentityEquationMissing
  residualClosureEquationStatus :=
    InteriorTerminalIdentityFieldSourceResidualClosureEquationStatus.residualContributionAvailableButNoIdentityClosureEquation
  foldOrderCoverageEquationStatus :=
    InteriorTerminalIdentityFieldSourceFoldOrderCoverageEquationStatus.foldUpdateOrderAvailableButNoIdentityClosureEquation
  leftRightTerminalIdentityStatus :=
    InteriorTerminalIdentityFieldSourceLeftRightTerminalIdentityStatus.separateLeftAndRightTerminalIdentityFieldsRequired
  terminalCoverageExportStatus :=
    InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  noAccumulatedEntryCancellationStatus :=
    InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentityFieldExpose
  noProductIdentityProofStatus :=
    InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentityFieldExpose
  noTwoSidedInvStatus :=
    InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentityFieldExpose
  noInteriorEliminationDataStatus :=
    InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentityFieldExpose
  noDtnDataStatus :=
    InteriorTerminalIdentityFieldSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentityFieldExpose
  noArithmeticTargetStatus :=
    InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentityFieldExpose
  nextConsumerStatus := InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource
  invariance_eq_coverageAudit := by
    rfl
  tracePivotCoverage_eq_coverageAuditRequirement := by
    rfl
  terminalFoldState_eq_coverageAudit := by
    rfl
  terminalResidualContribution_eq_coverageAudit := by
    intro i j
    rfl
  terminalResidualContribution_eq_trace :=
    C.terminalResidualContribution_eq_trace
  terminalFoldUpdateOrderContribution_eq_coverageAudit := by
    intro i j
    rfl
  terminalFoldUpdateOrderContribution_eq_trace :=
    C.terminalFoldUpdateOrderContribution_eq_trace
  coverageAuditLeftIdentityField_missing :=
    C.leftTerminalIdentityFieldStatus_eq
  coverageAuditRightIdentityField_missing :=
    C.rightTerminalIdentityFieldStatus_eq
  coverageAuditExport_blocked :=
    C.terminalCoverageExportStatus_eq
  invarianceNoTerminalIdentity_eq :=
    C.invariance.noTerminalIdentityStatus_eq
  tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation :=
    C.tracePivotCoverageSourceEqInteriorAccumulatedTraceEvaluation
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    C.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  exposureStatus_eq := by
    rfl
  leftTerminalIdentityFieldSourceStatus_eq := by
    rfl
  rightTerminalIdentityFieldSourceStatus_eq := by
    rfl
  terminalFoldInductionEquationStatus_eq := by
    rfl
  residualClosureEquationStatus_eq := by
    rfl
  foldOrderCoverageEquationStatus_eq := by
    rfl
  leftRightTerminalIdentityStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromInvariance
    (I : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T :=
  fromTerminalFoldResidualCoverageAudit
    (GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource.fromInvariance I)

theorem terminalCoverageSource_still_blocked
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    A0.terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate :=
  A0.terminalCoverageExportStatus_eq

theorem nextConsumer_is_terminalIdentityEquationSource
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    A0.nextConsumerStatus = InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource :=
  A0.nextConsumerStatus_eq

theorem leftIdentityField_source_missing
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    A0.leftTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI :=
  A0.leftTerminalIdentityFieldSourceStatus_eq

theorem rightIdentityField_source_missing
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    A0.rightTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI :=
  A0.rightTerminalIdentityFieldSourceStatus_eq

end GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource

structure GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  coverageAudit : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  exposureStatus : InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus
  terminalCoverageExportStatus : InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus
  noAccumulatedEntryCancellationStatus : InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus
  noProductIdentityProofStatus : InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalIdentityFieldSourceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalIdentityFieldSourceNextConsumerStatus
  invariance_eq_coverageAudit : invariance = coverageAudit.invariance
  leftBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i i = 1
  leftBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorLeftBlockFold W T i j = 0
  rightBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i i = 1
  rightBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorRightBlockFold W T i j = 0
  invarianceStatus_eq :
    invariance.invarianceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldInvarianceFoldInvarianceStatus.foldInvarianceFromInteriorBlockFoldNormalFormInteriorBlockFoldKernelResidualBridgeAndInteriorLocalStepCancellationFull
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    invariance.blockFoldNormalForm.accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  exposureStatus_eq :
    exposureStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus.terminalIdentityFieldsProvidedByExplicitCertificate
  terminalCoverageExportStatus_eq :
    terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourcePreparedFromTerminalIdentityFieldCertificate
  noAccumulatedEntryCancellationStatus_eq :
    noAccumulatedEntryCancellationStatus =
      InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentityFieldExpose
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentityFieldExpose
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentityFieldExpose
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentityFieldExpose
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTerminalIdentityFieldSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentityFieldExpose
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentityFieldExpose
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer

namespace GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromCoverageAuditAndIdentityFields
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T)
    (leftIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (rightIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (leftDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i i = 1)
    (leftOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorLeftBlockFold W T i j = 0)
    (rightDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i i = 1)
    (rightOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorRightBlockFold W T i j = 0) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T where
  coverageAudit := C
  invariance := C.invariance
  exposureStatus :=
    InteriorTerminalIdentityFieldSourceTerminalIdentityFieldExposureStatus.terminalIdentityFieldsProvidedByExplicitCertificate
  terminalCoverageExportStatus :=
    InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourcePreparedFromTerminalIdentityFieldCertificate
  noAccumulatedEntryCancellationStatus :=
    InteriorTerminalIdentityFieldSourceNoAccumulatedEntryCancellationStatus.noAccumulatedEntryCancellationInvariantInTerminalIdentityFieldExpose
  noProductIdentityProofStatus :=
    InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentityFieldExpose
  noTwoSidedInvStatus :=
    InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentityFieldExpose
  noInteriorEliminationDataStatus :=
    InteriorTerminalIdentityFieldSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalIdentityFieldExpose
  noDtnDataStatus :=
    InteriorTerminalIdentityFieldSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalIdentityFieldExpose
  noArithmeticTargetStatus :=
    InteriorTerminalIdentityFieldSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalIdentityFieldExpose
  nextConsumerStatus := InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  invariance_eq_coverageAudit := by
    rfl
  leftBlockFold_eq_identity := leftIdentity
  rightBlockFold_eq_identity := rightIdentity
  leftBlockFold_diagonal := leftDiagonal
  leftBlockFold_offdiag := leftOffdiag
  rightBlockFold_diagonal := rightDiagonal
  rightBlockFold_offdiag := rightOffdiag
  invarianceStatus_eq :=
    C.invarianceStatus_eq
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    C.invariance.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    C.invariance.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    C.invariance.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  exposureStatus_eq := by
    rfl
  terminalCoverageExportStatus_eq := by
    rfl
  noAccumulatedEntryCancellationStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem noProductIdentityProof
    (C : GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    C.noProductIdentityProofStatus =
      InteriorTerminalIdentityFieldSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalIdentityFieldExpose :=
  C.noProductIdentityProofStatus_eq

theorem noTwoSidedInv
    (C : GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    C.noTwoSidedInvStatus = InteriorTerminalIdentityFieldSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalIdentityFieldExpose :=
  C.noTwoSidedInvStatus_eq

end GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : RegularGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource b p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource.fromTerminalFoldResidualCoverageAudit C

def variableTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (C : VariableGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource β p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource.fromTerminalFoldResidualCoverageAudit C

structure InteriorTerminalIdentityFieldSourceTerminalFoldResidualIdentityFieldsLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource b p regularWeight
  variableAudit : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource β p variableWeight
  ledgerStatus : InteriorTerminalIdentityFieldSourceLedgerStatus
  regularExportStatus : InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus
  variableExportStatus : InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus
  nextConsumerStatus : InteriorTerminalIdentityFieldSourceNextConsumerStatus
  regularExportStatus_eq :
    regularAudit.terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  variableExportStatus_eq :
    variableAudit.terminalCoverageExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  ledgerStatus_eq :
    ledgerStatus = InteriorTerminalIdentityFieldSourceLedgerStatus.terminalIdentityFieldMissingSourceAuditClosed
  regularExportStatusValue_eq :
    regularExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  variableExportStatusValue_eq :
    variableExportStatus =
      InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource

namespace InteriorTerminalIdentityFieldSourceTerminalFoldResidualIdentityFieldsLedger

def fromRegularAndVariableCoverageAudits
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularCoverageAudit : RegularGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource b p regularWeight)
    (variableCoverageAudit : VariableGeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource β p variableWeight) :
    InteriorTerminalIdentityFieldSourceTerminalFoldResidualIdentityFieldsLedger b β p regularWeight variableWeight where
  regularAudit := regularTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource regularCoverageAudit
  variableAudit := variableTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource variableCoverageAudit
  ledgerStatus := InteriorTerminalIdentityFieldSourceLedgerStatus.terminalIdentityFieldMissingSourceAuditClosed
  regularExportStatus :=
    InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  variableExportStatus :=
    InteriorTerminalIdentityFieldSourceTerminalCoverageExportStatus.terminalCoverageSourceBlockedUntilTerminalIdentityFieldCertificate
  nextConsumerStatus := InteriorTerminalIdentityFieldSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityEquationSourceTerminalFoldResidualIdentityEquationSource
  regularExportStatus_eq := by
    rfl
  variableExportStatus_eq := by
    rfl
  ledgerStatus_eq := by
    rfl
  regularExportStatusValue_eq := by
    rfl
  variableExportStatusValue_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalIdentityFieldSourceTerminalFoldResidualIdentityFieldsLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
