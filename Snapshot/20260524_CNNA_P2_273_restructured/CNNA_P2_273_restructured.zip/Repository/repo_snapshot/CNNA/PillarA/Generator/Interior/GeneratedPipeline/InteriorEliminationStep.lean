import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart


universe u

inductive InteriorEliminationTracePivotDatumStatus where
  | pivotFromInteriorEliminationCarrierCarrierNode
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceResidualDatumStatus where
  | residualFromInteriorBlockInteriorEliminationdRProfile
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceStepUpdateStatus where
  | stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceEliminationStepStatus where
  | generatedInteriorEliminationLocalStepClosed
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoMatrixInvStatus where
  | noMatrixInvForEliminationStep
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoGlobalInverseStatus where
  | noGlobalInverseForEliminationStep
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoCertificateStatus where
  | noCertificateForEliminationStep
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoFreePivotDataStatus where
  | noFreePivotData
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoGlobalPivotOrderStatus where
  | noGlobalPivotOrder
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoTraceSemanticsStatus where
  | noTraceSemantics
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoInverseEntryFunctionStatus where
  | noInverseEntryFunctionInInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoMatrixExportStatus where
  | noMatrixExportInInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceNextPositiveConstructionGate where
  | generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorEliminationTraceGeneratedInteriorEliminationStepLedgerStatus where
  | generatedInteriorEliminationLocalStepClosed
  deriving DecidableEq, Repr

def generatedInteriorLocalBaseEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorBlock W i j

def generatedInteriorLocalRowResidual
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (pivot j : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorBlock W pivot j

def generatedInteriorLocalColumnResidual
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (pivot i : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorBlock W i pivot

def generatedInteriorLocalPivotEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (pivot : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorBlock W pivot pivot

structure GeneratedInteriorPivotDatum
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) where
  pivotIndex : GeneratedInteriorIndex A
  node : GeneratedInteriorEliminationNode Cell p A P wp W K.candidate
  depth : Nat
  measure : Nat
  pivotEntry : ℝ
  pivotDatumStatus : InteriorEliminationTracePivotDatumStatus
  noFreePivotDataStatus : InteriorEliminationTraceNoFreePivotDataStatus
  noGlobalPivotOrderStatus : InteriorEliminationTraceNoGlobalPivotOrderStatus
  node_eq_carrierNode : node = K.nodeOf pivotIndex
  node_index_eq_pivot : node.index = pivotIndex
  node_membership_from_partition : node.approximantIndex ∈ P.interiorCarrier
  node_profileData_eq_carrierProfileData : node.profileData = K.profileData
  node_candidate_eq_carrierCandidate : node.candidate = K.candidate
  depth_eq_carrierDepth : depth = (K.depthOf pivotIndex).depth
  measure_eq_carrierMeasure : measure = (K.measureOf pivotIndex).measure
  pivotEntry_eq_interiorBlock : pivotEntry = generatedInteriorLocalPivotEntry W pivotIndex
  pivotDatumStatus_eq :
    pivotDatumStatus = InteriorEliminationTracePivotDatumStatus.pivotFromInteriorEliminationCarrierCarrierNode
  noFreePivotDataStatus_eq :
    noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
  noGlobalPivotOrderStatus_eq :
    noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder

namespace GeneratedInteriorPivotDatum

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromCarrierNode
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorPivotDatum Cell p A P wp W E K where
  pivotIndex := i
  node := K.nodeOf i
  depth := (K.depthOf i).depth
  measure := (K.measureOf i).measure
  pivotEntry := generatedInteriorLocalPivotEntry W i
  pivotDatumStatus := InteriorEliminationTracePivotDatumStatus.pivotFromInteriorEliminationCarrierCarrierNode
  noFreePivotDataStatus := InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
  noGlobalPivotOrderStatus := InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder
  node_eq_carrierNode := by
    rfl
  node_index_eq_pivot :=
    K.node_index_eq i
  node_membership_from_partition :=
    K.node_membership_from_partition i
  node_profileData_eq_carrierProfileData :=
    K.node_profileData_eq i
  node_candidate_eq_carrierCandidate :=
    K.node_candidate_eq i
  depth_eq_carrierDepth := by
    rfl
  measure_eq_carrierMeasure := by
    rfl
  pivotEntry_eq_interiorBlock := by
    rfl
  pivotDatumStatus_eq := by
    rfl
  noFreePivotDataStatus_eq := by
    rfl
  noGlobalPivotOrderStatus_eq := by
    rfl

theorem pivotBoundToInteriorEliminationCarrierNode
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) :
    Q.node = K.nodeOf Q.pivotIndex :=
  Q.node_eq_carrierNode

theorem noFreePivotData
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) :
    Q.noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData :=
  Q.noFreePivotDataStatus_eq

theorem noGlobalPivotOrder
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) :
    Q.noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder :=
  Q.noGlobalPivotOrderStatus_eq

end GeneratedInteriorPivotDatum

structure GeneratedInteriorResidualDatum
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) where
  profileData : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  rowResidual : GeneratedInteriorIndex A → ℝ
  columnResidual : GeneratedInteriorIndex A → ℝ
  residualDatumStatus : InteriorEliminationTraceResidualDatumStatus
  profileSourceStatus : InteriorEliminationCarrierProfileSourceStatus
  candidateSourceStatus : InteriorEliminationCarrierCandidateSourceStatus
  profileData_eq_carrierProfileData : profileData = K.profileData
  candidate_eq_carrierCandidate : candidate = K.candidate
  candidate_profile_eq_profileData : candidate.profile = profileData.profile
  candidate_sourceCompatible :
    GeneratedInteriorEliminationCandidateSourceCompatible candidate.source profileData.profile
  rowResidual_eq_interiorBlock :
    ∀ j : GeneratedInteriorIndex A,
      rowResidual j = generatedInteriorLocalRowResidual W Q.pivotIndex j
  columnResidual_eq_interiorBlock :
    ∀ i : GeneratedInteriorIndex A,
      columnResidual i = generatedInteriorLocalColumnResidual W Q.pivotIndex i
  residualDatumStatus_eq :
    residualDatumStatus = InteriorEliminationTraceResidualDatumStatus.residualFromInteriorBlockInteriorEliminationdRProfile
  profileSourceStatus_eq :
    profileSourceStatus =
      InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure
  candidateSourceStatus_eq :
    candidateSourceStatus =
      InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate

namespace GeneratedInteriorResidualDatum

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {Q : GeneratedInteriorPivotDatum Cell p A P wp W E K}

def fromInteriorBlockInteriorEliminationdRProfile
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) :
    GeneratedInteriorResidualDatum Cell p A P wp W E K Q where
  profileData := K.candidate.profileData
  candidate := K.candidate
  rowResidual := fun j => generatedInteriorLocalRowResidual W Q.pivotIndex j
  columnResidual := fun i => generatedInteriorLocalColumnResidual W Q.pivotIndex i
  residualDatumStatus := InteriorEliminationTraceResidualDatumStatus.residualFromInteriorBlockInteriorEliminationdRProfile
  profileSourceStatus :=
    InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure
  candidateSourceStatus :=
    InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate
  profileData_eq_carrierProfileData :=
    K.profileData_eq_candidateProfileData.symm
  candidate_eq_carrierCandidate := by
    rfl
  candidate_profile_eq_profileData :=
    K.candidate.profileEqInteriorBlockProfile
  candidate_sourceCompatible :=
    K.candidate.sourceCompatible
  rowResidual_eq_interiorBlock := by
    intro j
    rfl
  columnResidual_eq_interiorBlock := by
    intro i
    rfl
  residualDatumStatus_eq := by
    rfl
  profileSourceStatus_eq := by
    rfl
  candidateSourceStatus_eq := by
    rfl

theorem residualUsesInteriorBlockInteriorEliminationdR
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q) :
    R.profileSourceStatus =
        InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure ∧
      R.candidateSourceStatus =
        InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate :=
  And.intro R.profileSourceStatus_eq R.candidateSourceStatus_eq

theorem rowResidual_eq
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q)
    (j : GeneratedInteriorIndex A) :
    R.rowResidual j = generatedInteriorLocalRowResidual W Q.pivotIndex j :=
  R.rowResidual_eq_interiorBlock j

theorem columnResidual_eq
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q)
    (i : GeneratedInteriorIndex A) :
    R.columnResidual i = generatedInteriorLocalColumnResidual W Q.pivotIndex i :=
  R.columnResidual_eq_interiorBlock i

end GeneratedInteriorResidualDatum

structure GeneratedInteriorStepUpdate
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K)
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q) where
  pivotDatum : GeneratedInteriorPivotDatum Cell p A P wp W E K
  residualDatum : GeneratedInteriorResidualDatum Cell p A P wp W E K Q
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  baseEntry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  rowResidual : GeneratedInteriorIndex A → ℝ
  columnResidual : GeneratedInteriorIndex A → ℝ
  pivotEntry : ℝ
  stepUpdateStatus : InteriorEliminationTraceStepUpdateStatus
  noMatrixInvStatus : InteriorEliminationTraceNoMatrixInvStatus
  noGlobalInverseStatus : InteriorEliminationTraceNoGlobalInverseStatus
  noCertificateStatus : InteriorEliminationTraceNoCertificateStatus
  noInverseEntryFunctionStatus : InteriorEliminationTraceNoInverseEntryFunctionStatus
  noMatrixExportStatus : InteriorEliminationTraceNoMatrixExportStatus
  pivotDatum_eq : pivotDatum = Q
  residualDatum_eq : residualDatum = R
  candidate_eq_residualCandidate : candidate = R.candidate
  baseEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      baseEntry i j = generatedInteriorLocalBaseEntry W i j
  rowResidual_eq_residualDatum :
    ∀ j : GeneratedInteriorIndex A, rowResidual j = R.rowResidual j
  columnResidual_eq_residualDatum :
    ∀ i : GeneratedInteriorIndex A, columnResidual i = R.columnResidual i
  pivotEntry_eq_pivotDatum : pivotEntry = Q.pivotEntry
  stepUpdateStatus_eq :
    stepUpdateStatus = InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  noGlobalInverseStatus_eq :
    noGlobalInverseStatus = InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
  noCertificateStatus_eq :
    noCertificateStatus = InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
  noInverseEntryFunctionStatus_eq :
    noInverseEntryFunctionStatus =
      InteriorEliminationTraceNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationTrace
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorEliminationTraceNoMatrixExportStatus.noMatrixExportInInteriorEliminationTrace

namespace GeneratedInteriorStepUpdate

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {Q : GeneratedInteriorPivotDatum Cell p A P wp W E K}
variable {R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q}

def fromInteriorBlockInteriorEliminationdRCandidate
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q) :
    GeneratedInteriorStepUpdate Cell p A P wp W E K Q R where
  pivotDatum := Q
  residualDatum := R
  candidate := R.candidate
  baseEntry := fun i j => generatedInteriorLocalBaseEntry W i j
  rowResidual := R.rowResidual
  columnResidual := R.columnResidual
  pivotEntry := Q.pivotEntry
  stepUpdateStatus := InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC
  noMatrixInvStatus := InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  noGlobalInverseStatus := InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
  noCertificateStatus := InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
  noInverseEntryFunctionStatus :=
    InteriorEliminationTraceNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationTrace
  noMatrixExportStatus := InteriorEliminationTraceNoMatrixExportStatus.noMatrixExportInInteriorEliminationTrace
  pivotDatum_eq := by
    rfl
  residualDatum_eq := by
    rfl
  candidate_eq_residualCandidate := by
    rfl
  baseEntry_eq_interiorBlock := by
    intro i j
    rfl
  rowResidual_eq_residualDatum := by
    intro j
    rfl
  columnResidual_eq_residualDatum := by
    intro i
    rfl
  pivotEntry_eq_pivotDatum := by
    rfl
  stepUpdateStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noGlobalInverseStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noInverseEntryFunctionStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl

theorem noMatrixInv
    (U : GeneratedInteriorStepUpdate Cell p A P wp W E K Q R) :
    U.noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep :=
  U.noMatrixInvStatus_eq

theorem noGlobalInverse
    (U : GeneratedInteriorStepUpdate Cell p A P wp W E K Q R) :
    U.noGlobalInverseStatus =
      InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep :=
  U.noGlobalInverseStatus_eq

theorem noCertificate
    (U : GeneratedInteriorStepUpdate Cell p A P wp W E K Q R) :
    U.noCertificateStatus = InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep :=
  U.noCertificateStatus_eq

end GeneratedInteriorStepUpdate

structure GeneratedInteriorEliminationStep
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E) where
  pivotDatum : GeneratedInteriorPivotDatum Cell p A P wp W E K
  residualDatum : GeneratedInteriorResidualDatum Cell p A P wp W E K pivotDatum
  stepUpdate :
    GeneratedInteriorStepUpdate Cell p A P wp W E K pivotDatum residualDatum
  profileData : GeneratedInteriorBlockStructureProfile Cell p A P wp W
  candidate : GeneratedInteriorEliminationCandidate Cell p A P wp W
  stepStatus : InteriorEliminationTraceEliminationStepStatus
  noMatrixInvStatus : InteriorEliminationTraceNoMatrixInvStatus
  noFreePivotDataStatus : InteriorEliminationTraceNoFreePivotDataStatus
  noGlobalPivotOrderStatus : InteriorEliminationTraceNoGlobalPivotOrderStatus
  noTraceSemanticsStatus : InteriorEliminationTraceNoTraceSemanticsStatus
  noGlobalInverseStatus : InteriorEliminationTraceNoGlobalInverseStatus
  noCertificateStatus : InteriorEliminationTraceNoCertificateStatus
  noInverseEntryFunctionStatus : InteriorEliminationTraceNoInverseEntryFunctionStatus
  noMatrixExportStatus : InteriorEliminationTraceNoMatrixExportStatus
  noTwoSidedInvStatus : InteriorEliminationTraceNoTwoSidedInvStatus
  noDtnDataStatus : InteriorEliminationTraceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorEliminationTraceNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorEliminationTraceNextPositiveConstructionGate
  profileData_eq_carrierProfileData : profileData = K.profileData
  candidate_eq_carrierCandidate : candidate = K.candidate
  pivot_from_carrierNode : pivotDatum.node = K.nodeOf pivotDatum.pivotIndex
  residual_from_profile :
    residualDatum.residualDatumStatus =
      InteriorEliminationTraceResidualDatumStatus.residualFromInteriorBlockInteriorEliminationdRProfile
  update_from_candidate :
    stepUpdate.stepUpdateStatus =
      InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC
  stepStatus_eq :
    stepStatus = InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  noFreePivotDataStatus_eq :
    noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
  noGlobalPivotOrderStatus_eq :
    noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder
  noTraceSemanticsStatus_eq :
    noTraceSemanticsStatus = InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics
  noGlobalInverseStatus_eq :
    noGlobalInverseStatus = InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
  noCertificateStatus_eq :
    noCertificateStatus = InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
  noInverseEntryFunctionStatus_eq :
    noInverseEntryFunctionStatus =
      InteriorEliminationTraceNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationTrace
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorEliminationTraceNoMatrixExportStatus.noMatrixExportInInteriorEliminationTrace
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorEliminationTraceNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationTrace
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorEliminationTraceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationTrace
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorEliminationTraceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationTrace
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate = InteriorEliminationTraceNextPositiveConstructionGate.generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace

namespace GeneratedInteriorEliminationStep

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}

def fromCarrierNode
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorEliminationStep Cell p A P wp W E K :=
  let Q : GeneratedInteriorPivotDatum Cell p A P wp W E K :=
    GeneratedInteriorPivotDatum.fromCarrierNode K i
  let R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q :=
    GeneratedInteriorResidualDatum.fromInteriorBlockInteriorEliminationdRProfile Q
  let U : GeneratedInteriorStepUpdate Cell p A P wp W E K Q R :=
    GeneratedInteriorStepUpdate.fromInteriorBlockInteriorEliminationdRCandidate R
  {
    pivotDatum := Q
    residualDatum := R
    stepUpdate := U
    profileData := K.profileData
    candidate := K.candidate
    stepStatus := InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed
    noMatrixInvStatus := InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
    noFreePivotDataStatus := InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
    noGlobalPivotOrderStatus := InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder
    noTraceSemanticsStatus := InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics
    noGlobalInverseStatus := InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
    noCertificateStatus := InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
    noInverseEntryFunctionStatus :=
      InteriorEliminationTraceNoInverseEntryFunctionStatus.noInverseEntryFunctionInInteriorEliminationTrace
    noMatrixExportStatus := InteriorEliminationTraceNoMatrixExportStatus.noMatrixExportInInteriorEliminationTrace
    noTwoSidedInvStatus := InteriorEliminationTraceNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationTrace
    noDtnDataStatus :=
      InteriorEliminationTraceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationTrace
    noArithmeticTargetStatus :=
      InteriorEliminationTraceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationTrace
    nextPositiveConstructionGate := InteriorEliminationTraceNextPositiveConstructionGate.generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace
    profileData_eq_carrierProfileData := by
      rfl
    candidate_eq_carrierCandidate := by
      rfl
    pivot_from_carrierNode := by
      rfl
    residual_from_profile := by
      rfl
    update_from_candidate := by
      rfl
    stepStatus_eq := by
      rfl
    noMatrixInvStatus_eq := by
      rfl
    noFreePivotDataStatus_eq := by
      rfl
    noGlobalPivotOrderStatus_eq := by
      rfl
    noTraceSemanticsStatus_eq := by
      rfl
    noGlobalInverseStatus_eq := by
      rfl
    noCertificateStatus_eq := by
      rfl
    noInverseEntryFunctionStatus_eq := by
      rfl
    noMatrixExportStatus_eq := by
      rfl
    noTwoSidedInvStatus_eq := by
      rfl
    noDtnDataStatus_eq := by
      rfl
    noArithmeticTargetStatus_eq := by
      rfl
    nextPositiveConstructionGate_eq := by
      rfl
  }

theorem usesOnlyInteriorBlockInteriorEliminationdR
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.residualDatum.profileSourceStatus =
        InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure ∧
      S.residualDatum.candidateSourceStatus =
        InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate ∧
      S.stepUpdate.stepUpdateStatus =
        InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC :=
  And.intro S.residualDatum.profileSourceStatus_eq
    (And.intro S.residualDatum.candidateSourceStatus_eq S.stepUpdate.stepUpdateStatus_eq)

theorem noMatrixInv
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep :=
  S.noMatrixInvStatus_eq

theorem noFreePivotData
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData :=
  S.noFreePivotDataStatus_eq

theorem noGlobalPivotOrder
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder :=
  S.noGlobalPivotOrderStatus_eq

theorem noTraceSemantics
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noTraceSemanticsStatus = InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics :=
  S.noTraceSemanticsStatus_eq

end GeneratedInteriorEliminationStep

def generatedInteriorPivotDatumFromInteriorEliminationCarrierNode
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorPivotDatum Cell p A P wp W E K :=
  GeneratedInteriorPivotDatum.fromCarrierNode K i

def residualDatumFromInteriorBlockInteriorEliminationdRProfile
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (Q : GeneratedInteriorPivotDatum Cell p A P wp W E K) :
    GeneratedInteriorResidualDatum Cell p A P wp W E K Q :=
  GeneratedInteriorResidualDatum.fromInteriorBlockInteriorEliminationdRProfile Q

def stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef7253
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {Q : GeneratedInteriorPivotDatum Cell p A P wp W E K}
    (R : GeneratedInteriorResidualDatum Cell p A P wp W E K Q) :
    GeneratedInteriorStepUpdate Cell p A P wp W E K Q R :=
  GeneratedInteriorStepUpdate.fromInteriorBlockInteriorEliminationdRCandidate R

def localStepFromInteriorEliminationCarrierNode
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorEliminationStep Cell p A P wp W E K :=
  GeneratedInteriorEliminationStep.fromCarrierNode K i

def generatedInteriorEliminationStep_from_profile
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorEliminationStep Cell p A P wp W E K :=
  localStepFromInteriorEliminationCarrierNode K i

theorem generatedInteriorStepUsesOnlyInteriorBlockInteriorEliminationdR
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.residualDatum.profileSourceStatus =
        InteriorEliminationCarrierProfileSourceStatus.profileFromInteriorBlockInteriorBlockStructure ∧
      S.residualDatum.candidateSourceStatus =
        InteriorEliminationCarrierCandidateSourceStatus.candidateFromInteriorEliminationdRStructureDependentCandidate ∧
      S.stepUpdate.stepUpdateStatus =
        InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC :=
  GeneratedInteriorEliminationStep.usesOnlyInteriorBlockInteriorEliminationdR S

theorem noMatrixInv_for_eliminationStep
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep :=
  S.noMatrixInvStatus_eq

theorem noFreePivotData
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData :=
  S.noFreePivotDataStatus_eq

theorem noGlobalPivotOrder_for_eliminationStep
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder :=
  S.noGlobalPivotOrderStatus_eq

theorem noTraceSemantics_for_eliminationStep
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (S : GeneratedInteriorEliminationStep Cell p A P wp W E K) :
    S.noTraceSemanticsStatus = InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics :=
  S.noTraceSemanticsStatus_eq

def regularGeneratedInteriorEliminationStep
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (i : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p)) :
    GeneratedInteriorEliminationStep
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp) :=
  generatedInteriorEliminationStep_from_profile
    (regularGeneratedInteriorEliminationCarrier b p wp) i

def variableGeneratedInteriorEliminationStep
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy)
    (i : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    GeneratedInteriorEliminationStep
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp) :=
  generatedInteriorEliminationStep_from_profile
    (variableGeneratedInteriorEliminationCarrier β p wp) i

structure InteriorEliminationTraceGeneratedInteriorEliminationStepLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorEliminationTraceGeneratedInteriorEliminationStepLedgerStatus
  interiorEliminationCarrierLedger : InteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight
  regularStep :
    GeneratedInteriorEliminationStep
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
  variableStep :
    GeneratedInteriorEliminationStep
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
  interiorEliminationCarrierLedger_eq_main :
    interiorEliminationCarrierLedger = generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger
      b β p regularWeight variableWeight
  regularStep_eq_main :
    regularStep = regularGeneratedInteriorEliminationStep b p regularWeight regularPivot
  variableStep_eq_main :
    variableStep = variableGeneratedInteriorEliminationStep β p variableWeight variablePivot
  regularNoMatrixInv :
    regularStep.noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  variableNoMatrixInv :
    variableStep.noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  regularNoFreePivotData :
    regularStep.noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
  variableNoFreePivotData :
    variableStep.noFreePivotDataStatus = InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData
  regularNoGlobalPivotOrder :
    regularStep.noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder
  variableNoGlobalPivotOrder :
    variableStep.noGlobalPivotOrderStatus = InteriorEliminationTraceNoGlobalPivotOrderStatus.noGlobalPivotOrder
  regularNoTraceSemantics :
    regularStep.noTraceSemanticsStatus = InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics
  variableNoTraceSemantics :
    variableStep.noTraceSemanticsStatus = InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics
  regularNextPositiveConstructionGate :
    regularStep.nextPositiveConstructionGate = InteriorEliminationTraceNextPositiveConstructionGate.generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace
  variableNextPositiveConstructionGate :
    variableStep.nextPositiveConstructionGate = InteriorEliminationTraceNextPositiveConstructionGate.generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace
  status_eq_closed :
    status = InteriorEliminationTraceGeneratedInteriorEliminationStepLedgerStatus.generatedInteriorEliminationLocalStepClosed

def generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorEliminationTraceGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status := InteriorEliminationTraceGeneratedInteriorEliminationStepLedgerStatus.generatedInteriorEliminationLocalStepClosed
  interiorEliminationCarrierLedger := generatedInteriorEliminationCarrierGeneratedInteriorEliminationCarrierLedger b β p regularWeight variableWeight
  regularStep := regularGeneratedInteriorEliminationStep b p regularWeight regularPivot
  variableStep := variableGeneratedInteriorEliminationStep β p variableWeight variablePivot
  interiorEliminationCarrierLedger_eq_main := by
    rfl
  regularStep_eq_main := by
    rfl
  variableStep_eq_main := by
    rfl
  regularNoMatrixInv := by
    rfl
  variableNoMatrixInv := by
    rfl
  regularNoFreePivotData := by
    rfl
  variableNoFreePivotData := by
    rfl
  regularNoGlobalPivotOrder := by
    rfl
  variableNoGlobalPivotOrder := by
    rfl
  regularNoTraceSemantics := by
    rfl
  variableNoTraceSemantics := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorEliminationTraceGeneratedInteriorEliminationStepLedgerStatus.generatedInteriorEliminationLocalStepClosed := by
  rfl

theorem generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger_regularNoFreePivotData
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularStep.noFreePivotDataStatus =
      InteriorEliminationTraceNoFreePivotDataStatus.noFreePivotData := by
  rfl

theorem generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger_variableNoTraceSemantics
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot).variableStep.noTraceSemanticsStatus =
      InteriorEliminationTraceNoTraceSemanticsStatus.noTraceSemantics := by
  rfl

theorem generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorEliminationStepGeneratedInteriorEliminationStepLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularStep.nextPositiveConstructionGate =
      InteriorEliminationTraceNextPositiveConstructionGate.generatedInteriorEliminationTraceGeneratedInteriorEliminationTrace := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
