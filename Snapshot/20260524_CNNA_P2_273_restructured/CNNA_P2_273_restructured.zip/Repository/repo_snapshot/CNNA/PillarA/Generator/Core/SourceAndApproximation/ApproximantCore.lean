import CNNA.PillarA.Generator.Core.SourceAndApproximation.MainPath

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.MainPath

universe u

inductive ApproximantRoute where
  | generatedToCSubstrate
  deriving DecidableEq, Repr

inductive CarrierProvenanceStatus where
  | carrierFromGeneratedMainPath
  deriving DecidableEq, Repr

inductive CutoffProvenanceStatus where
  | cutoffFromConcretePolicy
  deriving DecidableEq, Repr

inductive TruncationProvenanceStatus where
  | approximantEqualsGeneratedMainPathTruncation
  deriving DecidableEq, Repr

inductive FiniteCarrierAPIStatus where
  | substrateFintypeAndDecidableEqForwarded
  deriving DecidableEq, Repr

inductive BoundaryPortsCoreStatus where
  | noBoundaryPortsInCore
  deriving DecidableEq, Repr

inductive CutSpecCoreStatus where
  | noCutSpecInCore
  deriving DecidableEq, Repr

inductive MatrixDataStatus where
  | noMatrixDataYet
  deriving DecidableEq, Repr

inductive DirichletDataStatus where
  | noDirichletDataYet
  deriving DecidableEq, Repr

inductive DtNDataStatus where
  | noDtNDataYet
  deriving DecidableEq, Repr

inductive DiscriminantDataStatus where
  | noDiscriminantOrTargetDataYet
  deriving DecidableEq, Repr

inductive GeneratedApproximantLedgerStatus where
  | generatedApproximantCoreClosed
  deriving DecidableEq, Repr

theorem GeneratedMainPath.approximant_eq_truncate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf} (P : MainPath.GeneratedMainPath Cell p) :
    P.toc.approximant p = P.family.truncate p.L_max := by
  calc
    P.toc.approximant p = (generatedBranchToC Cell).approximant p := by
      rw [P.toc_eq_generated]
    _ = (generatedBranchFamily Cell).truncate p.L_max := by
      exact ToCStrong.approximant_eq_truncate
        (T := generatedBranchToC Cell) p
    _ = P.family.truncate p.L_max := by
      rw [P.family_eq_generated]

structure GeneratedFiniteCarrierAPI
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (T : TruncatedFamily Cell) where
  carrier : ∀ L : Nat, Finset (Cell L)
  carrier_eq_approximant : ∀ L : Nat, carrier L = T.carrier L
  decidableEqCarrier : ∀ L : Nat, DecidableEq (Cell L)
  fintypeCarrier : ∀ L : Nat, Fintype (Cell L)
  decidableMemCarrier : ∀ L : Nat, ∀ x : Cell L, Decidable (x ∈ T.carrier L)
  status : FiniteCarrierAPIStatus
  status_eq_forwarded :
    status = FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded

namespace GeneratedFiniteCarrierAPI

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable (T : TruncatedFamily Cell)

def ofTruncatedFamily : GeneratedFiniteCarrierAPI Cell T where
  carrier := T.carrier
  carrier_eq_approximant := by
    intro L
    rfl
  decidableEqCarrier := by
    intro L
    infer_instance
  fintypeCarrier := by
    intro L
    infer_instance
  decidableMemCarrier := by
    intro L x
    infer_instance
  status := FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded
  status_eq_forwarded := by
    rfl

theorem carrier_eq
    (A : GeneratedFiniteCarrierAPI Cell T) (L : Nat) :
    A.carrier L = T.carrier L :=
  A.carrier_eq_approximant L

theorem status_forwarded
    (A : GeneratedFiniteCarrierAPI Cell T) :
    A.status = FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded :=
  A.status_eq_forwarded

end GeneratedFiniteCarrierAPI

structure GeneratedTruncationWitness
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    (P : MainPath.GeneratedMainPath Cell p)
    (T : TruncatedFamily Cell) where
  approximant_eq_mainPath : T = P.toc.approximant p
  approximant_eq_truncate : T = P.family.truncate p.L_max
  cutoff_eq_policy : T.cutoff = p.L_max
  carrier_from_mainPath : ∀ {L : Nat}, L ≤ p.L_max →
    T.carrier L = P.family.carrier L
  carrier_eq_univ_of_le : ∀ {L : Nat}, L ≤ p.L_max →
    T.carrier L = Finset.univ
  carrier_empty_of_gt : ∀ {L : Nat}, p.L_max < L →
    T.carrier L = ∅
  carrierProvenanceStatus : CarrierProvenanceStatus
  cutoffProvenanceStatus : CutoffProvenanceStatus
  truncationProvenanceStatus : TruncationProvenanceStatus
  carrierProvenanceStatus_eq :
    carrierProvenanceStatus = CarrierProvenanceStatus.carrierFromGeneratedMainPath
  cutoffProvenanceStatus_eq :
    cutoffProvenanceStatus = CutoffProvenanceStatus.cutoffFromConcretePolicy
  truncationProvenanceStatus_eq :
    truncationProvenanceStatus =
      TruncationProvenanceStatus.approximantEqualsGeneratedMainPathTruncation

namespace GeneratedTruncationWitness

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}

def ofMainPath (P : MainPath.GeneratedMainPath Cell p) :
    GeneratedTruncationWitness P (P.toc.approximant p) where
  approximant_eq_mainPath := by
    rfl
  approximant_eq_truncate := by
    exact GeneratedMainPath.approximant_eq_truncate P
  cutoff_eq_policy := by
    rw [GeneratedMainPath.approximant_eq_truncate P]
    rfl
  carrier_from_mainPath := by
    intro L hL
    rw [GeneratedMainPath.approximant_eq_truncate P]
    exact DirectedFamily.truncate_carrier_of_le (F := P.family) hL
  carrier_eq_univ_of_le := by
    intro L hL
    exact P.approximant_carrier_eq_univ_of_le hL
  carrier_empty_of_gt := by
    intro L hL
    rw [GeneratedMainPath.approximant_eq_truncate P]
    exact DirectedFamily.truncate_carrier_of_gt (F := P.family) hL
  carrierProvenanceStatus := CarrierProvenanceStatus.carrierFromGeneratedMainPath
  cutoffProvenanceStatus := CutoffProvenanceStatus.cutoffFromConcretePolicy
  truncationProvenanceStatus :=
    TruncationProvenanceStatus.approximantEqualsGeneratedMainPathTruncation
  carrierProvenanceStatus_eq := by
    rfl
  cutoffProvenanceStatus_eq := by
    rfl
  truncationProvenanceStatus_eq := by
    rfl

theorem cutoff_from_policy
    {P : MainPath.GeneratedMainPath Cell p} {T : TruncatedFamily Cell}
    (W : GeneratedTruncationWitness P T) :
    T.cutoff = p.L_max :=
  W.cutoff_eq_policy

theorem carrier_eq_univ
    {P : MainPath.GeneratedMainPath Cell p} {T : TruncatedFamily Cell}
    (W : GeneratedTruncationWitness P T) {L : Nat}
    (hL : L ≤ p.L_max) :
    T.carrier L = Finset.univ :=
  W.carrier_eq_univ_of_le hL

end GeneratedTruncationWitness

structure GeneratedApproximantStrong
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf) where
  mainPath : MainPath.GeneratedMainPath Cell p
  approximant : TruncatedFamily Cell
  approximant_eq_mainPath : approximant = mainPath.toc.approximant p
  approximant_eq_truncate : approximant = mainPath.family.truncate p.L_max
  route : ApproximantRoute
  route_eq_generated : route = ApproximantRoute.generatedToCSubstrate
  truncationWitness : GeneratedTruncationWitness mainPath approximant
  finiteCarrierAPI : GeneratedFiniteCarrierAPI Cell approximant
  boundaryPortsStatus : BoundaryPortsCoreStatus
  cutSpecStatus : CutSpecCoreStatus
  matrixDataStatus : MatrixDataStatus
  dirichletDataStatus : DirichletDataStatus
  dtnDataStatus : DtNDataStatus
  discriminantDataStatus : DiscriminantDataStatus
  noBoundaryPortsInCore :
    boundaryPortsStatus = BoundaryPortsCoreStatus.noBoundaryPortsInCore
  noCutSpecInCore :
    cutSpecStatus = CutSpecCoreStatus.noCutSpecInCore
  noMatrixDataYet :
    matrixDataStatus = MatrixDataStatus.noMatrixDataYet
  noDirichletDataYet :
    dirichletDataStatus = DirichletDataStatus.noDirichletDataYet
  noDtNDataYet :
    dtnDataStatus = DtNDataStatus.noDtNDataYet
  noDiscriminantOrTargetDataYet :
    discriminantDataStatus =
      DiscriminantDataStatus.noDiscriminantOrTargetDataYet

namespace GeneratedApproximantStrong

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}

def fromMainPath (P : MainPath.GeneratedMainPath Cell p) :
    GeneratedApproximantStrong Cell p where
  mainPath := P
  approximant := P.toc.approximant p
  approximant_eq_mainPath := by
    rfl
  approximant_eq_truncate := by
    exact GeneratedMainPath.approximant_eq_truncate P
  route := ApproximantRoute.generatedToCSubstrate
  route_eq_generated := by
    rfl
  truncationWitness := GeneratedTruncationWitness.ofMainPath P
  finiteCarrierAPI := GeneratedFiniteCarrierAPI.ofTruncatedFamily (P.toc.approximant p)
  boundaryPortsStatus := BoundaryPortsCoreStatus.noBoundaryPortsInCore
  cutSpecStatus := CutSpecCoreStatus.noCutSpecInCore
  matrixDataStatus := MatrixDataStatus.noMatrixDataYet
  dirichletDataStatus := DirichletDataStatus.noDirichletDataYet
  dtnDataStatus := DtNDataStatus.noDtNDataYet
  discriminantDataStatus := DiscriminantDataStatus.noDiscriminantOrTargetDataYet
  noBoundaryPortsInCore := by
    rfl
  noCutSpecInCore := by
    rfl
  noMatrixDataYet := by
    rfl
  noDirichletDataYet := by
    rfl
  noDtNDataYet := by
    rfl
  noDiscriminantOrTargetDataYet := by
    rfl

theorem route_generated
    (A : GeneratedApproximantStrong Cell p) :
    A.route = ApproximantRoute.generatedToCSubstrate :=
  A.route_eq_generated

theorem cutoff_from_policy
    (A : GeneratedApproximantStrong Cell p) :
    A.approximant.cutoff = p.L_max :=
  A.truncationWitness.cutoff_eq_policy

theorem carrier_from_mainPath
    (A : GeneratedApproximantStrong Cell p) {L : Nat}
    (hL : L ≤ p.L_max) :
    A.approximant.carrier L = A.mainPath.family.carrier L :=
  A.truncationWitness.carrier_from_mainPath hL

theorem carrier_eq_univ_of_le
    (A : GeneratedApproximantStrong Cell p) {L : Nat}
    (hL : L ≤ p.L_max) :
    A.approximant.carrier L = Finset.univ :=
  A.truncationWitness.carrier_eq_univ_of_le hL

theorem carrier_empty_of_gt
    (A : GeneratedApproximantStrong Cell p) {L : Nat}
    (hL : p.L_max < L) :
    A.approximant.carrier L = ∅ :=
  A.truncationWitness.carrier_empty_of_gt hL

theorem finiteCarrierAPI_status
    (A : GeneratedApproximantStrong Cell p) :
    A.finiteCarrierAPI.status =
      FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded :=
  A.finiteCarrierAPI.status_eq_forwarded

theorem no_boundary_ports
    (A : GeneratedApproximantStrong Cell p) :
    A.boundaryPortsStatus = BoundaryPortsCoreStatus.noBoundaryPortsInCore :=
  A.noBoundaryPortsInCore

theorem no_cutSpec
    (A : GeneratedApproximantStrong Cell p) :
    A.cutSpecStatus = CutSpecCoreStatus.noCutSpecInCore :=
  A.noCutSpecInCore

theorem no_matrix_data
    (A : GeneratedApproximantStrong Cell p) :
    A.matrixDataStatus = MatrixDataStatus.noMatrixDataYet :=
  A.noMatrixDataYet

theorem no_dirichlet_data
    (A : GeneratedApproximantStrong Cell p) :
    A.dirichletDataStatus = DirichletDataStatus.noDirichletDataYet :=
  A.noDirichletDataYet

end GeneratedApproximantStrong

def generatedApproximantStrong
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf) :
    GeneratedApproximantStrong Cell p :=
  GeneratedApproximantStrong.fromMainPath (generatedMainPath Cell p)

abbrev RegularGeneratedApproximantStrong
    (b : Nat) (p : ConcretePolicyOf) :=
  GeneratedApproximantStrong (ConcreteSubstrate.RegularCell b) p

abbrev VariableGeneratedApproximantStrong
    (β : Nat → Nat) (p : ConcretePolicyOf) :=
  GeneratedApproximantStrong (LevelVariableSubstrate.LevelVariableCell β) p

def regularGeneratedApproximantStrong
    (b : Nat) (p : ConcretePolicyOf) :
    RegularGeneratedApproximantStrong b p :=
  GeneratedApproximantStrong.fromMainPath (regularGeneratedMainPath b p)

def variableGeneratedApproximantStrong
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    VariableGeneratedApproximantStrong β p :=
  GeneratedApproximantStrong.fromMainPath (variableGeneratedMainPath β p)

theorem regularGeneratedApproximantStrong_mainPath
    (b : Nat) (p : ConcretePolicyOf) :
    (regularGeneratedApproximantStrong b p).mainPath =
      regularGeneratedMainPath b p := by
  rfl

theorem variableGeneratedApproximantStrong_mainPath
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (variableGeneratedApproximantStrong β p).mainPath =
      variableGeneratedMainPath β p := by
  rfl

theorem regularGeneratedApproximantStrong_route
    (b : Nat) (p : ConcretePolicyOf) :
    (regularGeneratedApproximantStrong b p).route =
      ApproximantRoute.generatedToCSubstrate := by
  rfl

theorem variableGeneratedApproximantStrong_route
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (variableGeneratedApproximantStrong β p).route =
      ApproximantRoute.generatedToCSubstrate := by
  rfl

theorem regularGeneratedApproximantStrong_cutoff
    (b : Nat) (p : ConcretePolicyOf) :
    (regularGeneratedApproximantStrong b p).approximant.cutoff = p.L_max := by
  exact GeneratedApproximantStrong.cutoff_from_policy
    (regularGeneratedApproximantStrong b p)

theorem variableGeneratedApproximantStrong_cutoff
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (variableGeneratedApproximantStrong β p).approximant.cutoff = p.L_max := by
  exact GeneratedApproximantStrong.cutoff_from_policy
    (variableGeneratedApproximantStrong β p)

theorem regularGeneratedApproximantStrong_carrier_eq_univ_of_le
    (b : Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    (regularGeneratedApproximantStrong b p).approximant.carrier L = Finset.univ := by
  exact GeneratedApproximantStrong.carrier_eq_univ_of_le
    (regularGeneratedApproximantStrong b p) hL

theorem variableGeneratedApproximantStrong_carrier_eq_univ_of_le
    (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    (variableGeneratedApproximantStrong β p).approximant.carrier L = Finset.univ := by
  exact GeneratedApproximantStrong.carrier_eq_univ_of_le
    (variableGeneratedApproximantStrong β p) hL

theorem regularGeneratedApproximantStrong_carrier_empty_of_gt
    (b : Nat) {p : ConcretePolicyOf} {L : Nat} (hL : p.L_max < L) :
    (regularGeneratedApproximantStrong b p).approximant.carrier L = ∅ := by
  exact GeneratedApproximantStrong.carrier_empty_of_gt
    (regularGeneratedApproximantStrong b p) hL

theorem variableGeneratedApproximantStrong_carrier_empty_of_gt
    (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat} (hL : p.L_max < L) :
    (variableGeneratedApproximantStrong β p).approximant.carrier L = ∅ := by
  exact GeneratedApproximantStrong.carrier_empty_of_gt
    (variableGeneratedApproximantStrong β p) hL

structure GeneratedApproximantLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) where
  status : GeneratedApproximantLedgerStatus
  generatedVariationLedger : GeneratedVariationLedger b β p
  regular : RegularGeneratedApproximantStrong b p
  variablePath : VariableGeneratedApproximantStrong β p
  generatedVariationLedger_eq_main : generatedVariationLedger = generatedVariationGeneratedVariationLedger b β p
  regular_eq_main : regular = regularGeneratedApproximantStrong b p
  variable_eq_main : variablePath = variableGeneratedApproximantStrong β p
  regular_mainPath_eq_generatedVariation : regular.mainPath = generatedVariationLedger.pair.regular
  variable_mainPath_eq_generatedVariation : variablePath.mainPath = generatedVariationLedger.pair.variablePath
  sameGeneratedPipeline :
    generatedVariationLedger.pair.pipelineAgreement =
      GeneratedPipelineAgreement.sameGeneratedToCPipeline
  noArithmeticSpecialVariation :
    generatedVariationLedger.pair.variationStatus =
      GeneratedVariationStatus.noArithmeticSpecialVariation
  regularRoute : regular.route = ApproximantRoute.generatedToCSubstrate
  variableRoute : variablePath.route = ApproximantRoute.generatedToCSubstrate
  regularCutoff : regular.approximant.cutoff = p.L_max
  variableCutoff : variablePath.approximant.cutoff = p.L_max
  regularFiniteCarrierAPI :
    regular.finiteCarrierAPI.status =
      FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded
  variableFiniteCarrierAPI :
    variablePath.finiteCarrierAPI.status =
      FiniteCarrierAPIStatus.substrateFintypeAndDecidableEqForwarded
  regularNoBoundaryPorts :
    regular.boundaryPortsStatus = BoundaryPortsCoreStatus.noBoundaryPortsInCore
  variableNoBoundaryPorts :
    variablePath.boundaryPortsStatus = BoundaryPortsCoreStatus.noBoundaryPortsInCore
  regularNoCutSpec : regular.cutSpecStatus = CutSpecCoreStatus.noCutSpecInCore
  variableNoCutSpec : variablePath.cutSpecStatus = CutSpecCoreStatus.noCutSpecInCore
  regularNoMatrixData : regular.matrixDataStatus = MatrixDataStatus.noMatrixDataYet
  variableNoMatrixData : variablePath.matrixDataStatus = MatrixDataStatus.noMatrixDataYet
  regularNoDirichletData :
    regular.dirichletDataStatus = DirichletDataStatus.noDirichletDataYet
  variableNoDirichletData :
    variablePath.dirichletDataStatus = DirichletDataStatus.noDirichletDataYet
  regularNoDtNData : regular.dtnDataStatus = DtNDataStatus.noDtNDataYet
  variableNoDtNData : variablePath.dtnDataStatus = DtNDataStatus.noDtNDataYet
  regularNoDiscriminantOrTargetData :
    regular.discriminantDataStatus =
      DiscriminantDataStatus.noDiscriminantOrTargetDataYet
  variableNoDiscriminantOrTargetData :
    variablePath.discriminantDataStatus =
      DiscriminantDataStatus.noDiscriminantOrTargetDataYet
  status_eq_closed :
    status = GeneratedApproximantLedgerStatus.generatedApproximantCoreClosed

def generatedApproximantGeneratedApproximantLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedApproximantLedger b β p where
  status := GeneratedApproximantLedgerStatus.generatedApproximantCoreClosed
  generatedVariationLedger := generatedVariationGeneratedVariationLedger b β p
  regular := regularGeneratedApproximantStrong b p
  variablePath := variableGeneratedApproximantStrong β p
  generatedVariationLedger_eq_main := by
    rfl
  regular_eq_main := by
    rfl
  variable_eq_main := by
    rfl
  regular_mainPath_eq_generatedVariation := by
    rfl
  variable_mainPath_eq_generatedVariation := by
    rfl
  sameGeneratedPipeline := by
    rfl
  noArithmeticSpecialVariation := by
    rfl
  regularRoute := by
    rfl
  variableRoute := by
    rfl
  regularCutoff := by
    exact GeneratedApproximantStrong.cutoff_from_policy
      (regularGeneratedApproximantStrong b p)
  variableCutoff := by
    exact GeneratedApproximantStrong.cutoff_from_policy
      (variableGeneratedApproximantStrong β p)
  regularFiniteCarrierAPI := by
    rfl
  variableFiniteCarrierAPI := by
    rfl
  regularNoBoundaryPorts := by
    rfl
  variableNoBoundaryPorts := by
    rfl
  regularNoCutSpec := by
    rfl
  variableNoCutSpec := by
    rfl
  regularNoMatrixData := by
    rfl
  variableNoMatrixData := by
    rfl
  regularNoDirichletData := by
    rfl
  variableNoDirichletData := by
    rfl
  regularNoDtNData := by
    rfl
  variableNoDtNData := by
    rfl
  regularNoDiscriminantOrTargetData := by
    rfl
  variableNoDiscriminantOrTargetData := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedApproximantGeneratedApproximantLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).status =
      GeneratedApproximantLedgerStatus.generatedApproximantCoreClosed := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_regularRoute
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).regular.route =
      ApproximantRoute.generatedToCSubstrate := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_variableRoute
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).variablePath.route =
      ApproximantRoute.generatedToCSubstrate := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_regularNoBoundaryPorts
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).regular.boundaryPortsStatus =
      BoundaryPortsCoreStatus.noBoundaryPortsInCore := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_variableNoBoundaryPorts
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).variablePath.boundaryPortsStatus =
      BoundaryPortsCoreStatus.noBoundaryPortsInCore := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_regularNoDirichletData
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).regular.dirichletDataStatus =
      DirichletDataStatus.noDirichletDataYet := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_variableNoDirichletData
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf) :
    (generatedApproximantGeneratedApproximantLedger b β p).variablePath.dirichletDataStatus =
      DirichletDataStatus.noDirichletDataYet := by
  rfl

theorem generatedApproximantGeneratedApproximantLedger_regularCarrier_eq_univ_of_le
    (b : Nat) (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat}
    (hL : L ≤ p.L_max) :
    (generatedApproximantGeneratedApproximantLedger b β p).regular.approximant.carrier L =
      Finset.univ := by
  exact regularGeneratedApproximantStrong_carrier_eq_univ_of_le (b := b) hL

theorem generatedApproximantGeneratedApproximantLedger_variableCarrier_eq_univ_of_le
    (b : Nat) (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat}
    (hL : L ≤ p.L_max) :
    (generatedApproximantGeneratedApproximantLedger b β p).variablePath.approximant.carrier L =
      Finset.univ := by
  exact variableGeneratedApproximantStrong_carrier_eq_univ_of_le (β := β) hL

end CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
