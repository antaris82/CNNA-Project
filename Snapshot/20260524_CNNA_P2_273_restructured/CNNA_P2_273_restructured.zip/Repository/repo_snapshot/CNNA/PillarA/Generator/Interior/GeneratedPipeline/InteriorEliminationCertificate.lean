import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorProvenTwoSidedInv

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv

universe u

open scoped BigOperators

def generatedBoundaryBlockGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ :=
  fun i j =>
    generatedDirichletMatrix W
      (GeneratedBoundaryIndex.toApproximantIndex i)
      (GeneratedBoundaryIndex.toApproximantIndex j)

def generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    Matrix (GeneratedBoundaryIndex A) (GeneratedInteriorIndex A) ℝ :=
  fun i j =>
    generatedDirichletMatrix W
      (GeneratedBoundaryIndex.toApproximantIndex i)
      (GeneratedInteriorIndex.toApproximantIndex j)

def generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) :
    Matrix (GeneratedInteriorIndex A) (GeneratedBoundaryIndex A) ℝ :=
  fun i j =>
    generatedDirichletMatrix W
      (GeneratedInteriorIndex.toApproximantIndex i)
      (GeneratedBoundaryIndex.toApproximantIndex j)

def generatedInteriorInverseMatrixGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ :=
  H.candidateMatrix

def generatedInteriorSolveGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    GeneratedInteriorIndex A → ℝ :=
  fun i =>
    - (H.candidateMatrix.mulVec
        ((generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ)) i

def generatedBoundaryOperatorGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ :=
  generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
    generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W * H.candidateMatrix *
      generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W

theorem generatedInteriorInverseMatrixEqHandoffCandidateGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    generatedInteriorInverseMatrixGeneralizedTopBoundaryDtN H = H.candidateMatrix := by
  rfl

theorem generatedBoundaryOperatorEqSchurGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) :
    generatedBoundaryOperatorGeneralizedTopBoundaryDtN H =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W * H.candidateMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W := by
  rfl

theorem generatedInteriorSolveSpecFromTwoSidedInvGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (w : TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    (generatedInteriorBlock W).mulVec (generatedInteriorSolveGeneralizedTopBoundaryDtN H φ) =
      - ((generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ) := by
  let rhs : GeneratedInteriorIndex A → ℝ :=
    (generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ
  have hL : generatedInteriorBlock W * H.candidateMatrix = 1 :=
    w.left_inv
  have hNeg :
      (generatedInteriorBlock W).mulVec (generatedInteriorSolveGeneralizedTopBoundaryDtN H φ) =
        fun i =>
          - ((generatedInteriorBlock W).mulVec
              (H.candidateMatrix.mulVec rhs)) i := by
    funext i
    simp [generatedInteriorSolveGeneralizedTopBoundaryDtN, rhs, Matrix.mulVec, dotProduct,
      Finset.sum_neg_distrib, mul_neg]
  calc
    (generatedInteriorBlock W).mulVec (generatedInteriorSolveGeneralizedTopBoundaryDtN H φ)
        = fun i =>
            - ((generatedInteriorBlock W).mulVec
                (H.candidateMatrix.mulVec rhs)) i := hNeg
    _ = fun i =>
          - (((generatedInteriorBlock W) * H.candidateMatrix).mulVec rhs) i := by
          simp [Matrix.mulVec_mulVec]
    _ = fun i => - rhs i := by
          simp [hL]
    _ = - ((generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ) := by
          rfl

theorem generatedBoundaryOperatorSpecGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ +
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (generatedInteriorSolveGeneralizedTopBoundaryDtN H φ) =
      (generatedBoundaryOperatorGeneralizedTopBoundaryDtN H).mulVec φ := by
  let rhsI : GeneratedInteriorIndex A → ℝ :=
    (generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ
  let wI : GeneratedInteriorIndex A → ℝ := H.candidateMatrix.mulVec rhsI
  let M : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ :=
    generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W * H.candidateMatrix *
      generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  funext b
  have hNeg :
      (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (fun i : GeneratedInteriorIndex A => - wI i) b =
        - ((generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec wI) b := by
    simp [Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, mul_neg]
  have hComp :
      M.mulVec φ b =
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec wI b := by
    simp [M, wI, rhsI, Matrix.mul_assoc, Matrix.mulVec_mulVec]
  have hNegMat :
      (-M).mulVec φ b = - (M.mulVec φ b) := by
    simp [Matrix.mulVec, dotProduct, Finset.sum_neg_distrib, neg_mul]
  have hInteriorTerm :
      (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (fun i : GeneratedInteriorIndex A => - wI i) b =
        (-M).mulVec φ b := by
    calc
      (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (fun i : GeneratedInteriorIndex A => - wI i) b
          = - ((generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec wI) b := hNeg
      _ = - (M.mulVec φ b) := by rw [hComp]
      _ = (-M).mulVec φ b := hNegMat.symm
  have hAdd :
      (generatedBoundaryBlockGeneralizedTopBoundaryDtN W + (-M)).mulVec φ b =
        (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ b + (-M).mulVec φ b := by
    simp [Matrix.mulVec, dotProduct, Finset.sum_add_distrib, add_mul]
  have hw : generatedInteriorSolveGeneralizedTopBoundaryDtN H φ =
      fun i : GeneratedInteriorIndex A => - wI i := by
    funext i
    simp [generatedInteriorSolveGeneralizedTopBoundaryDtN, wI, rhsI]
  calc
    ((generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ +
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
          (generatedInteriorSolveGeneralizedTopBoundaryDtN H φ)) b
        = (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ b +
            (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec
              (fun i : GeneratedInteriorIndex A => - wI i) b := by
              simp [hw]
    _ = (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ b + (-M).mulVec φ b := by
          rw [hInteriorTerm]
    _ = (generatedBoundaryBlockGeneralizedTopBoundaryDtN W + (-M)).mulVec φ b := by
          rw [hAdd]
    _ = (generatedBoundaryOperatorGeneralizedTopBoundaryDtN H).mulVec φ b := by
          simp [generatedBoundaryOperatorGeneralizedTopBoundaryDtN, M, sub_eq_add_neg]

structure GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S) where
  inverseMatrix : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ
  inverseMatrix_eq_handoffCandidate : inverseMatrix = H.candidateMatrix
  inverseWitness : TwoSidedInv (generatedInteriorBlock W) inverseMatrix
  boundaryOperator : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ
  boundaryOperator_eq_schur :
    boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W * inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  interiorSolve : (GeneratedBoundaryIndex A → ℝ) → GeneratedInteriorIndex A → ℝ
  interiorSolve_eq_inverseMul :
    ∀ φ : GeneratedBoundaryIndex A → ℝ,
      interiorSolve φ =
        fun i =>
          - (inverseMatrix.mulVec
              ((generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ)) i
  interiorSolve_spec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    (generatedInteriorBlock W).mulVec (interiorSolve φ) =
      - ((generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ)
  boundaryOperator_spec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    (generatedBoundaryBlockGeneralizedTopBoundaryDtN W).mulVec φ +
        (generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W).mulVec (interiorSolve φ) =
      boundaryOperator.mulVec φ

namespace GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}

def fromTwoSidedInv
    (w : TwoSidedInv (generatedInteriorBlock W) H.candidateMatrix) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H where
  inverseMatrix := H.candidateMatrix
  inverseMatrix_eq_handoffCandidate := by
    rfl
  inverseWitness := w
  boundaryOperator := generatedBoundaryOperatorGeneralizedTopBoundaryDtN H
  boundaryOperator_eq_schur := by
    rfl
  interiorSolve := generatedInteriorSolveGeneralizedTopBoundaryDtN H
  interiorSolve_eq_inverseMul := by
    intro φ
    rfl
  interiorSolve_spec := by
    intro φ
    exact generatedInteriorSolveSpecFromTwoSidedInvGeneralizedTopBoundaryDtN H w φ
  boundaryOperator_spec := by
    intro φ
    exact generatedBoundaryOperatorSpecGeneralizedTopBoundaryDtN H φ

theorem inverseMatrix_from_handoff
    (C : GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H) :
    C.inverseMatrix = H.candidateMatrix :=
  C.inverseMatrix_eq_handoffCandidate

theorem boundaryOperator_from_schur
    (C : GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H) :
    C.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W * C.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  C.boundaryOperator_eq_schur

end GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN

def generatedInteriorEliminationCertificateFromProductIdentityProofGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (Q : GeneratedInteriorInteriorTwoSidedInverseProductIdentityProof Cell p A P wp W E K T M S H) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (twoSidedInv_from_productIdentityProofR4a Q)

def generatedInteriorEliminationCertificateFromProductCancellationLedgerGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : GeneratedInteriorInteriorTwoSidedInverseProductCancellationLedger Cell p A P wp W E K T M S H) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (twoSidedInv_from_productCancellationLedger_via_r4a L)

def generatedInteriorEliminationCertificateFromInteriorEliminationCertificateLedgerGeneralizedTopBoundaryDtN
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
    {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
    (L : InteriorTwoSidedInverseValidationInteriorEliminationCertificateLedger Cell p A P wp W E K T M S H) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN Cell p A P wp W E K T M S H :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (twoSidedInvFromInteriorEliminationCertificateLedgerViaR4a L)

def regularGeneratedInteriorEliminationCertificateFromReRunProductCancellationLedgerGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (regularTwoSidedInv_from_reRunProductCancellationLedger L)

def variableGeneratedInteriorEliminationCertificateFromReRunProductCancellationLedgerGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationGeneratedProductCancellationLedger b β p regularWeight variableWeight) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (variableTwoSidedInv_from_reRunProductCancellationLedger L)

def regularGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight) :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (regularTwoSidedInv_from_accumulatedEntryCancellationLedger L)

def variableGeneratedInteriorEliminationCertificateFromAccumulatedEntryCancellationLedgerGeneralizedTopBoundaryDtN
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight) :=
  GeneratedInteriorEliminationCertificateGeneralizedTopBoundaryDtN.fromTwoSidedInv
    (variableTwoSidedInv_from_accumulatedEntryCancellationLedger L)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
