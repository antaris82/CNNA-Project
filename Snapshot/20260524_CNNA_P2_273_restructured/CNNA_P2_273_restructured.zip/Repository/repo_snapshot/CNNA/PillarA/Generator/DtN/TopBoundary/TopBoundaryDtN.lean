import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev TopBoundaryDtNOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.topBoundaryDtN

def topBoundaryDtNOutputKind : DerivedOutputKind :=
  DerivedOutputKind.topBoundaryDtN

theorem topBoundaryDtN_kind_eq (profile : TopBoundaryDtNOutputProfile) :
    profile.profile.kind = topBoundaryDtNOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
