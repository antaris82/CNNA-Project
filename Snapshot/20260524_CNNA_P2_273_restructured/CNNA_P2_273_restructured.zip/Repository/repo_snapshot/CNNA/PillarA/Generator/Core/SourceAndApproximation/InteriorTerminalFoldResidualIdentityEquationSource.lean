import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
import CNNA.PillarA.Generator.Schur.GeneratedPipeline.MultiSchur

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTerminalFoldResidualIdentityEquationSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields

universe u

inductive InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus where
  | terminalFoldInductionEquationCarriedByEquationDatum
  | terminalFoldInductionEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus where
  | residualClosureEquationCarriedByEquationDatum
  | residualClosureEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus where
  | foldOrderCoverageEquationCarriedByEquationDatum
  | foldOrderCoverageEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus where
  | separateLeftAndRightTerminalIdentityEquationsCarriedByEquationDatum
  | separateLeftAndRightTerminalIdentityEquationsRequiredBeyondCurrentInteriorTerminalFoldResidualAPI
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceEquationSourceStatus where
  | terminalFoldResidualIdentityEquationSourceCarriedByDatum
  | terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceCertificateExportStatus where
  | terminalIdentityFieldCertificatePreparedFromEquationSource
  | terminalIdentityFieldCertificateBlockedUntilEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoFreeIdentityFieldStatus where
  | noFreeIdentityFieldsInFinalCertificateAdapter
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInTerminalFoldResidualIdentityEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInTerminalFoldResidualIdentityEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInTerminalFoldResidualIdentityEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualIdentityEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualIdentityEquationSource
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceNextConsumerStatus where
  | interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource
  | interiorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityFullTerminalCoverageConsumer
  deriving DecidableEq, Repr

inductive InteriorTerminalIdentityEquationSourceLedgerStatus where
  | terminalFoldResidualIdentityEquationSourceAuditClosed
  | terminalFoldResidualIdentityEquationSourceCarriedByDatum
  deriving DecidableEq, Repr

structure GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  terminalFoldInductionEquationStatus : InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus
  residualClosureEquationStatus : InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus
  foldOrderCoverageEquationStatus : InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus
  leftRightTerminalIdentityEquationStatus : InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus
  leftBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i i = 1
  leftBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorLeftBlockFold W T i j = 0
  rightBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i i = 1
  rightBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorRightBlockFold W T i j = 0
  terminalFoldInductionEquationStatus_eq :
    terminalFoldInductionEquationStatus =
      InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus.terminalFoldInductionEquationCarriedByEquationDatum
  residualClosureEquationStatus_eq :
    residualClosureEquationStatus =
      InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus.residualClosureEquationCarriedByEquationDatum
  foldOrderCoverageEquationStatus_eq :
    foldOrderCoverageEquationStatus =
      InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus.foldOrderCoverageEquationCarriedByEquationDatum
  leftRightTerminalIdentityEquationStatus_eq :
    leftRightTerminalIdentityEquationStatus =
      InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus.separateLeftAndRightTerminalIdentityEquationsCarriedByEquationDatum

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTerminalIdentityEquations
    (leftIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (rightIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (leftDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i i = 1)
    (leftOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorLeftBlockFold W T i j = 0)
    (rightDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i i = 1)
    (rightOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorRightBlockFold W T i j = 0) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T where
  terminalFoldInductionEquationStatus :=
    InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus.terminalFoldInductionEquationCarriedByEquationDatum
  residualClosureEquationStatus :=
    InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus.residualClosureEquationCarriedByEquationDatum
  foldOrderCoverageEquationStatus :=
    InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus.foldOrderCoverageEquationCarriedByEquationDatum
  leftRightTerminalIdentityEquationStatus :=
    InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus.separateLeftAndRightTerminalIdentityEquationsCarriedByEquationDatum
  leftBlockFold_eq_identity := leftIdentity
  rightBlockFold_eq_identity := rightIdentity
  leftBlockFold_diagonal := leftDiagonal
  leftBlockFold_offdiag := leftOffdiag
  rightBlockFold_diagonal := rightDiagonal
  rightBlockFold_offdiag := rightOffdiag
  terminalFoldInductionEquationStatus_eq := by
    rfl
  residualClosureEquationStatus_eq := by
    rfl
  foldOrderCoverageEquationStatus_eq := by
    rfl
  leftRightTerminalIdentityEquationStatus_eq := by
    rfl

theorem leftIdentity
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.leftBlockFold_eq_identity i j

theorem rightIdentity
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  D.rightBlockFold_eq_identity i j

end GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource

structure GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  identityFieldsAudit : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T
  coverageAudit : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  tracePivotCoverage : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  terminalFoldState : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  terminalFoldInductionEquationStatus : InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus
  residualClosureEquationStatus : InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus
  foldOrderCoverageEquationStatus : InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus
  leftRightTerminalIdentityEquationStatus : InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus
  equationSourceStatus : InteriorTerminalIdentityEquationSourceEquationSourceStatus
  certificateExportStatus : InteriorTerminalIdentityEquationSourceCertificateExportStatus
  nextConsumerStatus : InteriorTerminalIdentityEquationSourceNextConsumerStatus
  coverageAudit_eq_identityFieldsAudit : coverageAudit = identityFieldsAudit.coverageAudit
  invariance_eq_identityFieldsAudit : invariance = identityFieldsAudit.invariance
  tracePivotCoverage_eq_identityFieldsAudit :
    tracePivotCoverage = identityFieldsAudit.tracePivotCoverage
  terminalFoldState_eq_identityFieldsAudit :
    terminalFoldState = identityFieldsAudit.terminalFoldState
  interiorTerminalFoldResidualIdentityFields_leftSource_missing :
    identityFieldsAudit.leftTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  interiorTerminalFoldResidualIdentityFields_rightSource_missing :
    identityFieldsAudit.rightTerminalIdentityFieldSourceStatus =
      InteriorTerminalIdentityFieldSourceTerminalIdentityFieldSourceStatus.terminalIdentityFieldSourceMissingFromCurrentInteriorTerminalFoldResidualAPI
  interiorTerminalFoldResidualIdentityFields_terminalFoldInductionStatus_eq :
    identityFieldsAudit.terminalFoldInductionEquationStatus =
      InteriorTerminalIdentityFieldSourceTerminalFoldInductionEquationStatus.foldInvarianceAvailableButTerminalIdentityEquationMissing
  interiorTerminalFoldResidualIdentityFields_residualClosureStatus_eq :
    identityFieldsAudit.residualClosureEquationStatus =
      InteriorTerminalIdentityFieldSourceResidualClosureEquationStatus.residualContributionAvailableButNoIdentityClosureEquation
  interiorTerminalFoldResidualIdentityFields_foldOrderCoverageStatus_eq :
    identityFieldsAudit.foldOrderCoverageEquationStatus =
      InteriorTerminalIdentityFieldSourceFoldOrderCoverageEquationStatus.foldUpdateOrderAvailableButNoIdentityClosureEquation
  terminalFoldInductionEquationStatus_eq :
    terminalFoldInductionEquationStatus =
      InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus.terminalFoldInductionEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  residualClosureEquationStatus_eq :
    residualClosureEquationStatus =
      InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus.residualClosureEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  foldOrderCoverageEquationStatus_eq :
    foldOrderCoverageEquationStatus =
      InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus.foldOrderCoverageEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  leftRightTerminalIdentityEquationStatus_eq :
    leftRightTerminalIdentityEquationStatus =
      InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus.separateLeftAndRightTerminalIdentityEquationsRequiredBeyondCurrentInteriorTerminalFoldResidualAPI
  equationSourceStatus_eq :
    equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  certificateExportStatus_eq :
    certificateExportStatus =
      InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromIdentityFieldsAudit
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T where
  identityFieldsAudit := A0
  coverageAudit := A0.coverageAudit
  invariance := A0.invariance
  tracePivotCoverage := A0.tracePivotCoverage
  terminalFoldState := A0.terminalFoldState
  terminalFoldInductionEquationStatus :=
    InteriorTerminalIdentityEquationSourceTerminalFoldInductionEquationStatus.terminalFoldInductionEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  residualClosureEquationStatus :=
    InteriorTerminalIdentityEquationSourceResidualClosureEquationStatus.residualClosureEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  foldOrderCoverageEquationStatus :=
    InteriorTerminalIdentityEquationSourceFoldOrderCoverageEquationStatus.foldOrderCoverageEquationMissingFromCurrentInteriorTerminalFoldResidualAPI
  leftRightTerminalIdentityEquationStatus :=
    InteriorTerminalIdentityEquationSourceLeftRightTerminalIdentityEquationStatus.separateLeftAndRightTerminalIdentityEquationsRequiredBeyondCurrentInteriorTerminalFoldResidualAPI
  equationSourceStatus :=
    InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  certificateExportStatus :=
    InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  nextConsumerStatus := InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource
  coverageAudit_eq_identityFieldsAudit := by
    rfl
  invariance_eq_identityFieldsAudit := by
    rfl
  tracePivotCoverage_eq_identityFieldsAudit := by
    rfl
  terminalFoldState_eq_identityFieldsAudit := by
    rfl
  interiorTerminalFoldResidualIdentityFields_leftSource_missing := A0.leftTerminalIdentityFieldSourceStatus_eq
  interiorTerminalFoldResidualIdentityFields_rightSource_missing := A0.rightTerminalIdentityFieldSourceStatus_eq
  interiorTerminalFoldResidualIdentityFields_terminalFoldInductionStatus_eq := A0.terminalFoldInductionEquationStatus_eq
  interiorTerminalFoldResidualIdentityFields_residualClosureStatus_eq := A0.residualClosureEquationStatus_eq
  interiorTerminalFoldResidualIdentityFields_foldOrderCoverageStatus_eq := A0.foldOrderCoverageEquationStatus_eq
  terminalFoldInductionEquationStatus_eq := by
    rfl
  residualClosureEquationStatus_eq := by
    rfl
  foldOrderCoverageEquationStatus_eq := by
    rfl
  leftRightTerminalIdentityEquationStatus_eq := by
    rfl
  equationSourceStatus_eq := by
    rfl
  certificateExportStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromCoverageAudit
    (C : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T :=
  fromIdentityFieldsAudit
    (GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource.fromTerminalFoldResidualCoverageAudit C)

theorem equationSource_still_required
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    A0.equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource :=
  A0.equationSourceStatus_eq

end GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource

structure GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  sourceAudit : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T
  equationDatum : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T
  identityFieldsAudit : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T
  coverageAudit : GeneratedInteriorTerminalFoldResidualCoverageAuditInteriorTerminalCoverageSource Cell p A P wp W E K T
  invariance : GeneratedInteriorBlockFoldInvarianceInteriorBlockFoldInvariance Cell p A P wp W E K T
  tracePivotCoverage : GeneratedInteriorTracePivotTerminalCoverageSourceInteriorTerminalFoldResidualCoverage Cell p A P wp W E K T
  terminalFoldState : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  equationSourceStatus : InteriorTerminalIdentityEquationSourceEquationSourceStatus
  certificateExportStatus : InteriorTerminalIdentityEquationSourceCertificateExportStatus
  noFreeIdentityFieldStatus : InteriorTerminalIdentityEquationSourceNoFreeIdentityFieldStatus
  noProductIdentityProofStatus : InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : InteriorTerminalIdentityEquationSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorTerminalIdentityEquationSourceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTerminalIdentityEquationSourceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTerminalIdentityEquationSourceNextConsumerStatus
  identityFieldsAudit_eq_sourceAudit : identityFieldsAudit = sourceAudit.identityFieldsAudit
  coverageAudit_eq_sourceAudit : coverageAudit = sourceAudit.coverageAudit
  invariance_eq_sourceAudit : invariance = sourceAudit.invariance
  tracePivotCoverage_eq_sourceAudit : tracePivotCoverage = sourceAudit.tracePivotCoverage
  terminalFoldState_eq_sourceAudit : terminalFoldState = sourceAudit.terminalFoldState
  leftBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightBlockFold_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i i = 1
  leftBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorLeftBlockFold W T i j = 0
  rightBlockFold_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i i = 1
  rightBlockFold_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorRightBlockFold W T i j = 0
  leftBlockFold_eq_identity_from_datum :
    ∀ i j : GeneratedInteriorIndex A,
      leftBlockFold_eq_identity i j = equationDatum.leftBlockFold_eq_identity i j
  rightBlockFold_eq_identity_from_datum :
    ∀ i j : GeneratedInteriorIndex A,
      rightBlockFold_eq_identity i j = equationDatum.rightBlockFold_eq_identity i j
  equationSourceStatus_eq :
    equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceCarriedByDatum
  certificateExportStatus_eq :
    certificateExportStatus =
      InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificatePreparedFromEquationSource
  noFreeIdentityFieldStatus_eq :
    noFreeIdentityFieldStatus =
      InteriorTerminalIdentityEquationSourceNoFreeIdentityFieldStatus.noFreeIdentityFieldsInFinalCertificateAdapter
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualIdentityEquationSource
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualIdentityEquationSource
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorTerminalIdentityEquationSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalFoldResidualIdentityEquationSource
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTerminalIdentityEquationSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualIdentityEquationSource
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTerminalIdentityEquationSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualIdentityEquationSource
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromAuditAndEquationDatum
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T where
  sourceAudit := A0
  equationDatum := D
  identityFieldsAudit := A0.identityFieldsAudit
  coverageAudit := A0.coverageAudit
  invariance := A0.invariance
  tracePivotCoverage := A0.tracePivotCoverage
  terminalFoldState := A0.terminalFoldState
  equationSourceStatus :=
    InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceCarriedByDatum
  certificateExportStatus :=
    InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificatePreparedFromEquationSource
  noFreeIdentityFieldStatus :=
    InteriorTerminalIdentityEquationSourceNoFreeIdentityFieldStatus.noFreeIdentityFieldsInFinalCertificateAdapter
  noProductIdentityProofStatus :=
    InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualIdentityEquationSource
  noTwoSidedInvStatus :=
    InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualIdentityEquationSource
  noInteriorEliminationDataStatus :=
    InteriorTerminalIdentityEquationSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInTerminalFoldResidualIdentityEquationSource
  noDtnDataStatus :=
    InteriorTerminalIdentityEquationSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInTerminalFoldResidualIdentityEquationSource
  noArithmeticTargetStatus :=
    InteriorTerminalIdentityEquationSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInTerminalFoldResidualIdentityEquationSource
  nextConsumerStatus := InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource
  identityFieldsAudit_eq_sourceAudit := by
    rfl
  coverageAudit_eq_sourceAudit := by
    rfl
  invariance_eq_sourceAudit := by
    rfl
  tracePivotCoverage_eq_sourceAudit := by
    rfl
  terminalFoldState_eq_sourceAudit := by
    rfl
  leftBlockFold_eq_identity := D.leftBlockFold_eq_identity
  rightBlockFold_eq_identity := D.rightBlockFold_eq_identity
  leftBlockFold_diagonal := D.leftBlockFold_diagonal
  leftBlockFold_offdiag := D.leftBlockFold_offdiag
  rightBlockFold_diagonal := D.rightBlockFold_diagonal
  rightBlockFold_offdiag := D.rightBlockFold_offdiag
  leftBlockFold_eq_identity_from_datum := by
    intro i j
    rfl
  rightBlockFold_eq_identity_from_datum := by
    intro i j
    rfl
  equationSourceStatus_eq := by
    rfl
  certificateExportStatus_eq := by
    rfl
  noFreeIdentityFieldStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromIdentityFieldsAuditAndEquationDatum
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource Cell p A P wp W E K T)
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T :=
  fromAuditAndEquationDatum
    (GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource.fromIdentityFieldsAudit A0) D

theorem leftBlockFold_entry_eq_identity
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  S.leftBlockFold_eq_identity i j

theorem rightBlockFold_entry_eq_identity
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  S.rightBlockFold_eq_identity i j

theorem noProductIdentityProof
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    S.noProductIdentityProofStatus =
      InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualIdentityEquationSource :=
  S.noProductIdentityProofStatus_eq

theorem noTwoSidedInv
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    S.noTwoSidedInvStatus =
      InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualIdentityEquationSource :=
  S.noTwoSidedInvStatus_eq

end GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource

def terminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T :=
  GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource.fromCoverageAuditAndIdentityFields
    S.coverageAudit
    S.leftBlockFold_eq_identity
    S.rightBlockFold_eq_identity
    S.leftBlockFold_diagonal
    S.leftBlockFold_offdiag
    S.rightBlockFold_diagonal
    S.rightBlockFold_offdiag

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource b p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource.fromIdentityFieldsAudit A0

def variableTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource β p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource.fromIdentityFieldsAudit A0

def regularTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource b p wp)
    (D : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.fromAuditAndEquationDatum A0 D

def variableTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource β p wp)
    (D : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.fromAuditAndEquationDatum A0 D

def regularTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p wp :=
  terminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

def variableTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p wp :=
  terminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

structure InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource b p regularWeight
  variableAudit : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource β p variableWeight
  ledgerStatus : InteriorTerminalIdentityEquationSourceLedgerStatus
  regularEquationSourceStatus : InteriorTerminalIdentityEquationSourceEquationSourceStatus
  variableEquationSourceStatus : InteriorTerminalIdentityEquationSourceEquationSourceStatus
  regularCertificateExportStatus : InteriorTerminalIdentityEquationSourceCertificateExportStatus
  variableCertificateExportStatus : InteriorTerminalIdentityEquationSourceCertificateExportStatus
  nextConsumerStatus : InteriorTerminalIdentityEquationSourceNextConsumerStatus
  regularEquationSourceStatus_eq :
    regularAudit.equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  variableEquationSourceStatus_eq :
    variableAudit.equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  ledgerStatus_eq :
    ledgerStatus = InteriorTerminalIdentityEquationSourceLedgerStatus.terminalFoldResidualIdentityEquationSourceAuditClosed
  regularEquationSourceStatusValue_eq :
    regularEquationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  variableEquationSourceStatusValue_eq :
    variableEquationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  regularCertificateExportStatusValue_eq :
    regularCertificateExportStatus =
      InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  variableCertificateExportStatusValue_eq :
    variableCertificateExportStatus =
      InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource

namespace InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceAuditLedger

def fromRegularAndVariableIdentityFieldAudits
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularIdentityFieldsAudit : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource b p regularWeight)
    (variableIdentityFieldsAudit : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldsAuditInteriorTerminalIdentityFieldSource β p variableWeight) :
    InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceAuditLedger b β p regularWeight variableWeight where
  regularAudit := regularTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource regularIdentityFieldsAudit
  variableAudit := variableTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource variableIdentityFieldsAudit
  ledgerStatus := InteriorTerminalIdentityEquationSourceLedgerStatus.terminalFoldResidualIdentityEquationSourceAuditClosed
  regularEquationSourceStatus :=
    InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  variableEquationSourceStatus :=
    InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource
  regularCertificateExportStatus :=
    InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  variableCertificateExportStatus :=
    InteriorTerminalIdentityEquationSourceCertificateExportStatus.terminalIdentityFieldCertificateBlockedUntilEquationSource
  nextConsumerStatus := InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource
  regularEquationSourceStatus_eq := by
    rfl
  variableEquationSourceStatus_eq := by
    rfl
  ledgerStatus_eq := by
    rfl
  regularEquationSourceStatusValue_eq := by
    rfl
  variableEquationSourceStatusValue_eq := by
    rfl
  regularCertificateExportStatusValue_eq := by
    rfl
  variableCertificateExportStatusValue_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceAuditLedger

structure InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularSource : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p regularWeight
  variableSource : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p variableWeight
  ledgerStatus : InteriorTerminalIdentityEquationSourceLedgerStatus
  regularCertificate : RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p regularWeight
  variableCertificate : VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p variableWeight
  nextConsumerStatus : InteriorTerminalIdentityEquationSourceNextConsumerStatus
  regularCertificate_eq_source :
    regularCertificate = regularTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource regularSource
  variableCertificate_eq_source :
    variableCertificate = variableTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource variableSource
  ledgerStatus_eq :
    ledgerStatus = InteriorTerminalIdentityEquationSourceLedgerStatus.terminalFoldResidualIdentityEquationSourceCarriedByDatum
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource

namespace InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger

def fromRegularAndVariableSources
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p regularWeight)
    (variableSource : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p variableWeight) :
    InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger b β p regularWeight variableWeight where
  regularSource := regularSource
  variableSource := variableSource
  ledgerStatus := InteriorTerminalIdentityEquationSourceLedgerStatus.terminalFoldResidualIdentityEquationSourceCarriedByDatum
  regularCertificate := regularTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource regularSource
  variableCertificate := variableTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource variableSource
  nextConsumerStatus := InteriorTerminalIdentityEquationSourceNextConsumerStatus.interiorTerminalFoldResidualIdentityCertificateTerminalIdentityFieldCertificateFromEquationSource
  regularCertificate_eq_source := by
    rfl
  variableCertificate_eq_source := by
    rfl
  ledgerStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger

abbrev GeneratedInteriorTerminalFoldResidualIdentityEquationDatum :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationDatum

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev fromTerminalIdentityEquations
    (leftIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (rightIdentity :
      ∀ i j : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i j =
          (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j)
    (leftDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorLeftBlockFold W T i i = 1)
    (leftOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorLeftBlockFold W T i j = 0)
    (rightDiagonal :
      ∀ i : GeneratedInteriorIndex A,
        generatedInteriorRightBlockFold W T i i = 1)
    (rightOffdiag :
      ∀ i j : GeneratedInteriorIndex A,
        i ≠ j → generatedInteriorRightBlockFold W T i j = 0) :
    GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource.fromTerminalIdentityEquations
    leftIdentity rightIdentity leftDiagonal leftOffdiag rightDiagonal rightOffdiag

abbrev leftIdentity
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource.leftIdentity D i j

abbrev rightIdentity
    (D : GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource.rightIdentity D i j

end GeneratedInteriorTerminalFoldResidualIdentityEquationDatum

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev equationSource_still_required
    (A0 : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    A0.equationSourceStatus =
      InteriorTerminalIdentityEquationSourceEquationSourceStatus.terminalFoldResidualIdentityEquationSourceRequiredBeyondCurrentInteriorTerminalIdentityFieldSource :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource.equationSource_still_required A0

end GeneratedInteriorTerminalFoldResidualIdentityEquationSourceAudit

abbrev GeneratedInteriorTerminalFoldResidualIdentityEquationSource :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource

namespace GeneratedInteriorTerminalFoldResidualIdentityEquationSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

abbrev leftBlockFold_entry_eq_identity
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorLeftBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.leftBlockFold_entry_eq_identity S i j

abbrev rightBlockFold_entry_eq_identity
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorRightBlockFold W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.rightBlockFold_entry_eq_identity S i j

abbrev noProductIdentityProof
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    S.noProductIdentityProofStatus =
      InteriorTerminalIdentityEquationSourceNoProductIdentityProofStatus.noProductIdentityProofInTerminalFoldResidualIdentityEquationSource :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.noProductIdentityProof S

abbrev noTwoSidedInv
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    S.noTwoSidedInvStatus =
      InteriorTerminalIdentityEquationSourceNoTwoSidedInvStatus.noTwoSidedInvInTerminalFoldResidualIdentityEquationSource :=
  GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource.noTwoSidedInv S

end GeneratedInteriorTerminalFoldResidualIdentityEquationSource

abbrev terminalFoldResidualIdentityFieldCertificateFromEquationSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource Cell p A P wp W E K T) :
    GeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource Cell p A P wp W E K T :=
  terminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityEquationDatum :=
  RegularGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityEquationDatum :=
  VariableGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource

abbrev RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSource :=
  RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource

abbrev VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSource :=
  VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource

abbrev regularTerminalFoldResidualIdentityEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource b p wp)
    (D : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp :=
  regularTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource A0 D

abbrev variableTerminalFoldResidualIdentityEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (A0 : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceAuditInteriorTerminalIdentityEquationSource β p wp)
    (D : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationDatumInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp :=
  variableTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource A0 D

abbrev regularTerminalFoldResidualIdentityFieldCertificateFromEquationSource
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p wp) :
    RegularGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource b p wp :=
  regularTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

abbrev variableTerminalFoldResidualIdentityFieldCertificateFromEquationSource
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (S : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p wp) :
    VariableGeneratedInteriorTerminalFoldResidualIdentityFieldCertificateInteriorTerminalIdentityFieldSource β p wp :=
  variableTerminalFoldResidualIdentityFieldCertificateFromInteriorTerminalIdentityEquationSource S

namespace TerminalFoldResidualIdentityEquationSourceLedger

abbrev fromRegularAndVariableSources
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource b p regularWeight)
    (variableSource : VariableGeneratedInteriorTerminalFoldResidualIdentityEquationSourceInteriorTerminalIdentityEquationSource β p variableWeight) :
    InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger b β p regularWeight variableWeight :=
  InteriorTerminalIdentityEquationSourceTerminalFoldResidualIdentityEquationSourceLedger.fromRegularAndVariableSources
    regularSource variableSource

end TerminalFoldResidualIdentityEquationSourceLedger

end CNNA.PillarA.Arithmetic.SourceAndApproximation.InteriorTerminalFoldResidualIdentityEquationSource
