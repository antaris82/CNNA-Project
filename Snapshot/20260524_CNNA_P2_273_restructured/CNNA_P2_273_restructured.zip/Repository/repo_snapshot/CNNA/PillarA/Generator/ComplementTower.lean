import CNNA.PillarA.Generator.RequestProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

universe u

inductive TowerLevelKind where
  | finite
  | limitProfile
  deriving DecidableEq, Repr

structure LevelWindowMembership (window : LevelWindow) where
  level : Nat
  lower : window.L_min ≤ level
  upper : level ≤ window.L_max

namespace LevelWindowMembership

variable {window : LevelWindow}

def inWindow (m : LevelWindowMembership window) : Prop :=
  window.L_min ≤ m.level ∧ m.level ≤ window.L_max

theorem inWindow_intro (m : LevelWindowMembership window) :
    m.inWindow :=
  ⟨m.lower, m.upper⟩

end LevelWindowMembership

structure ComplementFamilyTowerLevel where
  global : GlobalTheoryApproximationState
  windowLevel : LevelWindowMembership global.levelWindow
  kind : TowerLevelKind

namespace ComplementFamilyTowerLevel

def level (t : ComplementFamilyTowerLevel) : Nat :=
  t.windowLevel.level

theorem lower_bound (t : ComplementFamilyTowerLevel) :
    t.global.levelWindow.L_min ≤ t.level :=
  t.windowLevel.lower

theorem upper_bound (t : ComplementFamilyTowerLevel) :
    t.level ≤ t.global.levelWindow.L_max :=
  t.windowLevel.upper

theorem within_window (t : ComplementFamilyTowerLevel) :
    t.global.levelWindow.L_min ≤ t.level ∧
      t.level ≤ t.global.levelWindow.L_max :=
  ⟨t.lower_bound, t.upper_bound⟩

end ComplementFamilyTowerLevel

structure ComplementFamilyApproximationTower where
  lock : SinglePreparationLock
  LevelData : Nat → Type u
  levelProfile : (L : Nat) → LevelData L → ComplementFamilyTowerLevel
  locked : ∀ (L : Nat) (x : LevelData L), (levelProfile L x).global = lock.state
  nonemptyAtWindowMax : Nonempty (LevelData lock.state.levelWindow.L_max)

namespace ComplementFamilyApproximationTower

def global (tower : ComplementFamilyApproximationTower) :
    GlobalTheoryApproximationState :=
  tower.lock.state

def window (tower : ComplementFamilyApproximationTower) : LevelWindow :=
  tower.global.levelWindow

def L_max (tower : ComplementFamilyApproximationTower) : Nat :=
  tower.window.L_max

def topLevelData (tower : ComplementFamilyApproximationTower) :
    Type u :=
  tower.LevelData tower.L_max

theorem levelProfile_global_eq (tower : ComplementFamilyApproximationTower)
    (L : Nat) (x : tower.LevelData L) :
    (tower.levelProfile L x).global = tower.global :=
  tower.locked L x

theorem topLevel_nonempty (tower : ComplementFamilyApproximationTower) :
    Nonempty tower.topLevelData :=
  tower.nonemptyAtWindowMax

end ComplementFamilyApproximationTower

end CNNA.PillarA.Generator
