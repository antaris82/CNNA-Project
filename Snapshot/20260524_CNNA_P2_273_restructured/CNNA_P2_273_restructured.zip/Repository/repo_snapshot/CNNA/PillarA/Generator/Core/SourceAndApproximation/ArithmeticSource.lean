import CNNA.PillarA.Generator.Schur.GeneratedPipeline.MultiSchur
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur

universe u

inductive GeneratedArithmeticSourceKindGeneratedArithmeticSource where
  | regularGenerated
  | variableGenerated
  deriving DecidableEq, Repr

inductive GeneratedArithmeticSourceSourceGeneratedMultiSchurStatus where
  | sourceIsGeneratedMultiSchurGeneratedMultiSchurLedger
  deriving DecidableEq, Repr

inductive GeneratedArithmeticSourceNoNewToCGeneratorStatus where
  | noNewToCGeneratorInGeneratedArithmeticSource
  deriving DecidableEq, Repr

inductive GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus where
  | noPublicMultiSchurStrongForcedInGeneratedArithmeticSource
  deriving DecidableEq, Repr

inductive GeneratedArithmeticSourceNoLevelHistoryStatus where
  | noLevelHistoryDataInGeneratedArithmeticSource
  deriving DecidableEq, Repr

inductive GeneratedArithmeticSourceNoCharpolyDiscriminantStatus where
  | noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource
  deriving DecidableEq, Repr

structure GeneratedArithmeticSourceLevelStepWitnessRef71C4
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  kind : GeneratedArithmeticSourceKindGeneratedArithmeticSource
  sourceGeneratedMultiSchurStatus : GeneratedArithmeticSourceSourceGeneratedMultiSchurStatus
  sourceGeneratedMultiSchurStatusEq :
    sourceGeneratedMultiSchurStatus = GeneratedArithmeticSourceSourceGeneratedMultiSchurStatus.sourceIsGeneratedMultiSchurGeneratedMultiSchurLedger
  sourceMultiSchur : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H
  sourceEqGeneratedMultiSchur : sourceMultiSchur = G
  boundaryOperator : Matrix (GeneratedBoundaryIndex A) (GeneratedBoundaryIndex A) ℝ
  boundaryOperatorEqGeneratedMultiSchur : boundaryOperator = sourceMultiSchur.boundaryOperator
  boundaryOperator_eq_schur :
    boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  «apply» : (GeneratedBoundaryIndex A → ℝ) → GeneratedBoundaryIndex A → ℝ
  applyEqGeneratedMultiSchur : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = sourceMultiSchur.«apply» φ
  apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    «apply» φ = boundaryOperator.mulVec φ
  noNewToCGeneratorStatus : GeneratedArithmeticSourceNoNewToCGeneratorStatus
  noNewToCGeneratorStatus_eq :
    noNewToCGeneratorStatus = GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource
  noPublicMultiSchurStrongForcedStatus : GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus
  noPublicMultiSchurStrongForcedStatus_eq :
    noPublicMultiSchurStrongForcedStatus =
      GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource
  noLevelHistoryStatus : GeneratedArithmeticSourceNoLevelHistoryStatus
  noLevelHistoryStatus_eq :
    noLevelHistoryStatus = GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource
  noCharpolyDiscriminantStatus : GeneratedArithmeticSourceNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      GeneratedArithmeticSourceNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource

namespace GeneratedArithmeticSourceLevelStepWitnessRef71C4

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromGeneratedMultiSchur
    (kind : GeneratedArithmeticSourceKindGeneratedArithmeticSource)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G where
  kind := kind
  sourceGeneratedMultiSchurStatus := GeneratedArithmeticSourceSourceGeneratedMultiSchurStatus.sourceIsGeneratedMultiSchurGeneratedMultiSchurLedger
  sourceGeneratedMultiSchurStatusEq := by
    rfl
  sourceMultiSchur := G
  sourceEqGeneratedMultiSchur := by
    rfl
  boundaryOperator := G.boundaryOperator
  boundaryOperatorEqGeneratedMultiSchur := by
    rfl
  boundaryOperator_eq_schur := by
    exact G.boundaryOperator_eq_schur
  «apply» := G.«apply»
  applyEqGeneratedMultiSchur := by
    intro φ
    rfl
  apply_eq_mulVec := by
    intro φ
    exact G.apply_eq_mulVec φ
  noNewToCGeneratorStatus := GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource
  noNewToCGeneratorStatus_eq := by
    rfl
  noPublicMultiSchurStrongForcedStatus :=
    GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource
  noPublicMultiSchurStrongForcedStatus_eq := by
    rfl
  noLevelHistoryStatus := GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource
  noLevelHistoryStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    GeneratedArithmeticSourceNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource
  noCharpolyDiscriminantStatus_eq := by
    rfl

theorem sourceMultiSchurFromGeneratedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.sourceMultiSchur = G :=
  LevelStepWitness.sourceEqGeneratedMultiSchur

theorem boundaryOperatorFromGeneratedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.boundaryOperator = LevelStepWitness.sourceMultiSchur.boundaryOperator :=
  LevelStepWitness.boundaryOperatorEqGeneratedMultiSchur

theorem boundaryOperator_from_schur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          LevelStepWitness.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  LevelStepWitness.boundaryOperator_eq_schur

theorem applyFromGeneratedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    LevelStepWitness.«apply» φ = LevelStepWitness.sourceMultiSchur.«apply» φ :=
  LevelStepWitness.applyEqGeneratedMultiSchur φ

theorem apply_from_mulVec
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    LevelStepWitness.«apply» φ = LevelStepWitness.boundaryOperator.mulVec φ :=
  LevelStepWitness.apply_eq_mulVec φ

theorem noNewToCGeneratorForGeneratedArithmeticSource
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noNewToCGeneratorStatus =
      GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource :=
  LevelStepWitness.noNewToCGeneratorStatus_eq

theorem noPublicMultiSchurStrongForcedForGeneratedArithmeticSource
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noPublicMultiSchurStrongForcedStatus =
      GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource :=
  LevelStepWitness.noPublicMultiSchurStrongForcedStatus_eq

theorem noLevelHistoryForGeneratedArithmeticSource
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noLevelHistoryStatus = GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource :=
  LevelStepWitness.noLevelHistoryStatus_eq

theorem noCharpolyDiscriminantForGeneratedArithmeticSource
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noCharpolyDiscriminantStatus =
      GeneratedArithmeticSourceNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource :=
  LevelStepWitness.noCharpolyDiscriminantStatus_eq

end GeneratedArithmeticSourceLevelStepWitnessRef71C4

def regularGeneratedArithmeticSourceFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.regularMultiSchur :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.fromGeneratedMultiSchur
    GeneratedArithmeticSourceKindGeneratedArithmeticSource.regularGenerated L.regularMultiSchur

def variableGeneratedArithmeticSourceFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.variableMultiSchur :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.fromGeneratedMultiSchur
    GeneratedArithmeticSourceKindGeneratedArithmeticSource.variableGenerated L.variableMultiSchur

structure GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceGeneratedMultiSchurLedger : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight
  regularSource :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableSource :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularSourceKind : regularSource.kind = GeneratedArithmeticSourceKindGeneratedArithmeticSource.regularGenerated
  variableSourceKind : variableSource.kind = GeneratedArithmeticSourceKindGeneratedArithmeticSource.variableGenerated
  regularSourceEqGeneratedMultiSchurLevelStepWitnessRef6D51 : regularSource.sourceMultiSchur = sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableSourceEqGeneratedMultiSchurLevelStepWitnessRef9E64 : variableSource.sourceMultiSchur = sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularBoundaryOperatorEqGeneratedMultiSchur :
    regularSource.boundaryOperator = sourceGeneratedMultiSchurLedger.regularMultiSchur.boundaryOperator
  variableBoundaryOperatorEqGeneratedMultiSchur :
    variableSource.boundaryOperator = sourceGeneratedMultiSchurLedger.variableMultiSchur.boundaryOperator
  regular_boundaryOperator_eq_schur :
    regularSource.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN
        (regularGeneratedWeightPolicyEntrySource b p regularWeight) -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN
          (regularGeneratedWeightPolicyEntrySource b p regularWeight) *
          sourceGeneratedMultiSchurLedger.regularMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN
            (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variable_boundaryOperator_eq_schur :
    variableSource.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN
        (variableGeneratedWeightPolicyEntrySource β p variableWeight) -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN
          (variableGeneratedWeightPolicyEntrySource β p variableWeight) *
          sourceGeneratedMultiSchurLedger.variableMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN
            (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  regular_apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ,
    regularSource.«apply» φ = regularSource.boundaryOperator.mulVec φ
  variable_apply_eq_mulVec : ∀ φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ,
    variableSource.«apply» φ = variableSource.boundaryOperator.mulVec φ
  regular_noNewToCGeneratorStatus :
    regularSource.noNewToCGeneratorStatus = GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource
  variable_noNewToCGeneratorStatus :
    variableSource.noNewToCGeneratorStatus = GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource
  regular_noPublicMultiSchurStrongForcedStatus :
    regularSource.noPublicMultiSchurStrongForcedStatus =
      GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource
  variable_noPublicMultiSchurStrongForcedStatus :
    variableSource.noPublicMultiSchurStrongForcedStatus =
      GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource
  regular_noLevelHistoryStatus :
    regularSource.noLevelHistoryStatus = GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource
  variable_noLevelHistoryStatus :
    variableSource.noLevelHistoryStatus = GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource
  regular_noCharpolyDiscriminantStatus :
    regularSource.noCharpolyDiscriminantStatus =
      GeneratedArithmeticSourceNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource
  variable_noCharpolyDiscriminantStatus :
    variableSource.noCharpolyDiscriminantStatus =
      GeneratedArithmeticSourceNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInGeneratedArithmeticSource

def generatedArithmeticSourceGeneratedArithmeticSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight where
  sourceGeneratedMultiSchurLedger := L
  regularSource := regularGeneratedArithmeticSourceFromGeneratedMultiSchur L
  variableSource := variableGeneratedArithmeticSourceFromGeneratedMultiSchur L
  regularSourceKind := by
    rfl
  variableSourceKind := by
    rfl
  regularSourceEqGeneratedMultiSchurLevelStepWitnessRef6D51 := by
    rfl
  variableSourceEqGeneratedMultiSchurLevelStepWitnessRef9E64 := by
    rfl
  regularBoundaryOperatorEqGeneratedMultiSchur := by
    rfl
  variableBoundaryOperatorEqGeneratedMultiSchur := by
    rfl
  regular_boundaryOperator_eq_schur := by
    exact L.regularMultiSchur.boundaryOperator_eq_schur
  variable_boundaryOperator_eq_schur := by
    exact L.variableMultiSchur.boundaryOperator_eq_schur
  regular_apply_eq_mulVec := by
    intro φ
    exact L.regularMultiSchur.apply_eq_mulVec φ
  variable_apply_eq_mulVec := by
    intro φ
    exact L.variableMultiSchur.apply_eq_mulVec φ
  regular_noNewToCGeneratorStatus := by
    rfl
  variable_noNewToCGeneratorStatus := by
    rfl
  regular_noPublicMultiSchurStrongForcedStatus := by
    rfl
  variable_noPublicMultiSchurStrongForcedStatus := by
    rfl
  regular_noLevelHistoryStatus := by
    rfl
  variable_noLevelHistoryStatus := by
    rfl
  regular_noCharpolyDiscriminantStatus := by
    rfl
  variable_noCharpolyDiscriminantStatus := by
    rfl

def generatedArithmeticSourceGeneratedArithmeticSourceLedger_from_accumulatedEntryCancellationLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight :=
  generatedArithmeticSourceGeneratedArithmeticSourceLedger
    (generatedMultiSchurGeneratedMultiSchurLedger_from_accumulatedEntryCancellationLedger L)

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedgerRegularSourceFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight) :
    L.regularSource.sourceMultiSchur = L.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  L.regularSourceEqGeneratedMultiSchurLevelStepWitnessRef6D51

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedgerVariableSourceFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight) :
    L.variableSource.sourceMultiSchur = L.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  L.variableSourceEqGeneratedMultiSchurLevelStepWitnessRef9E64

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedgerRegularBoundaryOperatorFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight) :
    L.regularSource.boundaryOperator = L.sourceGeneratedMultiSchurLedger.regularMultiSchur.boundaryOperator :=
  L.regularBoundaryOperatorEqGeneratedMultiSchur

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedgerVariableBoundaryOperatorFromGeneratedMultiSchur
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight) :
    L.variableSource.boundaryOperator = L.sourceGeneratedMultiSchurLedger.variableMultiSchur.boundaryOperator :=
  L.variableBoundaryOperatorEqGeneratedMultiSchur

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedger_regular_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ) :
    L.regularSource.«apply» φ = L.regularSource.boundaryOperator.mulVec φ :=
  L.regular_apply_eq_mulVec φ

theorem generatedArithmeticSourceGeneratedArithmeticSourceLedger_variable_apply_eq_mulVec
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ) :
    L.variableSource.«apply» φ = L.variableSource.boundaryOperator.mulVec φ :=
  L.variable_apply_eq_mulVec φ

abbrev GeneratedArithmeticSourceKind :=
  GeneratedArithmeticSourceKindGeneratedArithmeticSource

abbrev GeneratedArithmeticSource :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4

namespace GeneratedArithmeticSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

abbrev fromGeneratedMultiSchur
    (kind : GeneratedArithmeticSourceKindGeneratedArithmeticSource)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.fromGeneratedMultiSchur kind G

abbrev sourceMultiSchur_from_generatedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.sourceMultiSchur = G :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.sourceMultiSchurFromGeneratedMultiSchur LevelStepWitness

abbrev boundaryOperator_from_generatedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.boundaryOperator = LevelStepWitness.sourceMultiSchur.boundaryOperator :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.boundaryOperatorFromGeneratedMultiSchur LevelStepWitness

abbrev boundaryOperator_from_schur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          LevelStepWitness.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.boundaryOperator_from_schur LevelStepWitness

abbrev apply_from_generatedMultiSchur
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    LevelStepWitness.«apply» φ = LevelStepWitness.sourceMultiSchur.«apply» φ :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.applyFromGeneratedMultiSchur LevelStepWitness φ

abbrev apply_from_mulVec
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    LevelStepWitness.«apply» φ = LevelStepWitness.boundaryOperator.mulVec φ :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.apply_from_mulVec LevelStepWitness φ

abbrev noNewToCGenerator
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noNewToCGeneratorStatus = GeneratedArithmeticSourceNoNewToCGeneratorStatus.noNewToCGeneratorInGeneratedArithmeticSource :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.noNewToCGeneratorForGeneratedArithmeticSource LevelStepWitness

abbrev noPublicMultiSchurStrongForced
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noPublicMultiSchurStrongForcedStatus =
      GeneratedArithmeticSourceNoPublicMultiSchurStrongForcedStatus.noPublicMultiSchurStrongForcedInGeneratedArithmeticSource :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.noPublicMultiSchurStrongForcedForGeneratedArithmeticSource LevelStepWitness

abbrev noLevelHistory
    (LevelStepWitness : GeneratedArithmeticSourceLevelStepWitnessRef71C4 Cell p A P wp W E K T M S H G) :
    LevelStepWitness.noLevelHistoryStatus = GeneratedArithmeticSourceNoLevelHistoryStatus.noLevelHistoryDataInGeneratedArithmeticSource :=
  GeneratedArithmeticSourceLevelStepWitnessRef71C4.noLevelHistoryForGeneratedArithmeticSource LevelStepWitness

end GeneratedArithmeticSource

abbrev regularGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.regularMultiSchur :=
  regularGeneratedArithmeticSourceFromGeneratedMultiSchur L

abbrev variableGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedMultiSchurGeneratedMultiSchurLedger b β p regularWeight variableWeight) :
    GeneratedArithmeticSourceLevelStepWitnessRef71C4
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.variableMultiSchur :=
  variableGeneratedArithmeticSourceFromGeneratedMultiSchur L

end CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource
