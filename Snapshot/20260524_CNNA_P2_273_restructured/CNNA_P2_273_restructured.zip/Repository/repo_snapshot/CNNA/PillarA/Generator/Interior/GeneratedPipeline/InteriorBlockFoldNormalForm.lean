import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation

universe u

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus where
  | blockFoldNormalFormFromAccumulatedTraceExpansion
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldSourceStatus where
  | sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus where
  | noBlockFoldIdentityInInteriorBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoProductIdentityProofStatus where
  | noProductIdentityProofInInteriorBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit
  deriving DecidableEq, Repr

def generatedInteriorAccumulatedLeftConvolution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorBlock W i k * generatedInteriorAccumulatedEntryValue T k j

def generatedInteriorAccumulatedRightConvolution
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorAccumulatedEntryValue T i k * generatedInteriorBlock W k j

def generatedInteriorLeftBlockFoldKernel
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j k : GeneratedInteriorIndex A) : ℝ :=
  generatedInteriorBlock W i k *
    (generatedInteriorTracePivotContribution T k j +
      generatedInteriorTraceLocalStepContribution T k j +
        generatedInteriorTraceResidualContribution T k j +
          generatedInteriorTraceFoldUpdateOrderContribution T k j)

def generatedInteriorRightBlockFoldKernel
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j k : GeneratedInteriorIndex A) : ℝ :=
  (generatedInteriorTracePivotContribution T i k +
      generatedInteriorTraceLocalStepContribution T i k +
        generatedInteriorTraceResidualContribution T i k +
          generatedInteriorTraceFoldUpdateOrderContribution T i k) *
    generatedInteriorBlock W k j

def generatedInteriorLeftBlockFold
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorLeftBlockFoldKernel W T i j k

def generatedInteriorRightBlockFold
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  ∑ k : GeneratedInteriorIndex A,
    generatedInteriorRightBlockFoldKernel W T i j k

structure GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  accumulatedTraceEvaluation :
    GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T
  accumulatedEntryFold : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  normalFormStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus
  sourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldSourceStatus
  noBlockFoldIdentityStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorAccumulatedEntryCancellationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus
  accumulatedTraceEvaluation_is_fromTrace :
    accumulatedTraceEvaluation =
      GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  accumulatedEntryFold_is_fromTrace :
    accumulatedEntryFold = GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedEntry_from_components :
    ∀ i j : GeneratedInteriorIndex A,
      accumulatedEntryFold.accumulatedEntry i j =
        generatedInteriorTracePivotContribution T i j +
          generatedInteriorTraceLocalStepContribution T i j +
            generatedInteriorTraceResidualContribution T i j +
              generatedInteriorTraceFoldUpdateOrderContribution T i j
  accumulatedEntry_from_trace :
    ∀ i j : GeneratedInteriorIndex A,
      accumulatedEntryFold.accumulatedEntry i j = generatedInteriorAccumulatedEntryValue T i j
  leftKernel_eq_components :
    ∀ i j k : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFoldKernel W T i j k =
        generatedInteriorBlock W i k *
          (generatedInteriorTracePivotContribution T k j +
            generatedInteriorTraceLocalStepContribution T k j +
              generatedInteriorTraceResidualContribution T k j +
                generatedInteriorTraceFoldUpdateOrderContribution T k j)
  rightKernel_eq_components :
    ∀ i j k : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFoldKernel W T i j k =
        (generatedInteriorTracePivotContribution T i k +
            generatedInteriorTraceLocalStepContribution T i k +
              generatedInteriorTraceResidualContribution T i k +
                generatedInteriorTraceFoldUpdateOrderContribution T i k) *
          generatedInteriorBlock W k j
  leftBlockFold_eq_kernelSum :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorLeftBlockFold W T i j =
        ∑ k : GeneratedInteriorIndex A,
          generatedInteriorLeftBlockFoldKernel W T i j k
  rightBlockFold_eq_kernelSum :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorRightBlockFold W T i j =
        ∑ k : GeneratedInteriorIndex A,
          generatedInteriorRightBlockFoldKernel W T i j k
  leftAccumulatedConvolution_eq_blockFold :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedLeftConvolution W T i j =
        generatedInteriorLeftBlockFold W T i j
  rightAccumulatedConvolution_eq_blockFold :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedRightConvolution W T i j =
        generatedInteriorRightBlockFold W T i j
  normalFormStatus_eq :
    normalFormStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  sourceStatus_eq :
    sourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldSourceStatus.sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  noBlockFoldIdentityStatus_eq :
    noBlockFoldIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus.noBlockFoldIdentityInInteriorBlockFoldNormalForm
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoProductIdentityProofStatus.noProductIdentityProofInInteriorBlockFoldNormalForm
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoTwoSidedInvStatus.noTwoSidedInvInInteriorBlockFoldNormalForm
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit

namespace GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}


def fromEliminationTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T where
  accumulatedTraceEvaluation :=
    GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  accumulatedEntryFold := GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  normalFormStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  sourceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldSourceStatus.sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  noBlockFoldIdentityStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus.noBlockFoldIdentityInInteriorBlockFoldNormalForm
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoProductIdentityProofStatus.noProductIdentityProofInInteriorBlockFoldNormalForm
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoTwoSidedInvStatus.noTwoSidedInvInInteriorBlockFoldNormalForm
  noInteriorEliminationCertificateStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus :=
    InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus :=
    InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextConsumerStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit
  accumulatedTraceEvaluation_is_fromTrace := by
    rfl
  accumulatedEntryFold_is_fromTrace := by
    rfl
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    T.sourceStatus_eq
  accumulatedTraceSourceEqInteriorTerminalFoldResidual := by
    rfl
  accumulatedFoldSourceEqInteriorTerminalFoldResidual := by
    rfl
  accumulatedEntry_from_components := by
    intro i j
    rfl
  accumulatedEntry_from_trace := by
    intro i j
    rfl
  leftKernel_eq_components := by
    intro i j k
    rfl
  rightKernel_eq_components := by
    intro i j k
    rfl
  leftBlockFold_eq_kernelSum := by
    intro i j
    rfl
  rightBlockFold_eq_kernelSum := by
    intro i j
    rfl
  leftAccumulatedConvolution_eq_blockFold := by
    intro i j
    rfl
  rightAccumulatedConvolution_eq_blockFold := by
    intro i j
    rfl
  normalFormStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noBlockFoldIdentityStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem leftAccumulatedConvolution_eq_blockFold_of_normalForm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedLeftConvolution W T i j =
      generatedInteriorLeftBlockFold W T i j :=
  N.leftAccumulatedConvolution_eq_blockFold i j

theorem rightAccumulatedConvolution_eq_blockFold_of_normalForm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedRightConvolution W T i j =
      generatedInteriorRightBlockFold W T i j :=
  N.rightAccumulatedConvolution_eq_blockFold i j

theorem nextClosureIsInteriorBlockFoldb
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T) :
    N.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit :=
  N.nextConsumerStatus_eq

theorem noIdentityProofInInteriorBlockFoldNormalForm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T) :
    N.noBlockFoldIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus.noBlockFoldIdentityInInteriorBlockFoldNormalForm :=
  N.noBlockFoldIdentityStatus_eq

end GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm

abbrev RegularGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularBlockFoldNormalFormInteriorBlockFoldNormalForm
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm b p wp :=
  GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm.fromEliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableBlockFoldNormalFormInteriorBlockFoldNormalForm
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm β p wp :=
  GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm.fromEliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularNormalForm : RegularGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm b p regularWeight
  variableNormalForm : VariableGeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm β p variableWeight
  status : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus
  regularStatus_eq :
    regularNormalForm.normalFormStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  variableStatus_eq :
    variableNormalForm.normalFormStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  regularNoIdentity_eq :
    regularNormalForm.noBlockFoldIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus.noBlockFoldIdentityInInteriorBlockFoldNormalForm
  variableNoIdentity_eq :
    variableNormalForm.noBlockFoldIdentityStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNoBlockFoldIdentityStatus.noBlockFoldIdentityInInteriorBlockFoldNormalForm
  status_eq :
    status =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit

def interiorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormLedger b β p regularWeight variableWeight where
  regularNormalForm := regularBlockFoldNormalFormInteriorBlockFoldNormalForm b p regularWeight
  variableNormalForm := variableBlockFoldNormalFormInteriorBlockFoldNormalForm β p variableWeight
  status :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormStatus.blockFoldNormalFormFromAccumulatedTraceExpansion
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit
  regularStatus_eq := by
    rfl
  variableStatus_eq := by
    rfl
  regularNoIdentity_eq := by
    rfl
  variableNoIdentity_eq := by
    rfl
  status_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem interiorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormLedgerNext
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationInteriorBlockFoldNormalFormBlockFoldNormalFormLedger
      b β p regularWeight variableWeight).nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNormalFormNextConsumerStatus.interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAudit := by
  rfl



end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
