import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource

universe u

inductive GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus where
  | generatedDirichletDegreeIsFiniteGeneratedWeightSum
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus where
  | generatedDegreeFormulaDependsOnInputWeightPolicy
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedConstantUnitFormulaStatus where
  | noConstantUnitFormulaExposedByCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNatCastFormulaStatus where
  | noNatCastDegreeFormulaExposedByCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus where
  | noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoScalarInvStatus where
  | noScalarInvInGeneratedDegreeFormulaAudit
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoMatrixInvStatus where
  | noMatrixInvInGeneratedDegreeFormulaAudit
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoExternalScaleOracleStatus where
  | noExternalScaleOracleInGeneratedDegreeFormulaAudit
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoProductIdentityProofStatus where
  | noProductIdentityProofInGeneratedDegreeFormulaAudit
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoTwoSidedInvStatus where
  | noTwoSidedInvInGeneratedDegreeFormulaAudit
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormulaSeed
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormulaSeed
  deriving DecidableEq, Repr

inductive GeneratedDegreeFormulaSeedNextConsumerStatus where
  | generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  deriving DecidableEq, Repr

theorem generatedDirichletDegreeEqEntryWeightSumGeneratedDegreeFormulaSeed
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A, generatedEntryWeight W i j := by
  unfold generatedDirichlet_degree
  rfl

theorem generatedDirichletDegreeEqGeneratedAdjacencyWeightSumGeneratedDegreeFormulaSeed
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent i j then W.policy.constantWeight i j else 0 := by
  unfold generatedDirichlet_degree generatedEntryWeight
  rfl

theorem generatedDirichletDegreeEqInputPolicyAdjacencyWeightSumGeneratedDegreeFormulaSeed
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent i j then wp.constantWeight i j else 0 := by
  calc
    generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then W.policy.constantWeight i j else 0 := by
      exact generatedDirichletDegreeEqGeneratedAdjacencyWeightSumGeneratedDegreeFormulaSeed W i
    _ = ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then wp.constantWeight i j else 0 := by
      rw [W.policy_eq_input]

structure GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T
  formulaStatus : GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus
  weightPolicyFormulaStatus : GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus
  constantUnitFormulaStatus : GeneratedDegreeFormulaSeedConstantUnitFormulaStatus
  natCastFormulaStatus : GeneratedDegreeFormulaSeedNatCastFormulaStatus
  operationalReciprocalSourceStatus : GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus
  noScalarInvStatus : GeneratedDegreeFormulaSeedNoScalarInvStatus
  noMatrixInvStatus : GeneratedDegreeFormulaSeedNoMatrixInvStatus
  noExternalScaleOracleStatus : GeneratedDegreeFormulaSeedNoExternalScaleOracleStatus
  noProductIdentityProofStatus : GeneratedDegreeFormulaSeedNoProductIdentityProofStatus
  noTwoSidedInvStatus : GeneratedDegreeFormulaSeedNoTwoSidedInvStatus
  noDtnDataStatus : GeneratedDegreeFormulaSeedNoDtnDataStatus
  noArithmeticTargetStatus : GeneratedDegreeFormulaSeedNoArithmeticTargetStatus
  nextConsumerStatus : GeneratedDegreeFormulaSeedNextConsumerStatus
  degree_eq_entryWeight_sum :
    ∀ i : GeneratedApproximantIndex A,
      generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A, generatedEntryWeight W i j
  degree_eq_generatedAdjacencyWeight_sum :
    ∀ i : GeneratedApproximantIndex A,
      generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then W.policy.constantWeight i j else 0
  degree_eq_inputPolicyAdjacencyWeight_sum :
    ∀ i : GeneratedApproximantIndex A,
      generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then wp.constantWeight i j else 0
  pivotEntry_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotEntry_eq_entryWeight_sum :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        ∑ j : GeneratedApproximantIndex A,
          generatedEntryWeight W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex)
            j
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j then
            wp.constantWeight
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j
          else 0
  formulaStatus_eq :
    formulaStatus =
      GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus.generatedDirichletDegreeIsFiniteGeneratedWeightSum
  weightPolicyFormulaStatus_eq :
    weightPolicyFormulaStatus =
      GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus.generatedDegreeFormulaDependsOnInputWeightPolicy
  constantUnitFormulaStatus_eq :
    constantUnitFormulaStatus =
      GeneratedDegreeFormulaSeedConstantUnitFormulaStatus.noConstantUnitFormulaExposedByCurrentGeneratedDegreeAPI
  natCastFormulaStatus_eq :
    natCastFormulaStatus =
      GeneratedDegreeFormulaSeedNatCastFormulaStatus.noNatCastDegreeFormulaExposedByCurrentGeneratedDegreeAPI
  operationalReciprocalSourceStatus_eq :
    operationalReciprocalSourceStatus =
      GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  noScalarInvStatus_eq :
    noScalarInvStatus = GeneratedDegreeFormulaSeedNoScalarInvStatus.noScalarInvInGeneratedDegreeFormulaAudit
  noMatrixInvStatus_eq :
    noMatrixInvStatus = GeneratedDegreeFormulaSeedNoMatrixInvStatus.noMatrixInvInGeneratedDegreeFormulaAudit
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      GeneratedDegreeFormulaSeedNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreeFormulaAudit
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      GeneratedDegreeFormulaSeedNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreeFormulaAudit
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = GeneratedDegreeFormulaSeedNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreeFormulaAudit
  noDtnDataStatus_eq :
    noDtnDataStatus = GeneratedDegreeFormulaSeedNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormulaSeed
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      GeneratedDegreeFormulaSeedNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormulaSeed
  nextConsumerStatus_eq :
    nextConsumerStatus =
      GeneratedDegreeFormulaSeedNextConsumerStatus.generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy

namespace GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromRequirement
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T where
  requirement := R
  formulaStatus :=
    GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus.generatedDirichletDegreeIsFiniteGeneratedWeightSum
  weightPolicyFormulaStatus :=
    GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus.generatedDegreeFormulaDependsOnInputWeightPolicy
  constantUnitFormulaStatus :=
    GeneratedDegreeFormulaSeedConstantUnitFormulaStatus.noConstantUnitFormulaExposedByCurrentGeneratedDegreeAPI
  natCastFormulaStatus :=
    GeneratedDegreeFormulaSeedNatCastFormulaStatus.noNatCastDegreeFormulaExposedByCurrentGeneratedDegreeAPI
  operationalReciprocalSourceStatus :=
    GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  noScalarInvStatus := GeneratedDegreeFormulaSeedNoScalarInvStatus.noScalarInvInGeneratedDegreeFormulaAudit
  noMatrixInvStatus := GeneratedDegreeFormulaSeedNoMatrixInvStatus.noMatrixInvInGeneratedDegreeFormulaAudit
  noExternalScaleOracleStatus :=
    GeneratedDegreeFormulaSeedNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedDegreeFormulaAudit
  noProductIdentityProofStatus :=
    GeneratedDegreeFormulaSeedNoProductIdentityProofStatus.noProductIdentityProofInGeneratedDegreeFormulaAudit
  noTwoSidedInvStatus := GeneratedDegreeFormulaSeedNoTwoSidedInvStatus.noTwoSidedInvInGeneratedDegreeFormulaAudit
  noDtnDataStatus := GeneratedDegreeFormulaSeedNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInGeneratedDegreeFormulaSeed
  noArithmeticTargetStatus :=
    GeneratedDegreeFormulaSeedNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInGeneratedDegreeFormulaSeed
  nextConsumerStatus :=
    GeneratedDegreeFormulaSeedNextConsumerStatus.generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  degree_eq_entryWeight_sum := by
    intro i
    exact generatedDirichletDegreeEqEntryWeightSumGeneratedDegreeFormulaSeed W i
  degree_eq_generatedAdjacencyWeight_sum := by
    intro i
    exact generatedDirichletDegreeEqGeneratedAdjacencyWeightSumGeneratedDegreeFormulaSeed W i
  degree_eq_inputPolicyAdjacencyWeight_sum := by
    intro i
    exact generatedDirichletDegreeEqInputPolicyAdjacencyWeightSumGeneratedDegreeFormulaSeed W i
  pivotEntry_eq_generatedDegree := by
    intro pivot
    exact R.pivotEntry_eq_generatedDegree pivot
  pivotEntry_eq_entryWeight_sum := by
    intro pivot
    calc
      (T.localStepOf pivot).stepUpdate.pivotEntry =
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) := by
        exact R.pivotEntry_eq_generatedDegree pivot
      _ = ∑ j : GeneratedApproximantIndex A,
            generatedEntryWeight W
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j := by
        exact generatedDirichletDegreeEqEntryWeightSumGeneratedDegreeFormulaSeed W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum := by
    intro pivot
    calc
      (T.localStepOf pivot).stepUpdate.pivotEntry =
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) := by
        exact R.pivotEntry_eq_generatedDegree pivot
      _ = ∑ j : GeneratedApproximantIndex A,
            if generatedAdjacent
                (GeneratedInteriorIndex.toApproximantIndex
                  (T.localStepOf pivot).pivotDatum.pivotIndex)
                j then
              wp.constantWeight
                (GeneratedInteriorIndex.toApproximantIndex
                  (T.localStepOf pivot).pivotDatum.pivotIndex)
                j
            else 0 := by
        exact generatedDirichletDegreeEqInputPolicyAdjacencyWeightSumGeneratedDegreeFormulaSeed W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  formulaStatus_eq := by
    rfl
  weightPolicyFormulaStatus_eq := by
    rfl
  constantUnitFormulaStatus_eq := by
    rfl
  natCastFormulaStatus_eq := by
    rfl
  operationalReciprocalSourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromInteriorEliminationdb2dAudit
    (A0 : GeneratedDegreePivotScaleSourceAuditDegreePivotScaleSource Cell p A P wp W E K T) :
    GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T :=
  fromRequirement A0.requirement

def fromInteriorTracePivotScaleWitnessequirement
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T :=
  fromRequirement R

def fromSourceAudit
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T) :
    GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T :=
  fromRequirement
    (GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness.fromSourceAudit A0)

theorem degree_formula_is_inputPolicyAdjacencyWeight_sum
    (A0 : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent i j then wp.constantWeight i j else 0 :=
  A0.degree_eq_inputPolicyAdjacencyWeight_sum i

theorem pivotEntry_formula_is_inputPolicyAdjacencyWeight_sum
    (A0 : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex)
            j then
          wp.constantWeight
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex)
            j
        else 0 :=
  A0.pivotEntry_eq_inputPolicyAdjacencyWeight_sum pivot

theorem operationalReciprocalSource_not_exposed
    (A0 : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T) :
    A0.operationalReciprocalSourceStatus =
      GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI :=
  A0.operationalReciprocalSourceStatus_eq

theorem nextClosureIsGeneratedDegreeFormula
    (A0 : GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed Cell p A P wp W E K T) :
    A0.nextConsumerStatus =
      GeneratedDegreeFormulaSeedNextConsumerStatus.generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy :=
  A0.nextConsumerStatus_eq

end GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed

abbrev RegularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed b p wp :=
  GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed.fromSourceAudit
    (regularLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant b p wp)

def variableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed β p wp :=
  GeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed.fromSourceAudit
    (variableLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant β p wp)

structure GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed b p regularWeight
  variableAudit : VariableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed β p variableWeight
  regularFormulaStatus_eq :
    regularAudit.formulaStatus =
      GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus.generatedDirichletDegreeIsFiniteGeneratedWeightSum
  variableFormulaStatus_eq :
    variableAudit.formulaStatus =
      GeneratedDegreeFormulaSeedGeneratedDegreeFormulaStatus.generatedDirichletDegreeIsFiniteGeneratedWeightSum
  regularWeightPolicyFormulaStatus_eq :
    regularAudit.weightPolicyFormulaStatus =
      GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus.generatedDegreeFormulaDependsOnInputWeightPolicy
  variableWeightPolicyFormulaStatus_eq :
    variableAudit.weightPolicyFormulaStatus =
      GeneratedDegreeFormulaSeedWeightPolicyFormulaStatus.generatedDegreeFormulaDependsOnInputWeightPolicy
  regularNoOperationalReciprocal_eq :
    regularAudit.operationalReciprocalSourceStatus =
      GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  variableNoOperationalReciprocal_eq :
    variableAudit.operationalReciprocalSourceStatus =
      GeneratedDegreeFormulaSeedOperationalReciprocalSourceStatus.noOperationalReciprocalSourceExposedByCurrentGeneratedDegreeAPI
  regularNextConsumer_eq :
    regularAudit.nextConsumerStatus =
      GeneratedDegreeFormulaSeedNextConsumerStatus.generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy
  variableNextConsumer_eq :
    variableAudit.nextConsumerStatus =
      GeneratedDegreeFormulaSeedNextConsumerStatus.generatedDegreeFormulaGeneratedDegreePivotReciprocalProfileFromWeightPolicy

namespace GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularAudit : RegularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed b p regularWeight)
    (variableAudit : VariableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed β p variableWeight) :
    GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger b β p regularWeight variableWeight where
  regularAudit := regularAudit
  variableAudit := variableAudit
  regularFormulaStatus_eq := regularAudit.formulaStatus_eq
  variableFormulaStatus_eq := variableAudit.formulaStatus_eq
  regularWeightPolicyFormulaStatus_eq := regularAudit.weightPolicyFormulaStatus_eq
  variableWeightPolicyFormulaStatus_eq := variableAudit.weightPolicyFormulaStatus_eq
  regularNoOperationalReciprocal_eq := regularAudit.operationalReciprocalSourceStatus_eq
  variableNoOperationalReciprocal_eq := variableAudit.operationalReciprocalSourceStatus_eq
  regularNextConsumer_eq := regularAudit.nextConsumerStatus_eq
  variableNextConsumer_eq := variableAudit.nextConsumerStatus_eq

end GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger

def generatedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger b β p regularWeight variableWeight :=
  GeneratedDegreeFormulaSeedGeneratedDegreeFormulaAuditLedger.fromRegularAndVariable
    (regularGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed b p regularWeight)
    (variableGeneratedDegreeFormulaAuditGeneratedDegreeFormulaSeed β p variableWeight)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
