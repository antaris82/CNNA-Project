import CNNA.PillarA.Generator.Boundary.GeneratedSubstrateRoute

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

namespace BoundarySource

structure BoundarySourceDecisionLedger where
  recursiveTypeDecision : RecursiveLevelHistoryTypeDecision
  recursiveTypeDecisionClosed :
    recursiveTypeDecision.signature.status =
      RecursiveTypeDecisionStatus.recursiveTypeDecisionClosed
  generatedSubstrateRoute : GeneratedSubstrateRouteLedger
  generatedSubstrateRouteConditional :
    generatedSubstrateRoute.status = GeneratedSubstrateRouteStatus.conditionalOpen
  recursiveLevelHistoryRoute : BoundarySourceRoute
  recursiveLevelHistoryRoute_eq_recursiveHistory : recursiveLevelHistoryRoute = BoundarySourceRoute.recursiveHistory
  idealThreadCutSpecCarrierClaim : IdealThreadCutSpecCarrierClaimDecision
  idealThreadCutSpecCarrierClaim_rejected :
    idealThreadCutSpecCarrierClaim =
      IdealThreadCutSpecCarrierClaimDecision.rejectedForLevelHistoryRoute
  freeBoundaryCarrier : FreeBoundaryCarrierDecision
  freeBoundaryCarrier_forbidden :
    freeBoundaryCarrier = FreeBoundaryCarrierDecision.forbiddenByCarrierDecision
  freeMatrixField : FreeMatrixFieldDecision
  freeMatrixField_forbidden :
    freeMatrixField = FreeMatrixFieldDecision.forbiddenByProofCarryingAggregation
  noFreeBoundaryCarrier :
    recursiveTypeDecision.signature.carrier = CarrierTypeDecision.levelHistoryIndex
  noFreeMatrixDecision :
    recursiveTypeDecision.signature.aggregation =
      AggregationDecision.sourceWitnessToProofCarryingMatrix
  exportOnlyThroughInterface :
    recursiveTypeDecision.signature.interfaceExport =
      InterfaceExportDecision.boundarySourceInterfaceOnly

namespace BoundarySourceDecisionLedger

def closed : BoundarySourceDecisionLedger where
  recursiveTypeDecision := RecursiveLevelHistoryTypeDecision.closed
  recursiveTypeDecisionClosed := by
    rfl
  generatedSubstrateRoute := GeneratedSubstrateRouteLedger.conditionalOpen
  generatedSubstrateRouteConditional := by
    rfl
  recursiveLevelHistoryRoute := BoundarySourceRoute.recursiveHistory
  recursiveLevelHistoryRoute_eq_recursiveHistory := by
    rfl
  idealThreadCutSpecCarrierClaim :=
    IdealThreadCutSpecCarrierClaimDecision.rejectedForLevelHistoryRoute
  idealThreadCutSpecCarrierClaim_rejected := by
    rfl
  freeBoundaryCarrier := FreeBoundaryCarrierDecision.forbiddenByCarrierDecision
  freeBoundaryCarrier_forbidden := by
    rfl
  freeMatrixField := FreeMatrixFieldDecision.forbiddenByProofCarryingAggregation
  freeMatrixField_forbidden := by
    rfl
  noFreeBoundaryCarrier := by
    rfl
  noFreeMatrixDecision := by
    rfl
  exportOnlyThroughInterface := by
    rfl

theorem closed_status :
    closed.recursiveTypeDecision.signature.status =
      RecursiveTypeDecisionStatus.recursiveTypeDecisionClosed := by
  rfl

theorem closed_route :
    closed.recursiveLevelHistoryRoute = BoundarySourceRoute.recursiveHistory := by
  rfl

theorem closed_generated_conditional :
    closed.generatedSubstrateRoute.status =
      GeneratedSubstrateRouteStatus.conditionalOpen := by
  rfl

theorem closed_freeMatrixField_forbidden :
    closed.freeMatrixField =
      FreeMatrixFieldDecision.forbiddenByProofCarryingAggregation := by
  rfl

end BoundarySourceDecisionLedger

end BoundarySource

namespace StrengtheningRecursiveHistoryBoundarySource

abbrev RecursiveHistoryBoundarySourceBoundarySourceDecisionLedger :=
  BoundarySource.BoundarySourceDecisionLedger

def boundarySourceDecisionDecisionLedgerClosed :
    RecursiveHistoryBoundarySourceBoundarySourceDecisionLedger :=
  BoundarySource.BoundarySourceDecisionLedger.closed

theorem boundarySourceDecisionDecisionLedgerClosed_status :
    boundarySourceDecisionDecisionLedgerClosed.recursiveTypeDecision.signature.status =
      BoundarySource.RecursiveTypeDecisionStatus.recursiveTypeDecisionClosed := by
  rfl

theorem boundarySourceDecisionDecisionLedgerClosed_route :
    boundarySourceDecisionDecisionLedgerClosed.recursiveLevelHistoryRoute =
      BoundarySource.BoundarySourceRoute.recursiveHistory := by
  rfl

theorem boundarySourceDecisionDecisionLedgerClosed_freeMatrixField_forbidden :
    boundarySourceDecisionDecisionLedgerClosed.freeMatrixField =
      BoundarySource.FreeMatrixFieldDecision.forbiddenByProofCarryingAggregation := by
  rfl

end StrengtheningRecursiveHistoryBoundarySource

end CNNA.PillarA.Arithmetic
