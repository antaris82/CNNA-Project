import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateStart


universe u

inductive InteriorAccumulatedEntryCancellationTraceEntryFoldStatus where
  | traceEntryFoldFromInteriorAccumulatedTraceEvaluationTrace
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationTraceEvaluationStatus where
  | traceEvaluationFromTraceEntryFold
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationInverseCandidateEntryStatus where
  | generatedInteriorInverseCandidateEntryBuiltFromTrace
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus where
  | inverseCandidateEntryFromInteriorAccumulatedTraceEvaluationTraceEvaluation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNotInteriorEliminationCandidateEntryCandidateStatus where
  | notInteriorEliminationCandidateEntryCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNotInteriorBlockDefinitionStatus where
  | notDefinedByGeneratedInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationValidationStatus where
  | entryNotProductValidatedUntilInteriorTwoSidedInverseerun
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoMatrixInvStatus where
  | noMatrixInvForInverseCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus where
  | noFreeInverseEntryTable
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus where
  | noExternalInverseOracleForInverseCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoMatrixExportStatus where
  | noMatrixExportInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoProductProofStatus where
  | noProductProofInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus where
  | noTwoSidedInvInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationNextPositiveConstructionGate where
  | interiorInverseCandidateMatrixMatrixExportWithoutProductProof
  deriving DecidableEq, Repr

inductive InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedgerStatus where
  | generatedInteriorInverseCandidateEntryClosed
  deriving DecidableEq, Repr

structure GeneratedInteriorTraceEntryFold
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  foldStatus : InteriorAccumulatedEntryCancellationTraceEntryFoldStatus
  sourceStatus : InteriorAccumulatedTraceEvaluationTraceSourceStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  trace_eq : trace = T
  entry_eq_traceStepUpdateRowResidual :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = (T.traceStepOf i).stepUpdate.rowResidual j
  source_eq_eliminationTrace : sourceStatus = T.sourceStatus
  sourceEqInteriorBlockInteriorEliminationdR :
    sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  foldStatus_eq :
    foldStatus = InteriorAccumulatedEntryCancellationTraceEntryFoldStatus.traceEntryFoldFromInteriorAccumulatedTraceEvaluationTrace
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation

namespace GeneratedInteriorTraceEntryFold

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}


def fromTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTraceEntryFold Cell p A P wp W E K T where
  trace := T
  entry := fun i j => (T.traceStepOf i).stepUpdate.rowResidual j
  foldStatus := InteriorAccumulatedEntryCancellationTraceEntryFoldStatus.traceEntryFoldFromInteriorAccumulatedTraceEvaluationTrace
  sourceStatus := T.sourceStatus
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  trace_eq := by
    rfl
  entry_eq_traceStepUpdateRowResidual := by
    intro i j
    rfl
  source_eq_eliminationTrace := by
    rfl
  sourceEqInteriorBlockInteriorEliminationdR :=
    T.sourceStatus_eq
  foldStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl

theorem source_eq_eliminationTrace_thm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorTraceEntryFold Cell p A P wp W E K T) :
    F.sourceStatus = T.sourceStatus :=
  F.source_eq_eliminationTrace

theorem sourceEqInteriorBlockInteriorEliminationdRThm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorTraceEntryFold Cell p A P wp W E K T) :
    F.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  F.sourceEqInteriorBlockInteriorEliminationdR

theorem noMatrixExport
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (F : GeneratedInteriorTraceEntryFold Cell p A P wp W E K T) :
    F.noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation :=
  F.noMatrixExportStatus_eq

end GeneratedInteriorTraceEntryFold

structure GeneratedInteriorTraceEvaluation
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  entryFold : GeneratedInteriorTraceEntryFold Cell p A P wp W E K T
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  evaluationStatus : InteriorAccumulatedEntryCancellationTraceEvaluationStatus
  sourceStatus : InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  trace_eq : trace = T
  entryFold_eq_fromTrace : entryFold = GeneratedInteriorTraceEntryFold.fromTrace T
  entry_eq_entryFold :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = entryFold.entry i j
  entry_eq_traceStepUpdateRowResidual :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = (T.traceStepOf i).stepUpdate.rowResidual j
  evaluationStatus_eq :
    evaluationStatus = InteriorAccumulatedEntryCancellationTraceEvaluationStatus.traceEvaluationFromTraceEntryFold
  sourceStatus_eq :
    sourceStatus =
      InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus.inverseCandidateEntryFromInteriorAccumulatedTraceEvaluationTraceEvaluation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation

namespace GeneratedInteriorTraceEvaluation

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}


def fromTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTraceEvaluation Cell p A P wp W E K T where
  trace := T
  entryFold := GeneratedInteriorTraceEntryFold.fromTrace T
  entry := fun i j => (GeneratedInteriorTraceEntryFold.fromTrace T).entry i j
  evaluationStatus := InteriorAccumulatedEntryCancellationTraceEvaluationStatus.traceEvaluationFromTraceEntryFold
  sourceStatus :=
    InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus.inverseCandidateEntryFromInteriorAccumulatedTraceEvaluationTraceEvaluation
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  trace_eq := by
    rfl
  entryFold_eq_fromTrace := by
    rfl
  entry_eq_entryFold := by
    intro i j
    rfl
  entry_eq_traceStepUpdateRowResidual := by
    intro i j
    rfl
  evaluationStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl

theorem entry_eq_traceStepUpdateRowResidual_thm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (Q : GeneratedInteriorTraceEvaluation Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    Q.entry i j = (T.traceStepOf i).stepUpdate.rowResidual j :=
  Q.entry_eq_traceStepUpdateRowResidual i j

end GeneratedInteriorTraceEvaluation

structure GeneratedInteriorInverseCandidateEntry
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  trace : GeneratedInteriorEliminationTrace Cell p A P wp W E K
  traceEvaluation : GeneratedInteriorTraceEvaluation Cell p A P wp W E K T
  entry : GeneratedInteriorIndex A → GeneratedInteriorIndex A → ℝ
  candidateStatus : InteriorAccumulatedEntryCancellationInverseCandidateEntryStatus
  sourceStatus : InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus
  notInteriorEliminationCandidateEntryCandidateStatus : InteriorAccumulatedEntryCancellationNotInteriorEliminationCandidateEntryCandidateStatus
  notInteriorBlockDefinitionStatus : InteriorAccumulatedEntryCancellationNotInteriorBlockDefinitionStatus
  validationStatus : InteriorAccumulatedEntryCancellationValidationStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noFreeInverseEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noMatrixExportStatus : InteriorAccumulatedEntryCancellationNoMatrixExportStatus
  noProductProofStatus : InteriorAccumulatedEntryCancellationNoProductProofStatus
  noTwoSidedInvStatus : InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorAccumulatedEntryCancellationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus
  nextPositiveConstructionGate : InteriorAccumulatedEntryCancellationNextPositiveConstructionGate
  trace_eq : trace = T
  traceEvaluation_eq_fromTrace : traceEvaluation = GeneratedInteriorTraceEvaluation.fromTrace T
  entry_eq_traceEvaluation :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = traceEvaluation.entry i j
  entry_eq_traceStepUpdateRowResidual :
    ∀ i j : GeneratedInteriorIndex A,
      entry i j = (T.traceStepOf i).stepUpdate.rowResidual j
  source_eq_eliminationTrace :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  candidateStatus_eq :
    candidateStatus =
      InteriorAccumulatedEntryCancellationInverseCandidateEntryStatus.generatedInteriorInverseCandidateEntryBuiltFromTrace
  sourceStatus_eq :
    sourceStatus =
      InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus.inverseCandidateEntryFromInteriorAccumulatedTraceEvaluationTraceEvaluation
  notInteriorEliminationCandidateEntryCandidateStatusEq :
    notInteriorEliminationCandidateEntryCandidateStatus =
      InteriorAccumulatedEntryCancellationNotInteriorEliminationCandidateEntryCandidateStatus.notInteriorEliminationCandidateEntryCandidateEntry
  notInteriorBlockDefinitionStatus_eq :
    notInteriorBlockDefinitionStatus =
      InteriorAccumulatedEntryCancellationNotInteriorBlockDefinitionStatus.notDefinedByGeneratedInteriorBlock
  validationStatus_eq :
    validationStatus =
      InteriorAccumulatedEntryCancellationValidationStatus.entryNotProductValidatedUntilInteriorTwoSidedInverseerun
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus_eq :
    noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus_eq :
    noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus_eq :
    noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextPositiveConstructionGate_eq :
    nextPositiveConstructionGate = InteriorAccumulatedEntryCancellationNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportWithoutProductProof

namespace GeneratedInteriorInverseCandidateEntry

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}


def fromTraceEvaluation
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T where
  trace := T
  traceEvaluation := GeneratedInteriorTraceEvaluation.fromTrace T
  entry := fun i j => (GeneratedInteriorTraceEvaluation.fromTrace T).entry i j
  candidateStatus :=
    InteriorAccumulatedEntryCancellationInverseCandidateEntryStatus.generatedInteriorInverseCandidateEntryBuiltFromTrace
  sourceStatus :=
    InteriorAccumulatedEntryCancellationInverseCandidateSourceStatus.inverseCandidateEntryFromInteriorAccumulatedTraceEvaluationTraceEvaluation
  notInteriorEliminationCandidateEntryCandidateStatus :=
    InteriorAccumulatedEntryCancellationNotInteriorEliminationCandidateEntryCandidateStatus.notInteriorEliminationCandidateEntryCandidateEntry
  notInteriorBlockDefinitionStatus :=
    InteriorAccumulatedEntryCancellationNotInteriorBlockDefinitionStatus.notDefinedByGeneratedInteriorBlock
  validationStatus := InteriorAccumulatedEntryCancellationValidationStatus.entryNotProductValidatedUntilInteriorTwoSidedInverseerun
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noFreeInverseEntryTableStatus :=
    InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noMatrixExportStatus := InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  noProductProofStatus := InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorAccumulatedEntryCancellationNoTwoSidedInvStatus.noTwoSidedInvInInteriorAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus :=
    InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus :=
    InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextPositiveConstructionGate := InteriorAccumulatedEntryCancellationNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportWithoutProductProof
  trace_eq := by
    rfl
  traceEvaluation_eq_fromTrace := by
    rfl
  entry_eq_traceEvaluation := by
    intro i j
    rfl
  entry_eq_traceStepUpdateRowResidual := by
    intro i j
    rfl
  source_eq_eliminationTrace :=
    T.sourceStatus_eq
  candidateStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  notInteriorEliminationCandidateEntryCandidateStatusEq := by
    rfl
  notInteriorBlockDefinitionStatus_eq := by
    rfl
  validationStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noFreeInverseEntryTableStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noMatrixExportStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextPositiveConstructionGate_eq := by
    rfl

theorem source_eq_eliminationTrace_thm
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  I.source_eq_eliminationTrace

theorem noMatrixInv
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noMatrixInvStatus =
      InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry :=
  I.noMatrixInvStatus_eq

theorem noFreeInverseEntryTable
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable :=
  I.noFreeInverseEntryTableStatus_eq

theorem noExternalInverseOracle
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry :=
  I.noExternalInverseOracleStatus_eq

theorem noMatrixExport
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noMatrixExportStatus = InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation :=
  I.noMatrixExportStatus_eq

theorem noProductProof
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noProductProofStatus = InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation :=
  I.noProductProofStatus_eq

end GeneratedInteriorInverseCandidateEntry

def traceEntryFold_from_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTraceEntryFold Cell p A P wp W E K T :=
  GeneratedInteriorTraceEntryFold.fromTrace T

def traceEvaluation_from_traceEntryFold
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorTraceEvaluation Cell p A P wp W E K T :=
  GeneratedInteriorTraceEvaluation.fromTrace T

def inverseCandidateEntry_from_finiteEliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T :=
  GeneratedInteriorInverseCandidateEntry.fromTraceEvaluation T

def inverseCandidateEntry_from_treeRecursiveElimination
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T :=
  inverseCandidateEntry_from_finiteEliminationTrace T

theorem inverseCandidateEntry_source_eq_eliminationTrace
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.trace = T :=
  I.trace_eq

theorem inverseCandidateEntrySourceEqInteriorBlockInteriorEliminationdR
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps :=
  I.source_eq_eliminationTrace

theorem noMatrixInv_for_inverseCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noMatrixInvStatus =
      InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry :=
  I.noMatrixInvStatus_eq

theorem noFreeInverseEntryTable
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable :=
  I.noFreeInverseEntryTableStatus_eq

theorem noExternalInverseOracle_for_inverseCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (I : GeneratedInteriorInverseCandidateEntry Cell p A P wp W E K T) :
    I.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry :=
  I.noExternalInverseOracleStatus_eq

def regularGeneratedInteriorInverseCandidateEntry
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp) :=
  inverseCandidateEntry_from_finiteEliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableGeneratedInteriorInverseCandidateEntry
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp) :=
  inverseCandidateEntry_from_finiteEliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedgerStatus
  interiorEliminationTraceLedger :
    InteriorAccumulatedTraceEvaluationGeneratedInteriorEliminationTraceLedger b β p regularWeight variableWeight
      regularPivot variablePivot
  regularTrace :
    GeneratedInteriorEliminationTrace
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
  variableTrace :
    GeneratedInteriorEliminationTrace
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
  regularInverseCandidateEntry :
    GeneratedInteriorInverseCandidateEntry
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
  variableInverseCandidateEntry :
    GeneratedInteriorInverseCandidateEntry
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
  interiorEliminationTraceLedger_eq_main :
    interiorEliminationTraceLedger = generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularTrace_eq_main :
    regularTrace = regularGeneratedInteriorEliminationTrace b p regularWeight
  variableTrace_eq_main :
    variableTrace = variableGeneratedInteriorEliminationTrace β p variableWeight
  regularCandidate_eq_main :
    regularInverseCandidateEntry = regularGeneratedInteriorInverseCandidateEntry b p regularWeight
  variableCandidate_eq_main :
    variableInverseCandidateEntry = variableGeneratedInteriorInverseCandidateEntry β p variableWeight
  regularSourceEqInteriorBlockInteriorEliminationdR :
    regularTrace.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  variableSourceEqInteriorBlockInteriorEliminationdR :
    variableTrace.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  regularNoMatrixInv :
    regularInverseCandidateEntry.noMatrixInvStatus =
      InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  variableNoMatrixInv :
    variableInverseCandidateEntry.noMatrixInvStatus =
      InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  regularNoFreeInverseEntryTable :
    regularInverseCandidateEntry.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  variableNoFreeInverseEntryTable :
    variableInverseCandidateEntry.noFreeInverseEntryTableStatus =
      InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  regularNoExternalInverseOracle :
    regularInverseCandidateEntry.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  variableNoExternalInverseOracle :
    variableInverseCandidateEntry.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  regularNoMatrixExport :
    regularInverseCandidateEntry.noMatrixExportStatus =
      InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  variableNoMatrixExport :
    variableInverseCandidateEntry.noMatrixExportStatus =
      InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation
  regularNoProductProof :
    regularInverseCandidateEntry.noProductProofStatus =
      InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  variableNoProductProof :
    variableInverseCandidateEntry.noProductProofStatus =
      InteriorAccumulatedEntryCancellationNoProductProofStatus.noProductProofInInteriorAccumulatedEntryCancellation
  regularNextPositiveConstructionGate :
    regularInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorAccumulatedEntryCancellationNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportWithoutProductProof
  variableNextPositiveConstructionGate :
    variableInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorAccumulatedEntryCancellationNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportWithoutProductProof
  status_eq_closed :
    status =
      InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedgerStatus.generatedInteriorInverseCandidateEntryClosed

def generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status :=
    InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedgerStatus.generatedInteriorInverseCandidateEntryClosed
  interiorEliminationTraceLedger :=
    generatedInteriorEliminationTraceGeneratedInteriorEliminationTraceLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularTrace := regularGeneratedInteriorEliminationTrace b p regularWeight
  variableTrace := variableGeneratedInteriorEliminationTrace β p variableWeight
  regularInverseCandidateEntry :=
    regularGeneratedInteriorInverseCandidateEntry b p regularWeight
  variableInverseCandidateEntry :=
    variableGeneratedInteriorInverseCandidateEntry β p variableWeight
  interiorEliminationTraceLedger_eq_main := by
    rfl
  regularTrace_eq_main := by
    rfl
  variableTrace_eq_main := by
    rfl
  regularCandidate_eq_main := by
    rfl
  variableCandidate_eq_main := by
    rfl
  regularSourceEqInteriorBlockInteriorEliminationdR := by
    rfl
  variableSourceEqInteriorBlockInteriorEliminationdR := by
    rfl
  regularNoMatrixInv := by
    rfl
  variableNoMatrixInv := by
    rfl
  regularNoFreeInverseEntryTable := by
    rfl
  variableNoFreeInverseEntryTable := by
    rfl
  regularNoExternalInverseOracle := by
    rfl
  variableNoExternalInverseOracle := by
    rfl
  regularNoMatrixExport := by
    rfl
  variableNoMatrixExport := by
    rfl
  regularNoProductProof := by
    rfl
  variableNoProductProof := by
    rfl
  regularNextPositiveConstructionGate := by
    rfl
  variableNextPositiveConstructionGate := by
    rfl
  status_eq_closed := by
    rfl

theorem generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorAccumulatedEntryCancellationGeneratedInteriorInverseCandidateEntryLedgerStatus.generatedInteriorInverseCandidateEntryClosed := by
  rfl

theorem generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger_regularNoMatrixExport
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularInverseCandidateEntry.noMatrixExportStatus =
      InteriorAccumulatedEntryCancellationNoMatrixExportStatus.noMatrixExportInInteriorAccumulatedEntryCancellation := by
  rfl

theorem generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger_variableNoExternalInverseOracle
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).variableInverseCandidateEntry.noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry := by
  rfl

theorem generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger_regularNextPositiveStage
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (generatedInteriorInverseCandidateEntryGeneratedInteriorInverseCandidateEntryLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularInverseCandidateEntry.nextPositiveConstructionGate =
      InteriorAccumulatedEntryCancellationNextPositiveConstructionGate.interiorInverseCandidateMatrixMatrixExportWithoutProductProof := by
  rfl

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
