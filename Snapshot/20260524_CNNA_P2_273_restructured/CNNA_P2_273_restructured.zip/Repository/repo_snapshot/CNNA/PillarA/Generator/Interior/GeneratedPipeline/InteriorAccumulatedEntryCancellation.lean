import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm

universe u

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus where
  | accumulatedEntryCancellationFromInteriorTerminalFoldResidualFold
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationSourceStatus where
  | sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus where
  | noProductIdentityProofInAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus where
  | noTwoSidedInvInAccumulatedEntryCancellation
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant
  deriving DecidableEq, Repr

structure GeneratedInteriorAccumulatedEntryCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  accumulatedTraceEvaluation :
    GeneratedInteriorAccumulatedTraceEvaluation Cell p A P wp W E K T
  accumulatedEntryFold : GeneratedInteriorAccumulatedEntryFold Cell p A P wp W E K T
  cancellationStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus
  sourceStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationSourceStatus
  noFreeEntryTableStatus : InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus
  noMatrixInvStatus : InteriorAccumulatedEntryCancellationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noProductIdentityProofStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorAccumulatedEntryCancellationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus
  accumulatedTraceEvaluation_is_fromTrace :
    accumulatedTraceEvaluation =
      GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  accumulatedEntryFold_is_fromTrace :
    accumulatedEntryFold = GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :
    accumulatedTraceEvaluation.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :
    accumulatedEntryFold.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedEntry_from_trace :
    ∀ i j : GeneratedInteriorIndex A,
      accumulatedEntryFold.accumulatedEntry i j = generatedInteriorAccumulatedEntryValue T i j
  leftAccumulatedConvolution_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedLeftConvolution W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  rightAccumulatedConvolution_eq_identity :
    ∀ i j : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedRightConvolution W T i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  leftAccumulatedConvolution_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedLeftConvolution W T i i = 1
  leftAccumulatedConvolution_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorAccumulatedLeftConvolution W T i j = 0
  rightAccumulatedConvolution_diagonal :
    ∀ i : GeneratedInteriorIndex A,
      generatedInteriorAccumulatedRightConvolution W T i i = 1
  rightAccumulatedConvolution_offdiag :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → generatedInteriorAccumulatedRightConvolution W T i j = 0
  cancellationStatus_eq :
    cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus.accumulatedEntryCancellationFromInteriorTerminalFoldResidualFold
  sourceStatus_eq :
    sourceStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationSourceStatus.sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  noFreeEntryTableStatus_eq :
    noFreeEntryTableStatus = InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus.noProductIdentityProofInAccumulatedEntryCancellation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus.noTwoSidedInvInAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant

namespace GeneratedInteriorAccumulatedEntryCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

theorem leftConvolution_entry_eq_identity
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedLeftConvolution W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  C.leftAccumulatedConvolution_eq_identity i j

theorem rightConvolution_entry_eq_identity
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedRightConvolution W T i j =
      (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j :=
  C.rightAccumulatedConvolution_eq_identity i j

theorem leftConvolution_diagonal
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedLeftConvolution W T i i = 1 :=
  C.leftAccumulatedConvolution_diagonal i

theorem leftConvolution_offdiag
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    generatedInteriorAccumulatedLeftConvolution W T i j = 0 :=
  C.leftAccumulatedConvolution_offdiag i j hij

theorem rightConvolution_diagonal
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i : GeneratedInteriorIndex A) :
    generatedInteriorAccumulatedRightConvolution W T i i = 1 :=
  C.rightAccumulatedConvolution_diagonal i

theorem rightConvolution_offdiag
    (C : GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    generatedInteriorAccumulatedRightConvolution W T i j = 0 :=
  C.rightAccumulatedConvolution_offdiag i j hij

end GeneratedInteriorAccumulatedEntryCancellationInvariant

abbrev RegularGeneratedInteriorAccumulatedEntryCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorAccumulatedEntryCancellationInvariant
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorAccumulatedEntryCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorAccumulatedEntryCancellationInvariant
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularCancellation :
    RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p regularWeight
  variableCancellation :
    VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p variableWeight
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus
  regularStatus_eq :
    regularCancellation.cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus.accumulatedEntryCancellationFromInteriorTerminalFoldResidualFold
  variableStatus_eq :
    variableCancellation.cancellationStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus.accumulatedEntryCancellationFromInteriorTerminalFoldResidualFold
  regularNoProductIdentityProof :
    regularCancellation.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus.noProductIdentityProofInAccumulatedEntryCancellation
  variableNoProductIdentityProof :
    variableCancellation.noProductIdentityProofStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus.noProductIdentityProofInAccumulatedEntryCancellation
  regularNoTwoSidedInv :
    regularCancellation.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus.noTwoSidedInvInAccumulatedEntryCancellation
  variableNoTwoSidedInv :
    variableCancellation.noTwoSidedInvStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus.noTwoSidedInvInAccumulatedEntryCancellation
  nextConsumerStatus_eq :
    nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant

namespace InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularCancellation :
      RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p regularWeight)
    (variableCancellation :
      VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight where
  regularCancellation := regularCancellation
  variableCancellation := variableCancellation
  nextConsumerStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant
  regularStatus_eq := regularCancellation.cancellationStatus_eq
  variableStatus_eq := variableCancellation.cancellationStatus_eq
  regularNoProductIdentityProof := regularCancellation.noProductIdentityProofStatus_eq
  variableNoProductIdentityProof := variableCancellation.noProductIdentityProofStatus_eq
  regularNoTwoSidedInv := regularCancellation.noTwoSidedInvStatus_eq
  variableNoTwoSidedInv := variableCancellation.noTwoSidedInvStatus_eq
  nextConsumerStatus_eq := by
    rfl

end InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger



end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
