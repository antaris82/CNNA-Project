import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldTerminalIdentity

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff

universe u

open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity

namespace GeneratedInteriorAccumulatedEntryCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTerminalIdentityInteriorBlockFoldTerminalIdentity
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T where
  accumulatedTraceEvaluation := D.invariance.blockFoldNormalForm.accumulatedTraceEvaluation
  accumulatedEntryFold := D.invariance.blockFoldNormalForm.accumulatedEntryFold
  cancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationStatus.accumulatedEntryCancellationFromInteriorTerminalFoldResidualFold
  sourceStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationSourceStatus.sourceFromInteriorBlockInteriorBlockAndInteriorTerminalFoldResidualAccumulatedEntry
  noFreeEntryTableStatus := InteriorAccumulatedEntryCancellationNoFreeInverseEntryTableStatus.noFreeInverseEntryTable
  noMatrixInvStatus := InteriorAccumulatedEntryCancellationNoMatrixInvStatus.noMatrixInvForInverseCandidateEntry
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noProductIdentityProofStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNoProductIdentityProofStatus.noProductIdentityProofInAccumulatedEntryCancellation
  noTwoSidedInvStatus := InteriorTwoSidedInverseValidationInteriorBlockFoldNoTwoSidedInvStatus.noTwoSidedInvInAccumulatedEntryCancellation
  noInteriorEliminationCertificateStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInInteriorAccumulatedEntryCancellation
  noInteriorEliminationDataStatus :=
    InteriorAccumulatedEntryCancellationNoInteriorEliminationDataStatus.noInteriorEliminationDataInInteriorAccumulatedEntryCancellation
  noDtnDataStatus :=
    InteriorAccumulatedEntryCancellationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorAccumulatedEntryCancellation
  noArithmeticTargetStatus :=
    InteriorAccumulatedEntryCancellationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorAccumulatedEntryCancellation
  nextConsumerStatus :=
    InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant
  accumulatedTraceEvaluation_is_fromTrace :=
    D.invariance.blockFoldNormalForm.accumulatedTraceEvaluation_is_fromTrace
  accumulatedEntryFold_is_fromTrace :=
    D.invariance.blockFoldNormalForm.accumulatedEntryFold_is_fromTrace
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :=
    D.traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A
  accumulatedTraceSourceEqInteriorTerminalFoldResidual :=
    D.accumulatedTraceSourceEqInteriorTerminalFoldResidual
  accumulatedFoldSourceEqInteriorTerminalFoldResidual :=
    D.accumulatedFoldSourceEqInteriorTerminalFoldResidual
  accumulatedEntry_from_trace :=
    D.invariance.blockFoldNormalForm.accumulatedEntry_from_trace
  leftAccumulatedConvolution_eq_identity :=
    D.leftAccumulatedConvolution_eq_identity
  rightAccumulatedConvolution_eq_identity :=
    D.rightAccumulatedConvolution_eq_identity
  leftAccumulatedConvolution_diagonal :=
    D.leftAccumulatedConvolution_diagonal
  leftAccumulatedConvolution_offdiag :=
    D.leftAccumulatedConvolution_offdiag
  rightAccumulatedConvolution_diagonal :=
    D.rightAccumulatedConvolution_diagonal
  rightAccumulatedConvolution_offdiag :=
    D.rightAccumulatedConvolution_offdiag
  cancellationStatus_eq := by
    rfl
  sourceStatus_eq := by
    rfl
  noFreeEntryTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

end GeneratedInteriorAccumulatedEntryCancellationInvariant

def accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    GeneratedInteriorAccumulatedEntryCancellationInvariant Cell p A P wp W E K T :=
  GeneratedInteriorAccumulatedEntryCancellationInvariant.fromTerminalIdentityInteriorBlockFoldTerminalIdentity D

theorem accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentityLeftIdentity
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    (accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D).leftAccumulatedConvolution_eq_identity i j =
      D.leftAccumulatedConvolution_eq_identity i j := by
  rfl

theorem accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentityRightIdentity
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T)
    (i j : GeneratedInteriorIndex A) :
    (accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D).rightAccumulatedConvolution_eq_identity i j =
      D.rightAccumulatedConvolution_eq_identity i j := by
  rfl

theorem accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentityNextClosure
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity Cell p A P wp W E K T) :
    (accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D).nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant :=
  (accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D).nextConsumerStatus_eq

def regularAccumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity
    {b : Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (D : RegularGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity b p wp) :
    RegularGeneratedInteriorAccumulatedEntryCancellationInvariant b p wp :=
  accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D

def variableAccumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity
    {β : Nat → Nat} {p : ConcretePolicyOf} {wp : WeightPolicy}
    (D : VariableGeneratedInteriorBlockFoldTerminalIdentityInteriorBlockFoldTerminalIdentity β p wp) :
    VariableGeneratedInteriorAccumulatedEntryCancellationInvariant β p wp :=
  accumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity D

def accumulatedEntryCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentity
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger b β p regularWeight variableWeight) :
    InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger b β p regularWeight variableWeight :=
  InteriorTwoSidedInverseValidationInteriorBlockFoldAccumulatedEntryCancellationLedger.fromRegularAndVariable
    (regularAccumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity
      L.regularTerminalIdentity)
    (variableAccumulatedEntryCancellationInvariantFromTerminalIdentityInteriorBlockFoldTerminalIdentity
      L.variableTerminalIdentity)

theorem accumulatedEntryCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentityNextClosure
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : InteriorTwoSidedInverseValidationInteriorBlockFoldTerminalIdentityTerminalIdentityLedger b β p regularWeight variableWeight) :
    (accumulatedEntryCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentity L).nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorBlockFoldNextConsumerStatus.interiorTwoSidedInverseValidationInteriorAccumulatedEntryCancellationEntryCancellationInvariant :=
  (accumulatedEntryCancellationLedgerFromTerminalIdentityLedgerInteriorBlockFoldTerminalIdentity L).nextConsumerStatus_eq

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
