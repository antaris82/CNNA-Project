import CNNA.PillarA.Arithmetic.Actions.ActionFormatDecision

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

namespace Schur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}
variable {source : ArithmeticSource Cell T} {L : Nat}

inductive SchurRecursionNodeKind where
  | root
  | interior
  | leaf
  deriving DecidableEq, Repr

inductive MobiusTransferSourceKind where
  | boundarySource
  | boundaryMatrixMatrixTransport
  | actionFormatActionFormatDiscipline
  deriving DecidableEq, Repr

inductive MobiusTransferParameterStatus where
  | fromBoundarySourceAndBoundaryMatrixProfileOnly
  deriving DecidableEq, Repr

inductive MobiusActionDataStatus where
  | preservationAndFormatOnlyNoNumericData
  deriving DecidableEq, Repr

def boundaryMatrixAt
    (B : BoundarySource.BoundarySourceSurface source L)
    (i j : BoundarySource.LevelHistoryIndex L) : ExecComplex :=
  B.interface.matrix (B.indexEmbedding.symm i) (B.indexEmbedding.symm j)

theorem boundaryMatrixAt_eq_interface
    (B : BoundarySource.BoundarySourceSurface source L)
    (i j : BoundarySource.LevelHistoryIndex L) :
    boundaryMatrixAt B i j =
      B.interface.matrix (B.indexEmbedding.symm i) (B.indexEmbedding.symm j) := by
  rfl

structure MobiusTransferParameters
    (B : BoundarySource.BoundarySourceSurface source L) where
  boundarySource : BoundarySource.BoundarySourceSurface source L
  boundarySource_eq : boundarySource = B
  matrixTransportLedger : BoundarySource.BoundaryMatrixProfileMatrixTransportLedger source L
  matrixTransportLedger_eq :
    matrixTransportLedger = BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.fromBoundarySource B
  actionFormatLedger : Actions.ActionFormatDecisionLedger source L
  actionFormatLedger_eq :
    actionFormatLedger = Actions.ActionFormatDecisionLedger.fromBoundarySource B
  transferSource : MobiusTransferSourceKind
  transferSource_eq : transferSource = MobiusTransferSourceKind.boundarySource
  parameterStatus : MobiusTransferParameterStatus
  parameterStatus_eq :
    parameterStatus = MobiusTransferParameterStatus.fromBoundarySourceAndBoundaryMatrixProfileOnly
  actionDataStatus : MobiusActionDataStatus
  actionDataStatus_eq :
    actionDataStatus = MobiusActionDataStatus.preservationAndFormatOnlyNoNumericData
  route : B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory
  consumptionPolicy :
    B.consumptionPolicy = BoundarySource.BoundarySourceConsumptionPolicy.boundarySourceOnly
  branchingCutoffAnchor :
    source.toc.approximant source.concretePolicy = T
  schurEliminationAnchor : source.coupling = source.multiSchur
  actionFormatDataDiscipline :
    actionFormatLedger.dataDiscipline =
      Actions.ActionFormatDataDisciplineStatus.formatOnlyNoNewNumericOrSpectralData
  noCutSpecCarrierClaim :
    ∀ _k : BoundarySource.LevelHistoryIndex L,
      source.toc.approximant source.concretePolicy = T

namespace MobiusTransferParameters

def fromBoundarySource
    (B : BoundarySource.BoundarySourceSurface source L) :
    MobiusTransferParameters B where
  boundarySource := B
  boundarySource_eq := by
    rfl
  matrixTransportLedger := BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.fromBoundarySource B
  matrixTransportLedger_eq := by
    rfl
  actionFormatLedger := Actions.ActionFormatDecisionLedger.fromBoundarySource B
  actionFormatLedger_eq := by
    rfl
  transferSource := MobiusTransferSourceKind.boundarySource
  transferSource_eq := by
    rfl
  parameterStatus := MobiusTransferParameterStatus.fromBoundarySourceAndBoundaryMatrixProfileOnly
  parameterStatus_eq := by
    rfl
  actionDataStatus := MobiusActionDataStatus.preservationAndFormatOnlyNoNumericData
  actionDataStatus_eq := by
    rfl
  route := B.route_recursiveHistory
  consumptionPolicy := B.consumptionPolicy_is_interfaceOnly
  branchingCutoffAnchor := B.noCutSpecCarrierClaim_at (⟨0, Nat.succ_pos L⟩)
  schurEliminationAnchor := B.schurContribution_eq
  actionFormatDataDiscipline := by
    rfl
  noCutSpecCarrierClaim := by
    intro k
    exact B.noCutSpecCarrierClaim_at k

theorem boundarySource_eq_anchor
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.boundarySource = B :=
  P.boundarySource_eq

theorem matrixTransportLedgerFromBoundaryMatrixProfile
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.matrixTransportLedger =
      BoundarySource.BoundaryMatrixProfileMatrixTransportLedger.fromBoundarySource B :=
  P.matrixTransportLedger_eq

theorem actionFormatLedgerFromActionFormatDecision
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.actionFormatLedger = Actions.ActionFormatDecisionLedger.fromBoundarySource B :=
  P.actionFormatLedger_eq

theorem transferSource_boundarySource
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.transferSource = MobiusTransferSourceKind.boundarySource :=
  P.transferSource_eq

theorem parameterStatusFromBoundarySourceAndBoundaryMatrixProfileOnly
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.parameterStatus = MobiusTransferParameterStatus.fromBoundarySourceAndBoundaryMatrixProfileOnly :=
  P.parameterStatus_eq

theorem actionDataStatus_noNumericData
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.actionDataStatus = MobiusActionDataStatus.preservationAndFormatOnlyNoNumericData :=
  P.actionDataStatus_eq

theorem route_recursiveHistory
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory :=
  P.route

theorem branchingCutoffAnchor_from_source
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    source.toc.approximant source.concretePolicy = T :=
  P.branchingCutoffAnchor

theorem schurEliminationAnchor_from_source
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    source.coupling = source.multiSchur :=
  P.schurEliminationAnchor

theorem actionFormatDataDiscipline_noNewNumericOrSpectralData
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) :
    P.actionFormatLedger.dataDiscipline =
      Actions.ActionFormatDataDisciplineStatus.formatOnlyNoNewNumericOrSpectralData :=
  P.actionFormatDataDiscipline

theorem noCutSpecCarrierClaim_at
    {B : BoundarySource.BoundarySourceSurface source L}
    (P : MobiusTransferParameters B) (k : BoundarySource.LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  P.noCutSpecCarrierClaim k

end MobiusTransferParameters

end Schur

end CNNA.PillarA.Arithmetic
