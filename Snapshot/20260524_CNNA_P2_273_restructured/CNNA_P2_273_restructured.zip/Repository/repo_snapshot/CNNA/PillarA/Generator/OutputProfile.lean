import CNNA.PillarA.Generator.ComplementTower

set_option autoImplicit false

namespace CNNA.PillarA.Generator

universe u

inductive DerivedOutputKind where
  | levelStepWitness
  | levelHistoryBoundaryPort
  | levelHistorySchurIndexMap
  | levelHistorySchurIndexBridgeConsistency
  | levelHistoryMatrix
  | multiSchur
  | topBoundaryDtN
  | generalizedTopBoundaryDtN
  deriving DecidableEq, Repr

structure GeneratorOutputSourceProfile where
  lock : SinglePreparationLock
  request : GeneratorRequestProfile
  tower : ComplementFamilyApproximationTower
  request_matches_lock : request.global = lock.state
  tower_matches_lock : tower.lock = lock

namespace GeneratorOutputSourceProfile

def state (source : GeneratorOutputSourceProfile) :
    GlobalTheoryApproximationState :=
  source.lock.state

def levelWindow (source : GeneratorOutputSourceProfile) :
    LevelWindow :=
  source.state.levelWindow

def L_max (source : GeneratorOutputSourceProfile) : Nat :=
  source.state.L_max

theorem request_global_eq_state (source : GeneratorOutputSourceProfile) :
    source.request.global = source.state := by
  change source.request.global = source.lock.state
  exact source.request_matches_lock

theorem tower_lock_eq (source : GeneratorOutputSourceProfile) :
    source.tower.lock = source.lock :=
  source.tower_matches_lock

theorem tower_global_eq_state (source : GeneratorOutputSourceProfile) :
    source.tower.global = source.state := by
  change source.tower.lock.state = source.lock.state
  rw [source.tower_matches_lock]

theorem tower_window_eq (source : GeneratorOutputSourceProfile) :
    source.tower.window = source.levelWindow := by
  change source.tower.global.levelWindow = source.state.levelWindow
  rw [source.tower_global_eq_state]

theorem tower_L_max_eq (source : GeneratorOutputSourceProfile) :
    source.tower.L_max = source.L_max := by
  change source.tower.lock.state.levelWindow.L_max =
    source.lock.state.levelWindow.L_max
  rw [source.tower_matches_lock]

end GeneratorOutputSourceProfile

structure GeneratorOutputProfile where
  source : GeneratorOutputSourceProfile
  kind : DerivedOutputKind
  requiredTier : RequestedDataTier
  request_tier_matches_required : source.request.requestedDataTier = requiredTier

namespace GeneratorOutputProfile

def state (profile : GeneratorOutputProfile) :
    GlobalTheoryApproximationState :=
  profile.source.state

def request (profile : GeneratorOutputProfile) : GeneratorRequestProfile :=
  profile.source.request

def lock (profile : GeneratorOutputProfile) : SinglePreparationLock :=
  profile.source.lock

def tower (profile : GeneratorOutputProfile) :
    ComplementFamilyApproximationTower :=
  profile.source.tower

def L_max (profile : GeneratorOutputProfile) : Nat :=
  profile.source.L_max

theorem request_global_eq_state (profile : GeneratorOutputProfile) :
    profile.request.global = profile.state := by
  change profile.source.request.global = profile.source.state
  exact profile.source.request_global_eq_state

theorem request_tier_eq_required (profile : GeneratorOutputProfile) :
    profile.request.requestedDataTier = profile.requiredTier := by
  change profile.source.request.requestedDataTier = profile.requiredTier
  exact profile.request_tier_matches_required

theorem tower_global_eq_state (profile : GeneratorOutputProfile) :
    profile.tower.global = profile.state := by
  change profile.source.tower.global = profile.source.state
  exact profile.source.tower_global_eq_state

theorem tower_L_max_eq (profile : GeneratorOutputProfile) :
    profile.tower.L_max = profile.L_max := by
  change profile.source.tower.L_max = profile.source.L_max
  exact profile.source.tower_L_max_eq

end GeneratorOutputProfile

structure GeneratorOutputKindProfile (kind : DerivedOutputKind) where
  profile : GeneratorOutputProfile
  kind_matches : profile.kind = kind

namespace GeneratorOutputKindProfile

variable {kind : DerivedOutputKind}

def source (profile : GeneratorOutputKindProfile kind) :
    GeneratorOutputSourceProfile :=
  profile.profile.source

def state (profile : GeneratorOutputKindProfile kind) :
    GlobalTheoryApproximationState :=
  profile.profile.state

theorem profile_kind_eq (profile : GeneratorOutputKindProfile kind) :
    profile.profile.kind = kind :=
  profile.kind_matches

theorem request_global_eq_state (profile : GeneratorOutputKindProfile kind) :
    profile.profile.request.global = profile.state := by
  change profile.profile.request.global = profile.profile.state
  exact profile.profile.request_global_eq_state

end GeneratorOutputKindProfile

structure GeneratorOutputInterface where
  profile : GeneratorOutputProfile
  Output : Type u

namespace GeneratorOutputInterface

def kind (iface : GeneratorOutputInterface) : DerivedOutputKind :=
  iface.profile.kind

def requiredTier (iface : GeneratorOutputInterface) : RequestedDataTier :=
  iface.profile.requiredTier

def state (iface : GeneratorOutputInterface) :
    GlobalTheoryApproximationState :=
  iface.profile.state

theorem request_global_eq_state (iface : GeneratorOutputInterface) :
    iface.profile.request.global = iface.state := by
  change iface.profile.request.global = iface.profile.state
  exact iface.profile.request_global_eq_state

end GeneratorOutputInterface

end CNNA.PillarA.Generator
