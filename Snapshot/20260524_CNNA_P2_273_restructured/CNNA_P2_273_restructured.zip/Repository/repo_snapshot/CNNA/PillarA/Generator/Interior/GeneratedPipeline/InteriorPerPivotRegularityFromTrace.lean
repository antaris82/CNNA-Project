import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant

universe u

inductive InteriorTracePivotRegularityPivotNonzeroSourceStatus where
  | pivotEntryNonzeroMustComeFromGeneratedDegreeProfile
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityPerPivotRegularityStatus where
  | perPivotRegularityFromTracePivotScaleWitness
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityTraceRegularityStatus where
  | traceRegularityFromPerPivotScaleWitness
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityPivotScaleSourceStatus where
  | pivotScaleWitnessMustComeFromGeneratedDegreeProfile
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNoMatrixInvStatus where
  | noMatrixInvInPerPivotRegularity
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNoTwoSidedInvStatus where
  | noTwoSidedInvInPerPivotRegularity
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNoProductIdentityProofStatus where
  | noProductIdentityProofInPerPivotRegularity
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotRegularity
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotRegularity
  deriving DecidableEq, Repr

inductive InteriorTracePivotRegularityNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  | interiorTracePivotScaleWitnessTracePivotEntryNonzeroFromGeneratedDegree
  | interiorTracePivotScaleWitnessTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

structure GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  sourceAudit : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T
  pivotNonzeroSourceStatus : InteriorTracePivotRegularityPivotNonzeroSourceStatus
  noMatrixInvStatus : InteriorTracePivotRegularityNoMatrixInvStatus
  noTwoSidedInvStatus : InteriorTracePivotRegularityNoTwoSidedInvStatus
  noProductIdentityProofStatus : InteriorTracePivotRegularityNoProductIdentityProofStatus
  noDtnDataStatus : InteriorTracePivotRegularityNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTracePivotRegularityNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTracePivotRegularityNextConsumerStatus
  pivotEntry_eq_block :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedInteriorBlock W
          (T.localStepOf pivot).pivotDatum.pivotIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex
  pivotEntry_eq_dirichletDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotNonzeroSourceStatus_eq :
    pivotNonzeroSourceStatus =
      InteriorTracePivotRegularityPivotNonzeroSourceStatus.pivotEntryNonzeroMustComeFromGeneratedDegreeProfile
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTracePivotRegularityNoMatrixInvStatus.noMatrixInvInPerPivotRegularity
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTracePivotRegularityNoTwoSidedInvStatus.noTwoSidedInvInPerPivotRegularity
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTracePivotRegularityNoProductIdentityProofStatus.noProductIdentityProofInPerPivotRegularity
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTracePivotRegularityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotRegularity
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTracePivotRegularityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotRegularity
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTracePivotRegularityNextConsumerStatus.interiorTracePivotScaleWitnessTracePivotScaleWitnessFromGeneratedDegree

namespace GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromSourceAudit
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T where
  sourceAudit := A0
  pivotNonzeroSourceStatus :=
    InteriorTracePivotRegularityPivotNonzeroSourceStatus.pivotEntryNonzeroMustComeFromGeneratedDegreeProfile
  noMatrixInvStatus := InteriorTracePivotRegularityNoMatrixInvStatus.noMatrixInvInPerPivotRegularity
  noTwoSidedInvStatus := InteriorTracePivotRegularityNoTwoSidedInvStatus.noTwoSidedInvInPerPivotRegularity
  noProductIdentityProofStatus :=
    InteriorTracePivotRegularityNoProductIdentityProofStatus.noProductIdentityProofInPerPivotRegularity
  noDtnDataStatus := InteriorTracePivotRegularityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotRegularity
  noArithmeticTargetStatus :=
    InteriorTracePivotRegularityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotRegularity
  nextConsumerStatus := InteriorTracePivotRegularityNextConsumerStatus.interiorTracePivotScaleWitnessTracePivotScaleWitnessFromGeneratedDegree
  pivotEntry_eq_block := by
    intro pivot
    exact A0.has_pivotEntry_eq_block pivot
  pivotEntry_eq_dirichletDegree := by
    intro pivot
    calc
      (T.localStepOf pivot).stepUpdate.pivotEntry =
          generatedInteriorBlock W
            (T.localStepOf pivot).pivotDatum.pivotIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex :=
        A0.has_pivotEntry_eq_block pivot
      _ = generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) :=
        generatedInteriorBlock_diag_degree_or_regularized_degree W
          (T.localStepOf pivot).pivotDatum.pivotIndex
  pivotNonzeroSourceStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem nextConsumer_is_tracePivotScaleWitness
    (R : GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T) :
    R.nextConsumerStatus = InteriorTracePivotRegularityNextConsumerStatus.interiorTracePivotScaleWitnessTracePivotScaleWitnessFromGeneratedDegree :=
  R.nextConsumerStatus_eq

end GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity

structure GeneratedInteriorTracePivotEntryNonzeroWitnessInteriorTracePivotRegularity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T
  pivotEntry_ne_zero :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry ≠ 0
  pivotEntry_ne_zero_source : InteriorTracePivotRegularityPivotNonzeroSourceStatus
  pivotEntry_ne_zero_bound_to_requirement :
    pivotEntry_ne_zero_source = requirement.pivotNonzeroSourceStatus

namespace GeneratedInteriorTracePivotEntryNonzeroWitnessInteriorTracePivotRegularity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

theorem pivotEntry_ne_zero_of_witness
    (N : GeneratedInteriorTracePivotEntryNonzeroWitnessInteriorTracePivotRegularity Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry ≠ 0 :=
  N.pivotEntry_ne_zero pivot

end GeneratedInteriorTracePivotEntryNonzeroWitnessInteriorTracePivotRegularity

structure GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T
  pivotScale : GeneratedInteriorIndex A → ℝ
  pivotScale_mul_pivotEntry :
    ∀ pivot : GeneratedInteriorIndex A,
      pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1
  pivotEntry_mul_pivotScale :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry * pivotScale pivot = 1
  pivotScaleSourceStatus : InteriorTracePivotRegularityPivotScaleSourceStatus
  pivotScaleSourceStatus_eq :
    pivotScaleSourceStatus =
      InteriorTracePivotRegularityPivotScaleSourceStatus.pivotScaleWitnessMustComeFromGeneratedDegreeProfile

namespace GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

theorem pivotScale_left_inverse
    (S : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    S.pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  S.pivotScale_mul_pivotEntry pivot

theorem pivotScale_right_inverse
    (S : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry * S.pivotScale pivot = 1 :=
  S.pivotEntry_mul_pivotScale pivot

end GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity

structure GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  scaleWitness : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T
  perPivotRegularity :
    ∀ pivot : GeneratedInteriorIndex A,
      GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant
        Cell p A P wp W E K (T.localStepOf pivot)
  traceLocalStepInvariant :
    GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant Cell p A P wp W E K T
  regularityStatus : InteriorTracePivotRegularityPerPivotRegularityStatus
  traceRegularityStatus : InteriorTracePivotRegularityTraceRegularityStatus
  noMatrixInvStatus : InteriorTracePivotRegularityNoMatrixInvStatus
  noTwoSidedInvStatus : InteriorTracePivotRegularityNoTwoSidedInvStatus
  noProductIdentityProofStatus : InteriorTracePivotRegularityNoProductIdentityProofStatus
  noDtnDataStatus : InteriorTracePivotRegularityNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTracePivotRegularityNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTracePivotRegularityNextConsumerStatus
  perPivotRegularity_eq_from_scaleWitness :
    ∀ pivot : GeneratedInteriorIndex A,
      perPivotRegularity pivot =
        GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant.fromScale
          (scaleWitness.pivotScale pivot)
          (scaleWitness.pivotScale_mul_pivotEntry pivot)
          (scaleWitness.pivotEntry_mul_pivotScale pivot)
  traceLocalStepInvariant_eq_from_perPivotRegularity :
    traceLocalStepInvariant =
      GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant.fromPerPivotRegularity
        scaleWitness.requirement.sourceAudit perPivotRegularity
  regularityStatus_eq :
    regularityStatus = InteriorTracePivotRegularityPerPivotRegularityStatus.perPivotRegularityFromTracePivotScaleWitness
  traceRegularityStatus_eq :
    traceRegularityStatus = InteriorTracePivotRegularityTraceRegularityStatus.traceRegularityFromPerPivotScaleWitness
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorTracePivotRegularityNoMatrixInvStatus.noMatrixInvInPerPivotRegularity
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorTracePivotRegularityNoTwoSidedInvStatus.noTwoSidedInvInPerPivotRegularity
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTracePivotRegularityNoProductIdentityProofStatus.noProductIdentityProofInPerPivotRegularity
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTracePivotRegularityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotRegularity
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTracePivotRegularityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotRegularity
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTracePivotRegularityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge

namespace GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromTracePivotScaleWitness
    (S : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T) :
    GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T where
  scaleWitness := S
  perPivotRegularity := fun pivot =>
    GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant.fromScale
      (S.pivotScale pivot)
      (S.pivotScale_mul_pivotEntry pivot)
      (S.pivotEntry_mul_pivotScale pivot)
  traceLocalStepInvariant :=
    GeneratedInteriorTraceLocalStepSchurCancellationInvariantInteriorLocalStepCancellationInvariant.fromPerPivotRegularity
      S.requirement.sourceAudit
      (fun pivot =>
        GeneratedInteriorLocalPivotRegularityWitnessInteriorLocalStepCancellationInvariant.fromScale
          (S.pivotScale pivot)
          (S.pivotScale_mul_pivotEntry pivot)
          (S.pivotEntry_mul_pivotScale pivot))
  regularityStatus := InteriorTracePivotRegularityPerPivotRegularityStatus.perPivotRegularityFromTracePivotScaleWitness
  traceRegularityStatus := InteriorTracePivotRegularityTraceRegularityStatus.traceRegularityFromPerPivotScaleWitness
  noMatrixInvStatus := InteriorTracePivotRegularityNoMatrixInvStatus.noMatrixInvInPerPivotRegularity
  noTwoSidedInvStatus := InteriorTracePivotRegularityNoTwoSidedInvStatus.noTwoSidedInvInPerPivotRegularity
  noProductIdentityProofStatus :=
    InteriorTracePivotRegularityNoProductIdentityProofStatus.noProductIdentityProofInPerPivotRegularity
  noDtnDataStatus := InteriorTracePivotRegularityNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotRegularity
  noArithmeticTargetStatus :=
    InteriorTracePivotRegularityNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotRegularity
  nextConsumerStatus := InteriorTracePivotRegularityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  perPivotRegularity_eq_from_scaleWitness := by
    intro pivot
    rfl
  traceLocalStepInvariant_eq_from_perPivotRegularity := by
    rfl
  regularityStatus_eq := by
    rfl
  traceRegularityStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem perPivotRegularity_leftInverse
    (R : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (R.perPivotRegularity pivot).pivotScale *
        (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  (R.perPivotRegularity pivot).pivotScale_mul_pivotEntry

theorem perPivotRegularity_rightInverse
    (R : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry *
        (R.perPivotRegularity pivot).pivotScale = 1 :=
  (R.perPivotRegularity pivot).pivotEntry_mul_pivotScale

theorem nextClosureIsInteriorBlockFoldKernelResidualBridge
    (R : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T) :
    R.nextConsumerStatus =
      InteriorTracePivotRegularityNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge :=
  R.nextConsumerStatus_eq

end GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity

abbrev RegularGeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
