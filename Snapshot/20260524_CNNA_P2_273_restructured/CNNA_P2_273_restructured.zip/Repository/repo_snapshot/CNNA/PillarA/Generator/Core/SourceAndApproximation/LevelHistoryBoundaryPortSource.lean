import CNNA.PillarA.Generator.LevelHistory.StepWitness.LevelStepWitness
import CNNA.PillarA.Generator.Core.SourceAndApproximation.ArithmeticSource
import CNNA.PillarA.Generator.LevelHistory.BoundaryPort.LevelHistoryBoundaryPortSource

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.SourceAndApproximation.LevelHistoryBoundaryPortSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource

universe u

inductive LevelHistoryBoundaryPortBoundaryPortSourceStatus where
  | generatedBoundaryPortFromLevelHistoryToSchurIndexLayer
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortBoundaryCarrierProvenanceStatus where
  | boundaryCarrierFromGeneratedBoundaryIndex
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortBoundaryOperatorProvenanceStatus where
  | boundaryOperatorReusedFromLevelHistoryToSchurIndexGeneratedArithmeticSourceSchur
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoFreeEnumerationStatus where
  | noFreeEnumerationInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoFreeTableStatus where
  | noFreeTableInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoChoiceStatus where
  | noChoiceInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoMatrixStartStatus where
  | noMatrixStartInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus where
  | noMatrixInvIntroducedInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus where
  | noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort
  deriving DecidableEq, Repr

inductive LevelHistoryBoundaryPortNextMatrixSourceStatus where
  | levelHistoryMatrixRequiresSchurIndexBridge
  deriving DecidableEq, Repr

abbrev LevelHistoryBoundaryPortNextConsumerStatus := LevelHistoryBoundaryPortNextMatrixSourceStatus

namespace LevelHistoryBoundaryPortNextConsumerStatus

def levelHistoryMatrixRequiresSchurIndexBridgeBeforeMatrixFromBridge :
    LevelHistoryBoundaryPortNextConsumerStatus :=
  LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge

def levelHistorySchurIndexBridgeBridgeRecheckRequiredBeforeLevelHistoryMatrixFromBridge :
    LevelHistoryBoundaryPortNextConsumerStatus :=
  levelHistoryMatrixRequiresSchurIndexBridgeBeforeMatrixFromBridge

end LevelHistoryBoundaryPortNextConsumerStatus

structure GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  sourceLevelHistorySchurIndexWitness : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAt : (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level) →
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAtEqFromGeneratedArithmeticSource : ∀ k,
    witnessAt k =
      GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource sourceLevelHistorySchurIndexWitness.sourceGeneratedArithmeticSourceLedger
        sourceLevelHistorySchurIndexWitness.level k
  witnessAtSourceEqLevelHistoryToSchurIndex : ∀ k,
    (witnessAt k).sourceGeneratedArithmeticSourceLedger = sourceLevelHistorySchurIndexWitness.sourceGeneratedArithmeticSourceLedger
  historyIndex : Type
  historyIndex_eq : historyIndex = GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level
  historyIndex_source : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level
  historyIndexSourceEqLevelHistoryToSchurIndex : historyIndex_source = sourceLevelHistorySchurIndexWitness.levelIndex
  toBoundaryIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level → GeneratedBoundaryIndex A
  toBoundaryIndex_sourceStatus : LevelHistoryBoundaryPortBoundaryPortSourceStatus
  toBoundaryIndex_sourceStatus_eq :
    toBoundaryIndex_sourceStatus =
      LevelHistoryBoundaryPortBoundaryPortSourceStatus.generatedBoundaryPortFromLevelHistoryToSchurIndexLayer
  toBoundaryIndex_level_eq_cutoff : ∀ k,
    (GeneratedBoundaryIndex.level (toBoundaryIndex k)).val = p.L_max
  toBoundaryIndex_mem_boundaryCarrier : ∀ k,
    GeneratedBoundaryIndex.toApproximantIndex (toBoundaryIndex k) ∈ P.boundaryCarrier
  boundaryCarrierProvenanceStatus : LevelHistoryBoundaryPortBoundaryCarrierProvenanceStatus
  boundaryCarrierProvenanceStatus_eq :
    boundaryCarrierProvenanceStatus =
      LevelHistoryBoundaryPortBoundaryCarrierProvenanceStatus.boundaryCarrierFromGeneratedBoundaryIndex
  boundaryCarrier_eq_generated :
    sourceLevelHistorySchurIndexWitness.boundaryCarrier = GeneratedBoundaryIndex A
  boundaryOperatorProvenanceStatus : LevelHistoryBoundaryPortBoundaryOperatorProvenanceStatus
  boundaryOperatorProvenanceStatus_eq :
    boundaryOperatorProvenanceStatus =
      LevelHistoryBoundaryPortBoundaryOperatorProvenanceStatus.boundaryOperatorReusedFromLevelHistoryToSchurIndexGeneratedArithmeticSourceSchur
  boundaryOperatorFromLevelHistoryToSchurIndex :
    sourceLevelHistorySchurIndexWitness.boundaryOperator = sourceLevelHistorySchurIndexWitness.source.boundaryOperator
  boundaryOperator_from_schur :
    sourceLevelHistorySchurIndexWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  applyFromLevelHistoryToSchurIndex : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    sourceLevelHistorySchurIndexWitness.«apply» φ = sourceLevelHistorySchurIndexWitness.source.«apply» φ
  apply_from_mulVec : ∀ φ : GeneratedBoundaryIndex A → ℝ,
    sourceLevelHistorySchurIndexWitness.«apply» φ = sourceLevelHistorySchurIndexWitness.boundaryOperator.mulVec φ
  noFreeEnumerationStatus : LevelHistoryBoundaryPortNoFreeEnumerationStatus
  noFreeEnumerationStatus_eq :
    noFreeEnumerationStatus = LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort
  noFreeTableStatus : LevelHistoryBoundaryPortNoFreeTableStatus
  noFreeTableStatus_eq :
    noFreeTableStatus = LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort
  noChoiceStatus : LevelHistoryBoundaryPortNoChoiceStatus
  noChoiceStatus_eq :
    noChoiceStatus = LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort
  noMatrixStartStatus : LevelHistoryBoundaryPortNoMatrixStartStatus
  noMatrixStartStatus_eq :
    noMatrixStartStatus = LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort
  noMatrixInvIntroducedStatus : LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus
  noMatrixInvIntroducedStatus_eq :
    noMatrixInvIntroducedStatus =
      LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort
  noCharpolyDiscriminantStatus : LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort
  nextConsumerStatus : LevelHistoryBoundaryPortNextMatrixSourceStatus
  nextConsumerStatus_eq :
    nextConsumerStatus = LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge

namespace GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromBoundaryMap
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G)
    (toBoundaryIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex W6.level → GeneratedBoundaryIndex A)
    (toBoundaryIndex_level_eq_cutoff : ∀ k,
      (GeneratedBoundaryIndex.level (toBoundaryIndex k)).val = p.L_max) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G where
  sourceLevelHistorySchurIndexWitness := W6
  witnessAt := fun k => GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource W6.sourceGeneratedArithmeticSourceLedger W6.level k
  witnessAtEqFromGeneratedArithmeticSource := by
    intro k
    rfl
  witnessAtSourceEqLevelHistoryToSchurIndex := by
    intro k
    rfl
  historyIndex := GeneratedLevelHistoryIndexLevelHistoryToSchurIndex W6.level
  historyIndex_eq := by
    rfl
  historyIndex_source := W6.levelIndex
  historyIndexSourceEqLevelHistoryToSchurIndex := by
    rfl
  toBoundaryIndex := toBoundaryIndex
  toBoundaryIndex_sourceStatus := LevelHistoryBoundaryPortBoundaryPortSourceStatus.generatedBoundaryPortFromLevelHistoryToSchurIndexLayer
  toBoundaryIndex_sourceStatus_eq := by
    rfl
  toBoundaryIndex_level_eq_cutoff := toBoundaryIndex_level_eq_cutoff
  toBoundaryIndex_mem_boundaryCarrier := by
    intro k
    rw [P.boundaryCarrier_eq]
    exact boundary_mem_boundaryCarrier (toBoundaryIndex k)
  boundaryCarrierProvenanceStatus :=
    LevelHistoryBoundaryPortBoundaryCarrierProvenanceStatus.boundaryCarrierFromGeneratedBoundaryIndex
  boundaryCarrierProvenanceStatus_eq := by
    rfl
  boundaryCarrier_eq_generated := by
    exact W6.boundaryCarrier_eq_generated
  boundaryOperatorProvenanceStatus :=
    LevelHistoryBoundaryPortBoundaryOperatorProvenanceStatus.boundaryOperatorReusedFromLevelHistoryToSchurIndexGeneratedArithmeticSourceSchur
  boundaryOperatorProvenanceStatus_eq := by
    rfl
  boundaryOperatorFromLevelHistoryToSchurIndex := by
    exact W6.boundaryOperatorEqGeneratedArithmeticSource
  boundaryOperator_from_schur := by
    exact W6.boundaryOperator_eq_schur
  applyFromLevelHistoryToSchurIndex := by
    intro φ
    exact W6.applyEqGeneratedArithmeticSource φ
  apply_from_mulVec := by
    intro φ
    exact W6.apply_eq_mulVec φ
  noFreeEnumerationStatus := LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort
  noFreeEnumerationStatus_eq := by
    rfl
  noFreeTableStatus := LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort
  noFreeTableStatus_eq := by
    rfl
  noChoiceStatus := LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort
  noChoiceStatus_eq := by
    rfl
  noMatrixStartStatus := LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort
  noMatrixStartStatus_eq := by
    rfl
  noMatrixInvIntroducedStatus :=
    LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort
  noMatrixInvIntroducedStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort
  noCharpolyDiscriminantStatus_eq := by
    rfl
  nextConsumerStatus := LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge
  nextConsumerStatus_eq := by
    rfl

theorem toBoundaryIndex_level
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex B.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (B.toBoundaryIndex k)).val = p.L_max :=
  B.toBoundaryIndex_level_eq_cutoff k

theorem toBoundaryIndex_mem_boundaryCarrier_proof
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex B.sourceLevelHistorySchurIndexWitness.level) :
    GeneratedBoundaryIndex.toApproximantIndex (B.toBoundaryIndex k) ∈ P.boundaryCarrier :=
  B.toBoundaryIndex_mem_boundaryCarrier k

theorem boundaryCarrierFromLevelHistoryToSchurIndex
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryCarrier = GeneratedBoundaryIndex A :=
  B.boundaryCarrier_eq_generated

theorem boundaryOperatorFromLevelHistoryToSchurIndexProof
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator = B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator :=
  B.boundaryOperatorFromLevelHistoryToSchurIndex

theorem boundaryOperator_from_schur_proof
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  B.boundaryOperator_from_schur

theorem apply_from_mulVec_proof
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    B.sourceLevelHistorySchurIndexWitness.«apply» φ = B.sourceLevelHistorySchurIndexWitness.boundaryOperator.mulVec φ :=
  B.apply_from_mulVec φ

theorem noFreeEnumeration
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noFreeEnumerationStatus = LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  B.noFreeEnumerationStatus_eq

theorem noFreeTable
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noFreeTableStatus = LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort :=
  B.noFreeTableStatus_eq

theorem noChoice
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noChoiceStatus = LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort :=
  B.noChoiceStatus_eq

theorem noMatrixStart
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noMatrixStartStatus = LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort :=
  B.noMatrixStartStatus_eq

theorem noMatrixInvIntroduced
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noMatrixInvIntroducedStatus =
      LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort :=
  B.noMatrixInvIntroducedStatus_eq

theorem noCharpolyDiscriminant
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noCharpolyDiscriminantStatus =
      LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort :=
  B.noCharpolyDiscriminantStatus_eq

theorem nextMatrixSourceRequiresSchurIndexBridge
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.nextConsumerStatus = LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge :=
  B.nextConsumerStatus_eq

theorem nextConsumerIsLevelHistorySchurIndexBridgeRecheck
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.nextConsumerStatus = LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge :=
  nextMatrixSourceRequiresSchurIndexBridge B

end GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort

def regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort
    (b : Nat) (p : ConcretePolicyOf) :
    GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) := by
  let level : Fin (p.L_max + 1) := ⟨p.L_max, Nat.lt_succ_self p.L_max⟩
  have hmem : ConcreteSubstrate.zeroCell b p.L_max ∈
      (regularGeneratedApproximantStrong b p).approximant.carrier p.L_max := by
    rw [regularGeneratedApproximantStrong_carrier_eq_univ_of_le b (p := p) le_rfl]
    exact Finset.mem_univ _
  exact
    ⟨⟨level, ⟨ConcreteSubstrate.zeroCell b p.L_max, hmem⟩⟩, by
      rfl⟩

def variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) := by
  let level : Fin (p.L_max + 1) := ⟨p.L_max, Nat.lt_succ_self p.L_max⟩
  have hmem : LevelVariableSubstrate.zeroCell β p.L_max ∈
      (variableGeneratedApproximantStrong β p).approximant.carrier p.L_max := by
    rw [variableGeneratedApproximantStrong_carrier_eq_univ_of_le β (p := p) le_rfl]
    exact Finset.mem_univ _
  exact
    ⟨⟨level, ⟨LevelVariableSubstrate.zeroCell β p.L_max, hmem⟩⟩, by
      rfl⟩

theorem regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff
    (b : Nat) (p : ConcretePolicyOf) :
    (GeneratedBoundaryIndex.level (regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort b p)).val = p.L_max :=
  GeneratedBoundaryIndex.level_eq_cutoff (regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort b p)

theorem variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (GeneratedBoundaryIndex.level (variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort β p)).val = p.L_max :=
  GeneratedBoundaryIndex.level_eq_cutoff (variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort β p)

def regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.fromBoundaryMap L.regularWitness
    (fun _ => regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort b p)
    (fun _ => regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff b p)

def variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.fromBoundaryMap L.variableWitness
    (fun _ => variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort β p)
    (fun _ => variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff β p)

structure LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceLevelHistoryToSchurIndexLedger : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight
  regularSource :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableSource :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularSourceEqFromLevelHistoryToSchurIndex :
    regularSource = regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex sourceLevelHistoryToSchurIndexLedger
  variableSourceEqFromLevelHistoryToSchurIndex :
    variableSource = variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex sourceLevelHistoryToSchurIndexLedger
  regularSourceLevelHistorySchurIndexWitnessEq : regularSource.sourceLevelHistorySchurIndexWitness = sourceLevelHistoryToSchurIndexLedger.regularWitness
  variableSourceLevelHistorySchurIndexWitnessEq : variableSource.sourceLevelHistorySchurIndexWitness = sourceLevelHistoryToSchurIndexLedger.variableWitness
  regular_toBoundaryIndex_level_eq_cutoff :
    ∀ k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex regularSource.sourceLevelHistorySchurIndexWitness.level,
      (GeneratedBoundaryIndex.level (regularSource.toBoundaryIndex k)).val = p.L_max
  variable_toBoundaryIndex_level_eq_cutoff :
    ∀ k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex variableSource.sourceLevelHistorySchurIndexWitness.level,
      (GeneratedBoundaryIndex.level (variableSource.toBoundaryIndex k)).val = p.L_max
  regular_toBoundaryIndex_mem_boundaryCarrier :
    ∀ k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex regularSource.sourceLevelHistorySchurIndexWitness.level,
      GeneratedBoundaryIndex.toApproximantIndex (regularSource.toBoundaryIndex k) ∈
      (regularGeneratedBoundaryInteriorPartition b p).boundaryCarrier
  variable_toBoundaryIndex_mem_boundaryCarrier :
    ∀ k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex variableSource.sourceLevelHistorySchurIndexWitness.level,
      GeneratedBoundaryIndex.toApproximantIndex (variableSource.toBoundaryIndex k) ∈
      (variableGeneratedBoundaryInteriorPartition β p).boundaryCarrier
  regularBoundaryOperatorFromLevelHistoryToSchurIndex :
    regularSource.sourceLevelHistorySchurIndexWitness.boundaryOperator =
      regularSource.sourceLevelHistorySchurIndexWitness.source.boundaryOperator
  variableBoundaryOperatorFromLevelHistoryToSchurIndex :
    variableSource.sourceLevelHistorySchurIndexWitness.boundaryOperator =
      variableSource.sourceLevelHistorySchurIndexWitness.source.boundaryOperator
  regular_apply_from_mulVec :
    ∀ φ : GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) → ℝ,
      regularSource.sourceLevelHistorySchurIndexWitness.«apply» φ =
        regularSource.sourceLevelHistorySchurIndexWitness.boundaryOperator.mulVec φ
  variable_apply_from_mulVec :
    ∀ φ : GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) → ℝ,
      variableSource.sourceLevelHistorySchurIndexWitness.«apply» φ =
        variableSource.sourceLevelHistorySchurIndexWitness.boundaryOperator.mulVec φ
  regularNoFreeEnumeration :
    regularSource.noFreeEnumerationStatus = LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort
  variableNoFreeEnumeration :
    variableSource.noFreeEnumerationStatus = LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort
  regularNoFreeTable :
    regularSource.noFreeTableStatus = LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort
  variableNoFreeTable :
    variableSource.noFreeTableStatus = LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort
  regularNoChoice :
    regularSource.noChoiceStatus = LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort
  variableNoChoice :
    variableSource.noChoiceStatus = LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort
  regularNoMatrixStart :
    regularSource.noMatrixStartStatus = LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort
  variableNoMatrixStart :
    variableSource.noMatrixStartStatus = LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort
  regularNoMatrixInvIntroduced :
    regularSource.noMatrixInvIntroducedStatus =
      LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort
  variableNoMatrixInvIntroduced :
    variableSource.noMatrixInvIntroducedStatus =
      LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort
  regularNoCharpolyDiscriminant :
    regularSource.noCharpolyDiscriminantStatus =
      LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort
  variableNoCharpolyDiscriminant :
    variableSource.noCharpolyDiscriminantStatus =
      LevelHistoryBoundaryPortNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistoryBoundaryPort
  regularNextConsumerStatus :
    regularSource.nextConsumerStatus = LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge
  variableNextConsumerStatus :
    variableSource.nextConsumerStatus = LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge

def levelHistoryBoundaryPortSourceGeneratedLevelHistoryBoundaryPortSourceLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight where
  sourceLevelHistoryToSchurIndexLedger := L
  regularSource := regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L
  variableSource := variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L
  regularSourceEqFromLevelHistoryToSchurIndex := by
    rfl
  variableSourceEqFromLevelHistoryToSchurIndex := by
    rfl
  regularSourceLevelHistorySchurIndexWitnessEq := by
    rfl
  variableSourceLevelHistorySchurIndexWitnessEq := by
    rfl
  regular_toBoundaryIndex_level_eq_cutoff := by
    intro k
    exact (regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).toBoundaryIndex_level_eq_cutoff k
  variable_toBoundaryIndex_level_eq_cutoff := by
    intro k
    exact (variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).toBoundaryIndex_level_eq_cutoff k
  regular_toBoundaryIndex_mem_boundaryCarrier := by
    intro k
    exact (regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).toBoundaryIndex_mem_boundaryCarrier k
  variable_toBoundaryIndex_mem_boundaryCarrier := by
    intro k
    exact (variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).toBoundaryIndex_mem_boundaryCarrier k
  regularBoundaryOperatorFromLevelHistoryToSchurIndex := by
    exact (regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).boundaryOperatorFromLevelHistoryToSchurIndex
  variableBoundaryOperatorFromLevelHistoryToSchurIndex := by
    exact (variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).boundaryOperatorFromLevelHistoryToSchurIndex
  regular_apply_from_mulVec := by
    intro φ
    exact (regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).apply_from_mulVec φ
  variable_apply_from_mulVec := by
    intro φ
    exact (variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L).apply_from_mulVec φ
  regularNoFreeEnumeration := by
    rfl
  variableNoFreeEnumeration := by
    rfl
  regularNoFreeTable := by
    rfl
  variableNoFreeTable := by
    rfl
  regularNoChoice := by
    rfl
  variableNoChoice := by
    rfl
  regularNoMatrixStart := by
    rfl
  variableNoMatrixStart := by
    rfl
  regularNoMatrixInvIntroduced := by
    rfl
  variableNoMatrixInvIntroduced := by
    rfl
  regularNoCharpolyDiscriminant := by
    rfl
  variableNoCharpolyDiscriminant := by
    rfl
  regularNextConsumerStatus := by
    rfl
  variableNextConsumerStatus := by
    rfl

def levelHistoryBoundaryPortSourceGeneratedLevelHistoryBoundaryPortSourceLedgerFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight :=
  levelHistoryBoundaryPortSourceGeneratedLevelHistoryBoundaryPortSourceLedger
    (generatedLevelStepWitnessGeneratedLevelStepWitnessLedger L level levelIndex)

theorem levelHistoryBoundaryPortSource_regular_toBoundaryIndex_level_eq_cutoff
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex L.regularSource.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (L.regularSource.toBoundaryIndex k)).val = p.L_max :=
  L.regular_toBoundaryIndex_level_eq_cutoff k

theorem levelHistoryBoundaryPortSource_variable_toBoundaryIndex_level_eq_cutoff
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex L.variableSource.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (L.variableSource.toBoundaryIndex k)).val = p.L_max :=
  L.variable_toBoundaryIndex_level_eq_cutoff k

theorem levelHistoryBoundaryPortSource_regular_noFreeEnumeration
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.regularSource.noFreeEnumerationStatus =
      LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  L.regularNoFreeEnumeration

theorem levelHistoryBoundaryPortSource_variable_noFreeEnumeration
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.variableSource.noFreeEnumerationStatus =
      LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  L.variableNoFreeEnumeration

theorem levelHistoryBoundaryPortSource_regular_nextConsumerStatus
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.regularSource.nextConsumerStatus =
      LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge :=
  L.regularNextConsumerStatus

theorem levelHistoryBoundaryPortSource_variable_nextConsumerStatus
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.variableSource.nextConsumerStatus =
      LevelHistoryBoundaryPortNextMatrixSourceStatus.levelHistoryMatrixRequiresSchurIndexBridge :=
  L.variableNextConsumerStatus

abbrev GeneratedLevelHistoryBoundaryPortSource :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort

namespace GeneratedLevelHistoryBoundaryPortSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

abbrev fromBoundaryMap
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G)
    (toBoundaryIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex W6.level → GeneratedBoundaryIndex A)
    (toBoundaryIndex_level_eq_cutoff : ∀ k,
      (GeneratedBoundaryIndex.level (toBoundaryIndex k)).val = p.L_max) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.fromBoundaryMap W6 toBoundaryIndex
    toBoundaryIndex_level_eq_cutoff

abbrev toBoundaryIndex_level
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex B.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (B.toBoundaryIndex k)).val = p.L_max :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.toBoundaryIndex_level B k

abbrev toBoundaryIndex_mem_boundaryCarrier_proof
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex B.sourceLevelHistorySchurIndexWitness.level) :
    GeneratedBoundaryIndex.toApproximantIndex (B.toBoundaryIndex k) ∈ P.boundaryCarrier :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.toBoundaryIndex_mem_boundaryCarrier_proof B k

abbrev boundaryCarrier_from_levelStep
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryCarrier = GeneratedBoundaryIndex A :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.boundaryCarrierFromLevelHistoryToSchurIndex B

abbrev boundaryOperator_from_levelStep
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator = B.sourceLevelHistorySchurIndexWitness.source.boundaryOperator :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.boundaryOperatorFromLevelHistoryToSchurIndexProof B

abbrev boundaryOperator_from_schur
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.sourceLevelHistorySchurIndexWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          B.sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.boundaryOperator_from_schur_proof B

abbrev apply_from_mulVec
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (φ : GeneratedBoundaryIndex A → ℝ) :
    B.sourceLevelHistorySchurIndexWitness.«apply» φ = B.sourceLevelHistorySchurIndexWitness.boundaryOperator.mulVec φ :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.apply_from_mulVec_proof B φ

abbrev noFreeEnumeration
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noFreeEnumerationStatus = LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.noFreeEnumeration B

abbrev noFreeTable
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noFreeTableStatus = LevelHistoryBoundaryPortNoFreeTableStatus.noFreeTableInLevelHistoryBoundaryPort :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.noFreeTable B

abbrev noChoice
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noChoiceStatus = LevelHistoryBoundaryPortNoChoiceStatus.noChoiceInLevelHistoryBoundaryPort :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.noChoice B

abbrev noMatrixStart
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noMatrixStartStatus = LevelHistoryBoundaryPortNoMatrixStartStatus.noMatrixStartInLevelHistoryBoundaryPort :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.noMatrixStart B

abbrev noMatrixInvIntroduced
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    B.noMatrixInvIntroducedStatus =
      LevelHistoryBoundaryPortNoMatrixInvIntroducedStatus.noMatrixInvIntroducedInLevelHistoryBoundaryPort :=
  GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort.noMatrixInvIntroduced B

end GeneratedLevelHistoryBoundaryPortSource

abbrev regularGeneratedBoundaryZeroPort
    (b : Nat) (p : ConcretePolicyOf) :
    GeneratedBoundaryIndex (regularGeneratedApproximantStrong b p) :=
  regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort b p

abbrev variableGeneratedBoundaryZeroPort
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    GeneratedBoundaryIndex (variableGeneratedApproximantStrong β p) :=
  variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort β p

abbrev regularGeneratedBoundaryZeroPort_level_eq_cutoff
    (b : Nat) (p : ConcretePolicyOf) :
    (GeneratedBoundaryIndex.level (regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPort b p)).val = p.L_max :=
  regularGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff b p

abbrev variableGeneratedBoundaryZeroPort_level_eq_cutoff
    (β : Nat → Nat) (p : ConcretePolicyOf) :
    (GeneratedBoundaryIndex.level (variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPort β p)).val = p.L_max :=
  variableGeneratedBoundaryZeroPortLevelHistoryBoundaryPortLevelEqCutoff β p

abbrev regularGeneratedLevelHistoryBoundaryPortSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  regularGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L

abbrev variableGeneratedLevelHistoryBoundaryPortSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  variableGeneratedLevelHistoryBoundaryPortSourceFromLevelHistoryToSchurIndex L

abbrev regular_toBoundaryIndex_level_eq_cutoff
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex L.regularSource.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (L.regularSource.toBoundaryIndex k)).val = p.L_max :=
  levelHistoryBoundaryPortSource_regular_toBoundaryIndex_level_eq_cutoff L k

abbrev variable_toBoundaryIndex_level_eq_cutoff
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex L.variableSource.sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level (L.variableSource.toBoundaryIndex k)).val = p.L_max :=
  levelHistoryBoundaryPortSource_variable_toBoundaryIndex_level_eq_cutoff L k

abbrev regular_noFreeEnumeration
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.regularSource.noFreeEnumerationStatus =
      LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  levelHistoryBoundaryPortSource_regular_noFreeEnumeration L

abbrev variable_noFreeEnumeration
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    L.variableSource.noFreeEnumerationStatus =
      LevelHistoryBoundaryPortNoFreeEnumerationStatus.noFreeEnumerationInLevelHistoryBoundaryPort :=
  levelHistoryBoundaryPortSource_variable_noFreeEnumeration L

end CNNA.PillarA.Arithmetic.SourceAndApproximation.LevelHistoryBoundaryPortSource
