import CNNA.PillarA.Generator.OutputCompatibility

set_option autoImplicit false

namespace CNNA.PillarA.Generator

inductive GeneratorOutputReleaseScope where
  | generatorOutputLayerOnly
  deriving DecidableEq, Repr

structure GeneratorOutputReleaseCertificate where
  compatibility : GeneratorOutputCompatibilityFacade
  transition : GeneratorOutputImportTransitionCertificate
  transition_facade_matches : transition.facade = compatibility
  scope : GeneratorOutputReleaseScope
  scope_is_generator_output_layer_only :
    scope = GeneratorOutputReleaseScope.generatorOutputLayerOnly

namespace GeneratorOutputReleaseCertificate

def source (certificate : GeneratorOutputReleaseCertificate) :
    GeneratorOutputSourceProfile :=
  certificate.compatibility.source

def state (certificate : GeneratorOutputReleaseCertificate) :
    GlobalTheoryApproximationState :=
  certificate.source.state

def releasedScope (certificate : GeneratorOutputReleaseCertificate) :
    GeneratorOutputReleaseScope :=
  certificate.scope

theorem transition_facade_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.transition.facade = certificate.compatibility :=
  certificate.transition_facade_matches

theorem releasedScope_is_generator_output_layer_only
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.releasedScope =
      GeneratorOutputReleaseScope.generatorOutputLayerOnly := by
  change certificate.scope = GeneratorOutputReleaseScope.generatorOutputLayerOnly
  exact certificate.scope_is_generator_output_layer_only

theorem transition_status_is_neutral_import_target
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.transition.status =
      GeneratorOutputImportTransitionStatus.neutralGeneratorImportsCarryTarget :=
  certificate.transition.status_is_neutral_import_target

theorem levelStepWitness_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelStepWitness.profile.source = certificate.source := by
  change certificate.compatibility.levelStepWitness.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.levelStepWitness_source_eq

theorem levelHistoryBoundaryPort_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistoryBoundaryPort.profile.source =
      certificate.source := by
  change certificate.compatibility.levelHistoryBoundaryPort.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.levelHistoryBoundaryPort_source_eq

theorem levelHistorySchurIndexMap_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistorySchurIndexMap.profile.source =
      certificate.source := by
  change certificate.compatibility.levelHistorySchurIndexMap.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.levelHistorySchurIndexMap_source_eq

theorem levelHistorySchurIndexBridgeConsistency_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistorySchurIndexBridgeConsistency.profile.source =
      certificate.source := by
  change certificate.compatibility.levelHistorySchurIndexBridgeConsistency.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.levelHistorySchurIndexBridgeConsistency_source_eq

theorem levelHistoryMatrix_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistoryMatrix.profile.source = certificate.source := by
  change certificate.compatibility.levelHistoryMatrix.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.levelHistoryMatrix_source_eq

theorem multiSchur_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.multiSchur.profile.source = certificate.source := by
  change certificate.compatibility.multiSchur.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.multiSchur_source_eq

theorem topBoundaryDtN_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.topBoundaryDtN.profile.source = certificate.source := by
  change certificate.compatibility.topBoundaryDtN.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.topBoundaryDtN_source_eq

theorem generalizedTopBoundaryDtN_source_eq
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.generalizedTopBoundaryDtN.profile.source =
      certificate.source := by
  change certificate.compatibility.generalizedTopBoundaryDtN.profile.source =
    certificate.compatibility.source
  exact certificate.compatibility.generalizedTopBoundaryDtN_source_eq

theorem levelStepWitness_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelStepWitness.profile.kind =
      DerivedOutputKind.levelStepWitness :=
  certificate.compatibility.levelStepWitness_kind

theorem levelHistoryBoundaryPort_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistoryBoundaryPort.profile.kind =
      DerivedOutputKind.levelHistoryBoundaryPort :=
  certificate.compatibility.levelHistoryBoundaryPort_kind

theorem levelHistorySchurIndexMap_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistorySchurIndexMap.profile.kind =
      DerivedOutputKind.levelHistorySchurIndexMap :=
  certificate.compatibility.levelHistorySchurIndexMap_kind

theorem levelHistorySchurIndexBridgeConsistency_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistorySchurIndexBridgeConsistency.profile.kind =
      DerivedOutputKind.levelHistorySchurIndexBridgeConsistency :=
  certificate.compatibility.levelHistorySchurIndexBridgeConsistency_kind

theorem levelHistoryMatrix_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.levelHistoryMatrix.profile.kind =
      DerivedOutputKind.levelHistoryMatrix :=
  certificate.compatibility.levelHistoryMatrix_kind

theorem multiSchur_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.multiSchur.profile.kind =
      DerivedOutputKind.multiSchur :=
  certificate.compatibility.multiSchur_kind

theorem topBoundaryDtN_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.topBoundaryDtN.profile.kind =
      DerivedOutputKind.topBoundaryDtN :=
  certificate.compatibility.topBoundaryDtN_kind

theorem generalizedTopBoundaryDtN_kind
    (certificate : GeneratorOutputReleaseCertificate) :
    certificate.compatibility.generalizedTopBoundaryDtN.profile.kind =
      DerivedOutputKind.generalizedTopBoundaryDtN :=
  certificate.compatibility.generalizedTopBoundaryDtN_kind

end GeneratorOutputReleaseCertificate

end CNNA.PillarA.Generator
