import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.DtN.Core.DtN

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry

open scoped BigOperators

universe u

inductive GeneratedCandidateEntryShapeAuditOutcome where
  | candidateEntryEqualsInteriorBlock
  | shapeObstruction
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus where
  | candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoRepairStatus where
  | noRepairFormulaNoMatrixInvNoExternalOracle
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7 where
  | noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef1B04
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068 where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef6F6B
  deriving DecidableEq, Repr

inductive GeneratedInteriorTwoSidedInvObstructionReason where
  | candidateEntryEqualsInteriorBlockAndSquareIdentityNotDerived
  deriving DecidableEq, Repr

inductive GeneratedInteriorTwoSidedInvReturnTarget where
  | returnToInteriorEliminationCandidateEntry
  | returnToInteriorEliminationdR
  | returnToInteriorBlock
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerStatus where
  | shapeAuditClosedProductProofObstructed
  deriving DecidableEq, Repr

def GeneratedInteriorCandidateLeftProductEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (generatedInteriorBlock W * candidateMatrix_from_candidateEntry E) i j

def GeneratedInteriorCandidateRightProductEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) : ℝ :=
  (candidateMatrix_from_candidateEntry E * generatedInteriorBlock W) i j

theorem candidateEntry_eq_candidateSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    E.entry i j =
      generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
        E.candidate i j :=
  E.entry_eq_from_treeRecursiveProfile i j

theorem candidateMatrix_entry_eq_candidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    candidateMatrix_from_candidateEntry E i j = E.entry i j :=
  candidateMatrix_from_candidateEntry_entry E i j

theorem candidateEntry_eq_interiorBlock
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    E.entry i j = generatedInteriorBlock W i j := by
  calc
    E.entry i j =
        generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
          E.candidate i j :=
      candidateEntry_eq_candidateSource E i j
    _ = generatedInteriorBlock W i j := by
      unfold generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
      rw [E.candidateSource_treeRecursive]

theorem candidateMatrix_entry_eq_interiorBlock
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    candidateMatrix_from_candidateEntry E i j = generatedInteriorBlock W i j := by
  calc
    candidateMatrix_from_candidateEntry E i j = E.entry i j :=
      candidateMatrix_entry_eq_candidateEntry E i j
    _ = generatedInteriorBlock W i j :=
      candidateEntry_eq_interiorBlock E i j

theorem candidateMatrix_eq_interiorBlock
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    candidateMatrix_from_candidateEntry E = generatedInteriorBlock W := by
  funext i j
  exact candidateMatrix_entry_eq_interiorBlock E i j

theorem candidateEntry_eq_interiorBlock_or_shapeObstruction
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    (∀ i j : GeneratedInteriorIndex A, E.entry i j = generatedInteriorBlock W i j) ∨
      GeneratedCandidateEntryShapeAuditOutcome.shapeObstruction =
        GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock := by
  exact Or.inl (fun i j => candidateEntry_eq_interiorBlock E i j)

theorem interiorBlock_square_left_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorCandidateLeftProductEntry E i j =
      (generatedInteriorBlock W * generatedInteriorBlock W) i j :=
  congrArg
    (fun M : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ =>
      (generatedInteriorBlock W * M) i j)
    (candidateMatrix_eq_interiorBlock E)

theorem interiorBlock_square_right_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (i j : GeneratedInteriorIndex A) :
    GeneratedInteriorCandidateRightProductEntry E i j =
      (generatedInteriorBlock W * generatedInteriorBlock W) i j :=
  congrArg
    (fun M : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ =>
      (M * generatedInteriorBlock W) i j)
    (candidateMatrix_eq_interiorBlock E)

structure GeneratedCandidateEntryShapeAudit
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp) where
  candidateEntry : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W
  outcome : GeneratedCandidateEntryShapeAuditOutcome
  status : InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus
  noRepairStatus : InteriorTwoSidedInverseValidationNoRepairStatus
  candidateEntry_eq_candidateSource :
    ∀ i j : GeneratedInteriorIndex A,
      candidateEntry.entry i j =
        generatedInteriorEliminationCandidateEntry_from_treeRecursiveProfile_value
          candidateEntry.candidate i j
  candidateMatrix_entry_eq_candidateEntry :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix_from_candidateEntry candidateEntry i j = candidateEntry.entry i j
  candidateEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      candidateEntry.entry i j = generatedInteriorBlock W i j
  candidateMatrix_entry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A,
      candidateMatrix_from_candidateEntry candidateEntry i j = generatedInteriorBlock W i j
  candidateMatrix_eq_interiorBlock :
    candidateMatrix_from_candidateEntry candidateEntry = generatedInteriorBlock W
  candidateEntry_eq_interiorBlock_or_shapeObstruction :
    (∀ i j : GeneratedInteriorIndex A,
      candidateEntry.entry i j = generatedInteriorBlock W i j) ∨
      GeneratedCandidateEntryShapeAuditOutcome.shapeObstruction =
        GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock
  outcome_eq_candidateEntryEqualsInteriorBlock :
    outcome = GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock
  status_eq_closed :
    status = InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus.candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry
  noRepairStatus_eq :
    noRepairStatus = InteriorTwoSidedInverseValidationNoRepairStatus.noRepairFormulaNoMatrixInvNoExternalOracle

namespace GeneratedCandidateEntryShapeAudit

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}

def fromCandidateEntry
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    GeneratedCandidateEntryShapeAudit Cell p A P wp W where
  candidateEntry := E
  outcome := GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock
  status := InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus.candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry
  noRepairStatus := InteriorTwoSidedInverseValidationNoRepairStatus.noRepairFormulaNoMatrixInvNoExternalOracle
  candidateEntry_eq_candidateSource := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_candidateSource E i j
  candidateMatrix_entry_eq_candidateEntry := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateMatrix_entry_eq_candidateEntry E i j
  candidateEntry_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_interiorBlock E i j
  candidateMatrix_entry_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateMatrix_entry_eq_interiorBlock E i j
  candidateMatrix_eq_interiorBlock :=
    CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateMatrix_eq_interiorBlock E
  candidateEntry_eq_interiorBlock_or_shapeObstruction :=
    CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_interiorBlock_or_shapeObstruction E
  outcome_eq_candidateEntryEqualsInteriorBlock := by
    rfl
  status_eq_closed := by
    rfl
  noRepairStatus_eq := by
    rfl

end GeneratedCandidateEntryShapeAudit

structure GeneratedInteriorTwoSidedInvProof
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) : Prop where
  left_product_entry_eq_one :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateLeftProductEntry E i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  right_product_entry_eq_one :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateRightProductEntry E i j =
        (1 : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ) i j
  left_product_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateLeftProductEntry E i i = 1
  left_product_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorCandidateLeftProductEntry E i j = 0
  right_product_diagonal_entry :
    ∀ i : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateRightProductEntry E i i = 1
  right_product_offdiag_entry :
    ∀ i j : GeneratedInteriorIndex A,
      i ≠ j → GeneratedInteriorCandidateRightProductEntry E i j = 0

def provenTwoSidedInv
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (H : GeneratedInteriorTwoSidedInvProof Cell p A P wp W E) :
    TwoSidedInv (generatedInteriorBlock W) (candidateMatrix_from_candidateEntry E) where
  left_inv := by
    funext i j
    exact H.left_product_entry_eq_one i j
  right_inv := by
    funext i j
    exact H.right_product_entry_eq_one i j

theorem left_product_diagonal_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (H : GeneratedInteriorTwoSidedInvProof Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorCandidateLeftProductEntry E i i = 1 :=
  H.left_product_diagonal_entry i

theorem left_product_offdiag_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (H : GeneratedInteriorTwoSidedInvProof Cell p A P wp W E)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorCandidateLeftProductEntry E i j = 0 :=
  H.left_product_offdiag_entry i j hij

theorem right_product_diagonal_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (H : GeneratedInteriorTwoSidedInvProof Cell p A P wp W E)
    (i : GeneratedInteriorIndex A) :
    GeneratedInteriorCandidateRightProductEntry E i i = 1 :=
  H.right_product_diagonal_entry i

theorem right_product_offdiag_entry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    (H : GeneratedInteriorTwoSidedInvProof Cell p A P wp W E)
    (i j : GeneratedInteriorIndex A)
    (hij : i ≠ j) :
    GeneratedInteriorCandidateRightProductEntry E i j = 0 :=
  H.right_product_offdiag_entry i j hij

structure GeneratedInteriorTwoSidedInvObstruction
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) where
  shapeAudit : GeneratedCandidateEntryShapeAudit Cell p A P wp W
  reason : GeneratedInteriorTwoSidedInvObstructionReason
  returnTarget : GeneratedInteriorTwoSidedInvReturnTarget
  noRepairStatus : InteriorTwoSidedInverseValidationNoRepairStatus
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068
  shapeAudit_candidateEntry_eq : shapeAudit.candidateEntry = E
  candidateEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex A, E.entry i j = generatedInteriorBlock W i j
  leftProduct_is_interiorBlockSquare :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateLeftProductEntry E i j =
        (generatedInteriorBlock W * generatedInteriorBlock W) i j
  rightProduct_is_interiorBlockSquare :
    ∀ i j : GeneratedInteriorIndex A,
      GeneratedInteriorCandidateRightProductEntry E i j =
        (generatedInteriorBlock W * generatedInteriorBlock W) i j
  reason_eq :
    reason =
      GeneratedInteriorTwoSidedInvObstructionReason.candidateEntryEqualsInteriorBlockAndSquareIdentityNotDerived
  returnTarget_eq : returnTarget = GeneratedInteriorTwoSidedInvReturnTarget.returnToInteriorEliminationdR
  noRepairStatus_eq :
    noRepairStatus = InteriorTwoSidedInverseValidationNoRepairStatus.noRepairFormulaNoMatrixInvNoExternalOracle
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef1B04
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef6F6B

def generatedInteriorTwoSidedInvObstruction_fromShapeAudit
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W) :
    GeneratedInteriorTwoSidedInvObstruction Cell p A P wp W E where
  shapeAudit := GeneratedCandidateEntryShapeAudit.fromCandidateEntry E
  reason :=
    GeneratedInteriorTwoSidedInvObstructionReason.candidateEntryEqualsInteriorBlockAndSquareIdentityNotDerived
  returnTarget := GeneratedInteriorTwoSidedInvReturnTarget.returnToInteriorEliminationdR
  noRepairStatus := InteriorTwoSidedInverseValidationNoRepairStatus.noRepairFormulaNoMatrixInvNoExternalOracle
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef1B04
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef6F6B
  shapeAudit_candidateEntry_eq := by
    rfl
  candidateEntry_eq_interiorBlock := by
    intro i j
    exact CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv.candidateEntry_eq_interiorBlock E i j
  leftProduct_is_interiorBlockSquare := by
    intro i j
    exact interiorBlock_square_left_entry E i j
  rightProduct_is_interiorBlockSquare := by
    intro i j
    exact interiorBlock_square_right_entry E i j
  reason_eq := by
    rfl
  returnTarget_eq := by
    rfl
  noRepairStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl

def regularGeneratedCandidateEntryShapeAudit
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedCandidateEntryShapeAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp) :=
  GeneratedCandidateEntryShapeAudit.fromCandidateEntry
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)

def variableGeneratedCandidateEntryShapeAudit
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedCandidateEntryShapeAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp) :=
  GeneratedCandidateEntryShapeAudit.fromCandidateEntry
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)

def regularGeneratedInteriorTwoSidedInvObstruction
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorTwoSidedInvObstruction
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp) :=
  generatedInteriorTwoSidedInvObstruction_fromShapeAudit
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)

def variableGeneratedInteriorTwoSidedInvObstruction
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorTwoSidedInvObstruction
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp) :=
  generatedInteriorTwoSidedInvObstruction_fromShapeAudit
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)

structure InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus
  generatedInteriorEliminationCandidateEntryLedger : InteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight
  regularShapeAudit :
    GeneratedCandidateEntryShapeAudit
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
  variableShapeAudit :
    GeneratedCandidateEntryShapeAudit
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
  generatedInteriorEliminationCandidateEntryLedger_eq_main :
    generatedInteriorEliminationCandidateEntryLedger = generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight
  regularShapeAudit_eq_main :
    regularShapeAudit = regularGeneratedCandidateEntryShapeAudit b p regularWeight
  variableShapeAudit_eq_main :
    variableShapeAudit = variableGeneratedCandidateEntryShapeAudit β p variableWeight
  regularCandidateEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      regularShapeAudit.candidateEntry.entry i j =
        regularGeneratedInteriorBlock b p regularWeight i j
  variableCandidateEntry_eq_interiorBlock :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      variableShapeAudit.candidateEntry.entry i j =
        variableGeneratedInteriorBlock β p variableWeight i j
  regularOutcome_eq_candidateEntryEqualsInteriorBlock :
    regularShapeAudit.outcome = GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock
  variableOutcome_eq_candidateEntryEqualsInteriorBlock :
    variableShapeAudit.outcome = GeneratedCandidateEntryShapeAuditOutcome.candidateEntryEqualsInteriorBlock
  status_eq_closed :
    status = InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus.candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry

def interiorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger b β p regularWeight variableWeight where
  status := InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus.candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry
  generatedInteriorEliminationCandidateEntryLedger := generatedInteriorEliminationCandidateEntryGeneratedInteriorEliminationCandidateEntryLedger b β p regularWeight variableWeight
  regularShapeAudit := regularGeneratedCandidateEntryShapeAudit b p regularWeight
  variableShapeAudit := variableGeneratedCandidateEntryShapeAudit β p variableWeight
  generatedInteriorEliminationCandidateEntryLedger_eq_main := by
    rfl
  regularShapeAudit_eq_main := by
    rfl
  variableShapeAudit_eq_main := by
    rfl
  regularCandidateEntry_eq_interiorBlock := by
    intro i j
    exact (regularGeneratedCandidateEntryShapeAudit b p regularWeight).candidateEntry_eq_interiorBlock i j
  variableCandidateEntry_eq_interiorBlock := by
    intro i j
    exact (variableGeneratedCandidateEntryShapeAudit β p variableWeight).candidateEntry_eq_interiorBlock i j
  regularOutcome_eq_candidateEntryEqualsInteriorBlock := by
    exact (regularGeneratedCandidateEntryShapeAudit b p regularWeight).outcome_eq_candidateEntryEqualsInteriorBlock
  variableOutcome_eq_candidateEntryEqualsInteriorBlock := by
    exact (variableGeneratedCandidateEntryShapeAudit β p variableWeight).outcome_eq_candidateEntryEqualsInteriorBlock
  status_eq_closed := by
    rfl

structure InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerInteriorInverseCandidateStartRefC30F
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  status : InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerStatus
  shapeLedger : InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger b β p regularWeight variableWeight
  regularObstruction :
    GeneratedInteriorTwoSidedInvObstruction
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
  variableObstruction :
    GeneratedInteriorTwoSidedInvObstruction
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
  noCertificateStatus : InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7
  noDtnDataStatus : InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A
  noArithmeticTargetStatus : InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068
  shapeLedger_eq_main :
    shapeLedger = interiorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger b β p regularWeight variableWeight
  regularObstruction_eq_main :
    regularObstruction = regularGeneratedInteriorTwoSidedInvObstruction b p regularWeight
  variableObstruction_eq_main :
    variableObstruction = variableGeneratedInteriorTwoSidedInvObstruction β p variableWeight
  regularReturnTarget_eq :
    regularObstruction.returnTarget = GeneratedInteriorTwoSidedInvReturnTarget.returnToInteriorEliminationdR
  variableReturnTarget_eq :
    variableObstruction.returnTarget = GeneratedInteriorTwoSidedInvReturnTarget.returnToInteriorEliminationdR
  noCertificateStatus_eq :
    noCertificateStatus =
      InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef1B04
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef6F6B
  status_eq_obstructed :
    status = InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerStatus.shapeAuditClosedProductProofObstructed

def interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerInteriorInverseCandidateStartRefC30F b β p regularWeight variableWeight where
  status := InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerStatus.shapeAuditClosedProductProofObstructed
  shapeLedger := interiorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger b β p regularWeight variableWeight
  regularObstruction := regularGeneratedInteriorTwoSidedInvObstruction b p regularWeight
  variableObstruction := variableGeneratedInteriorTwoSidedInvObstruction β p variableWeight
  noCertificateStatus :=
    InteriorTwoSidedInverseValidationNoInteriorEliminationCertificateStatusInteriorTwoSidedInvCoreRef64C7.noInteriorEliminationCertificateInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef1B04
  noDtnDataStatus := InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D
  noArithmeticTargetStatus :=
    InteriorTwoSidedInverseValidationNoArithmeticTargetStatusInteriorTwoSidedInvCoreRef5068.noCharpolyFactorDiscriminantOrL23TargetInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef6F6B
  shapeLedger_eq_main := by
    rfl
  regularObstruction_eq_main := by
    rfl
  variableObstruction_eq_main := by
    rfl
  regularReturnTarget_eq := by
    rfl
  variableReturnTarget_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  status_eq_obstructed := by
    rfl

theorem interiorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidation0CandidateEntryShapeAuditLedger b β p regularWeight variableWeight).status =
      InteriorTwoSidedInverseValidation0CandidateEntryShapeAuditStatus.candidateEntryShapeAuditedFromInteriorEliminationCandidateEntry := by
  rfl

theorem interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger b β p regularWeight variableWeight).status =
      InteriorTwoSidedInverseValidationGeneratedTwoSidedInvLedgerStatus.shapeAuditClosedProductProofObstructed := by
  rfl

theorem interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger_regularReturnTarget
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger b β p regularWeight variableWeight).regularObstruction.returnTarget =
      GeneratedInteriorTwoSidedInvReturnTarget.returnToInteriorEliminationdR := by
  rfl

theorem interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger_variableNoDtnData
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    (interiorTwoSidedInverseValidationGeneratedTwoSidedInvLedger b β p regularWeight variableWeight).variableObstruction.noDtnDataStatus =
      InteriorTwoSidedInverseValidationNoDtnDataStatusInteriorTwoSidedInvCoreRef544A.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTwoSidedInverseValidationInteriorTwoSidedInvCoreRef998D := by
  rfl


end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
