import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateMatrix

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix

universe u

inductive InteriorInverseCandidateShapeSeparationShapeSeparationStatus where
  | shapeSeparationFromInteriorInverseCandidateMatrixMatrix
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationSourceSeparationStatus where
  | sourceSeparatedAsInteriorTerminalFoldResidualAccumulatedEntry
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus where
  | noInteriorEliminationCandidateEntryCandidateEntryFallback
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus where
  | noInteriorBlockFallbackWithoutFutureInvolutiveProof
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationInvolutiveBlockProofGateStatus where
  | involutiveBlockProofDeferredToInteriorTwoSidedInverseValidationProductClosure
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoLocalResidualWrapperFallbackStatus where
  | noOnlyLocalResidualWrapperFallback
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoFreeTableStatus where
  | noFreeMatrixOrEntryTableInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoMatrixInvStatus where
  | noMatrixInvInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoProductProofStatus where
  | noProductProofInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus where
  | noTwoSidedInvInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoInteriorEliminationCertificateStatus where
  | noInteriorEliminationCertificateInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationNextGateStatus where
  | interiorInverseCandidateHandoffHandoffAfterShapeSeparation
  deriving DecidableEq, Repr

inductive InteriorInverseCandidateShapeSeparationLedgerStatus where
  | shapeSeparationClosedAfterPositiveMatrixExport
  deriving DecidableEq, Repr

structure GeneratedInteriorInverseCandidateShapeSeparation
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) where
  sourceMatrix : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T
  sourceCandidateEntry : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W
  accumulatedInverseCandidateEntry :
    GeneratedInteriorAccumulatedInverseCandidateEntry Cell p A P wp W E K T
  matrix : Matrix (GeneratedInteriorIndex A) (GeneratedInteriorIndex A) ℝ
  shapeSeparationStatus : InteriorInverseCandidateShapeSeparationShapeSeparationStatus
  sourceSeparationStatus : InteriorInverseCandidateShapeSeparationSourceSeparationStatus
  noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus :
    InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus
  noInteriorBlockFallbackStatus : InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus
  involutiveBlockProofGateStatus : InteriorInverseCandidateShapeSeparationInvolutiveBlockProofGateStatus
  noLocalResidualWrapperFallbackStatus : InteriorInverseCandidateShapeSeparationNoLocalResidualWrapperFallbackStatus
  notOnlyLocalResidualWrapperStatus : InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus
  noFreeTableStatus : InteriorInverseCandidateShapeSeparationNoFreeTableStatus
  noMatrixInvStatus : InteriorInverseCandidateShapeSeparationNoMatrixInvStatus
  noExternalInverseOracleStatus : InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus
  noProductProofStatus : InteriorInverseCandidateShapeSeparationNoProductProofStatus
  noTwoSidedInvStatus : InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus
  noInteriorEliminationCertificateStatus :
    InteriorInverseCandidateShapeSeparationNoInteriorEliminationCertificateStatus
  noInteriorEliminationDataStatus : InteriorInverseCandidateShapeSeparationNoInteriorEliminationDataStatus
  noDtnDataStatus : InteriorInverseCandidateShapeSeparationNoDtnDataStatus
  noArithmeticTargetStatus : InteriorInverseCandidateShapeSeparationNoArithmeticTargetStatus
  nextGateStatus : InteriorInverseCandidateShapeSeparationNextGateStatus
  sourceMatrix_eq : sourceMatrix = M
  sourceCandidateEntry_eq : sourceCandidateEntry = M.sourceCandidateEntry
  accumulatedInverseCandidateEntry_eq :
    accumulatedInverseCandidateEntry = M.accumulatedInverseCandidateEntry
  matrix_eq : matrix = M.matrix
  matrixEntryFromInteriorInverseCandidateMatrixMatrix :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = M.matrix i j
  matrixEntry_from_accumulatedEntry :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = accumulatedInverseCandidateEntry.entry i j
  matrixEntry_from_accumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex A,
      matrix i j = generatedInteriorAccumulatedEntryValue T i j
  sourceMatrix_from_accumulatedEntry :
    M.matrix = inverseCandidateMatrix_from_accumulatedEntry M.accumulatedInverseCandidateEntry
  sourceStatusEqInteriorInverseCandidateMatrix :
    M.sourceStatus =
      InteriorInverseCandidateMatrixInverseCandidateMatrixSourceStatus.matrixEntriesFromInteriorTerminalFoldResidualAccumulatedEntry
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :
    accumulatedInverseCandidateEntry.sourceStatus =
      InteriorTerminalFoldResidualAccumulatedSourceStatus.accumulatedEntryFromInteriorAccumulatedTraceEvaluationTraceAndInteriorEliminationTraceLocalSteps
  accumulatedEntry_notOnlyLocalResidualWrapper :
    accumulatedInverseCandidateEntry.notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  shapeSeparationStatus_eq :
    shapeSeparationStatus = InteriorInverseCandidateShapeSeparationShapeSeparationStatus.shapeSeparationFromInteriorInverseCandidateMatrixMatrix
  sourceSeparationStatus_eq :
    sourceSeparationStatus =
      InteriorInverseCandidateShapeSeparationSourceSeparationStatus.sourceSeparatedAsInteriorTerminalFoldResidualAccumulatedEntry
  noInteriorEliminationCandidateEntryCandidateEntryFallbackStatusEq :
    noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryCandidateEntryFallback
  noInteriorBlockFallbackStatus_eq :
    noInteriorBlockFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus.noInteriorBlockFallbackWithoutFutureInvolutiveProof
  involutiveBlockProofGateStatus_eq :
    involutiveBlockProofGateStatus =
      InteriorInverseCandidateShapeSeparationInvolutiveBlockProofGateStatus.involutiveBlockProofDeferredToInteriorTwoSidedInverseValidationProductClosure
  noLocalResidualWrapperFallbackStatus_eq :
    noLocalResidualWrapperFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoLocalResidualWrapperFallbackStatus.noOnlyLocalResidualWrapperFallback
  notOnlyLocalResidualWrapperStatus_eq :
    notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  noFreeTableStatus_eq :
    noFreeTableStatus = InteriorInverseCandidateShapeSeparationNoFreeTableStatus.noFreeMatrixOrEntryTableInShapeSeparation
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorInverseCandidateShapeSeparationNoMatrixInvStatus.noMatrixInvInShapeSeparation
  noExternalInverseOracleStatus_eq :
    noExternalInverseOracleStatus =
      InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noProductProofStatus_eq :
    noProductProofStatus = InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus.noTwoSidedInvInShapeSeparation
  noInteriorEliminationCertificateStatus_eq :
    noInteriorEliminationCertificateStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInShapeSeparation
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationDataStatus.noInteriorEliminationDataInShapeSeparation
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorInverseCandidateShapeSeparationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInShapeSeparation
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorInverseCandidateShapeSeparationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInShapeSeparation
  nextGateStatus_eq :
    nextGateStatus = InteriorInverseCandidateShapeSeparationNextGateStatus.interiorInverseCandidateHandoffHandoffAfterShapeSeparation

namespace GeneratedInteriorInverseCandidateShapeSeparation

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInteriorInverseCandidateMatrixMatrix
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M where
  sourceMatrix := M
  sourceCandidateEntry := M.sourceCandidateEntry
  accumulatedInverseCandidateEntry := M.accumulatedInverseCandidateEntry
  matrix := M.matrix
  shapeSeparationStatus := InteriorInverseCandidateShapeSeparationShapeSeparationStatus.shapeSeparationFromInteriorInverseCandidateMatrixMatrix
  sourceSeparationStatus :=
    InteriorInverseCandidateShapeSeparationSourceSeparationStatus.sourceSeparatedAsInteriorTerminalFoldResidualAccumulatedEntry
  noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus :=
    InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryCandidateEntryFallback
  noInteriorBlockFallbackStatus :=
    InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus.noInteriorBlockFallbackWithoutFutureInvolutiveProof
  involutiveBlockProofGateStatus :=
    InteriorInverseCandidateShapeSeparationInvolutiveBlockProofGateStatus.involutiveBlockProofDeferredToInteriorTwoSidedInverseValidationProductClosure
  noLocalResidualWrapperFallbackStatus :=
    InteriorInverseCandidateShapeSeparationNoLocalResidualWrapperFallbackStatus.noOnlyLocalResidualWrapperFallback
  notOnlyLocalResidualWrapperStatus :=
    M.accumulatedInverseCandidateEntry.notOnlyLocalResidualWrapperStatus
  noFreeTableStatus := InteriorInverseCandidateShapeSeparationNoFreeTableStatus.noFreeMatrixOrEntryTableInShapeSeparation
  noMatrixInvStatus := InteriorInverseCandidateShapeSeparationNoMatrixInvStatus.noMatrixInvInShapeSeparation
  noExternalInverseOracleStatus :=
    InteriorAccumulatedEntryCancellationNoExternalInverseOracleStatus.noExternalInverseOracleForInverseCandidateEntry
  noProductProofStatus := InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation
  noTwoSidedInvStatus := InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus.noTwoSidedInvInShapeSeparation
  noInteriorEliminationCertificateStatus :=
    InteriorInverseCandidateShapeSeparationNoInteriorEliminationCertificateStatus.noInteriorEliminationCertificateInShapeSeparation
  noInteriorEliminationDataStatus :=
    InteriorInverseCandidateShapeSeparationNoInteriorEliminationDataStatus.noInteriorEliminationDataInShapeSeparation
  noDtnDataStatus :=
    InteriorInverseCandidateShapeSeparationNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInShapeSeparation
  noArithmeticTargetStatus :=
    InteriorInverseCandidateShapeSeparationNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInShapeSeparation
  nextGateStatus := InteriorInverseCandidateShapeSeparationNextGateStatus.interiorInverseCandidateHandoffHandoffAfterShapeSeparation
  sourceMatrix_eq := by
    rfl
  sourceCandidateEntry_eq := by
    rfl
  accumulatedInverseCandidateEntry_eq := by
    rfl
  matrix_eq := by
    rfl
  matrixEntryFromInteriorInverseCandidateMatrixMatrix := by
    intro i j
    rfl
  matrixEntry_from_accumulatedEntry := by
    intro i j
    exact M.matrixEntry_from_accumulatedEntry i j
  matrixEntry_from_accumulatedTraceValue := by
    intro i j
    exact M.matrixEntry_from_accumulatedTraceValue i j
  sourceMatrix_from_accumulatedEntry :=
    M.matrix_from_accumulatedEntry
  sourceStatusEqInteriorInverseCandidateMatrix :=
    M.sourceStatus_eq
  accumulatedSourceStatusEqInteriorTerminalFoldResidual :=
    M.accumulatedInverseCandidateEntry.source_is_accumulatedTraceEvaluation
  accumulatedEntry_notOnlyLocalResidualWrapper :=
    M.accumulatedInverseCandidateEntry.notOnlyLocalResidualWrapperStatus_eq
  shapeSeparationStatus_eq := by
    rfl
  sourceSeparationStatus_eq := by
    rfl
  noInteriorEliminationCandidateEntryCandidateEntryFallbackStatusEq := by
    rfl
  noInteriorBlockFallbackStatus_eq := by
    rfl
  involutiveBlockProofGateStatus_eq := by
    rfl
  noLocalResidualWrapperFallbackStatus_eq := by
    rfl
  notOnlyLocalResidualWrapperStatus_eq :=
    M.accumulatedInverseCandidateEntry.notOnlyLocalResidualWrapperStatus_eq
  noFreeTableStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalInverseOracleStatus_eq := by
    rfl
  noProductProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationCertificateStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextGateStatus_eq := by
    rfl

end GeneratedInteriorInverseCandidateShapeSeparation

def inverseCandidateShapeSeparation_from_matrix
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T) :
    GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M :=
  GeneratedInteriorInverseCandidateShapeSeparation.fromInteriorInverseCandidateMatrixMatrix M

theorem inverseCandidateEntryNotInteriorEliminationCandidateEntryCandidateEntry
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryCandidateEntryFallback :=
  S.noInteriorEliminationCandidateEntryCandidateEntryFallbackStatusEq

theorem inverseCandidateEntry_not_interiorBlock_or_involutiveBlockProof
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.noInteriorBlockFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus.noInteriorBlockFallbackWithoutFutureInvolutiveProof :=
  S.noInteriorBlockFallbackStatus_eq

theorem inverseCandidateMatrix_not_interiorBlock_or_involutiveBlockProof
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.involutiveBlockProofGateStatus =
      InteriorInverseCandidateShapeSeparationInvolutiveBlockProofGateStatus.involutiveBlockProofDeferredToInteriorTwoSidedInverseValidationProductClosure :=
  S.involutiveBlockProofGateStatus_eq

theorem inverseCandidateMatrix_not_only_localResidualWrapper
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper :=
  S.notOnlyLocalResidualWrapperStatus_eq

theorem inverseCandidateMatrix_entry_eq_accumulatedTraceValue_afterShapeSeparation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (i j : GeneratedInteriorIndex A) :
    S.matrix i j = generatedInteriorAccumulatedEntryValue T i j :=
  S.matrixEntry_from_accumulatedTraceValue i j

theorem noProductProof_for_shapeSeparation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.noProductProofStatus = InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation :=
  S.noProductProofStatus_eq

theorem noTwoSidedInv_for_shapeSeparation
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M) :
    S.noTwoSidedInvStatus = InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus.noTwoSidedInvInShapeSeparation :=
  S.noTwoSidedInvStatus_eq

def regularGeneratedInteriorInverseCandidateShapeSeparation
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateShapeSeparation
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) wp
      (regularGeneratedWeightPolicyEntrySource b p wp)
      (regularGeneratedInteriorEliminationCandidateEntry b p wp)
      (regularGeneratedInteriorEliminationCarrier b p wp)
      (regularGeneratedInteriorEliminationTrace b p wp)
      (regularGeneratedInteriorInverseCandidateMatrix b p wp) :=
  inverseCandidateShapeSeparation_from_matrix
    (regularGeneratedInteriorInverseCandidateMatrix b p wp)

def variableGeneratedInteriorInverseCandidateShapeSeparation
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    GeneratedInteriorInverseCandidateShapeSeparation
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) wp
      (variableGeneratedWeightPolicyEntrySource β p wp)
      (variableGeneratedInteriorEliminationCandidateEntry β p wp)
      (variableGeneratedInteriorEliminationCarrier β p wp)
      (variableGeneratedInteriorEliminationTrace β p wp)
      (variableGeneratedInteriorInverseCandidateMatrix β p wp) :=
  inverseCandidateShapeSeparation_from_matrix
    (variableGeneratedInteriorInverseCandidateMatrix β p wp)

structure InteriorInverseCandidateShapeSeparationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) where
  status : InteriorInverseCandidateShapeSeparationLedgerStatus
  interiorInverseCandidateMatrixLedger :
    InteriorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularShapeSeparation :
    GeneratedInteriorInverseCandidateShapeSeparation
      (ConcreteSubstrate.RegularCell b) p
      (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
  variableShapeSeparation :
    GeneratedInteriorInverseCandidateShapeSeparation
      (LevelVariableSubstrate.LevelVariableCell β) p
      (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
  interiorInverseCandidateMatrixLedger_eq_main :
    interiorInverseCandidateMatrixLedger =
      interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
        b β p regularWeight variableWeight regularPivot variablePivot
  regularMatrixEntryFromAccumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p),
      regularShapeSeparation.matrix i j =
        generatedInteriorAccumulatedEntryValue
          (regularGeneratedInteriorEliminationTrace b p regularWeight) i j
  variableMatrixEntryFromAccumulatedTraceValue :
    ∀ i j : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p),
      variableShapeSeparation.matrix i j =
        generatedInteriorAccumulatedEntryValue
          (variableGeneratedInteriorEliminationTrace β p variableWeight) i j
  regularNotInteriorEliminationCandidateEntryFallback :
    regularShapeSeparation.noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryCandidateEntryFallback
  variableNotInteriorEliminationCandidateEntryFallback :
    variableShapeSeparation.noInteriorEliminationCandidateEntryCandidateEntryFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorEliminationCandidateEntryCandidateEntryFallbackStatus.noInteriorEliminationCandidateEntryCandidateEntryFallback
  regularNoInteriorBlockFallbackWithoutFutureInvolutiveProof :
    regularShapeSeparation.noInteriorBlockFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus.noInteriorBlockFallbackWithoutFutureInvolutiveProof
  variableNoInteriorBlockFallbackWithoutFutureInvolutiveProof :
    variableShapeSeparation.noInteriorBlockFallbackStatus =
      InteriorInverseCandidateShapeSeparationNoInteriorBlockFallbackStatus.noInteriorBlockFallbackWithoutFutureInvolutiveProof
  regularNoOnlyLocalResidualWrapperFallback :
    regularShapeSeparation.notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  variableNoOnlyLocalResidualWrapperFallback :
    variableShapeSeparation.notOnlyLocalResidualWrapperStatus =
      InteriorTerminalFoldResidualNotOnlyLocalResidualWrapperStatus.notOnlyLocalResidualWrapper
  regularNoProductProof :
    regularShapeSeparation.noProductProofStatus =
      InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation
  variableNoProductProof :
    variableShapeSeparation.noProductProofStatus =
      InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation
  regularNoTwoSidedInv :
    regularShapeSeparation.noTwoSidedInvStatus =
      InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus.noTwoSidedInvInShapeSeparation
  variableNoTwoSidedInv :
    variableShapeSeparation.noTwoSidedInvStatus =
      InteriorInverseCandidateShapeSeparationNoTwoSidedInvStatus.noTwoSidedInvInShapeSeparation
  regularNextGate :
    regularShapeSeparation.nextGateStatus =
      InteriorInverseCandidateShapeSeparationNextGateStatus.interiorInverseCandidateHandoffHandoffAfterShapeSeparation
  variableNextGate :
    variableShapeSeparation.nextGateStatus =
      InteriorInverseCandidateShapeSeparationNextGateStatus.interiorInverseCandidateHandoffHandoffAfterShapeSeparation
  status_eq_closed :
    status = InteriorInverseCandidateShapeSeparationLedgerStatus.shapeSeparationClosedAfterPositiveMatrixExport

def interiorInverseCandidateShapeSeparationLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    InteriorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot where
  status := InteriorInverseCandidateShapeSeparationLedgerStatus.shapeSeparationClosedAfterPositiveMatrixExport
  interiorInverseCandidateMatrixLedger :=
    interiorInverseCandidateMatrixGeneratedInteriorInverseCandidateMatrixLedger
      b β p regularWeight variableWeight regularPivot variablePivot
  regularShapeSeparation :=
    regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight
  variableShapeSeparation :=
    variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight
  interiorInverseCandidateMatrixLedger_eq_main := by
    rfl
  regularMatrixEntryFromAccumulatedTraceValue := by
    intro i j
    exact
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight).matrixEntry_from_accumulatedTraceValue i j
  variableMatrixEntryFromAccumulatedTraceValue := by
    intro i j
    exact
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight).matrixEntry_from_accumulatedTraceValue i j
  regularNotInteriorEliminationCandidateEntryFallback :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).noInteriorEliminationCandidateEntryCandidateEntryFallbackStatusEq
  variableNotInteriorEliminationCandidateEntryFallback :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).noInteriorEliminationCandidateEntryCandidateEntryFallbackStatusEq
  regularNoInteriorBlockFallbackWithoutFutureInvolutiveProof :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).noInteriorBlockFallbackStatus_eq
  variableNoInteriorBlockFallbackWithoutFutureInvolutiveProof :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).noInteriorBlockFallbackStatus_eq
  regularNoOnlyLocalResidualWrapperFallback :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).notOnlyLocalResidualWrapperStatus_eq
  variableNoOnlyLocalResidualWrapperFallback :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).notOnlyLocalResidualWrapperStatus_eq
  regularNoProductProof :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).noProductProofStatus_eq
  variableNoProductProof :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).noProductProofStatus_eq
  regularNoTwoSidedInv :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).noTwoSidedInvStatus_eq
  variableNoTwoSidedInv :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).noTwoSidedInvStatus_eq
  regularNextGate :=
    (regularGeneratedInteriorInverseCandidateShapeSeparation
      b p regularWeight).nextGateStatus_eq
  variableNextGate :=
    (variableGeneratedInteriorInverseCandidateShapeSeparation
      β p variableWeight).nextGateStatus_eq
  status_eq_closed := by
    rfl

theorem interiorInverseCandidateShapeSeparationLedger_status
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot).status =
      InteriorInverseCandidateShapeSeparationLedgerStatus.shapeSeparationClosedAfterPositiveMatrixExport := by
  rfl

theorem interiorInverseCandidateShapeSeparationLedger_regularNextGate
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularShapeSeparation.nextGateStatus =
      InteriorInverseCandidateShapeSeparationNextGateStatus.interiorInverseCandidateHandoffHandoffAfterShapeSeparation := by
  rfl

theorem interiorInverseCandidateShapeSeparationLedger_regularNoProductProof
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy)
    (regularPivot : GeneratedInteriorIndex (regularGeneratedApproximantStrong b p))
    (variablePivot : GeneratedInteriorIndex (variableGeneratedApproximantStrong β p)) :
    (interiorInverseCandidateShapeSeparationLedger
      b β p regularWeight variableWeight regularPivot variablePivot).regularShapeSeparation.noProductProofStatus =
      InteriorInverseCandidateShapeSeparationNoProductProofStatus.noProductProofInShapeSeparation := by
  rfl


end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
