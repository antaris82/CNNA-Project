import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
import CNNA.PillarA.Generator.Core.SourceAndApproximation.DegreePivotScaleSource
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreeFormulaFromWeightPolicy
import CNNA.PillarA.Generator.Operational.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy

set_option autoImplicit false
open scoped BigOperators

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy

universe u

inductive OperationalDegreeReciprocalSourceOperationalDegreeReciprocalDatumStatus where
  | operationalDegreeReciprocalDatumProvided
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceWeightPolicyDegreeFormulaStatus where
  | weightPolicyDegreeFormulaCarriedFromGeneratedDegreeFormula
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceReciprocalProfileStatus where
  | reciprocalProfileBuiltFromOperationalDegreeSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceTracePivotScaleWitnessStatus where
  | tracePivotScaleWitnessExportedThroughDegreePivotScaleSourceInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoScalarInvStatus where
  | noScalarInvInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoMatrixInvStatus where
  | noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus where
  | noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoFreeScaleTableStatus where
  | noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoProductIdentityProofStatus where
  | noProductIdentityProofInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoTwoSidedInvStatus where
  | noTwoSidedInvInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus where
  | noInteriorEliminationDataInGeneratedOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInOperationalDegreeReciprocalSource
  deriving DecidableEq, Repr

inductive OperationalDegreeReciprocalSourceNextConsumerStatus where
  | interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  deriving DecidableEq, Repr

structure GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  generatedDegreeFormulaAttempt :
    GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T
  degreePivotScale : GeneratedInteriorIndex A → ℝ
  datumStatus : OperationalDegreeReciprocalSourceOperationalDegreeReciprocalDatumStatus
  weightPolicyDegreeFormulaStatus : OperationalDegreeReciprocalSourceWeightPolicyDegreeFormulaStatus
  noScalarInvStatus : OperationalDegreeReciprocalSourceNoScalarInvStatus
  noMatrixInvStatus : OperationalDegreeReciprocalSourceNoMatrixInvStatus
  noExternalScaleOracleStatus : OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus
  noFreeScaleTableStatus : OperationalDegreeReciprocalSourceNoFreeScaleTableStatus
  degree_eq_inputPolicyAdjacencyWeight_sum :
    ∀ i : GeneratedApproximantIndex A,
      generatedDirichlet_degree W i =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent i j then wp.constantWeight i j else 0
  pivotEntry_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        ∑ j : GeneratedApproximantIndex A,
          if generatedAdjacent
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j then
            wp.constantWeight
              (GeneratedInteriorIndex.toApproximantIndex
                (T.localStepOf pivot).pivotDatum.pivotIndex)
              j
          else 0
  degreePivotScale_mul_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      degreePivotScale pivot *
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) = 1
  generatedDegree_mul_degreePivotScale :
    ∀ pivot : GeneratedInteriorIndex A,
      generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) *
          degreePivotScale pivot = 1
  generatedDegreeFormula_profileConstructionStatus_eq :
    generatedDegreeFormulaAttempt.profileConstructionStatus =
      GeneratedDegreeFormulaProfileConstructionStatus.generatedDegreePivotReciprocalProfileNotConstructedFromCurrentWeightPolicySumAPI
  generatedDegreeFormula_nextConsumerStatus_eq :
    generatedDegreeFormulaAttempt.nextConsumerStatus =
      GeneratedDegreeFormulaNextConsumerStatus.generatedOperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSource
  datumStatus_eq :
    datumStatus =
      OperationalDegreeReciprocalSourceOperationalDegreeReciprocalDatumStatus.operationalDegreeReciprocalDatumProvided
  weightPolicyDegreeFormulaStatus_eq :
    weightPolicyDegreeFormulaStatus =
      OperationalDegreeReciprocalSourceWeightPolicyDegreeFormulaStatus.weightPolicyDegreeFormulaCarriedFromGeneratedDegreeFormula
  noScalarInvStatus_eq :
    noScalarInvStatus =
      OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  noFreeScaleTableStatus_eq :
    noFreeScaleTableStatus =
      OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource

namespace GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromGeneratedDegreeFormulaAttempt
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T)
    (degreePivotScale : GeneratedInteriorIndex A → ℝ)
    (hLeftDegree : ∀ pivot : GeneratedInteriorIndex A,
      degreePivotScale pivot *
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) = 1)
    (hRightDegree : ∀ pivot : GeneratedInteriorIndex A,
      generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) *
          degreePivotScale pivot = 1) :
    GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T where
  generatedDegreeFormulaAttempt := D
  degreePivotScale := degreePivotScale
  datumStatus :=
    OperationalDegreeReciprocalSourceOperationalDegreeReciprocalDatumStatus.operationalDegreeReciprocalDatumProvided
  weightPolicyDegreeFormulaStatus :=
    OperationalDegreeReciprocalSourceWeightPolicyDegreeFormulaStatus.weightPolicyDegreeFormulaCarriedFromGeneratedDegreeFormula
  noScalarInvStatus :=
    OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  noMatrixInvStatus :=
    OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  noExternalScaleOracleStatus :=
    OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  noFreeScaleTableStatus :=
    OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  degree_eq_inputPolicyAdjacencyWeight_sum := by
    intro i
    exact D.degree_eq_inputPolicyAdjacencyWeight_sum i
  pivotEntry_eq_generatedDegree := by
    intro pivot
    exact D.pivotEntry_eq_generatedDegree pivot
  pivotEntry_eq_inputPolicyAdjacencyWeight_sum := by
    intro pivot
    exact D.pivotEntry_eq_inputPolicyAdjacencyWeight_sum pivot
  degreePivotScale_mul_generatedDegree := hLeftDegree
  generatedDegree_mul_degreePivotScale := hRightDegree
  generatedDegreeFormula_profileConstructionStatus_eq := D.profileConstructionStatus_eq
  generatedDegreeFormula_nextConsumerStatus_eq := D.nextConsumerStatus_eq
  datumStatus_eq := by
    rfl
  weightPolicyDegreeFormulaStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noFreeScaleTableStatus_eq := by
    rfl

theorem leftGeneratedDegreeEquation
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    O.degreePivotScale pivot *
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex) = 1 :=
  O.degreePivotScale_mul_generatedDegree pivot

theorem rightGeneratedDegreeEquation
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex) *
        O.degreePivotScale pivot = 1 :=
  O.generatedDegree_mul_degreePivotScale pivot

theorem pivotEntry_eq_generatedDegree_of
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      generatedDirichlet_degree W
        (GeneratedInteriorIndex.toApproximantIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex) :=
  O.pivotEntry_eq_generatedDegree pivot

theorem weightPolicyDegreeFormula_of
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (i : GeneratedApproximantIndex A) :
    generatedDirichlet_degree W i =
      ∑ j : GeneratedApproximantIndex A,
        if generatedAdjacent i j then wp.constantWeight i j else 0 :=
  O.degree_eq_inputPolicyAdjacencyWeight_sum i

end GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource

def generatedDegreePivotReciprocalProfileFromOperationalDatumOperationalDegreeReciprocalSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T :=
  GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource.fromGeneratedDegreeReciprocalProfile
    O.generatedDegreeFormulaAttempt.audit.requirement
    O.degreePivotScale
    O.degreePivotScale_mul_generatedDegree
    O.generatedDegree_mul_degreePivotScale

structure GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  operationalDatum : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T
  reciprocalProfile : GeneratedDegreePivotReciprocalProfileDegreePivotScaleSource Cell p A P wp W E K T
  generatedDegreePivotScaleScaleSource : GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource Cell p A P wp W E K T
  tracePivotScaleWitness : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T
  reciprocalProfileStatus : OperationalDegreeReciprocalSourceReciprocalProfileStatus
  tracePivotScaleWitnessStatus : OperationalDegreeReciprocalSourceTracePivotScaleWitnessStatus
  noScalarInvStatus : OperationalDegreeReciprocalSourceNoScalarInvStatus
  noMatrixInvStatus : OperationalDegreeReciprocalSourceNoMatrixInvStatus
  noExternalScaleOracleStatus : OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus
  noFreeScaleTableStatus : OperationalDegreeReciprocalSourceNoFreeScaleTableStatus
  noProductIdentityProofStatus : OperationalDegreeReciprocalSourceNoProductIdentityProofStatus
  noTwoSidedInvStatus : OperationalDegreeReciprocalSourceNoTwoSidedInvStatus
  noInteriorEliminationDataStatus : OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus
  noDtnDataStatus : OperationalDegreeReciprocalSourceNoDtnDataStatus
  noArithmeticTargetStatus : OperationalDegreeReciprocalSourceNoArithmeticTargetStatus
  nextConsumerStatus : OperationalDegreeReciprocalSourceNextConsumerStatus
  reciprocalProfile_eq_from_operationalDatum :
    reciprocalProfile =
      generatedDegreePivotReciprocalProfileFromOperationalDatumOperationalDegreeReciprocalSource operationalDatum
  generatedDegreePivotScaleScaleSource_eq_from_reciprocalProfile :
    generatedDegreePivotScaleScaleSource =
      GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.fromReciprocalProfile
        reciprocalProfile
  tracePivotScaleWitness_eq_from_generatedDegreePivotScaleScaleSource :
    tracePivotScaleWitness =
      tracePivotScaleWitnessFromGeneratedDegreePivotScaleSourceDegreePivotScaleSource generatedDegreePivotScaleScaleSource
  reciprocalProfileStatus_eq :
    reciprocalProfileStatus =
      OperationalDegreeReciprocalSourceReciprocalProfileStatus.reciprocalProfileBuiltFromOperationalDegreeSource
  tracePivotScaleWitnessStatus_eq :
    tracePivotScaleWitnessStatus =
      OperationalDegreeReciprocalSourceTracePivotScaleWitnessStatus.tracePivotScaleWitnessExportedThroughDegreePivotScaleSourceInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
  noScalarInvStatus_eq :
    noScalarInvStatus =
      OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  noFreeScaleTableStatus_eq :
    noFreeScaleTableStatus =
      OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      OperationalDegreeReciprocalSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedOperationalDegreeReciprocalSource
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      OperationalDegreeReciprocalSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedOperationalDegreeReciprocalSource
  noInteriorEliminationDataStatus_eq :
    noInteriorEliminationDataStatus =
      OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInGeneratedOperationalDegreeReciprocalSource
  noDtnDataStatus_eq :
    noDtnDataStatus =
      OperationalDegreeReciprocalSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInOperationalDegreeReciprocalSource
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      OperationalDegreeReciprocalSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInOperationalDegreeReciprocalSource
  nextConsumerStatus_eq :
    nextConsumerStatus =
      OperationalDegreeReciprocalSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge

namespace GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromOperationalDatum
    (O : GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T where
  operationalDatum := O
  reciprocalProfile := generatedDegreePivotReciprocalProfileFromOperationalDatumOperationalDegreeReciprocalSource O
  generatedDegreePivotScaleScaleSource :=
    GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.fromReciprocalProfile
      (generatedDegreePivotReciprocalProfileFromOperationalDatumOperationalDegreeReciprocalSource O)
  tracePivotScaleWitness :=
    tracePivotScaleWitnessFromGeneratedDegreePivotScaleSourceDegreePivotScaleSource
      (GeneratedInteriorGeneratedDegreePivotScaleSourceDegreePivotScaleSource.fromReciprocalProfile
        (generatedDegreePivotReciprocalProfileFromOperationalDatumOperationalDegreeReciprocalSource O))
  reciprocalProfileStatus :=
    OperationalDegreeReciprocalSourceReciprocalProfileStatus.reciprocalProfileBuiltFromOperationalDegreeSource
  tracePivotScaleWitnessStatus :=
    OperationalDegreeReciprocalSourceTracePivotScaleWitnessStatus.tracePivotScaleWitnessExportedThroughDegreePivotScaleSourceInteriorTracePivotScaleWitnessInteriorTracePivotRegularity
  noScalarInvStatus :=
    OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  noMatrixInvStatus :=
    OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  noExternalScaleOracleStatus :=
    OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  noFreeScaleTableStatus :=
    OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  noProductIdentityProofStatus :=
    OperationalDegreeReciprocalSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedOperationalDegreeReciprocalSource
  noTwoSidedInvStatus :=
    OperationalDegreeReciprocalSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedOperationalDegreeReciprocalSource
  noInteriorEliminationDataStatus :=
    OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInGeneratedOperationalDegreeReciprocalSource
  noDtnDataStatus := OperationalDegreeReciprocalSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInOperationalDegreeReciprocalSource
  noArithmeticTargetStatus :=
    OperationalDegreeReciprocalSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInOperationalDegreeReciprocalSource
  nextConsumerStatus := OperationalDegreeReciprocalSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  reciprocalProfile_eq_from_operationalDatum := by
    rfl
  generatedDegreePivotScaleScaleSource_eq_from_reciprocalProfile := by
    rfl
  tracePivotScaleWitness_eq_from_generatedDegreePivotScaleScaleSource := by
    rfl
  reciprocalProfileStatus_eq := by
    rfl
  tracePivotScaleWitnessStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noFreeScaleTableStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noInteriorEliminationDataStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem leftScaleEquation
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    S.generatedDegreePivotScaleScaleSource.interiorTracePivotScaleScaleSource.pivotScale pivot *
        (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  S.generatedDegreePivotScaleScaleSource.interiorTracePivotScaleScaleSource.pivotScale_mul_pivotEntry pivot

theorem rightScaleEquation
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry *
        S.generatedDegreePivotScaleScaleSource.interiorTracePivotScaleScaleSource.pivotScale pivot = 1 :=
  S.generatedDegreePivotScaleScaleSource.interiorTracePivotScaleScaleSource.pivotEntry_mul_pivotScale pivot

theorem nextClosureIsInteriorBlockFoldKernelResidualBridge
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    S.nextConsumerStatus =
      OperationalDegreeReciprocalSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge :=
  S.nextConsumerStatus_eq

end GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource

def generatedOperationalDegreeReciprocalSource_from_weightPolicy
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (D : GeneratedDegreePivotReciprocalProfileFromWeightPolicyGeneratedDegreeFormula Cell p A P wp W E K T)
    (degreePivotScale : GeneratedInteriorIndex A → ℝ)
    (hLeftDegree : ∀ pivot : GeneratedInteriorIndex A,
      degreePivotScale pivot *
          generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) = 1)
    (hRightDegree : ∀ pivot : GeneratedInteriorIndex A,
      generatedDirichlet_degree W
            (GeneratedInteriorIndex.toApproximantIndex
              (T.localStepOf pivot).pivotDatum.pivotIndex) *
          degreePivotScale pivot = 1) :
    GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T :=
  GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource.fromOperationalDatum
    (GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource.fromGeneratedDegreeFormulaAttempt
      D degreePivotScale hLeftDegree hRightDegree)

def tracePivotScaleWitnessFromGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T :=
  S.tracePivotScaleWitness

abbrev RegularGeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedOperationalDegreeReciprocalDatumOperationalDegreeReciprocalSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

structure OperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSourceLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularSource : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p regularWeight
  variableSource : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p variableWeight
  regularNoScalarInvStatus_eq :
    regularSource.noScalarInvStatus =
      OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  variableNoScalarInvStatus_eq :
    variableSource.noScalarInvStatus =
      OperationalDegreeReciprocalSourceNoScalarInvStatus.noScalarInvInGeneratedOperationalDegreeReciprocalSource
  regularNoMatrixInvStatus_eq :
    regularSource.noMatrixInvStatus =
      OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  variableNoMatrixInvStatus_eq :
    variableSource.noMatrixInvStatus =
      OperationalDegreeReciprocalSourceNoMatrixInvStatus.noMatrixInvInGeneratedOperationalDegreeReciprocalSource
  regularNoExternalScaleOracleStatus_eq :
    regularSource.noExternalScaleOracleStatus =
      OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  variableNoExternalScaleOracleStatus_eq :
    variableSource.noExternalScaleOracleStatus =
      OperationalDegreeReciprocalSourceNoExternalScaleOracleStatus.noExternalScaleOracleInGeneratedOperationalDegreeReciprocalSource
  regularNoFreeScaleTableStatus_eq :
    regularSource.noFreeScaleTableStatus =
      OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  variableNoFreeScaleTableStatus_eq :
    variableSource.noFreeScaleTableStatus =
      OperationalDegreeReciprocalSourceNoFreeScaleTableStatus.noFreeScaleTableInGeneratedOperationalDegreeReciprocalSource
  regularNoProductIdentityProofStatus_eq :
    regularSource.noProductIdentityProofStatus =
      OperationalDegreeReciprocalSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedOperationalDegreeReciprocalSource
  variableNoProductIdentityProofStatus_eq :
    variableSource.noProductIdentityProofStatus =
      OperationalDegreeReciprocalSourceNoProductIdentityProofStatus.noProductIdentityProofInGeneratedOperationalDegreeReciprocalSource
  regularNoTwoSidedInvStatus_eq :
    regularSource.noTwoSidedInvStatus =
      OperationalDegreeReciprocalSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedOperationalDegreeReciprocalSource
  variableNoTwoSidedInvStatus_eq :
    variableSource.noTwoSidedInvStatus =
      OperationalDegreeReciprocalSourceNoTwoSidedInvStatus.noTwoSidedInvInGeneratedOperationalDegreeReciprocalSource
  regularNoInteriorEliminationDataStatus_eq :
    regularSource.noInteriorEliminationDataStatus =
      OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInGeneratedOperationalDegreeReciprocalSource
  variableNoInteriorEliminationDataStatus_eq :
    variableSource.noInteriorEliminationDataStatus =
      OperationalDegreeReciprocalSourceNoInteriorEliminationDataStatus.noInteriorEliminationDataInGeneratedOperationalDegreeReciprocalSource
  regularNoDtnDataStatus_eq :
    regularSource.noDtnDataStatus =
      OperationalDegreeReciprocalSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInOperationalDegreeReciprocalSource
  variableNoDtnDataStatus_eq :
    variableSource.noDtnDataStatus =
      OperationalDegreeReciprocalSourceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInOperationalDegreeReciprocalSource
  regularNoArithmeticTargetStatus_eq :
    regularSource.noArithmeticTargetStatus =
      OperationalDegreeReciprocalSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInOperationalDegreeReciprocalSource
  variableNoArithmeticTargetStatus_eq :
    variableSource.noArithmeticTargetStatus =
      OperationalDegreeReciprocalSourceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInOperationalDegreeReciprocalSource
  regularNextConsumerStatus_eq :
    regularSource.nextConsumerStatus =
      OperationalDegreeReciprocalSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  variableNextConsumerStatus_eq :
    variableSource.nextConsumerStatus =
      OperationalDegreeReciprocalSourceNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge

namespace OperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSourceLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularSource : RegularGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource b p regularWeight)
    (variableSource : VariableGeneratedOperationalDegreeReciprocalSourceOperationalDegreeReciprocalSource β p variableWeight) :
    OperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSourceLedger b β p regularWeight variableWeight where
  regularSource := regularSource
  variableSource := variableSource
  regularNoScalarInvStatus_eq := regularSource.noScalarInvStatus_eq
  variableNoScalarInvStatus_eq := variableSource.noScalarInvStatus_eq
  regularNoMatrixInvStatus_eq := regularSource.noMatrixInvStatus_eq
  variableNoMatrixInvStatus_eq := variableSource.noMatrixInvStatus_eq
  regularNoExternalScaleOracleStatus_eq := regularSource.noExternalScaleOracleStatus_eq
  variableNoExternalScaleOracleStatus_eq := variableSource.noExternalScaleOracleStatus_eq
  regularNoFreeScaleTableStatus_eq := regularSource.noFreeScaleTableStatus_eq
  variableNoFreeScaleTableStatus_eq := variableSource.noFreeScaleTableStatus_eq
  regularNoProductIdentityProofStatus_eq := regularSource.noProductIdentityProofStatus_eq
  variableNoProductIdentityProofStatus_eq := variableSource.noProductIdentityProofStatus_eq
  regularNoTwoSidedInvStatus_eq := regularSource.noTwoSidedInvStatus_eq
  variableNoTwoSidedInvStatus_eq := variableSource.noTwoSidedInvStatus_eq
  regularNoInteriorEliminationDataStatus_eq := regularSource.noInteriorEliminationDataStatus_eq
  variableNoInteriorEliminationDataStatus_eq := variableSource.noInteriorEliminationDataStatus_eq
  regularNoDtnDataStatus_eq := regularSource.noDtnDataStatus_eq
  variableNoDtnDataStatus_eq := variableSource.noDtnDataStatus_eq
  regularNoArithmeticTargetStatus_eq := regularSource.noArithmeticTargetStatus_eq
  variableNoArithmeticTargetStatus_eq := variableSource.noArithmeticTargetStatus_eq
  regularNextConsumerStatus_eq := regularSource.nextConsumerStatus_eq
  variableNextConsumerStatus_eq := variableSource.nextConsumerStatus_eq

end OperationalDegreeReciprocalSourceGeneratedOperationalDegreeReciprocalSourceLedger

end CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
