import CNNA.PillarA.Generator.OutputProfile

set_option autoImplicit false

namespace CNNA.PillarA.Generator

abbrev MultiSchurOutputProfile :=
  GeneratorOutputKindProfile DerivedOutputKind.multiSchur

def multiSchurOutputKind : DerivedOutputKind :=
  DerivedOutputKind.multiSchur

theorem multiSchur_kind_eq (profile : MultiSchurOutputProfile) :
    profile.profile.kind = multiSchurOutputKind :=
  profile.kind_matches

end CNNA.PillarA.Generator
