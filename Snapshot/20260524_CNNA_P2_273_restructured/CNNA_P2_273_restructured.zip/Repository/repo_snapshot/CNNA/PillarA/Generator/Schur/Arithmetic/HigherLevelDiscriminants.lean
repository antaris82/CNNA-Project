import CNNA.PillarA.Generator.Schur.Arithmetic.HigherLevelOutcomeRouter

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

namespace Schur

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}
variable {source : ArithmeticSource Cell T} {L : Nat}

inductive HigherLevelDiscriminantSearchStatus where
  | quadraticOrderDiscriminantSearchClosedByCertificate
  deriving DecidableEq, Repr

inductive HigherLevelFormalOutputStatus where
  | theoremCertificateOrExplicitObservationOnly
  deriving DecidableEq, Repr

inductive HigherLevelUncertifiedNumericsStatus where
  | uncertifiedNumericsExcludedFromFormalPath
  deriving DecidableEq, Repr

structure HigherLevelDiscriminantSearchLedger
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : SpectralParameter) where
  outcomeRoute : HigherLevelOutcomeRoute B b hL z
  outcome : HigherLevelQuadraticOrderNormCertificateOutcome
  outcome_eq_route : outcome = outcomeRoute.outcome
  searchStatus : HigherLevelDiscriminantSearchStatus
  searchStatus_eq :
    searchStatus =
      HigherLevelDiscriminantSearchStatus.quadraticOrderDiscriminantSearchClosedByCertificate
  formalOutputStatus : HigherLevelFormalOutputStatus
  formalOutputStatus_eq :
    formalOutputStatus = HigherLevelFormalOutputStatus.theoremCertificateOrExplicitObservationOnly
  uncertifiedNumericsStatus : HigherLevelUncertifiedNumericsStatus
  uncertifiedNumericsStatus_eq :
    uncertifiedNumericsStatus =
      HigherLevelUncertifiedNumericsStatus.uncertifiedNumericsExcludedFromFormalPath
  levelGreaterThanThree : 3 < L
  route : B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory
  noCutSpecCarrierClaim :
    ∀ _k : BoundarySource.LevelHistoryIndex L,
      source.toc.approximant source.concretePolicy = T

namespace HigherLevelDiscriminantSearchLedger

variable {B : BoundarySource.BoundarySourceSurface source L}
variable {b : Nat} {hL : 3 < L} {z : SpectralParameter}

def fromCertificate
    (C : HigherLevelQuadraticOrderNormCertificateCertificate B b hL z) :
    HigherLevelDiscriminantSearchLedger B b hL z :=
  let R := HigherLevelOutcomeRoute.fromCertificate C
  {
    outcomeRoute := R
    outcome := R.outcome
    outcome_eq_route := by
      rfl
    searchStatus := HigherLevelDiscriminantSearchStatus.quadraticOrderDiscriminantSearchClosedByCertificate
    searchStatus_eq := by
      rfl
    formalOutputStatus := HigherLevelFormalOutputStatus.theoremCertificateOrExplicitObservationOnly
    formalOutputStatus_eq := by
      rfl
    uncertifiedNumericsStatus :=
      HigherLevelUncertifiedNumericsStatus.uncertifiedNumericsExcludedFromFormalPath
    uncertifiedNumericsStatus_eq := by
      rfl
    levelGreaterThanThree := R.levelGreaterThanThree
    route := R.route
    noCutSpecCarrierClaim := R.noCutSpecCarrierClaim
  }

theorem search_status_closed
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z) :
    Ldg.searchStatus =
      HigherLevelDiscriminantSearchStatus.quadraticOrderDiscriminantSearchClosedByCertificate :=
  Ldg.searchStatus_eq

theorem formal_output_status
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z) :
    Ldg.formalOutputStatus = HigherLevelFormalOutputStatus.theoremCertificateOrExplicitObservationOnly :=
  Ldg.formalOutputStatus_eq

theorem uncertified_numerics_excluded
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z) :
    Ldg.uncertifiedNumericsStatus =
      HigherLevelUncertifiedNumericsStatus.uncertifiedNumericsExcludedFromFormalPath :=
  Ldg.uncertifiedNumericsStatus_eq

theorem outcome_three_way
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z) :
    Ldg.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      Ldg.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        Ldg.outcome = HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree := by
  have hR := HigherLevelOutcomeRoute.outcome_three_way Ldg.outcomeRoute
  cases hR with
  | inl h =>
      exact Or.inl (Eq.trans Ldg.outcome_eq_route h)
  | inr hRest =>
      cases hRest with
      | inl h =>
          exact Or.inr (Or.inl (Eq.trans Ldg.outcome_eq_route h))
      | inr h =>
          exact Or.inr (Or.inr (Eq.trans Ldg.outcome_eq_route h))

theorem route_recursiveHistory
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z) :
    B.interface.route = BoundarySource.BoundarySourceRoute.recursiveHistory :=
  Ldg.route

theorem noCutSpecCarrierClaim_at
    (Ldg : HigherLevelDiscriminantSearchLedger B b hL z)
    (k : BoundarySource.LevelHistoryIndex L) :
    source.toc.approximant source.concretePolicy = T :=
  Ldg.noCutSpecCarrierClaim k

end HigherLevelDiscriminantSearchLedger

end Schur

namespace StrengtheningQuadraticOrderNormCertificate

abbrev QuadraticOrderNormCertificateDiscriminantSearchStatus := Schur.HigherLevelDiscriminantSearchStatus
abbrev QuadraticOrderNormCertificateFormalOutputStatus := Schur.HigherLevelFormalOutputStatus
abbrev QuadraticOrderNormCertificateUncertifiedNumericsStatus := Schur.HigherLevelUncertifiedNumericsStatus

abbrev QuadraticOrderNormCertificateDiscriminantSearchLedger
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    (B : BoundarySource.BoundarySourceSurface source L)
    (b : Nat) (hL : 3 < L)
    (z : Schur.SpectralParameter) :=
  Schur.HigherLevelDiscriminantSearchLedger B b hL z

def QuadraticOrderNormCertificateDiscriminantSearchLedgerFromCertificate
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (C : Schur.HigherLevelQuadraticOrderNormCertificateCertificate B b hL z) :
    QuadraticOrderNormCertificateDiscriminantSearchLedger B b hL z :=
  Schur.HigherLevelDiscriminantSearchLedger.fromCertificate C

theorem QuadraticOrderNormCertificateDiscriminantSearchLedgerOutcomeThreeWay
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L} {z : Schur.SpectralParameter}
    (Ldg : QuadraticOrderNormCertificateDiscriminantSearchLedger B b hL z) :
    Ldg.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticHeegnerHit ∨
      Ldg.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.quadraticNonHeegner ∨
        Ldg.outcome = Schur.HigherLevelQuadraticOrderNormCertificateOutcome.irreducibleOrHigherDegree :=
  Schur.HigherLevelDiscriminantSearchLedger.outcome_three_way Ldg

end StrengtheningQuadraticOrderNormCertificate

end CNNA.PillarA.Arithmetic
