import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation

universe u

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantSourceAuditStatus where
  | localStepSchurCancellationSourceAuditFromInteriorEliminationTraceAndInteriorBlockFoldNormalForm
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantPositiveSourceStatus where
  | baseRowColumnAndPivotEntriesExposedFromInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus where
  | missingPivotScaleInCurrentInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus where
  | missingUpdatedEntryInCurrentInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus where
  | missingUpdatedEntryEqSchurInCurrentInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingLeftLocalCancellationStatus where
  | missingLeftLocalStepCancellationInCurrentInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingRightLocalCancellationStatus where
  | missingRightLocalStepCancellationInCurrentInteriorEliminationTrace
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus where
  | interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant
  deriving DecidableEq, Repr

inductive InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNoIdentityStatus where
  | noBlockFoldIdentityInInteriorLocalStepCancellationInvariant
  deriving DecidableEq, Repr

structure GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  blockFoldNormalForm : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T
  sourceAuditStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantSourceAuditStatus
  positiveSourceStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantPositiveSourceStatus
  missingPivotScaleStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus
  missingUpdatedEntryStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus
  missingSchurUpdateEquationStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus
  missingLeftLocalCancellationStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingLeftLocalCancellationStatus
  missingRightLocalCancellationStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingRightLocalCancellationStatus
  noIdentityStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNoIdentityStatus
  noMatrixInvStatus : InteriorEliminationTraceNoMatrixInvStatus
  noGlobalInverseStatus : InteriorEliminationTraceNoGlobalInverseStatus
  noCertificateStatus : InteriorEliminationTraceNoCertificateStatus
  noTwoSidedInvStatus : InteriorEliminationTraceNoTwoSidedInvStatus
  noDtnDataStatus : InteriorEliminationTraceNoDtnDataStatus
  noArithmeticTargetStatus : InteriorEliminationTraceNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus
  blockFoldAccumulatedTraceEvaluation_is_fromTrace :
    blockFoldNormalForm.accumulatedTraceEvaluation =
      GeneratedInteriorAccumulatedTraceEvaluation.fromEliminationTrace T
  blockFoldAccumulatedEntryFold_is_fromTrace :
    blockFoldNormalForm.accumulatedEntryFold =
      GeneratedInteriorAccumulatedEntryFold.fromEliminationTrace T
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A :
    T.sourceStatus =
      InteriorAccumulatedTraceEvaluationTraceSourceStatus.traceFromInteriorEliminationCarrierCarrierAndInteriorEliminationTraceLocalSteps
  has_baseEntry_eq_block :
    ∀ pivot i j : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.baseEntry i j = generatedInteriorBlock W i j
  has_rowResidual_eq_block :
    ∀ pivot j : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.rowResidual j =
        generatedInteriorBlock W (T.localStepOf pivot).pivotDatum.pivotIndex j
  has_columnResidual_eq_block :
    ∀ pivot i : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.columnResidual i =
        generatedInteriorBlock W i (T.localStepOf pivot).pivotDatum.pivotIndex
  has_pivotEntry_eq_block :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedInteriorBlock W
          (T.localStepOf pivot).pivotDatum.pivotIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex
  localStepStatusEqInteriorEliminationTrace :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepStatus =
        InteriorEliminationTraceEliminationStepStatus.generatedInteriorEliminationLocalStepClosed
  stepUpdateStatusEqInteriorEliminationTrace :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.stepUpdateStatus =
        InteriorEliminationTraceStepUpdateStatus.stepUpdateFromInteriorBlockInteriorEliminationdRCandidateInteriorEliminationStepRef48BC
  noMatrixInvStatus_eq :
    noMatrixInvStatus = InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  noGlobalInverseStatus_eq :
    noGlobalInverseStatus = InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
  noCertificateStatus_eq :
    noCertificateStatus = InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus = InteriorEliminationTraceNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationTrace
  noDtnDataStatus_eq :
    noDtnDataStatus = InteriorEliminationTraceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationTrace
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorEliminationTraceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationTrace
  sourceAuditStatus_eq :
    sourceAuditStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantSourceAuditStatus.localStepSchurCancellationSourceAuditFromInteriorEliminationTraceAndInteriorBlockFoldNormalForm
  positiveSourceStatus_eq :
    positiveSourceStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantPositiveSourceStatus.baseRowColumnAndPivotEntriesExposedFromInteriorEliminationTrace
  missingPivotScaleStatus_eq :
    missingPivotScaleStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus.missingPivotScaleInCurrentInteriorEliminationTrace
  missingUpdatedEntryStatus_eq :
    missingUpdatedEntryStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus.missingUpdatedEntryInCurrentInteriorEliminationTrace
  missingSchurUpdateEquationStatus_eq :
    missingSchurUpdateEquationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus.missingUpdatedEntryEqSchurInCurrentInteriorEliminationTrace
  missingLeftLocalCancellationStatus_eq :
    missingLeftLocalCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingLeftLocalCancellationStatus.missingLeftLocalStepCancellationInCurrentInteriorEliminationTrace
  missingRightLocalCancellationStatus_eq :
    missingRightLocalCancellationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingRightLocalCancellationStatus.missingRightLocalStepCancellationInCurrentInteriorEliminationTrace
  noIdentityStatus_eq :
    noIdentityStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNoIdentityStatus.noBlockFoldIdentityInInteriorLocalStepCancellationInvariant
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant

namespace GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromBlockFoldNormalForm
    (N : GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm Cell p A P wp W E K T) :
    GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T where
  blockFoldNormalForm := N
  sourceAuditStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantSourceAuditStatus.localStepSchurCancellationSourceAuditFromInteriorEliminationTraceAndInteriorBlockFoldNormalForm
  positiveSourceStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantPositiveSourceStatus.baseRowColumnAndPivotEntriesExposedFromInteriorEliminationTrace
  missingPivotScaleStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus.missingPivotScaleInCurrentInteriorEliminationTrace
  missingUpdatedEntryStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus.missingUpdatedEntryInCurrentInteriorEliminationTrace
  missingSchurUpdateEquationStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus.missingUpdatedEntryEqSchurInCurrentInteriorEliminationTrace
  missingLeftLocalCancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingLeftLocalCancellationStatus.missingLeftLocalStepCancellationInCurrentInteriorEliminationTrace
  missingRightLocalCancellationStatus :=
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingRightLocalCancellationStatus.missingRightLocalStepCancellationInCurrentInteriorEliminationTrace
  noIdentityStatus := InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNoIdentityStatus.noBlockFoldIdentityInInteriorLocalStepCancellationInvariant
  noMatrixInvStatus := InteriorEliminationTraceNoMatrixInvStatus.noMatrixInvForEliminationStep
  noGlobalInverseStatus := InteriorEliminationTraceNoGlobalInverseStatus.noGlobalInverseForEliminationStep
  noCertificateStatus := InteriorEliminationTraceNoCertificateStatus.noCertificateForEliminationStep
  noTwoSidedInvStatus := InteriorEliminationTraceNoTwoSidedInvStatus.noTwoSidedInvInInteriorEliminationTrace
  noDtnDataStatus := InteriorEliminationTraceNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorEliminationTrace
  noArithmeticTargetStatus :=
    InteriorEliminationTraceNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorEliminationTrace
  nextConsumerStatus := InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant
  blockFoldAccumulatedTraceEvaluation_is_fromTrace :=
    N.accumulatedTraceEvaluation_is_fromTrace
  blockFoldAccumulatedEntryFold_is_fromTrace :=
    N.accumulatedEntryFold_is_fromTrace
  traceSourceEqInteriorAccumulatedTraceEvaluationInteriorAccumulatedEntryCancellationRef336A := T.sourceStatus_eq
  has_baseEntry_eq_block := by
    intro pivot i j
    exact (T.localStepOf pivot).stepUpdate.baseEntry_eq_interiorBlock i j
  has_rowResidual_eq_block := by
    intro pivot j
    calc
      (T.localStepOf pivot).stepUpdate.rowResidual j =
          (T.localStepOf pivot).residualDatum.rowResidual j :=
        (T.localStepOf pivot).stepUpdate.rowResidual_eq_residualDatum j
      _ = generatedInteriorLocalRowResidual W (T.localStepOf pivot).pivotDatum.pivotIndex j :=
        (T.localStepOf pivot).residualDatum.rowResidual_eq_interiorBlock j
      _ = generatedInteriorBlock W (T.localStepOf pivot).pivotDatum.pivotIndex j := by
        rfl
  has_columnResidual_eq_block := by
    intro pivot i
    calc
      (T.localStepOf pivot).stepUpdate.columnResidual i =
          (T.localStepOf pivot).residualDatum.columnResidual i :=
        (T.localStepOf pivot).stepUpdate.columnResidual_eq_residualDatum i
      _ = generatedInteriorLocalColumnResidual W (T.localStepOf pivot).pivotDatum.pivotIndex i :=
        (T.localStepOf pivot).residualDatum.columnResidual_eq_interiorBlock i
      _ = generatedInteriorBlock W i (T.localStepOf pivot).pivotDatum.pivotIndex := by
        rfl
  has_pivotEntry_eq_block := by
    intro pivot
    calc
      (T.localStepOf pivot).stepUpdate.pivotEntry =
          (T.localStepOf pivot).pivotDatum.pivotEntry :=
        (T.localStepOf pivot).stepUpdate.pivotEntry_eq_pivotDatum
      _ = generatedInteriorLocalPivotEntry W (T.localStepOf pivot).pivotDatum.pivotIndex :=
        (T.localStepOf pivot).pivotDatum.pivotEntry_eq_interiorBlock
      _ = generatedInteriorBlock W
          (T.localStepOf pivot).pivotDatum.pivotIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex := by
        rfl
  localStepStatusEqInteriorEliminationTrace := by
    intro pivot
    exact (T.localStepOf pivot).stepStatus_eq
  stepUpdateStatusEqInteriorEliminationTrace := by
    intro pivot
    exact (T.localStepOf pivot).stepUpdate.stepUpdateStatus_eq
  noMatrixInvStatus_eq := by
    rfl
  noGlobalInverseStatus_eq := by
    rfl
  noCertificateStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  sourceAuditStatus_eq := by
    rfl
  positiveSourceStatus_eq := by
    rfl
  missingPivotScaleStatus_eq := by
    rfl
  missingUpdatedEntryStatus_eq := by
    rfl
  missingSchurUpdateEquationStatus_eq := by
    rfl
  missingLeftLocalCancellationStatus_eq := by
    rfl
  missingRightLocalCancellationStatus_eq := by
    rfl
  noIdentityStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromEliminationTrace
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) :
    GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T :=
  fromBlockFoldNormalForm (GeneratedInteriorBlockFoldNormalFormInteriorBlockFoldNormalForm.fromEliminationTrace T)

theorem baseEntry_eq_block
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i j : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.baseEntry i j = generatedInteriorBlock W i j :=
  A0.has_baseEntry_eq_block pivot i j

theorem rowResidual_eq_block
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot j : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.rowResidual j =
      generatedInteriorBlock W (T.localStepOf pivot).pivotDatum.pivotIndex j :=
  A0.has_rowResidual_eq_block pivot j

theorem columnResidual_eq_block
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot i : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.columnResidual i =
      generatedInteriorBlock W i (T.localStepOf pivot).pivotDatum.pivotIndex :=
  A0.has_columnResidual_eq_block pivot i

theorem pivotEntry_eq_block
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      generatedInteriorBlock W
        (T.localStepOf pivot).pivotDatum.pivotIndex
        (T.localStepOf pivot).pivotDatum.pivotIndex :=
  A0.has_pivotEntry_eq_block pivot

theorem nextClosureIsInteriorLocalStepCancellationInvariant
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T) :
    A0.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant :=
  A0.nextConsumerStatus_eq

end GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant

abbrev RegularGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

def regularLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    RegularGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant b p wp :=
  GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant.fromEliminationTrace
    (regularGeneratedInteriorEliminationTrace b p wp)

def variableLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :
    VariableGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant β p wp :=
  GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant.fromEliminationTrace
    (variableGeneratedInteriorEliminationTrace β p wp)

structure InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  regularAudit : RegularGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant b p regularWeight
  variableAudit : VariableGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant β p variableWeight
  regularNextConsumer_eq :
    regularAudit.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant
  variableNextConsumer_eq :
    variableAudit.nextConsumerStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantNextConsumerStatus.interiorLocalStepCancellationInvariantLocalStepSchurCancellationInvariant
  regularMissingPivotScale_eq :
    regularAudit.missingPivotScaleStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus.missingPivotScaleInCurrentInteriorEliminationTrace
  variableMissingPivotScale_eq :
    variableAudit.missingPivotScaleStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingPivotScaleStatus.missingPivotScaleInCurrentInteriorEliminationTrace
  regularMissingUpdatedEntry_eq :
    regularAudit.missingUpdatedEntryStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus.missingUpdatedEntryInCurrentInteriorEliminationTrace
  variableMissingUpdatedEntry_eq :
    variableAudit.missingUpdatedEntryStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingUpdatedEntryStatus.missingUpdatedEntryInCurrentInteriorEliminationTrace
  regularMissingSchurUpdate_eq :
    regularAudit.missingSchurUpdateEquationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus.missingUpdatedEntryEqSchurInCurrentInteriorEliminationTrace
  variableMissingSchurUpdate_eq :
    variableAudit.missingSchurUpdateEquationStatus =
      InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantMissingSchurUpdateEquationStatus.missingUpdatedEntryEqSchurInCurrentInteriorEliminationTrace

namespace InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger

def fromRegularAndVariable
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (regularAudit : RegularGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant b p regularWeight)
    (variableAudit : VariableGeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant β p variableWeight) :
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger
      b β p regularWeight variableWeight where
  regularAudit := regularAudit
  variableAudit := variableAudit
  regularNextConsumer_eq := regularAudit.nextConsumerStatus_eq
  variableNextConsumer_eq := variableAudit.nextConsumerStatus_eq
  regularMissingPivotScale_eq := regularAudit.missingPivotScaleStatus_eq
  variableMissingPivotScale_eq := variableAudit.missingPivotScaleStatus_eq
  regularMissingUpdatedEntry_eq := regularAudit.missingUpdatedEntryStatus_eq
  variableMissingUpdatedEntry_eq := variableAudit.missingUpdatedEntryStatus_eq
  regularMissingSchurUpdate_eq := regularAudit.missingSchurUpdateEquationStatus_eq
  variableMissingSchurUpdate_eq := variableAudit.missingSchurUpdateEquationStatus_eq

end InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger

def interiorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) :
    InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger
      b β p regularWeight variableWeight :=
  InteriorTwoSidedInverseValidationInteriorLocalStepCancellationInvariantLocalStepSchurCancellationSourceAuditLedger.fromRegularAndVariable
    (regularLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant b p regularWeight)
    (variableLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant β p variableWeight)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
