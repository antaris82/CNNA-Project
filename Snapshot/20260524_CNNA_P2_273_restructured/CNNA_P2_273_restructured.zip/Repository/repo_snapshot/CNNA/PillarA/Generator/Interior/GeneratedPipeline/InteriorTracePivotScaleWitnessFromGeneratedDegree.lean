import CNNA.PillarA.Generator.Core.SourceAndApproximation.ApproximantCore
import CNNA.PillarA.Generator.Core.GeneratedPipeline.BoundaryInteriorPartition
import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlock
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidate
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationCarrier
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationStep
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorEliminationTrace
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorInverseCandidateEntry
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorBlockFoldNormalForm
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorAccumulatedEntryCancellation
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
import CNNA.PillarA.Generator.Interior.GeneratedPipeline.InteriorPerPivotRegularityFromTrace

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace

universe u

inductive InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus where
  | generatedDegreeScaleSourceRequiredForTracePivotScaleWitness
  | generatedDegreeScaleSourceProvidedWithTwoSidedScaleEquations
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoScalarInvStatus where
  | noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoMatrixInvStatus where
  | noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus where
  | noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoProductIdentityProofStatus where
  | noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoTwoSidedInvStatus where
  | noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoDtnDataStatus where
  | noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNoArithmeticTargetStatus where
  | noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  deriving DecidableEq, Repr

inductive InteriorTracePivotScaleWitnessNextConsumerStatus where
  | generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge
  | interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  deriving DecidableEq, Repr

structure GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  interiorTracePivotRegularityequirement :
    GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T
  sourceStatus : InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus
  noScalarInvStatus : InteriorTracePivotScaleWitnessNoScalarInvStatus
  noMatrixInvStatus : InteriorTracePivotScaleWitnessNoMatrixInvStatus
  noExternalScaleOracleStatus : InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus
  noProductIdentityProofStatus : InteriorTracePivotScaleWitnessNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTracePivotScaleWitnessNoTwoSidedInvStatus
  noDtnDataStatus : InteriorTracePivotScaleWitnessNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTracePivotScaleWitnessNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTracePivotScaleWitnessNextConsumerStatus
  pivotEntry_eq_block :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedInteriorBlock W
          (T.localStepOf pivot).pivotDatum.pivotIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex
  pivotEntry_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  sourceStatus_eq :
    sourceStatus =
      InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceRequiredForTracePivotScaleWitness
  noScalarInvStatus_eq :
    noScalarInvStatus =
      InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge

namespace GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromInteriorTracePivotRegularityequirement
    (R : GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T where
  interiorTracePivotRegularityequirement := R
  sourceStatus :=
    InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceRequiredForTracePivotScaleWitness
  noScalarInvStatus :=
    InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus :=
    InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus :=
    InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus :=
    InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus :=
    InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus :=
    InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus :=
    InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus := InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge
  pivotEntry_eq_block := by
    intro pivot
    exact R.pivotEntry_eq_block pivot
  pivotEntry_eq_generatedDegree := by
    intro pivot
    exact R.pivotEntry_eq_dirichletDegree pivot
  sourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromSourceAudit
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T :=
  fromInteriorTracePivotRegularityequirement
    (GeneratedInteriorTracePivotEntryNonzeroRequirementInteriorTracePivotRegularity.fromSourceAudit A0)

theorem pivotEntry_bound_to_generatedDegree
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      generatedDirichlet_degree W
        (GeneratedInteriorIndex.toApproximantIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex) :=
  R.pivotEntry_eq_generatedDegree pivot

theorem nextConsumer_requires_generatedDegreeScaleSource
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    R.nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge :=
  R.nextConsumerStatus_eq

end GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness

structure GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T
  pivotScale : GeneratedInteriorIndex A → ℝ
  scaleSourceStatus : InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus
  noScalarInvStatus : InteriorTracePivotScaleWitnessNoScalarInvStatus
  noMatrixInvStatus : InteriorTracePivotScaleWitnessNoMatrixInvStatus
  noExternalScaleOracleStatus : InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus
  source_eq_generatedDegree :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry =
        generatedDirichlet_degree W
          (GeneratedInteriorIndex.toApproximantIndex
            (T.localStepOf pivot).pivotDatum.pivotIndex)
  pivotScale_mul_pivotEntry :
    ∀ pivot : GeneratedInteriorIndex A,
      pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1
  pivotEntry_mul_pivotScale :
    ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry * pivotScale pivot = 1
  scaleSourceStatus_eq :
    scaleSourceStatus =
      InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceProvidedWithTwoSidedScaleEquations
  noScalarInvStatus_eq :
    noScalarInvStatus =
      InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree

namespace GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromGeneratedDegreeScale
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivotScale : GeneratedInteriorIndex A → ℝ)
    (hLeft : ∀ pivot : GeneratedInteriorIndex A,
      pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1)
    (hRight : ∀ pivot : GeneratedInteriorIndex A,
      (T.localStepOf pivot).stepUpdate.pivotEntry * pivotScale pivot = 1) :
    GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T where
  requirement := R
  pivotScale := pivotScale
  scaleSourceStatus :=
    InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceProvidedWithTwoSidedScaleEquations
  noScalarInvStatus :=
    InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus :=
    InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus :=
    InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  source_eq_generatedDegree := by
    intro pivot
    exact R.pivotEntry_eq_generatedDegree pivot
  pivotScale_mul_pivotEntry := hLeft
  pivotEntry_mul_pivotScale := hRight
  scaleSourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl

theorem leftScaleEquation
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    S.pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  S.pivotScale_mul_pivotEntry pivot

theorem rightScaleEquation
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry * S.pivotScale pivot = 1 :=
  S.pivotEntry_mul_pivotScale pivot

theorem source_eq_generatedDegree_of
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry =
      generatedDirichlet_degree W
        (GeneratedInteriorIndex.toApproximantIndex
          (T.localStepOf pivot).pivotDatum.pivotIndex) :=
  S.source_eq_generatedDegree pivot

end GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness


def generatedInteriorTracePivotScaleWitnessFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T where
  requirement := S.requirement.interiorTracePivotRegularityequirement
  pivotScale := S.pivotScale
  pivotScale_mul_pivotEntry := S.pivotScale_mul_pivotEntry
  pivotEntry_mul_pivotScale := S.pivotEntry_mul_pivotScale
  pivotScaleSourceStatus :=
    InteriorTracePivotRegularityPivotScaleSourceStatus.pivotScaleWitnessMustComeFromGeneratedDegreeProfile
  pivotScaleSourceStatus_eq := by
    rfl

def generatedInteriorPerPivotRegularityFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {p : ConcretePolicyOf}
    {A : GeneratedApproximantStrong Cell p}
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    {P : GeneratedBoundaryInteriorPartition Cell p A}
    {wp : WeightPolicy}
    {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
    {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
    {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
    {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T :=
  GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity.fromTracePivotScaleWitness
    (generatedInteriorTracePivotScaleWitnessFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness S)

structure GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  scaleSource : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T
  tracePivotScaleWitness : GeneratedInteriorTracePivotScaleWitnessInteriorTracePivotRegularity Cell p A P wp W E K T
  perPivotRegularity : GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity Cell p A P wp W E K T
  sourceStatus : InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus
  noScalarInvStatus : InteriorTracePivotScaleWitnessNoScalarInvStatus
  noMatrixInvStatus : InteriorTracePivotScaleWitnessNoMatrixInvStatus
  noExternalScaleOracleStatus : InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus
  noProductIdentityProofStatus : InteriorTracePivotScaleWitnessNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTracePivotScaleWitnessNoTwoSidedInvStatus
  noDtnDataStatus : InteriorTracePivotScaleWitnessNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTracePivotScaleWitnessNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTracePivotScaleWitnessNextConsumerStatus
  tracePivotScaleWitness_eq_from_generatedDegreeScaleSource :
    tracePivotScaleWitness =
      generatedInteriorTracePivotScaleWitnessFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness scaleSource
  perPivotRegularity_eq_from_tracePivotScaleWitness :
    perPivotRegularity =
      GeneratedInteriorPerPivotRegularityFromTraceInteriorTracePivotRegularity.fromTracePivotScaleWitness
        tracePivotScaleWitness
  sourceStatus_eq :
    sourceStatus =
      InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceProvidedWithTwoSidedScaleEquations
  noScalarInvStatus_eq :
    noScalarInvStatus =
      InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge

namespace GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromGeneratedDegreeScaleSource
    (S : GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness Cell p A P wp W E K T where
  scaleSource := S
  tracePivotScaleWitness :=
    generatedInteriorTracePivotScaleWitnessFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness S
  perPivotRegularity :=
    generatedInteriorPerPivotRegularityFromGeneratedDegreeScaleSourceInteriorTracePivotScaleWitness S
  sourceStatus :=
    InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceProvidedWithTwoSidedScaleEquations
  noScalarInvStatus :=
    InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus :=
    InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus :=
    InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus :=
    InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus :=
    InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus := InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus :=
    InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus := InteriorTracePivotScaleWitnessNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge
  tracePivotScaleWitness_eq_from_generatedDegreeScaleSource := by
    rfl
  perPivotRegularity_eq_from_tracePivotScaleWitness := by
    rfl
  sourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

theorem tracePivotScaleWitness_left_inverse
    (G : GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    G.tracePivotScaleWitness.pivotScale pivot * (T.localStepOf pivot).stepUpdate.pivotEntry = 1 :=
  G.tracePivotScaleWitness.pivotScale_mul_pivotEntry pivot

theorem tracePivotScaleWitness_right_inverse
    (G : GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness Cell p A P wp W E K T)
    (pivot : GeneratedInteriorIndex A) :
    (T.localStepOf pivot).stepUpdate.pivotEntry * G.tracePivotScaleWitness.pivotScale pivot = 1 :=
  G.tracePivotScaleWitness.pivotEntry_mul_pivotScale pivot

theorem nextClosureIsInteriorBlockFoldKernelResidualBridge
    (G : GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    G.nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.interiorTwoSidedInverseValidationInteriorBlockFoldKernelResidualBridgeBlockFoldKernelToLocalSchurResidualBridge :=
  G.nextConsumerStatus_eq

end GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness

structure GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K) where
  requirement : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T
  sourceStatus : InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus
  noScalarInvStatus : InteriorTracePivotScaleWitnessNoScalarInvStatus
  noMatrixInvStatus : InteriorTracePivotScaleWitnessNoMatrixInvStatus
  noExternalScaleOracleStatus : InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus
  noProductIdentityProofStatus : InteriorTracePivotScaleWitnessNoProductIdentityProofStatus
  noTwoSidedInvStatus : InteriorTracePivotScaleWitnessNoTwoSidedInvStatus
  noDtnDataStatus : InteriorTracePivotScaleWitnessNoDtnDataStatus
  noArithmeticTargetStatus : InteriorTracePivotScaleWitnessNoArithmeticTargetStatus
  nextConsumerStatus : InteriorTracePivotScaleWitnessNextConsumerStatus
  sourceStatus_eq :
    sourceStatus =
      InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceRequiredForTracePivotScaleWitness
  noScalarInvStatus_eq :
    noScalarInvStatus =
      InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus_eq :
    noMatrixInvStatus =
      InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus_eq :
    noExternalScaleOracleStatus =
      InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus_eq :
    noProductIdentityProofStatus =
      InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus_eq :
    noTwoSidedInvStatus =
      InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus_eq :
    noDtnDataStatus =
      InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus_eq :
    noArithmeticTargetStatus =
      InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus_eq :
    nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge

namespace GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}

def fromRequirement
    (R : GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness Cell p A P wp W E K T where
  requirement := R
  sourceStatus :=
    InteriorTracePivotScaleWitnessGeneratedDegreeScaleSourceStatus.generatedDegreeScaleSourceRequiredForTracePivotScaleWitness
  noScalarInvStatus :=
    InteriorTracePivotScaleWitnessNoScalarInvStatus.noScalarInvInTracePivotScaleWitnessFromGeneratedDegree
  noMatrixInvStatus :=
    InteriorTracePivotScaleWitnessNoMatrixInvStatus.noMatrixInvInTracePivotScaleWitnessFromGeneratedDegree
  noExternalScaleOracleStatus :=
    InteriorTracePivotScaleWitnessNoExternalScaleOracleStatus.noExternalScaleOracleInTracePivotScaleWitnessFromGeneratedDegree
  noProductIdentityProofStatus :=
    InteriorTracePivotScaleWitnessNoProductIdentityProofStatus.noProductIdentityProofInTracePivotScaleWitnessFromGeneratedDegree
  noTwoSidedInvStatus :=
    InteriorTracePivotScaleWitnessNoTwoSidedInvStatus.noTwoSidedInvInTracePivotScaleWitnessFromGeneratedDegree
  noDtnDataStatus := InteriorTracePivotScaleWitnessNoDtnDataStatus.noDtnGeneralizedDtnOrMultiSchurDataInInteriorTracePivotScaleWitness
  noArithmeticTargetStatus :=
    InteriorTracePivotScaleWitnessNoArithmeticTargetStatus.noCharpolyFactorDiscriminantOrL23TargetInInteriorTracePivotScaleWitness
  nextConsumerStatus := InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge
  sourceStatus_eq := by
    rfl
  noScalarInvStatus_eq := by
    rfl
  noMatrixInvStatus_eq := by
    rfl
  noExternalScaleOracleStatus_eq := by
    rfl
  noProductIdentityProofStatus_eq := by
    rfl
  noTwoSidedInvStatus_eq := by
    rfl
  noDtnDataStatus_eq := by
    rfl
  noArithmeticTargetStatus_eq := by
    rfl
  nextConsumerStatus_eq := by
    rfl

def fromSourceAudit
    (A0 : GeneratedInteriorLocalStepSchurCancellationSourceAuditInteriorLocalStepCancellationInvariant Cell p A P wp W E K T) :
    GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness Cell p A P wp W E K T :=
  fromRequirement
    (GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness.fromSourceAudit A0)

theorem nextConsumer_requires_generatedDegreeScaleSource
    (A0 : GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness Cell p A P wp W E K T) :
    A0.nextConsumerStatus = InteriorTracePivotScaleWitnessNextConsumerStatus.generatedDegreeScaleSourceRequiredBeforeInteriorBlockFoldKernelResidualBridge :=
  A0.nextConsumerStatus_eq

end GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness

abbrev RegularGeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleSourceRequirementInteriorTracePivotScaleWitness
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorGeneratedDegreePivotScaleSourceInteriorTracePivotScaleWitness
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeInteriorTracePivotScaleWitness
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

abbrev RegularGeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness
    (b : Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness
    (ConcreteSubstrate.RegularCell b) p
    (regularGeneratedApproximantStrong b p)
    (regularGeneratedBoundaryInteriorPartition b p) wp
    (regularGeneratedWeightPolicyEntrySource b p wp)
    (regularGeneratedInteriorEliminationCandidateEntry b p wp)
    (regularGeneratedInteriorEliminationCarrier b p wp)
    (regularGeneratedInteriorEliminationTrace b p wp)

abbrev VariableGeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness
    (β : Nat → Nat) (p : ConcretePolicyOf) (wp : WeightPolicy) :=
  GeneratedInteriorTracePivotScaleWitnessFromGeneratedDegreeAuditInteriorTracePivotScaleWitness
    (LevelVariableSubstrate.LevelVariableCell β) p
    (variableGeneratedApproximantStrong β p)
    (variableGeneratedBoundaryInteriorPartition β p) wp
    (variableGeneratedWeightPolicyEntrySource β p wp)
    (variableGeneratedInteriorEliminationCandidateEntry β p wp)
    (variableGeneratedInteriorEliminationCarrier β p wp)
    (variableGeneratedInteriorEliminationTrace β p wp)

end CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
