import CNNA.PillarA.Generator.LevelHistory.StepWitness.LevelStepWitness
import CNNA.PillarA.Generator.LevelHistory.BoundaryPort.LevelHistoryBoundaryPortSource
import CNNA.PillarA.Generator.LevelHistory.SchurIndex.LevelHistorySchurIndexMap
import CNNA.PillarA.Generator.LevelHistory.SchurIndex.LevelHistorySchurIndexBridgeConsistency
import CNNA.PillarA.Generator.LevelHistory.Matrix.LevelHistoryMatrixFromBridge
import CNNA.PillarA.Generator.Schur.MultiSchur.MultiSchur
import CNNA.PillarA.Generator.DtN.TopBoundary.TopBoundaryDtN
import CNNA.PillarA.Generator.DtN.TopBoundary.GeneralizedTopBoundaryDtN

set_option autoImplicit false

namespace CNNA.PillarA.Generator

inductive GeneratorOutputImportTransitionStatus where
  | compatibilityFacadeOnly
  | neutralGeneratorImportsCarryTarget
  deriving DecidableEq, Repr

structure GeneratorOutputCompatibilityFacade where
  source : GeneratorOutputSourceProfile
  levelStepWitness : LevelStepWitnessOutputProfile
  levelStepWitness_source_eq : levelStepWitness.profile.source = source
  levelHistoryBoundaryPort : LevelHistoryBoundaryPortOutputProfile
  levelHistoryBoundaryPort_source_eq : levelHistoryBoundaryPort.profile.source = source
  levelHistorySchurIndexMap : LevelHistorySchurIndexMapOutputProfile
  levelHistorySchurIndexMap_source_eq : levelHistorySchurIndexMap.profile.source = source
  levelHistorySchurIndexBridgeConsistency : LevelHistorySchurIndexBridgeConsistencyOutputProfile
  levelHistorySchurIndexBridgeConsistency_source_eq :
    levelHistorySchurIndexBridgeConsistency.profile.source = source
  levelHistoryMatrix : LevelHistoryMatrixOutputProfile
  levelHistoryMatrix_source_eq : levelHistoryMatrix.profile.source = source
  multiSchur : MultiSchurOutputProfile
  multiSchur_source_eq : multiSchur.profile.source = source
  topBoundaryDtN : TopBoundaryDtNOutputProfile
  topBoundaryDtN_source_eq : topBoundaryDtN.profile.source = source
  generalizedTopBoundaryDtN : GeneralizedTopBoundaryDtNOutputProfile
  generalizedTopBoundaryDtN_source_eq : generalizedTopBoundaryDtN.profile.source = source

namespace GeneratorOutputCompatibilityFacade

theorem levelStepWitness_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.levelStepWitness.profile.kind = DerivedOutputKind.levelStepWitness :=
  facade.levelStepWitness.kind_matches

theorem levelHistoryBoundaryPort_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.levelHistoryBoundaryPort.profile.kind =
      DerivedOutputKind.levelHistoryBoundaryPort :=
  facade.levelHistoryBoundaryPort.kind_matches

theorem levelHistorySchurIndexMap_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.levelHistorySchurIndexMap.profile.kind =
      DerivedOutputKind.levelHistorySchurIndexMap :=
  facade.levelHistorySchurIndexMap.kind_matches

theorem levelHistorySchurIndexBridgeConsistency_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.levelHistorySchurIndexBridgeConsistency.profile.kind =
      DerivedOutputKind.levelHistorySchurIndexBridgeConsistency :=
  facade.levelHistorySchurIndexBridgeConsistency.kind_matches

theorem levelHistoryMatrix_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.levelHistoryMatrix.profile.kind = DerivedOutputKind.levelHistoryMatrix :=
  facade.levelHistoryMatrix.kind_matches

theorem multiSchur_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.multiSchur.profile.kind = DerivedOutputKind.multiSchur :=
  facade.multiSchur.kind_matches

theorem topBoundaryDtN_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.topBoundaryDtN.profile.kind = DerivedOutputKind.topBoundaryDtN :=
  facade.topBoundaryDtN.kind_matches

theorem generalizedTopBoundaryDtN_kind
    (facade : GeneratorOutputCompatibilityFacade) :
    facade.generalizedTopBoundaryDtN.profile.kind =
      DerivedOutputKind.generalizedTopBoundaryDtN :=
  facade.generalizedTopBoundaryDtN.kind_matches

end GeneratorOutputCompatibilityFacade

structure GeneratorOutputImportTransitionCertificate where
  facade : GeneratorOutputCompatibilityFacade
  status : GeneratorOutputImportTransitionStatus
  status_eq : status = GeneratorOutputImportTransitionStatus.neutralGeneratorImportsCarryTarget

namespace GeneratorOutputImportTransitionCertificate

theorem status_is_neutral_import_target
    (certificate : GeneratorOutputImportTransitionCertificate) :
    certificate.status =
      GeneratorOutputImportTransitionStatus.neutralGeneratorImportsCarryTarget :=
  certificate.status_eq

end GeneratorOutputImportTransitionCertificate

end CNNA.PillarA.Generator
