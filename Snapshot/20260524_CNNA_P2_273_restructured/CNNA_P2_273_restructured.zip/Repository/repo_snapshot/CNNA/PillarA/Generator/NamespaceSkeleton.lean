import CNNA.PillarA.Foundation.BuildAll

set_option autoImplicit false

namespace CNNA.PillarA.Generator

inductive NeutralGeneratorNamespaceLayer where
  | foundationInput
  | generatorSurface
  | compatibilitySurface
  deriving DecidableEq, Repr

inductive NeutralGeneratorNamespaceStatus where
  | skeletonOnly
  | sourceImplemented
  deriving DecidableEq, Repr

inductive NeutralGeneratorCompatibilityRouteStatus where
  | retainedCompatibilitySurface
  deriving DecidableEq, Repr

structure NeutralFoundationGeneratorNamespaceSkeleton where
  foundationLayer : NeutralGeneratorNamespaceLayer
  generatorLayer : NeutralGeneratorNamespaceLayer
  compatibilityLayer : NeutralGeneratorNamespaceLayer
  status : NeutralGeneratorNamespaceStatus
  compatibilityRoute : NeutralGeneratorCompatibilityRouteStatus
  foundationLayer_eq : foundationLayer = NeutralGeneratorNamespaceLayer.foundationInput
  generatorLayer_eq : generatorLayer = NeutralGeneratorNamespaceLayer.generatorSurface
  compatibilityLayer_eq : compatibilityLayer = NeutralGeneratorNamespaceLayer.compatibilitySurface
  status_eq : status = NeutralGeneratorNamespaceStatus.skeletonOnly
  compatibilityRoute_eq :
    compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface

namespace NeutralFoundationGeneratorNamespaceSkeleton

def foundationInputLayer (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    NeutralGeneratorNamespaceLayer :=
  skeleton.foundationLayer

def generatorSurfaceLayer (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    NeutralGeneratorNamespaceLayer :=
  skeleton.generatorLayer

def compatibilitySurfaceLayer (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    NeutralGeneratorNamespaceLayer :=
  skeleton.compatibilityLayer

def isSkeletonOnly (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) : Prop :=
  skeleton.status = NeutralGeneratorNamespaceStatus.skeletonOnly

theorem foundationInputLayer_eq
    (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    skeleton.foundationInputLayer =
      NeutralGeneratorNamespaceLayer.foundationInput :=
  skeleton.foundationLayer_eq

theorem generatorSurfaceLayer_eq
    (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    skeleton.generatorSurfaceLayer =
      NeutralGeneratorNamespaceLayer.generatorSurface :=
  skeleton.generatorLayer_eq

theorem compatibilitySurfaceLayer_eq
    (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    skeleton.compatibilitySurfaceLayer =
      NeutralGeneratorNamespaceLayer.compatibilitySurface :=
  skeleton.compatibilityLayer_eq

theorem isSkeletonOnly_intro
    (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    skeleton.isSkeletonOnly :=
  skeleton.status_eq

theorem compatibilityRoute_retained
    (skeleton : NeutralFoundationGeneratorNamespaceSkeleton) :
    skeleton.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface :=
  skeleton.compatibilityRoute_eq

end NeutralFoundationGeneratorNamespaceSkeleton

structure NeutralGeneratorNamespaceBuildSurface where
  skeleton : NeutralFoundationGeneratorNamespaceSkeleton
  foundationBuildLayer : NeutralGeneratorNamespaceLayer
  generatorBuildLayer : NeutralGeneratorNamespaceLayer
  compatibilityBuildLayer : NeutralGeneratorNamespaceLayer
  foundationBuildLayer_eq :
    foundationBuildLayer = NeutralGeneratorNamespaceLayer.foundationInput
  generatorBuildLayer_eq :
    generatorBuildLayer = NeutralGeneratorNamespaceLayer.generatorSurface
  compatibilityBuildLayer_eq :
    compatibilityBuildLayer = NeutralGeneratorNamespaceLayer.compatibilitySurface
  skeleton_status_eq :
    skeleton.status = NeutralGeneratorNamespaceStatus.skeletonOnly
  skeleton_compatibilityRoute_eq :
    skeleton.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface

namespace NeutralGeneratorNamespaceBuildSurface

def status (surface : NeutralGeneratorNamespaceBuildSurface) :
    NeutralGeneratorNamespaceStatus :=
  surface.skeleton.status

def compatibilityRoute (surface : NeutralGeneratorNamespaceBuildSurface) :
    NeutralGeneratorCompatibilityRouteStatus :=
  surface.skeleton.compatibilityRoute

theorem status_eq_skeletonOnly
    (surface : NeutralGeneratorNamespaceBuildSurface) :
    surface.status = NeutralGeneratorNamespaceStatus.skeletonOnly :=
  surface.skeleton_status_eq

theorem compatibilityRoute_eq_retained
    (surface : NeutralGeneratorNamespaceBuildSurface) :
    surface.compatibilityRoute =
      NeutralGeneratorCompatibilityRouteStatus.retainedCompatibilitySurface :=
  surface.skeleton_compatibilityRoute_eq

theorem foundationBuildLayer_is_foundationInput
    (surface : NeutralGeneratorNamespaceBuildSurface) :
    surface.foundationBuildLayer =
      NeutralGeneratorNamespaceLayer.foundationInput :=
  surface.foundationBuildLayer_eq

theorem generatorBuildLayer_is_generatorSurface
    (surface : NeutralGeneratorNamespaceBuildSurface) :
    surface.generatorBuildLayer =
      NeutralGeneratorNamespaceLayer.generatorSurface :=
  surface.generatorBuildLayer_eq

theorem compatibilityBuildLayer_is_compatibilitySurface
    (surface : NeutralGeneratorNamespaceBuildSurface) :
    surface.compatibilityBuildLayer =
      NeutralGeneratorNamespaceLayer.compatibilitySurface :=
  surface.compatibilityBuildLayer_eq

end NeutralGeneratorNamespaceBuildSurface

end CNNA.PillarA.Generator
