import CNNA.PillarA.Generator.DtN.BuildAll
