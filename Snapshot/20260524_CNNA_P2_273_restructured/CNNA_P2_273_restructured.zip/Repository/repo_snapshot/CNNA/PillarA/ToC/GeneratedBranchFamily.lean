import CNNA.PillarA.Generator.GeneratedBranchFamily

set_option autoImplicit false

namespace CNNA.PillarA.ToC

open CNNA.PillarA.Foundation

universe u

namespace GeneratedBranchFamily

abbrev NonSingletonWitness (Cell : Nat → Type u) [SubstrateClass Cell] (L : Nat) : Type u :=
  CNNA.PillarA.Generator.GeneratedBranchFamily.NonSingletonWitness Cell L

end GeneratedBranchFamily

abbrev generatedBranchFamily (Cell : Nat → Type u) [SubstrateClass Cell] :
    DirectedFamily (Cell := Cell) :=
  CNNA.PillarA.Generator.generatedBranchFamily Cell

theorem generatedBranchFamily_carrier
    (Cell : Nat → Type u) [SubstrateClass Cell] (L : Nat) :
    (generatedBranchFamily Cell).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.generatedBranchFamily_carrier Cell L

theorem generatedBranchFamily_rooted
    (Cell : Nat → Type u) [SubstrateClass Cell] :
    (generatedBranchFamily Cell).carrier 0 = SubstrateClass.rootLayer (Cell := Cell) := by
  exact CNNA.PillarA.Generator.generatedBranchFamily_rooted Cell

abbrev generatedBranchToC (Cell : Nat → Type u) [SubstrateClass Cell] :
    ToCStrongOf Cell :=
  CNNA.PillarA.Generator.generatedBranchToC Cell

theorem generatedBranchToC_ideal
    (Cell : Nat → Type u) [SubstrateClass Cell] :
    (generatedBranchToC Cell).ideal = generatedBranchFamily Cell := by
  exact CNNA.PillarA.Generator.generatedBranchToC_ideal Cell

theorem generatedBranchToC_approximant_carrier_of_le
    (Cell : Nat → Type u) [SubstrateClass Cell]
    {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    ((generatedBranchToC Cell).approximant p).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.generatedBranchToC_approximant_carrier_of_le
    (Cell := Cell) hL

abbrev regularGeneratedFamily (b : Nat) :
    DirectedFamily (Cell := CNNA.PillarA.Foundation.ConcreteSubstrate.RegularCell b) :=
  CNNA.PillarA.Generator.regularGeneratedFamily b

abbrev regularGeneratedToC (b : Nat) :
    ToCStrongOf (CNNA.PillarA.Foundation.ConcreteSubstrate.RegularCell b) :=
  CNNA.PillarA.Generator.regularGeneratedToC b

theorem regularGeneratedFamily_carrier (b L : Nat) :
    (regularGeneratedFamily b).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.regularGeneratedFamily_carrier b L

theorem regularGeneratedToC_approximant_carrier_of_le
    (b : Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    ((regularGeneratedToC b).approximant p).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.regularGeneratedToC_approximant_carrier_of_le
    (b := b) hL

def regularGeneratedFamily_nonSingletonAtSucc
    {b L : Nat} (hb : 0 < b) :
    GeneratedBranchFamily.NonSingletonWitness
      (CNNA.PillarA.Foundation.ConcreteSubstrate.RegularCell b) (L + 1) :=
  CNNA.PillarA.Generator.regularGeneratedFamily_nonSingletonAtSucc (L := L) hb

abbrev variableGeneratedFamily (β : Nat → Nat) :
    DirectedFamily (Cell := CNNA.PillarA.Foundation.LevelVariableSubstrate.LevelVariableCell β) :=
  CNNA.PillarA.Generator.variableGeneratedFamily β

abbrev variableGeneratedToC (β : Nat → Nat) :
    ToCStrongOf (CNNA.PillarA.Foundation.LevelVariableSubstrate.LevelVariableCell β) :=
  CNNA.PillarA.Generator.variableGeneratedToC β

theorem variableGeneratedFamily_carrier (β : Nat → Nat) (L : Nat) :
    (variableGeneratedFamily β).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.variableGeneratedFamily_carrier β L

theorem variableGeneratedToC_approximant_carrier_of_le
    (β : Nat → Nat) {p : ConcretePolicyOf} {L : Nat} (hL : L ≤ p.L_max) :
    ((variableGeneratedToC β).approximant p).carrier L = Finset.univ := by
  exact CNNA.PillarA.Generator.variableGeneratedToC_approximant_carrier_of_le
    (β := β) hL

def variableGeneratedFamily_nonSingletonAtSucc
    {β : Nat → Nat} {L : Nat} (hβ : 0 < β L) :
    GeneratedBranchFamily.NonSingletonWitness
      (CNNA.PillarA.Foundation.LevelVariableSubstrate.LevelVariableCell β) (L + 1) :=
  CNNA.PillarA.Generator.variableGeneratedFamily_nonSingletonAtSucc (L := L) hβ

end CNNA.PillarA.ToC
