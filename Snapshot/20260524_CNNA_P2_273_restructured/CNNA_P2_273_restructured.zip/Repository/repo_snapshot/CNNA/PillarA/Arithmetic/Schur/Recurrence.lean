import CNNA.PillarA.Generator.Schur.Arithmetic.Recurrence
