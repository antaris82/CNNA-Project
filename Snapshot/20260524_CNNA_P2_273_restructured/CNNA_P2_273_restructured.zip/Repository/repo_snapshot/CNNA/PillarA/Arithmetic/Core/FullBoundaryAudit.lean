import CNNA.PillarA.Generator.Core.FullBoundaryAudit
