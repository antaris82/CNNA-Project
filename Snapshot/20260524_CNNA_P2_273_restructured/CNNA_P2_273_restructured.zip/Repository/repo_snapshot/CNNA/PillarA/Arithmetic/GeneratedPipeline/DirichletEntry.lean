import CNNA.PillarA.Generator.Core.GeneratedPipeline.DirichletEntry
