import CNNA.PillarA.Handoff.Internal.SpineReleaseCertificate

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Handoff

universe u v w

inductive ArithmeticHubFacadeStatus where
  | declared
  | connected
  | blocked
  deriving DecidableEq, Repr

inductive ArithmeticHubPayloadExposureStatus where
  | typedOnly
  | payloadDeferred
  | payloadReady
  | blocked
  deriving DecidableEq, Repr

inductive ArithmeticHubAxiomImportStatus where
  | cutEdgeReadoutOnly
  | primitiveImported
  | blocked
  deriving DecidableEq, Repr

structure ArithmeticHubHandoffFacade where
  spine : InternalHandoffSpineReleaseCertificate.{u, v, w}
  status : ArithmeticHubFacadeStatus
  payloadExposure : ArithmeticHubPayloadExposureStatus
  axiomImportStatus : ArithmeticHubAxiomImportStatus
  status_declared : status = ArithmeticHubFacadeStatus.declared
  payloadExposure_typedOnly :
    payloadExposure = ArithmeticHubPayloadExposureStatus.typedOnly
  axiomImportStatus_cutEdgeReadoutOnly :
    axiomImportStatus = ArithmeticHubAxiomImportStatus.cutEdgeReadoutOnly
  spine_hubKind_arithmetic : spine.hubKind = InternalHubKind.arithmetic
  spine_family_arithmetic : spine.family = InternalCutEdgeTheoryFamily.arithmetic

namespace ArithmeticHubHandoffFacade

def standard
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHubInterfaceStandard.{u, v} :=
  facade.spine.standard

def inputSchema
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypeSchema.{u, v} :=
  facade.standard.input

def outputSchema
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypeSchema.{u, v} :=
  facade.standard.output

def cutStateSchema
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypeSchema.{u, v} :=
  facade.standard.cutState

def residualSchema
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypeSchema.{u, v} :=
  facade.standard.residual

def reviewGateSchema
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypeSchema.{u, v} :=
  facade.standard.reviewGate

def stableOutputRecord
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.output :=
  facade.spine.catalog.records.stableRecord

def cutStateRecord
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.cutState :=
  facade.spine.catalog.records.interfaceSurface

def residualRecord
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.residual :=
  facade.spine.catalog.records.darkComplement

def reviewGateRecord
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    InternalHandoffTypedRecord facade.standard.reviewGate :=
  facade.spine.catalog.records.regulatorBranch

def releaseCertificate
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    GeneratorRequestApproximationReleaseCertificate :=
  facade.spine.releaseCertificate

def global
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    GlobalTheoryApproximationState :=
  facade.spine.global

def limitProfile
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    PillarAToBLimitApproximationProfile :=
  facade.spine.limitProfile

theorem status_is_declared
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.status = ArithmeticHubFacadeStatus.declared :=
  facade.status_declared

theorem payloadExposure_is_typedOnly
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.payloadExposure = ArithmeticHubPayloadExposureStatus.typedOnly :=
  facade.payloadExposure_typedOnly

theorem axiomImportStatus_is_cutEdgeReadoutOnly
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.axiomImportStatus =
      ArithmeticHubAxiomImportStatus.cutEdgeReadoutOnly :=
  facade.axiomImportStatus_cutEdgeReadoutOnly

theorem hubKind_is_arithmetic
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.spine.hubKind = InternalHubKind.arithmetic :=
  facade.spine_hubKind_arithmetic

theorem family_is_arithmetic
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.spine.family = InternalCutEdgeTheoryFamily.arithmetic :=
  facade.spine_family_arithmetic

theorem family_eq_hub_family
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.spine.family =
      InternalCutEdgeTheoryFamily.forHub facade.spine.hubKind :=
  facade.spine.family_eq_hub_family

theorem output_global_eq_input_global
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.outputSchema.global = facade.inputSchema.global :=
  facade.spine.bright_global_eq_input_global

theorem residual_global_eq_input_global
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.residualSchema.global = facade.inputSchema.global :=
  facade.spine.darkComplement_global_eq_input_global

theorem cutState_global_eq_input_global
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.cutStateSchema.global = facade.inputSchema.global :=
  facade.spine.interface_global_eq_input_global

theorem reviewGate_global_eq_input_global
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.reviewGateSchema.global = facade.inputSchema.global :=
  facade.spine.regulator_global_eq_input_global

theorem request_global_eq_lock
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.standard.request.global = facade.standard.lock.state :=
  facade.spine.request_global_eq_lock

theorem gate_global_eq_limit_state
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.standard.gate.global = facade.standard.limitProfile.state :=
  facade.spine.gate_global_eq_limit_state

theorem input_target_consumer
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.inputSchema.target.role = InternalHandoffRole.consumer :=
  facade.standard.input_target_role

theorem output_source_producer
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.outputSchema.source.role = InternalHandoffRole.producer :=
  facade.standard.output_source_role

theorem cutState_source_interface
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.cutStateSchema.source.role = InternalHandoffRole.interface :=
  facade.standard.cutState_source_role

theorem residual_source_interface
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.residualSchema.source.role = InternalHandoffRole.interface :=
  facade.standard.residual_source_role

theorem reviewGate_source_regulator
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.reviewGateSchema.source.role = InternalHandoffRole.regulator :=
  facade.standard.reviewGate_source_role

theorem input_direction_generatorToHub
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.inputSchema.direction = InternalHandoffDirection.generatorToHub :=
  facade.standard.input_direction

theorem output_direction_hubToInternalHandoff
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.outputSchema.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.output_direction

theorem cutState_direction_hubToInternalHandoff
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.cutStateSchema.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.cutState_direction

theorem residual_direction_hubToInternalHandoff
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.residualSchema.direction =
      InternalHandoffDirection.hubToInternalHandoff :=
  facade.standard.residual_direction

theorem reviewGate_direction_regulatorToInterface
    (facade : ArithmeticHubHandoffFacade.{u, v, w}) :
    facade.reviewGateSchema.direction =
      InternalHandoffDirection.regulatorToInterface :=
  facade.standard.reviewGate_direction

end ArithmeticHubHandoffFacade

end CNNA.PillarA.Arithmetic
