import CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
import CNNA.PillarA.Generator.LevelHistory.SchurIndex.LevelHistorySchurIndexMap

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryToSchurIndex

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource

universe u

inductive LevelHistorySchurIndexBridgeBridgeOutcome where
  | bridgeSuccess
  | obstructionMissingGeneratedIndexSource
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeGeneratedIndexMapSourceStatus where
  | generatedHistoryToBoundaryMapSourceRequired
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeMissingLevelToBoundaryMapSourceStatus where
  | missingGeneratedLevelHistoryToBoundaryMapSource
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeMissingSchurIndexProvenanceStatus where
  | missingGeneratedSchurIndexProvenance
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus where
  | noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus where
  | noFreeReplacementIndexInLevelHistorySchurIndexBridge
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus where
  | noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus where
  | noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  deriving DecidableEq, Repr

inductive LevelHistorySchurIndexBridgeNextConsumerBlockedStatus where
  | levelHistoryMatrixBlockedUntilBridgeSuccess
  deriving DecidableEq, Repr

structure GeneratedLevelHistorySchurIndexBridge
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  sourceLevelHistorySchurIndexWitness : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAt : (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level) →
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAtSourceEqLevelHistoryToSchurIndex : ∀ k, (witnessAt k).sourceGeneratedArithmeticSourceLedger = sourceLevelHistorySchurIndexWitness.sourceGeneratedArithmeticSourceLedger
  witnessAt_boundaryCarrier_eq_generated : ∀ k,
    (witnessAt k).boundaryCarrier = GeneratedBoundaryIndex A
  toBoundaryIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level → GeneratedBoundaryIndex A
  toBoundaryIndex_sourceStatus : LevelHistorySchurIndexBridgeGeneratedIndexMapSourceStatus
  toBoundaryIndex_sourceStatus_eq :
    toBoundaryIndex_sourceStatus =
      LevelHistorySchurIndexBridgeGeneratedIndexMapSourceStatus.generatedHistoryToBoundaryMapSourceRequired
  toBoundaryIndex_level_eq_cutoff : ∀ k,
    (GeneratedBoundaryIndex.level (toBoundaryIndex k)).val = p.L_max
  boundaryOperatorFromLevelHistoryToSchurIndex :
    sourceLevelHistorySchurIndexWitness.boundaryOperator = sourceLevelHistorySchurIndexWitness.source.boundaryOperator
  boundaryOperator_from_schur :
    sourceLevelHistorySchurIndexWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  noFreeFintypeEnumerationStatus : LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus : LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus
  noLevelHistoryMatrixStatus_eq :
    noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus : LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge

structure GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge
    (Cell : Nat → Type u) [SubstrateClass Cell]
    (p : ConcretePolicyOf)
    (A : GeneratedApproximantStrong Cell p)
    [Fintype (GeneratedBoundaryIndex A)]
    [Fintype (GeneratedInteriorIndex A)]
    [DecidableEq (GeneratedInteriorIndex A)]
    (P : GeneratedBoundaryInteriorPartition Cell p A)
    (wp : WeightPolicy)
    (W : GeneratedWeightPolicyEntrySource Cell p A P wp)
    (E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W)
    (K : GeneratedInteriorEliminationCarrier Cell p A P wp W E)
    (T : GeneratedInteriorEliminationTrace Cell p A P wp W E K)
    (M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T)
    (S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M)
    (H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S)
    (G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H) where
  sourceLevelHistorySchurIndexWitness : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAt : (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistorySchurIndexWitness.level) →
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G
  witnessAtSourceEqGeneratedArithmeticSource : ∀ k,
    (witnessAt k).source = sourceLevelHistorySchurIndexWitness.sourceGeneratedArithmeticSourceLedger
  witnessAt_boundaryCarrier_eq_generated : ∀ k,
    (witnessAt k).boundaryCarrier = GeneratedBoundaryIndex A
  witnessAtBoundaryOperatorEqGeneratedArithmeticSource : ∀ k,
    (witnessAt k).boundaryOperator = (witnessAt k).source.boundaryOperator
  witnessAt_boundaryOperator_eq_schur : ∀ k,
    (witnessAt k).boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          (witnessAt k).source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W
  witnessAt_apply_eq_mulVec : ∀ k (φ : GeneratedBoundaryIndex A → ℝ),
    (witnessAt k).«apply» φ = (witnessAt k).boundaryOperator.mulVec φ
  outcome : LevelHistorySchurIndexBridgeBridgeOutcome
  outcome_eq_obstruction : outcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  missingLevelToBoundaryMapSource : LevelHistorySchurIndexBridgeMissingLevelToBoundaryMapSourceStatus
  missingLevelToBoundaryMapSource_eq :
    missingLevelToBoundaryMapSource =
      LevelHistorySchurIndexBridgeMissingLevelToBoundaryMapSourceStatus.missingGeneratedLevelHistoryToBoundaryMapSource
  missingSchurIndexProvenance : LevelHistorySchurIndexBridgeMissingSchurIndexProvenanceStatus
  missingSchurIndexProvenance_eq :
    missingSchurIndexProvenance =
      LevelHistorySchurIndexBridgeMissingSchurIndexProvenanceStatus.missingGeneratedSchurIndexProvenance
  noFreeFintypeEnumerationStatus : LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus : LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus
  noFreeReplacementIndexStatus_eq :
    noFreeReplacementIndexStatus =
      LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus : LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus
  noLevelHistoryMatrixStatus_eq :
    noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus : LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  nextConsumerBlockedStatus : LevelHistorySchurIndexBridgeNextConsumerBlockedStatus
  nextConsumerBlockedStatus_eq :
    nextConsumerBlockedStatus = LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess

namespace GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromLevelHistorySchurIndexWitness
    (W6 : GeneratedLevelStepWitnessLevelHistoryToSchurIndex Cell p A P wp W E K T M S H G) :
    GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G where
  sourceLevelHistorySchurIndexWitness := W6
  witnessAt := fun k => GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource W6.sourceGeneratedArithmeticSourceLedger W6.level k
  witnessAtSourceEqGeneratedArithmeticSource := by
    intro k
    rfl
  witnessAt_boundaryCarrier_eq_generated := by
    intro k
    rfl
  witnessAtBoundaryOperatorEqGeneratedArithmeticSource := by
    intro k
    rfl
  witnessAt_boundaryOperator_eq_schur := by
    intro k
    exact (GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource W6.sourceGeneratedArithmeticSourceLedger W6.level k).boundaryOperator_eq_schur
  witnessAt_apply_eq_mulVec := by
    intro k φ
    exact (GeneratedLevelStepWitnessLevelHistoryToSchurIndex.fromGeneratedArithmeticSource W6.sourceGeneratedArithmeticSourceLedger W6.level k).apply_eq_mulVec φ
  outcome := LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  outcome_eq_obstruction := by
    rfl
  missingLevelToBoundaryMapSource :=
    LevelHistorySchurIndexBridgeMissingLevelToBoundaryMapSourceStatus.missingGeneratedLevelHistoryToBoundaryMapSource
  missingLevelToBoundaryMapSource_eq := by
    rfl
  missingSchurIndexProvenance :=
    LevelHistorySchurIndexBridgeMissingSchurIndexProvenanceStatus.missingGeneratedSchurIndexProvenance
  missingSchurIndexProvenance_eq := by
    rfl
  noFreeFintypeEnumerationStatus := LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noFreeReplacementIndexStatus := LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus_eq := by
    rfl
  noLevelHistoryMatrixStatus := LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl
  nextConsumerBlockedStatus := LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess
  nextConsumerBlockedStatus_eq := by
    rfl

theorem outcome_is_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.outcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  O.outcome_eq_obstruction

theorem missingLevelToBoundaryMapSource_is_recorded
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.missingLevelToBoundaryMapSource =
      LevelHistorySchurIndexBridgeMissingLevelToBoundaryMapSourceStatus.missingGeneratedLevelHistoryToBoundaryMapSource :=
  O.missingLevelToBoundaryMapSource_eq

theorem missingSchurIndexProvenance_is_recorded
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.missingSchurIndexProvenance =
      LevelHistorySchurIndexBridgeMissingSchurIndexProvenanceStatus.missingGeneratedSchurIndexProvenance :=
  O.missingSchurIndexProvenance_eq

theorem noFreeFintypeEnumeration_for_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge :=
  O.noFreeFintypeEnumerationStatus_eq

theorem noFreeReplacementIndex_for_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.noFreeReplacementIndexStatus =
      LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge :=
  O.noFreeReplacementIndexStatus_eq

theorem noLevelHistoryMatrix_for_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge :=
  O.noLevelHistoryMatrixStatus_eq

theorem noCharpolyDiscriminant_for_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge :=
  O.noCharpolyDiscriminantStatus_eq

theorem levelHistoryMatrix_blocked_for_obstruction
    (O : GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G) :
    O.nextConsumerBlockedStatus = LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess :=
  O.nextConsumerBlockedStatus_eq

end GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge

structure LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceLevelHistoryToSchurIndexLedger : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight
  level : Nat
  levelEqLevelHistoryToSchurIndex : level = sourceLevelHistoryToSchurIndexLedger.level
  regularWitnessAt : (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistoryToSchurIndexLedger.level) →
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableWitnessAt : (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex sourceLevelHistoryToSchurIndexLedger.level) →
    GeneratedLevelStepWitnessLevelHistoryToSchurIndex
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularWitnessAtEqFromGeneratedArithmeticSource : ∀ k,
    regularWitnessAt k =
      regularGeneratedLevelStepWitnessFromGeneratedArithmeticSource sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger
        sourceLevelHistoryToSchurIndexLedger.level k
  variableWitnessAtEqFromGeneratedArithmeticSource : ∀ k,
    variableWitnessAt k =
      variableGeneratedLevelStepWitnessFromGeneratedArithmeticSource sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger
        sourceLevelHistoryToSchurIndexLedger.level k
  regularObstruction :
    GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableObstruction :
    GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  regularOutcome_eq : regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  variableOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  variableOutcome_eq : variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  noFreeFintypeEnumerationStatus : LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus : LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus
  noFreeReplacementIndexStatus_eq :
    noFreeReplacementIndexStatus = LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus : LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus
  noLevelHistoryMatrixStatus_eq :
    noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus : LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  nextConsumerBlockedStatus : LevelHistorySchurIndexBridgeNextConsumerBlockedStatus
  nextConsumerBlockedStatus_eq :
    nextConsumerBlockedStatus = LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess

def levelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryToSchurIndexGeneratedLevelStepWitnessLedger b β p regularWeight variableWeight) :
    LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight where
  sourceLevelHistoryToSchurIndexLedger := L
  level := L.level
  levelEqLevelHistoryToSchurIndex := by
    rfl
  regularWitnessAt := fun k =>
    regularGeneratedLevelStepWitnessFromGeneratedArithmeticSource L.sourceGeneratedArithmeticSourceLedger L.level k
  variableWitnessAt := fun k =>
    variableGeneratedLevelStepWitnessFromGeneratedArithmeticSource L.sourceGeneratedArithmeticSourceLedger L.level k
  regularWitnessAtEqFromGeneratedArithmeticSource := by
    intro k
    rfl
  variableWitnessAtEqFromGeneratedArithmeticSource := by
    intro k
    rfl
  regularObstruction :=
    GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge.fromLevelHistorySchurIndexWitness L.regularWitness
  variableObstruction :=
    GeneratedLevelHistorySchurIndexObstructionLevelHistorySchurIndexBridge.fromLevelHistorySchurIndexWitness L.variableWitness
  regularOutcome := LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  regularOutcome_eq := by
    rfl
  variableOutcome := LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  variableOutcome_eq := by
    rfl
  noFreeFintypeEnumerationStatus := LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noFreeReplacementIndexStatus := LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus_eq := by
    rfl
  noLevelHistoryMatrixStatus := LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl
  nextConsumerBlockedStatus := LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess
  nextConsumerBlockedStatus_eq := by
    rfl

theorem levelHistorySchurIndexBridgeGate_regular_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  G7.regularOutcome_eq

theorem levelHistorySchurIndexBridgeGate_variable_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  G7.variableOutcome_eq

theorem levelHistorySchurIndexBridgeGate_noFreeFintypeEnumeration
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge :=
  G7.noFreeFintypeEnumerationStatus_eq

theorem levelHistorySchurIndexBridgeGate_noFreeReplacementIndex
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.noFreeReplacementIndexStatus = LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge :=
  G7.noFreeReplacementIndexStatus_eq

theorem levelHistorySchurIndexBridgeGate_noLevelHistoryMatrix
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge :=
  G7.noLevelHistoryMatrixStatus_eq

theorem levelHistorySchurIndexBridgeGate_noCharpolyDiscriminant
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge :=
  G7.noCharpolyDiscriminantStatus_eq

theorem levelHistorySchurIndexBridgeGate_levelHistoryMatrix_blocked
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (G7 : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight) :
    G7.nextConsumerBlockedStatus = LevelHistorySchurIndexBridgeNextConsumerBlockedStatus.levelHistoryMatrixBlockedUntilBridgeSuccess :=
  G7.nextConsumerBlockedStatus_eq

end CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryToSchurIndex
