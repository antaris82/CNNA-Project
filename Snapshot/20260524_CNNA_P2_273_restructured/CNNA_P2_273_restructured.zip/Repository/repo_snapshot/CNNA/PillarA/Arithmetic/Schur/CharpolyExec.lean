import CNNA.PillarA.Generator.Schur.Arithmetic.CharpolyExec
