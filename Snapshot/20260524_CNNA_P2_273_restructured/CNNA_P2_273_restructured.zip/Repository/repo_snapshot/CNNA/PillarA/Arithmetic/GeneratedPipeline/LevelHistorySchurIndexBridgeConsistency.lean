import CNNA.PillarA.Arithmetic.SourceAndApproximation.LevelHistoryBoundaryPortSource
import CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryToSchurIndex
import CNNA.PillarA.Generator.LevelHistory.SchurIndex.LevelHistorySchurIndexBridgeConsistency

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistorySchurIndexBridgeConsistency

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC
open CNNA.PillarA.DtN
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ApproximantCore
open CNNA.PillarA.Arithmetic.GeneratedPipeline.BoundaryInteriorPartition
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DirichletEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlock
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCarrier
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationStep
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateEntry
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedTraceEvaluation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldNormalForm
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationSourceAudit
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepSchurCancellationInvariant
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorPerPivotRegularityFromTrace
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTracePivotScaleWitnessFromGeneratedDegree
open CNNA.PillarA.Arithmetic.SourceAndApproximation.DegreePivotScaleSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreeFormulaFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.DegreePivotReciprocalProfileFromWeightPolicy
open CNNA.PillarA.Arithmetic.GeneratedPipeline.OperationalDegreeReciprocalSource
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldKernelLocalSchurResidualBridge
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorLocalStepCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldInvariance
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateMatrix
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateShapeSeparation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorInverseCandidateHandoff
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualCoverage
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTerminalFoldResidualIdentityFields
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorBlockFoldTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorAccumulatedEntryCancellationFromTerminalIdentity
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellationDerivation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorTraceCancellation
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProductIdentityProof
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorProvenTwoSidedInv
open CNNA.PillarA.Arithmetic.GeneratedPipeline.InteriorEliminationCertificate
open CNNA.PillarA.Arithmetic.GeneratedPipeline.TopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedTopBoundaryDtN
open CNNA.PillarA.Arithmetic.GeneratedPipeline.GeneralizedDtNToMultiSchurSourceLedger
open CNNA.PillarA.Arithmetic.GeneratedPipeline.MultiSchur
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelStepWitness
open CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistoryToSchurIndex
open CNNA.PillarA.Arithmetic.SourceAndApproximation.ArithmeticSource
open CNNA.PillarA.Arithmetic.SourceAndApproximation.LevelHistoryBoundaryPortSource

universe u

inductive LevelHistorySchurIndexBridgeSourceStatus where
  | consumedLevelHistoryBoundaryPortSource
  deriving DecidableEq, Repr

abbrev LevelHistorySchurIndexBridgeBridgeRecheckSourceStatus :=
  LevelHistorySchurIndexBridgeSourceStatus

namespace LevelHistorySchurIndexBridgeBridgeRecheckSourceStatus

def consumedLevelHistoryBoundaryPortBoundaryPortSource :
    LevelHistorySchurIndexBridgeBridgeRecheckSourceStatus :=
  LevelHistorySchurIndexBridgeSourceStatus.consumedLevelHistoryBoundaryPortSource

end LevelHistorySchurIndexBridgeBridgeRecheckSourceStatus

inductive LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus where
  | levelHistoryMatrixReleasedAfterBridgeSuccess
  deriving DecidableEq, Repr

abbrev LevelHistorySchurIndexBridgeBridgeRecheckLevelHistoryMatrixFromBridgeGateStatus :=
  LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus

namespace LevelHistorySchurIndexBridgeBridgeRecheckLevelHistoryMatrixFromBridgeGateStatus

def levelHistoryMatrixReleasedAfterRegularVariableBridgeSuccess :
    LevelHistorySchurIndexBridgeBridgeRecheckLevelHistoryMatrixFromBridgeGateStatus :=
  LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus.levelHistoryMatrixReleasedAfterBridgeSuccess

end LevelHistorySchurIndexBridgeBridgeRecheckLevelHistoryMatrixFromBridgeGateStatus

namespace GeneratedLevelHistorySchurIndexBridge

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {p : ConcretePolicyOf}
variable {A : GeneratedApproximantStrong Cell p}
variable [Fintype (GeneratedBoundaryIndex A)]
variable [Fintype (GeneratedInteriorIndex A)]
variable [DecidableEq (GeneratedInteriorIndex A)]
variable {P : GeneratedBoundaryInteriorPartition Cell p A}
variable {wp : WeightPolicy}
variable {W : GeneratedWeightPolicyEntrySource Cell p A P wp}
variable {E : GeneratedInteriorEliminationCandidateEntry Cell p A P wp W}
variable {K : GeneratedInteriorEliminationCarrier Cell p A P wp W E}
variable {T : GeneratedInteriorEliminationTrace Cell p A P wp W E K}
variable {M : GeneratedInteriorInverseCandidateMatrix Cell p A P wp W E K T}
variable {S : GeneratedInteriorInverseCandidateShapeSeparation Cell p A P wp W E K T M}
variable {H : InteriorInverseCandidateValidationHandoff Cell p A P wp W E K T M S}
variable {G : GeneratedMultiSchurGeneratedMultiSchur Cell p A P wp W E K T M S H}

def fromLevelHistoryBoundaryPort
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    GeneratedLevelHistorySchurIndexBridge Cell p A P wp W E K T M S H G where
  sourceLevelHistorySchurIndexWitness := B.sourceLevelHistorySchurIndexWitness
  witnessAt := B.witnessAt
  witnessAtSourceEqLevelHistoryToSchurIndex := by
    intro k
    exact B.witnessAtSourceEqLevelHistoryToSchurIndex k
  witnessAt_boundaryCarrier_eq_generated := by
    intro k
    exact (B.witnessAt k).boundaryCarrier_eq_generated
  toBoundaryIndex := B.toBoundaryIndex
  toBoundaryIndex_sourceStatus :=
    LevelHistorySchurIndexBridgeGeneratedIndexMapSourceStatus.generatedHistoryToBoundaryMapSourceRequired
  toBoundaryIndex_sourceStatus_eq := by
    rfl
  toBoundaryIndex_level_eq_cutoff := by
    intro k
    exact B.toBoundaryIndex_level_eq_cutoff k
  boundaryOperatorFromLevelHistoryToSchurIndex := by
    exact B.boundaryOperatorFromLevelHistoryToSchurIndex
  boundaryOperator_from_schur := by
    exact B.boundaryOperator_from_schur
  noFreeFintypeEnumerationStatus := LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noLevelHistoryMatrixStatus := LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl

theorem fromLevelHistoryBoundaryPortSourceLevelHistorySchurIndexWitness
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness = B.sourceLevelHistorySchurIndexWitness := by
  rfl

theorem fromLevelHistoryBoundaryPortWitnessAtSourceEqLevelHistoryToSchurIndex
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.level) :
    ((fromLevelHistoryBoundaryPort B).witnessAt k).sourceGeneratedArithmeticSourceLedger =
      (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.sourceGeneratedArithmeticSourceLedger :=
  (fromLevelHistoryBoundaryPort B).witnessAtSourceEqLevelHistoryToSchurIndex k

theorem fromLevelHistoryBoundaryPortWitnessAtBoundaryCarrierEqGenerated
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.level) :
    ((fromLevelHistoryBoundaryPort B).witnessAt k).boundaryCarrier = GeneratedBoundaryIndex A :=
  (fromLevelHistoryBoundaryPort B).witnessAt_boundaryCarrier_eq_generated k

theorem fromLevelHistoryBoundaryPortToBoundaryIndexLevelEqCutoff
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G)
    (k : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.level) :
    (GeneratedBoundaryIndex.level ((fromLevelHistoryBoundaryPort B).toBoundaryIndex k)).val = p.L_max :=
  (fromLevelHistoryBoundaryPort B).toBoundaryIndex_level_eq_cutoff k

theorem fromLevelHistoryBoundaryPortBoundaryOperatorFromLevelHistoryToSchurIndex
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.boundaryOperator =
      (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.source.boundaryOperator :=
  (fromLevelHistoryBoundaryPort B).boundaryOperatorFromLevelHistoryToSchurIndex

theorem fromLevelHistoryBoundaryPortBoundaryOperatorFromSchur
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.boundaryOperator =
      generatedBoundaryBlockGeneralizedTopBoundaryDtN W -
        generatedBoundaryInteriorBlockGeneralizedTopBoundaryDtN W *
          (fromLevelHistoryBoundaryPort B).sourceLevelHistorySchurIndexWitness.source.sourceMultiSchur.sourceInteriorEliminationCertificate.inverseMatrix *
          generatedInteriorBoundaryBlockGeneralizedTopBoundaryDtN W :=
  (fromLevelHistoryBoundaryPort B).boundaryOperator_from_schur

theorem fromLevelHistoryBoundaryPortNoLevelHistoryMatrix
    (B : GeneratedLevelHistoryBoundaryPortSourceLevelHistoryBoundaryPort Cell p A P wp W E K T M S H G) :
    (fromLevelHistoryBoundaryPort B).noLevelHistoryMatrixStatus =
      LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge :=
  (fromLevelHistoryBoundaryPort B).noLevelHistoryMatrixStatus_eq

end GeneratedLevelHistorySchurIndexBridge

def regularGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistorySchurIndexBridge
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      L.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur :=
  GeneratedLevelHistorySchurIndexBridge.fromLevelHistoryBoundaryPort L.regularSource

def variableGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    GeneratedLevelHistorySchurIndexBridge
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      L.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur :=
  GeneratedLevelHistorySchurIndexBridge.fromLevelHistoryBoundaryPort L.variableSource

structure LevelHistorySchurIndexBridgeConsistencyLedger
    (b : Nat) (β : Nat → Nat) (p : ConcretePolicyOf)
    (regularWeight variableWeight : WeightPolicy) where
  sourceLevelHistoryBoundaryPortLedger : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight
  historicalLevelHistorySchurIndexBridgeGate : LevelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate b β p regularWeight variableWeight
  historicalLevelHistorySchurIndexBridgeGateEq :
    historicalLevelHistorySchurIndexBridgeGate = levelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger
  historicalRegularOutcome_eq_obstruction :
    historicalLevelHistorySchurIndexBridgeGate.regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  historicalVariableOutcome_eq_obstruction :
    historicalLevelHistorySchurIndexBridgeGate.variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource
  regularBridge :
    GeneratedLevelHistorySchurIndexBridge
      (ConcreteSubstrate.RegularCell b) p (regularGeneratedApproximantStrong b p)
      (regularGeneratedBoundaryInteriorPartition b p) regularWeight
      (regularGeneratedWeightPolicyEntrySource b p regularWeight)
      (regularGeneratedInteriorEliminationCandidateEntry b p regularWeight)
      (regularGeneratedInteriorEliminationCarrier b p regularWeight)
      (regularGeneratedInteriorEliminationTrace b p regularWeight)
      (regularGeneratedInteriorInverseCandidateMatrix b p regularWeight)
      (regularGeneratedInteriorInverseCandidateShapeSeparation b p regularWeight)
      (regularInteriorInverseCandidateValidationHandoff b p regularWeight)
      sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.regularMultiSchur
  variableBridge :
    GeneratedLevelHistorySchurIndexBridge
      (LevelVariableSubstrate.LevelVariableCell β) p (variableGeneratedApproximantStrong β p)
      (variableGeneratedBoundaryInteriorPartition β p) variableWeight
      (variableGeneratedWeightPolicyEntrySource β p variableWeight)
      (variableGeneratedInteriorEliminationCandidateEntry β p variableWeight)
      (variableGeneratedInteriorEliminationCarrier β p variableWeight)
      (variableGeneratedInteriorEliminationTrace β p variableWeight)
      (variableGeneratedInteriorInverseCandidateMatrix β p variableWeight)
      (variableGeneratedInteriorInverseCandidateShapeSeparation β p variableWeight)
      (variableInteriorInverseCandidateValidationHandoff β p variableWeight)
      sourceLevelHistoryBoundaryPortLedger.sourceLevelHistoryToSchurIndexLedger.sourceGeneratedArithmeticSourceLedger.sourceGeneratedMultiSchurLedger.variableMultiSchur
  regularBridgeEqFromLevelHistoryBoundaryPort :
    regularBridge = regularGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort sourceLevelHistoryBoundaryPortLedger
  variableBridgeEqFromLevelHistoryBoundaryPort :
    variableBridge = variableGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort sourceLevelHistoryBoundaryPortLedger
  regularSourceStatus : LevelHistorySchurIndexBridgeSourceStatus
  regularSourceStatus_eq :
    regularSourceStatus = LevelHistorySchurIndexBridgeSourceStatus.consumedLevelHistoryBoundaryPortSource
  variableSourceStatus : LevelHistorySchurIndexBridgeSourceStatus
  variableSourceStatus_eq :
    variableSourceStatus = LevelHistorySchurIndexBridgeSourceStatus.consumedLevelHistoryBoundaryPortSource
  regularOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  regularOutcome_eq : regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  variableOutcome : LevelHistorySchurIndexBridgeBridgeOutcome
  variableOutcome_eq : variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  noFreeFintypeEnumerationStatus : LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus
  noFreeFintypeEnumerationStatus_eq :
    noFreeFintypeEnumerationStatus =
      LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus : LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus
  noFreeReplacementIndexStatus_eq :
    noFreeReplacementIndexStatus = LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus : LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus
  noLevelHistoryMatrixStatus_eq :
    noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus : LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus
  noCharpolyDiscriminantStatus_eq :
    noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  levelHistoryMatrixGateStatus : LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus
  levelHistoryMatrixGateStatus_eq :
    levelHistoryMatrixGateStatus =
      LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus.levelHistoryMatrixReleasedAfterBridgeSuccess

abbrev LevelHistorySchurIndexBridgeBridgeRecheckLedger :=
  LevelHistorySchurIndexBridgeConsistencyLedger

def levelHistorySchurIndexBridgeConsistencyLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight where
  sourceLevelHistoryBoundaryPortLedger := L
  historicalLevelHistorySchurIndexBridgeGate := levelHistorySchurIndexBridgeGeneratedLevelHistoryToSchurIndexGate L.sourceLevelHistoryToSchurIndexLedger
  historicalLevelHistorySchurIndexBridgeGateEq := by
    rfl
  historicalRegularOutcome_eq_obstruction := by
    rfl
  historicalVariableOutcome_eq_obstruction := by
    rfl
  regularBridge := regularGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L
  variableBridge := variableGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L
  regularBridgeEqFromLevelHistoryBoundaryPort := by
    rfl
  variableBridgeEqFromLevelHistoryBoundaryPort := by
    rfl
  regularSourceStatus := LevelHistorySchurIndexBridgeSourceStatus.consumedLevelHistoryBoundaryPortSource
  regularSourceStatus_eq := by
    rfl
  variableSourceStatus := LevelHistorySchurIndexBridgeSourceStatus.consumedLevelHistoryBoundaryPortSource
  variableSourceStatus_eq := by
    rfl
  regularOutcome := LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  regularOutcome_eq := by
    rfl
  variableOutcome := LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess
  variableOutcome_eq := by
    rfl
  noFreeFintypeEnumerationStatus := LevelHistorySchurIndexBridgeNoFreeFintypeEnumerationStatus.noFreeFintypeEnumerationInLevelHistorySchurIndexBridge
  noFreeFintypeEnumerationStatus_eq := by
    rfl
  noFreeReplacementIndexStatus := LevelHistorySchurIndexBridgeNoFreeReplacementIndexStatus.noFreeReplacementIndexInLevelHistorySchurIndexBridge
  noFreeReplacementIndexStatus_eq := by
    rfl
  noLevelHistoryMatrixStatus := LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge
  noLevelHistoryMatrixStatus_eq := by
    rfl
  noCharpolyDiscriminantStatus :=
    LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge
  noCharpolyDiscriminantStatus_eq := by
    rfl
  levelHistoryMatrixGateStatus := LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus.levelHistoryMatrixReleasedAfterBridgeSuccess
  levelHistoryMatrixGateStatus_eq := by
    rfl

def levelHistorySchurIndexBridgeBridgeRecheckLedger
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistoryBoundaryPortGeneratedLevelHistoryBoundaryPortSourceLedger b β p regularWeight variableWeight) :
    LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight :=
  levelHistorySchurIndexBridgeConsistencyLedger L

def levelHistorySchurIndexBridgeConsistencyLedgerFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight :=
  levelHistorySchurIndexBridgeConsistencyLedger
    (levelHistoryBoundaryPortSourceGeneratedLevelHistoryBoundaryPortSourceLedgerFromGeneratedArithmeticSource L level levelIndex)

def levelHistorySchurIndexBridgeBridgeRecheckLedgerFromGeneratedArithmeticSource
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : GeneratedArithmeticSourceLedgerLevelHistoryMatrixFromBridgeRefF989 b β p regularWeight variableWeight)
    (level : Nat)
    (levelIndex : GeneratedLevelHistoryIndexLevelHistoryToSchurIndex level) :
    LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight :=
  levelHistorySchurIndexBridgeConsistencyLedgerFromGeneratedArithmeticSource L level levelIndex

theorem levelHistorySchurIndexBridgeConsistency_regular_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  L.regularOutcome_eq

theorem levelHistorySchurIndexBridgeConsistency_variable_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  L.variableOutcome_eq

theorem levelHistorySchurIndexBridgeConsistency_historical_regular_outcome_is_obstruction
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.historicalLevelHistorySchurIndexBridgeGate.regularOutcome =
      LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  L.historicalRegularOutcome_eq_obstruction

theorem levelHistorySchurIndexBridgeConsistency_historical_variable_outcome_is_obstruction
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.historicalLevelHistorySchurIndexBridgeGate.variableOutcome =
      LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  L.historicalVariableOutcome_eq_obstruction

theorem levelHistorySchurIndexBridgeConsistencyRegularBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.regularBridge = regularGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L.sourceLevelHistoryBoundaryPortLedger :=
  L.regularBridgeEqFromLevelHistoryBoundaryPort

theorem levelHistorySchurIndexBridgeConsistencyVariableBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.variableBridge = variableGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L.sourceLevelHistoryBoundaryPortLedger :=
  L.variableBridgeEqFromLevelHistoryBoundaryPort

theorem levelHistorySchurIndexBridgeConsistency_levelHistoryMatrix_gate_released
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.levelHistoryMatrixGateStatus =
      LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus.levelHistoryMatrixReleasedAfterBridgeSuccess :=
  L.levelHistoryMatrixGateStatus_eq

theorem levelHistorySchurIndexBridgeConsistency_noLevelHistoryMatrix
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge :=
  L.noLevelHistoryMatrixStatus_eq

theorem levelHistorySchurIndexBridgeConsistency_noCharpolyDiscriminant
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeConsistencyLedger b β p regularWeight variableWeight) :
    L.noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge :=
  L.noCharpolyDiscriminantStatus_eq


theorem levelHistorySchurIndexBridgeBridgeRecheck_regular_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.regularOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  levelHistorySchurIndexBridgeConsistency_regular_outcome L

theorem levelHistorySchurIndexBridgeBridgeRecheck_variable_outcome
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.variableOutcome = LevelHistorySchurIndexBridgeBridgeOutcome.bridgeSuccess :=
  levelHistorySchurIndexBridgeConsistency_variable_outcome L

theorem levelHistorySchurIndexBridgeBridgeRecheck_historical_regular_outcome_is_obstruction
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.historicalLevelHistorySchurIndexBridgeGate.regularOutcome =
      LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  levelHistorySchurIndexBridgeConsistency_historical_regular_outcome_is_obstruction L

theorem levelHistorySchurIndexBridgeBridgeRecheck_historical_variable_outcome_is_obstruction
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.historicalLevelHistorySchurIndexBridgeGate.variableOutcome =
      LevelHistorySchurIndexBridgeBridgeOutcome.obstructionMissingGeneratedIndexSource :=
  levelHistorySchurIndexBridgeConsistency_historical_variable_outcome_is_obstruction L

theorem levelHistorySchurIndexBridgeBridgeRecheckRegularBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.regularBridge = regularGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L.sourceLevelHistoryBoundaryPortLedger :=
  levelHistorySchurIndexBridgeConsistencyRegularBridgeFromLevelHistoryBoundaryPort L

theorem levelHistorySchurIndexBridgeBridgeRecheckVariableBridgeFromLevelHistoryBoundaryPort
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.variableBridge = variableGeneratedLevelHistorySchurIndexBridgeFromLevelHistoryBoundaryPort L.sourceLevelHistoryBoundaryPortLedger :=
  levelHistorySchurIndexBridgeConsistencyVariableBridgeFromLevelHistoryBoundaryPort L

theorem levelHistorySchurIndexBridgeBridgeRecheck_levelHistoryMatrix_gate_released
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.levelHistoryMatrixGateStatus =
      LevelHistorySchurIndexBridgeLevelHistoryMatrixGateStatus.levelHistoryMatrixReleasedAfterBridgeSuccess :=
  levelHistorySchurIndexBridgeConsistency_levelHistoryMatrix_gate_released L

theorem levelHistorySchurIndexBridgeBridgeRecheck_noLevelHistoryMatrix
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.noLevelHistoryMatrixStatus = LevelHistorySchurIndexBridgeNoLevelHistoryMatrixStatus.noLevelHistoryMatrixInLevelHistorySchurIndexBridge :=
  levelHistorySchurIndexBridgeConsistency_noLevelHistoryMatrix L

theorem levelHistorySchurIndexBridgeBridgeRecheck_noCharpolyDiscriminant
    {b : Nat} {β : Nat → Nat} {p : ConcretePolicyOf}
    {regularWeight variableWeight : WeightPolicy}
    (L : LevelHistorySchurIndexBridgeBridgeRecheckLedger b β p regularWeight variableWeight) :
    L.noCharpolyDiscriminantStatus =
      LevelHistorySchurIndexBridgeNoCharpolyDiscriminantStatus.noCharpolyFactorDiscriminantDataInLevelHistorySchurIndexBridge :=
  levelHistorySchurIndexBridgeConsistency_noCharpolyDiscriminant L

end CNNA.PillarA.Arithmetic.GeneratedPipeline.LevelHistorySchurIndexBridgeConsistency
