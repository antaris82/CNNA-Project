import CNNA.PillarA.Generator.Schur.Arithmetic.CharpolyC
