import CNNA.PillarA.Arithmetic.CayleyDickson.ArithmeticCDBridge
import CNNA.PillarA.Arithmetic.Orders.NormForms

set_option autoImplicit false

namespace CNNA.PillarA.Arithmetic

open CNNA.PillarA.Foundation
open CNNA.PillarA.ToC

universe u

namespace Convergence

variable {Cell : Nat → Type u} [SubstrateClass Cell]
variable {T : TruncatedFamily Cell}
variable {source : ArithmeticSource Cell T} {L : Nat}

inductive DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification where
  | gaussianDMinusFourCompatibility
  | eisensteinDMinusThreeCompatibility
  | imaginaryQuadraticOrderCompatibility
  | higherDegreeOrIrreducibleCDCObstruction
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus where
  | quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityScalarComparisonStatus where
  | scalarDataComparedOnlyThroughExplicitTransfer
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityNormComparisonStatus where
  | normAndNormFormDataComparedOnlyThroughCertificates
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityConjugationComparisonStatus where
  | conjugationDataKeptSeparateUntilTransferLemma
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityFormComparisonStatus where
  | quadraticFormDataComparedNoAlgebraIdentification
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus where
  | periodLatticePeriodLatticePreparationOnly
  | blockedForNonQuadraticOutcome
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus where
  | noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityDerivedOnlyStatus where
  | ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  deriving DecidableEq, Repr

inductive DiscriminantAlgebraCompatibilityCDCObstructionStatus where
  | nonQuadraticOutcomeBlockedFromCDComplexIdentification
  deriving DecidableEq, Repr

structure ImaginaryQuadraticDiscriminantWitness
    (Q : Orders.QuadraticNormFormCertificate) where
  discriminant : ℤ
  discriminant_eq_normDiscriminant : discriminant = Q.normDiscriminant
  negative : discriminant < 0

namespace ImaginaryQuadraticDiscriminantWitness

def gaussian : ImaginaryQuadraticDiscriminantWitness Orders.QuadraticNormFormCertificate.gaussian where
  discriminant := -4
  discriminant_eq_normDiscriminant := by
    rfl
  negative := by
    decide

def eisenstein : ImaginaryQuadraticDiscriminantWitness Orders.QuadraticNormFormCertificate.eisenstein where
  discriminant := -3
  discriminant_eq_normDiscriminant := by
    rfl
  negative := by
    decide

theorem discriminant_matches_norm
    {Q : Orders.QuadraticNormFormCertificate}
    (W : ImaginaryQuadraticDiscriminantWitness Q) :
    W.discriminant = Q.normDiscriminant :=
  W.discriminant_eq_normDiscriminant

end ImaginaryQuadraticDiscriminantWitness

structure QuadraticOrderCDCompatibilitySurface
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter)
    (Q : Orders.QuadraticNormFormCertificate) where
  bridge : CayleyDickson.CDComplexArithmeticBridge source X L z
  discriminantWitness : ImaginaryQuadraticDiscriminantWitness Q
  orderDiscriminant_eq_normDiscriminant :
    Q.orderCertificate.order.discriminant = Q.normDiscriminant
  classification : DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification
  classification_eq :
    classification = DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.imaginaryQuadraticOrderCompatibility ∨
      classification = DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.gaussianDMinusFourCompatibility ∨
        classification = DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.eisensteinDMinusThreeCompatibility
  noOrderCDEqualityStatus : DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus
  noOrderCDEqualityStatus_eq :
    noOrderCDEqualityStatus =
      DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  scalarComparisonStatus : DiscriminantAlgebraCompatibilityScalarComparisonStatus
  scalarComparisonStatus_eq :
    scalarComparisonStatus =
      DiscriminantAlgebraCompatibilityScalarComparisonStatus.scalarDataComparedOnlyThroughExplicitTransfer
  normComparisonStatus : DiscriminantAlgebraCompatibilityNormComparisonStatus
  normComparisonStatus_eq :
    normComparisonStatus =
      DiscriminantAlgebraCompatibilityNormComparisonStatus.normAndNormFormDataComparedOnlyThroughCertificates
  conjugationComparisonStatus : DiscriminantAlgebraCompatibilityConjugationComparisonStatus
  conjugationComparisonStatus_eq :
    conjugationComparisonStatus =
      DiscriminantAlgebraCompatibilityConjugationComparisonStatus.conjugationDataKeptSeparateUntilTransferLemma
  formComparisonStatus : DiscriminantAlgebraCompatibilityFormComparisonStatus
  formComparisonStatus_eq :
    formComparisonStatus =
      DiscriminantAlgebraCompatibilityFormComparisonStatus.quadraticFormDataComparedNoAlgebraIdentification
  periodLatticePreparationStatus : DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus
  periodLatticePreparationStatus_eq :
    periodLatticePreparationStatus =
      DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.periodLatticePeriodLatticePreparationOnly
  downstreamDisciplineStatus : DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus
  downstreamDisciplineStatus_eq :
    downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  derivedOnlyStatus : DiscriminantAlgebraCompatibilityDerivedOnlyStatus
  derivedOnlyStatus_eq :
    derivedOnlyStatus = DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  cdBridgeClosed :
    bridge.bridgeStatus = CayleyDickson.CayleyDicksonBoundaryBridgeBridgeLedgerStatus.complexCouplingComplexCouplingTestClosed
  cdNoIdentification :
    bridge.noIdentificationStatus =
      CayleyDickson.CayleyDicksonBoundaryBridgeNoIdentificationStatus.noExecMirrorCDComplexIdentificationWithoutTransferLemma
  cdSharedSchur : X.schur = source.multiSchur
  schurDiscriminantBridge :
    Q.bridge.schurDiscriminant =
      ((Q.bridge.conductor * Q.bridge.conductor : Nat) : ℤ) * Q.bridge.fundamentalDiscriminant
  noIrreduciblePrimeShortcut :
    Q.irreduciblePrimeDisciplineStatus =
      Orders.IrreduciblePrimeDisciplineStatus.noIrreduciblePrimeEquivalenceWithoutClassNumberOrUFD

namespace QuadraticOrderCDCompatibilitySurface

variable {X : CayleyDickson.StructuralCDSource Cell T}
variable {z : Schur.SpectralParameter}

def fromImaginaryQuadratic
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    (Q : Orders.QuadraticNormFormCertificate)
    (W : ImaginaryQuadraticDiscriminantWitness Q)
    (hOrderNorm : Q.orderCertificate.order.discriminant = Q.normDiscriminant) :
    QuadraticOrderCDCompatibilitySurface (source := source) X L z Q where
  bridge := Bdg
  discriminantWitness := W
  orderDiscriminant_eq_normDiscriminant := hOrderNorm
  classification := DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.imaginaryQuadraticOrderCompatibility
  classification_eq := Or.inl rfl
  noOrderCDEqualityStatus :=
    DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  noOrderCDEqualityStatus_eq := by
    rfl
  scalarComparisonStatus := DiscriminantAlgebraCompatibilityScalarComparisonStatus.scalarDataComparedOnlyThroughExplicitTransfer
  scalarComparisonStatus_eq := by
    rfl
  normComparisonStatus := DiscriminantAlgebraCompatibilityNormComparisonStatus.normAndNormFormDataComparedOnlyThroughCertificates
  normComparisonStatus_eq := by
    rfl
  conjugationComparisonStatus :=
    DiscriminantAlgebraCompatibilityConjugationComparisonStatus.conjugationDataKeptSeparateUntilTransferLemma
  conjugationComparisonStatus_eq := by
    rfl
  formComparisonStatus := DiscriminantAlgebraCompatibilityFormComparisonStatus.quadraticFormDataComparedNoAlgebraIdentification
  formComparisonStatus_eq := by
    rfl
  periodLatticePreparationStatus := DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.periodLatticePeriodLatticePreparationOnly
  periodLatticePreparationStatus_eq := by
    rfl
  downstreamDisciplineStatus :=
    DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  downstreamDisciplineStatus_eq := by
    rfl
  derivedOnlyStatus := DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  derivedOnlyStatus_eq := by
    rfl
  cdBridgeClosed := CayleyDickson.CDComplexArithmeticBridge.status_closed Bdg
  cdNoIdentification := CayleyDickson.CDComplexArithmeticBridge.no_exec_mirror_cd_identification Bdg
  cdSharedSchur := CayleyDickson.CDComplexArithmeticBridge.shared_schur_provenance Bdg
  schurDiscriminantBridge := Orders.QuadraticNormFormCertificate.schur_to_fundamental_bridge Q
  noIrreduciblePrimeShortcut := Orders.QuadraticNormFormCertificate.no_irreducible_prime_shortcut Q

def gaussian
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    QuadraticOrderCDCompatibilitySurface (source := source) X L z Orders.QuadraticNormFormCertificate.gaussian where
  bridge := Bdg
  discriminantWitness := ImaginaryQuadraticDiscriminantWitness.gaussian
  orderDiscriminant_eq_normDiscriminant := by
    rfl
  classification := DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.gaussianDMinusFourCompatibility
  classification_eq := Or.inr (Or.inl rfl)
  noOrderCDEqualityStatus :=
    DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  noOrderCDEqualityStatus_eq := by
    rfl
  scalarComparisonStatus := DiscriminantAlgebraCompatibilityScalarComparisonStatus.scalarDataComparedOnlyThroughExplicitTransfer
  scalarComparisonStatus_eq := by
    rfl
  normComparisonStatus := DiscriminantAlgebraCompatibilityNormComparisonStatus.normAndNormFormDataComparedOnlyThroughCertificates
  normComparisonStatus_eq := by
    rfl
  conjugationComparisonStatus :=
    DiscriminantAlgebraCompatibilityConjugationComparisonStatus.conjugationDataKeptSeparateUntilTransferLemma
  conjugationComparisonStatus_eq := by
    rfl
  formComparisonStatus := DiscriminantAlgebraCompatibilityFormComparisonStatus.quadraticFormDataComparedNoAlgebraIdentification
  formComparisonStatus_eq := by
    rfl
  periodLatticePreparationStatus := DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.periodLatticePeriodLatticePreparationOnly
  periodLatticePreparationStatus_eq := by
    rfl
  downstreamDisciplineStatus :=
    DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  downstreamDisciplineStatus_eq := by
    rfl
  derivedOnlyStatus := DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  derivedOnlyStatus_eq := by
    rfl
  cdBridgeClosed := CayleyDickson.CDComplexArithmeticBridge.status_closed Bdg
  cdNoIdentification := CayleyDickson.CDComplexArithmeticBridge.no_exec_mirror_cd_identification Bdg
  cdSharedSchur := CayleyDickson.CDComplexArithmeticBridge.shared_schur_provenance Bdg
  schurDiscriminantBridge :=
    Orders.QuadraticNormFormCertificate.schur_to_fundamental_bridge
      Orders.QuadraticNormFormCertificate.gaussian
  noIrreduciblePrimeShortcut :=
    Orders.QuadraticNormFormCertificate.no_irreducible_prime_shortcut
      Orders.QuadraticNormFormCertificate.gaussian

def eisenstein
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    QuadraticOrderCDCompatibilitySurface (source := source) X L z Orders.QuadraticNormFormCertificate.eisenstein where
  bridge := Bdg
  discriminantWitness := ImaginaryQuadraticDiscriminantWitness.eisenstein
  orderDiscriminant_eq_normDiscriminant := by
    rfl
  classification := DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.eisensteinDMinusThreeCompatibility
  classification_eq := Or.inr (Or.inr rfl)
  noOrderCDEqualityStatus :=
    DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  noOrderCDEqualityStatus_eq := by
    rfl
  scalarComparisonStatus := DiscriminantAlgebraCompatibilityScalarComparisonStatus.scalarDataComparedOnlyThroughExplicitTransfer
  scalarComparisonStatus_eq := by
    rfl
  normComparisonStatus := DiscriminantAlgebraCompatibilityNormComparisonStatus.normAndNormFormDataComparedOnlyThroughCertificates
  normComparisonStatus_eq := by
    rfl
  conjugationComparisonStatus :=
    DiscriminantAlgebraCompatibilityConjugationComparisonStatus.conjugationDataKeptSeparateUntilTransferLemma
  conjugationComparisonStatus_eq := by
    rfl
  formComparisonStatus := DiscriminantAlgebraCompatibilityFormComparisonStatus.quadraticFormDataComparedNoAlgebraIdentification
  formComparisonStatus_eq := by
    rfl
  periodLatticePreparationStatus := DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.periodLatticePeriodLatticePreparationOnly
  periodLatticePreparationStatus_eq := by
    rfl
  downstreamDisciplineStatus :=
    DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  downstreamDisciplineStatus_eq := by
    rfl
  derivedOnlyStatus := DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  derivedOnlyStatus_eq := by
    rfl
  cdBridgeClosed := CayleyDickson.CDComplexArithmeticBridge.status_closed Bdg
  cdNoIdentification := CayleyDickson.CDComplexArithmeticBridge.no_exec_mirror_cd_identification Bdg
  cdSharedSchur := CayleyDickson.CDComplexArithmeticBridge.shared_schur_provenance Bdg
  schurDiscriminantBridge :=
    Orders.QuadraticNormFormCertificate.schur_to_fundamental_bridge
      Orders.QuadraticNormFormCertificate.eisenstein
  noIrreduciblePrimeShortcut :=
    Orders.QuadraticNormFormCertificate.no_irreducible_prime_shortcut
      Orders.QuadraticNormFormCertificate.eisenstein

def gaussianFromBoundarySource
    (B : BoundarySource.BoundarySourceSurface source L)
    (X : CayleyDickson.StructuralCDSource Cell T)
    (z : Schur.SpectralParameter)
    (hSchur : X.schur = source.multiSchur) :
    QuadraticOrderCDCompatibilitySurface (source := source) X L z Orders.QuadraticNormFormCertificate.gaussian :=
  gaussian (source := source) (CayleyDickson.CDComplexArithmeticBridge.fromBoundarySource (source := source) B X z hSchur)

def eisensteinFromBoundarySource
    (B : BoundarySource.BoundarySourceSurface source L)
    (X : CayleyDickson.StructuralCDSource Cell T)
    (z : Schur.SpectralParameter)
    (hSchur : X.schur = source.multiSchur) :
    QuadraticOrderCDCompatibilitySurface (source := source) X L z Orders.QuadraticNormFormCertificate.eisenstein :=
  eisenstein (source := source) (CayleyDickson.CDComplexArithmeticBridge.fromBoundarySource (source := source) B X z hSchur)

theorem no_order_cd_equality
    {Q : Orders.QuadraticNormFormCertificate}
    (S : QuadraticOrderCDCompatibilitySurface (source := source) X L z Q) :
    S.noOrderCDEqualityStatus =
      DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra :=
  S.noOrderCDEqualityStatus_eq

theorem period_lattice_preparation_only
    {Q : Orders.QuadraticNormFormCertificate}
    (S : QuadraticOrderCDCompatibilitySurface (source := source) X L z Q) :
    S.periodLatticePreparationStatus =
      DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.periodLatticePeriodLatticePreparationOnly :=
  S.periodLatticePreparationStatus_eq

theorem no_downstream_shortcut
    {Q : Orders.QuadraticNormFormCertificate}
    (S : QuadraticOrderCDCompatibilitySurface (source := source) X L z Q) :
    S.downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow :=
  S.downstreamDisciplineStatus_eq

theorem cd_no_identification
    {Q : Orders.QuadraticNormFormCertificate}
    (S : QuadraticOrderCDCompatibilitySurface (source := source) X L z Q) :
    S.bridge.noIdentificationStatus =
      CayleyDickson.CayleyDicksonBoundaryBridgeNoIdentificationStatus.noExecMirrorCDComplexIdentificationWithoutTransferLemma :=
  S.cdNoIdentification

theorem gaussian_classification
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (gaussian (source := source) Bdg).classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.gaussianDMinusFourCompatibility := by
  rfl

theorem eisenstein_classification
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (eisenstein (source := source) Bdg).classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.eisensteinDMinusThreeCompatibility := by
  rfl

theorem gaussian_discriminant_is_negative_four
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (gaussian (source := source) Bdg).discriminantWitness.discriminant = -4 := by
  rfl

theorem eisenstein_discriminant_is_negative_three
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (eisenstein (source := source) Bdg).discriminantWitness.discriminant = -3 := by
  rfl

end QuadraticOrderCDCompatibilitySurface

structure NonQuadraticCDComplexObstruction
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter) where
  bridge : CayleyDickson.CDComplexArithmeticBridge source X L z
  block : Orders.NonQuadraticDiscriminantBlock
  classification : DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification
  classification_eq :
    classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.higherDegreeOrIrreducibleCDCObstruction
  obstructionStatus : DiscriminantAlgebraCompatibilityCDCObstructionStatus
  obstructionStatus_eq :
    obstructionStatus =
      DiscriminantAlgebraCompatibilityCDCObstructionStatus.nonQuadraticOutcomeBlockedFromCDComplexIdentification
  forwardingBlocked :
    block.forwardingStatus = Orders.NonQuadraticForwardingStatus.blockedFromQuadraticOrderPath
  periodLatticePreparationStatus : DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus
  periodLatticePreparationStatus_eq :
    periodLatticePreparationStatus = DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.blockedForNonQuadraticOutcome
  downstreamDisciplineStatus : DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus
  downstreamDisciplineStatus_eq :
    downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  derivedOnlyStatus : DiscriminantAlgebraCompatibilityDerivedOnlyStatus
  derivedOnlyStatus_eq :
    derivedOnlyStatus = DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  cdBridgeClosed :
    bridge.bridgeStatus = CayleyDickson.CayleyDicksonBoundaryBridgeBridgeLedgerStatus.complexCouplingComplexCouplingTestClosed
  cdNoIdentification :
    bridge.noIdentificationStatus =
      CayleyDickson.CayleyDicksonBoundaryBridgeNoIdentificationStatus.noExecMirrorCDComplexIdentificationWithoutTransferLemma
  cdSharedSchur : X.schur = source.multiSchur

namespace NonQuadraticCDComplexObstruction

variable {X : CayleyDickson.StructuralCDSource Cell T}
variable {z : Schur.SpectralParameter}

def fromBlock
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    (N : Orders.NonQuadraticDiscriminantBlock) :
    NonQuadraticCDComplexObstruction (source := source) X L z where
  bridge := Bdg
  block := N
  classification :=
    DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.higherDegreeOrIrreducibleCDCObstruction
  classification_eq := by
    rfl
  obstructionStatus :=
    DiscriminantAlgebraCompatibilityCDCObstructionStatus.nonQuadraticOutcomeBlockedFromCDComplexIdentification
  obstructionStatus_eq := by
    rfl
  forwardingBlocked := Orders.NonQuadraticDiscriminantBlock.blocked N
  periodLatticePreparationStatus := DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.blockedForNonQuadraticOutcome
  periodLatticePreparationStatus_eq := by
    rfl
  downstreamDisciplineStatus :=
    DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  downstreamDisciplineStatus_eq := by
    rfl
  derivedOnlyStatus := DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  derivedOnlyStatus_eq := by
    rfl
  cdBridgeClosed := CayleyDickson.CDComplexArithmeticBridge.status_closed Bdg
  cdNoIdentification := CayleyDickson.CDComplexArithmeticBridge.no_exec_mirror_cd_identification Bdg
  cdSharedSchur := CayleyDickson.CDComplexArithmeticBridge.shared_schur_provenance Bdg

def fromQuadraticOrderNormCertificateCertificate
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    {B : BoundarySource.BoundarySourceSurface source L}
    {b : Nat} {hL : 3 < L}
    (C : Schur.HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    NonQuadraticCDComplexObstruction (source := source) X L z :=
  fromBlock (source := source) Bdg (Orders.NonQuadraticDiscriminantBlock.fromQuadraticOrderNormCertificate C)

def fromBoundarySourceAndQuadraticOrderNormCertificateCertificate
    (B : BoundarySource.BoundarySourceSurface source L)
    (X : CayleyDickson.StructuralCDSource Cell T)
    (z : Schur.SpectralParameter)
    (hSchur : X.schur = source.multiSchur)
    {b : Nat} {hL : 3 < L}
    (C : Schur.HigherLevelIrreducibleOrHigherDegreeCertificate B b hL z) :
    NonQuadraticCDComplexObstruction (source := source) X L z :=
  fromQuadraticOrderNormCertificateCertificate (source := source)
    (CayleyDickson.CDComplexArithmeticBridge.fromBoundarySource (source := source) B X z hSchur) C

theorem classification_obstruction
    (O : NonQuadraticCDComplexObstruction (source := source) X L z) :
    O.classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.higherDegreeOrIrreducibleCDCObstruction :=
  O.classification_eq

theorem forwarding_blocked
    (O : NonQuadraticCDComplexObstruction (source := source) X L z) :
    O.block.forwardingStatus = Orders.NonQuadraticForwardingStatus.blockedFromQuadraticOrderPath :=
  O.forwardingBlocked

theorem period_lattice_blocked
    (O : NonQuadraticCDComplexObstruction (source := source) X L z) :
    O.periodLatticePreparationStatus = DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus.blockedForNonQuadraticOutcome :=
  O.periodLatticePreparationStatus_eq

theorem no_downstream_shortcut
    (O : NonQuadraticCDComplexObstruction (source := source) X L z) :
    O.downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow :=
  O.downstreamDisciplineStatus_eq

end NonQuadraticCDComplexObstruction

structure CDArithmeticCompatibility
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter) where
  bridge : CayleyDickson.CDComplexArithmeticBridge source X L z
  orderCertificate : Option Orders.QuadraticOrderConventionCertificate
  normFormCertificate : Option Orders.QuadraticNormFormCertificate
  nonQuadraticBlock : Option Orders.NonQuadraticDiscriminantBlock
  classification : DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification
  noOrderCDEqualityStatus : DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus
  noOrderCDEqualityStatus_eq :
    noOrderCDEqualityStatus =
      DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  periodLatticePreparationStatus : DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus
  downstreamDisciplineStatus : DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus
  downstreamDisciplineStatus_eq :
    downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow
  derivedOnlyStatus : DiscriminantAlgebraCompatibilityDerivedOnlyStatus
  derivedOnlyStatus_eq :
    derivedOnlyStatus = DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly
  cdNoIdentification :
    bridge.noIdentificationStatus =
      CayleyDickson.CayleyDicksonBoundaryBridgeNoIdentificationStatus.noExecMirrorCDComplexIdentificationWithoutTransferLemma
  cdSharedSchur : X.schur = source.multiSchur

namespace CDArithmeticCompatibility

variable {X : CayleyDickson.StructuralCDSource Cell T}
variable {z : Schur.SpectralParameter}

def fromQuadraticSurface
    {Q : Orders.QuadraticNormFormCertificate}
    (S : QuadraticOrderCDCompatibilitySurface (source := source) X L z Q) :
    CDArithmeticCompatibility (source := source) X L z where
  bridge := S.bridge
  orderCertificate := some Q.orderCertificate
  normFormCertificate := some Q
  nonQuadraticBlock := none
  classification := S.classification
  noOrderCDEqualityStatus := S.noOrderCDEqualityStatus
  noOrderCDEqualityStatus_eq := S.noOrderCDEqualityStatus_eq
  periodLatticePreparationStatus := S.periodLatticePreparationStatus
  downstreamDisciplineStatus := S.downstreamDisciplineStatus
  downstreamDisciplineStatus_eq := S.downstreamDisciplineStatus_eq
  derivedOnlyStatus := S.derivedOnlyStatus
  derivedOnlyStatus_eq := S.derivedOnlyStatus_eq
  cdNoIdentification := S.cdNoIdentification
  cdSharedSchur := S.cdSharedSchur

def fromNonQuadraticObstruction
    (O : NonQuadraticCDComplexObstruction (source := source) X L z) :
    CDArithmeticCompatibility (source := source) X L z where
  bridge := O.bridge
  orderCertificate := none
  normFormCertificate := none
  nonQuadraticBlock := some O.block
  classification := O.classification
  noOrderCDEqualityStatus :=
    DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra
  noOrderCDEqualityStatus_eq := by
    rfl
  periodLatticePreparationStatus := O.periodLatticePreparationStatus
  downstreamDisciplineStatus := O.downstreamDisciplineStatus
  downstreamDisciplineStatus_eq := O.downstreamDisciplineStatus_eq
  derivedOnlyStatus := O.derivedOnlyStatus
  derivedOnlyStatus_eq := O.derivedOnlyStatus_eq
  cdNoIdentification := O.cdNoIdentification
  cdSharedSchur := O.cdSharedSchur

def gaussian
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    CDArithmeticCompatibility (source := source) X L z :=
  fromQuadraticSurface (source := source) (QuadraticOrderCDCompatibilitySurface.gaussian (source := source) Bdg)

def eisenstein
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    CDArithmeticCompatibility (source := source) X L z :=
  fromQuadraticSurface (source := source) (QuadraticOrderCDCompatibilitySurface.eisenstein (source := source) Bdg)

def nonQuadratic
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    (N : Orders.NonQuadraticDiscriminantBlock) :
    CDArithmeticCompatibility (source := source) X L z :=
  fromNonQuadraticObstruction (source := source) (NonQuadraticCDComplexObstruction.fromBlock (source := source) Bdg N)

theorem no_order_cd_equality
    (C : CDArithmeticCompatibility (source := source) X L z) :
    C.noOrderCDEqualityStatus =
      DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus.quadraticOrderNotIdentifiedWithCayleyDicksonAlgebra :=
  C.noOrderCDEqualityStatus_eq

theorem no_downstream_shortcut
    (C : CDArithmeticCompatibility (source := source) X L z) :
    C.downstreamDisciplineStatus =
      DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow :=
  C.downstreamDisciplineStatus_eq

theorem derived_only
    (C : CDArithmeticCompatibility (source := source) X L z) :
    C.derivedOnlyStatus = DiscriminantAlgebraCompatibilityDerivedOnlyStatus.ordersCayleyDicksonOrdersAndCayleyDicksonBoundaryBridgeCDDataOnly :=
  C.derivedOnlyStatus_eq

theorem gaussian_classification
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (gaussian (source := source) Bdg).classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.gaussianDMinusFourCompatibility := by
  rfl

theorem eisenstein_classification
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    (eisenstein (source := source) Bdg).classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.eisensteinDMinusThreeCompatibility := by
  rfl

theorem nonQuadratic_classification
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    (N : Orders.NonQuadraticDiscriminantBlock) :
    (nonQuadratic (source := source) Bdg N).classification =
      DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification.higherDegreeOrIrreducibleCDCObstruction := by
  rfl

end CDArithmeticCompatibility

end Convergence

namespace StrengtheningDiscriminantAlgebraCompatibility

abbrev DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification :=
  Convergence.DiscriminantAlgebraCompatibilityDiscriminantAlgebraClassification
abbrev DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus :=
  Convergence.DiscriminantAlgebraCompatibilityQuadraticOrderCDEqualityStatus
abbrev DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus :=
  Convergence.DiscriminantAlgebraCompatibilityPeriodLatticePreparationStatus
abbrev DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus :=
  Convergence.DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus
abbrev DiscriminantAlgebraCompatibilityImaginaryQuadraticDiscriminantWitness :=
  Convergence.ImaginaryQuadraticDiscriminantWitness
abbrev DiscriminantAlgebraCompatibilityQuadraticOrderCDCompatibilitySurface
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T}
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter)
    (Q : Orders.QuadraticNormFormCertificate) :=
  Convergence.QuadraticOrderCDCompatibilitySurface (source := source) X L z Q
abbrev DiscriminantAlgebraCompatibilityNonQuadraticCDComplexObstruction
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T}
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter) :=
  Convergence.NonQuadraticCDComplexObstruction (source := source) X L z
abbrev DiscriminantAlgebraCompatibilityCDArithmeticCompatibility
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T}
    (X : CayleyDickson.StructuralCDSource Cell T)
    (L : Nat)
    (z : Schur.SpectralParameter) :=
  Convergence.CDArithmeticCompatibility (source := source) X L z

def DiscriminantAlgebraCompatibilityGaussianCompatibilityFromBridge
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {X : CayleyDickson.StructuralCDSource Cell T} {z : Schur.SpectralParameter}
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    DiscriminantAlgebraCompatibilityCDArithmeticCompatibility (source := source) X L z :=
  Convergence.CDArithmeticCompatibility.gaussian (source := source) Bdg

def DiscriminantAlgebraCompatibilityEisensteinCompatibilityFromBridge
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {X : CayleyDickson.StructuralCDSource Cell T} {z : Schur.SpectralParameter}
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z) :
    DiscriminantAlgebraCompatibilityCDArithmeticCompatibility (source := source) X L z :=
  Convergence.CDArithmeticCompatibility.eisenstein (source := source) Bdg

def DiscriminantAlgebraCompatibilityNonQuadraticObstructionFromBridge
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {X : CayleyDickson.StructuralCDSource Cell T} {z : Schur.SpectralParameter}
    (Bdg : CayleyDickson.CDComplexArithmeticBridge source X L z)
    (N : Orders.NonQuadraticDiscriminantBlock) :
    DiscriminantAlgebraCompatibilityCDArithmeticCompatibility (source := source) X L z :=
  Convergence.CDArithmeticCompatibility.nonQuadratic (source := source) Bdg N

theorem DiscriminantAlgebraCompatibilityCompatibilityNoDownstreamShortcut
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {X : CayleyDickson.StructuralCDSource Cell T} {z : Schur.SpectralParameter}
    (C : DiscriminantAlgebraCompatibilityCDArithmeticCompatibility (source := source) X L z) :
    C.downstreamDisciplineStatus =
      Convergence.DiscriminantAlgebraCompatibilityDownstreamDisciplineStatus.noJQFunctionLMoonshineConsumerBeforeDownstreamArithmeticWindow :=
  Convergence.CDArithmeticCompatibility.no_downstream_shortcut (source := source) C

theorem DiscriminantAlgebraCompatibilityCompatibilityNoCdIdentification
    {Cell : Nat → Type u} [SubstrateClass Cell]
    {T : TruncatedFamily Cell}
    {source : ArithmeticSource Cell T} {L : Nat}
    {X : CayleyDickson.StructuralCDSource Cell T} {z : Schur.SpectralParameter}
    (C : DiscriminantAlgebraCompatibilityCDArithmeticCompatibility (source := source) X L z) :
    C.bridge.noIdentificationStatus =
      CayleyDickson.CayleyDicksonBoundaryBridgeNoIdentificationStatus.noExecMirrorCDComplexIdentificationWithoutTransferLemma :=
  C.cdNoIdentification

end StrengtheningDiscriminantAlgebraCompatibility

end CNNA.PillarA.Arithmetic
