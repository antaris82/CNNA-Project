import CNNA.PillarA.Arithmetic.GeneratedPipeline.BuildAll
