import CNNA.PillarA.Generator.Core.SourceAndApproximation.MainPath
