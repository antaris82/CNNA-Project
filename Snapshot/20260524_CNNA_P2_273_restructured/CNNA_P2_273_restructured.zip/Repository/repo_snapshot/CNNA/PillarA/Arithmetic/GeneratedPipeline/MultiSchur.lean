import CNNA.PillarA.Generator.Schur.GeneratedPipeline.MultiSchur
