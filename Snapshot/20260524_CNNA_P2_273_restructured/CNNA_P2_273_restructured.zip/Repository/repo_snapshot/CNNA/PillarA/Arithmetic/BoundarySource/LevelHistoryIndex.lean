import CNNA.PillarA.Generator.Boundary.LevelHistoryIndex
