import CNNA.PillarA.Generator.Core.SourceAndApproximation.BuildAll
