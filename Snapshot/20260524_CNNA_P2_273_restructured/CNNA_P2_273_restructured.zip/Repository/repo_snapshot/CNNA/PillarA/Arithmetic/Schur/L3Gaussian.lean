import CNNA.PillarA.Generator.Schur.Arithmetic.L3Gaussian
