# CNNA Explorer Tooling

This package contains the CNNA Lean source snapshot, the semantic YAML core, and the local tooling that builds the CNNA Explorer database from those sources.

The source-of-truth model is strict:

```text
Lean code = formal truth
YAML core = semantic planning, dossier, workflow and graph metadata
build/ = all generated data
MySQL = generated read-only Explorer materialization
Explorer UI = navigation and review surface, not a theory source
```

Generated data must stay under `build/`. It must not be copied back into `Repository/masters/`, `Repository/repo_snapshot/`, or the repository root.

---

## Contents

```text
Repository/
  README.md
  repo_snapshot/                 CNNA Lean source snapshot
  masters/
    cnna_roadmap_master.yaml     semantic master entry point
    tables/                      canonical phase/object/dossier/graph YAML
    policies/                    current retention and Explorer-generation policies
  scripts/
    validate_yaml_core.py
  tools/
    explorer/                    Explorer build, audit and release pipeline
    proof_dependency/            Lean declaration extraction and MySQL import internals
    package/                     source-package hygiene and slim packaging tools
```

The slim source package intentionally excludes:

```text
build/
Repository/masters/generated/
raw extraction captures
normalized declaration/proof-edge payloads
Explorer SQL/TSV output
local audit reports
throwaway test packages
cache files
```

Those outputs are regenerated locally.

---

## Requirements

Run commands from the project root, the directory containing both `lakefile.lean` and `Repository/`.

Required locally:

```text
Lean/Lake toolchain matching lean-toolchain
Lake dependencies available locally
Python 3
MySQL or MariaDB client/server
```

The Explorer import uses `LOAD DATA LOCAL INFILE`, so MySQL must allow local infile loading on both client and server sides.

---

## One-command Explorer pipeline

Use this as the normal command:

```bash
python3 Repository/tools/explorer/run_explorer_pipeline.py
```

It performs the complete current workflow:

```text
1. Build semantic-core Explorer SQL/Bulk data from Lean + YAML.
2. Import the generated Bulk package into MySQL with full refresh.
3. Run the post-import DB audit.
4. Run the release/reproducibility/package-hygiene certificate.
```

A successful run proves that the local Explorer data path is coherent:

```text
Lean/YAML inputs → build/semantic-core SQL/Bulk → MySQL full refresh → audit → release certificate
```

The stable working directory is:

```text
build/proof_dependency_extraction/current/
```

Normal pipeline runs do not delete `current/` at startup. Rebuilds are staged first and promoted only after a successful build.

---

## Fresh rebuild and cache control

Use a full clean test only when you deliberately want to discard the active generated workdir:

```bash
python3 Repository/tools/explorer/run_explorer_pipeline.py --clean-current
```

Other useful controls:

```bash
# Ignore the stage cache and recompute the relevant stages.
python3 Repository/tools/explorer/run_explorer_pipeline.py --force

# Reuse existing normalized declaration data where valid.
python3 Repository/tools/explorer/run_explorer_pipeline.py --from-existing

# Build and audit, but skip the final release certificate.
python3 Repository/tools/explorer/run_explorer_pipeline.py --skip-release

# Build only, without MySQL import and release.
python3 Repository/tools/explorer/run_explorer_pipeline.py --skip-import --skip-release
```

### Incrementality boundary

The current cache is stage-level, not declaration-level.

```text
No relevant input changed:
  reuse the current build outputs.

Only YAML, dossiers, graph metadata or SQL exporter changed:
  reuse existing normalized Lean declarations;
  rebuild SQL/Bulk and rerun import/audit/release.

Lean source, toolchain, Lake manifest or Lean extractor changed:
  rerun the Lean extraction and rebuild downstream outputs.
```

Lean/Lake may reuse compiled artifacts internally, but the Explorer extractor still scans the elaborated CNNA environment as a whole when Lean extraction is required. It does not yet skip individual unchanged Lean declarations or modules.

Inspect the current decision without building:

```bash
python3 Repository/tools/explorer/build_explorer_sql.py --explain-cache
```

---

## Generated working directory

After a successful pipeline run, the active workdir has this shape:

```text
build/proof_dependency_extraction/current/
  raw/                         local raw extractor output
  normalized/                  normalized declaration and audit data
  sql/unified/bulk/            MySQL bulk import package
    00_schema.sql
    load_order.tsv
    data/*.tsv
  reports/                     build, audit and release reports
  cache/                       stage-cache fingerprints
```

Only `build/` contains generated payloads. The source package remains small and reproducible.

---

## MySQL import behavior

The pipeline imports into the database:

```text
cnna_explorer
```

The import is a full refresh:

```text
DROP DATABASE IF EXISTS cnna_explorer;
CREATE DATABASE cnna_explorer;
LOAD DATA LOCAL INFILE ...
```

There is no merge, no upsert, and no manual DB edit that becomes source data. The database is a generated materialization of Lean code plus YAML semantic core.

Run the import/audit step directly only for targeted recovery:

```bash
bash Repository/tools/proof_dependency/import_unified_explorer_sql.sh --audit \
  build/proof_dependency_extraction/current/sql/unified/bulk
```

The pipeline wrapper runs this step automatically.

---

## MySQL credentials and LOCAL INFILE

Prefer a local MySQL client config instead of putting passwords in shell commands:

```ini
[client]
user=cnna
password=YOUR_PASSWORD
host=localhost
local-infile=1
```

Save it as:

```bash
~/.my.cnf
```

and restrict permissions:

```bash
chmod 600 ~/.my.cnf
```

If the import reports that local data loading is disabled, enable it for the current server session:

```bash
sudo mysql -e "SET GLOBAL local_infile = 1;"
```

Check:

```bash
mysql --local-infile=1 -e "SHOW VARIABLES LIKE 'local_infile';"
```

After importing, you may disable it again:

```bash
sudo mysql -e "SET GLOBAL local_infile = 0;"
```

For a dedicated local Explorer user:

```sql
CREATE USER IF NOT EXISTS 'cnna'@'localhost' IDENTIFIED BY 'YOUR_PASSWORD';
GRANT ALL PRIVILEGES ON cnna_explorer.* TO 'cnna'@'localhost';
FLUSH PRIVILEGES;
```

---

## Explorer database content

The standard semantic-core Explorer export contains current navigation and review data, including:

```text
planning_phases
planning_objects
implementation_scratchpads
object_proof_dossiers
object_dossier_documents
predicted_graph_nodes
predicted_graph_edges
derived_graph_nodes
derived_graph_edges
explorer_graph_nodes
explorer_graph_edges
lean_declarations
lean_declaration_dossier_links
explorer_semantic_status_overlay
explorer_readonly_query_contract
explorer_statistics
```

The Explorer DB contains generated semantic/navigation content only. It does not contain raw captures, full proof-edge dumps, old generated manifests, or forensic payload mirrors.

Proof-dependency edge data may be generated locally for audit, but it is not admitted as Explorer semantic truth and is not part of the default Explorer content.

---

## Read-only Explorer contract

The Explorer is a read-only consumer of the generated database.

Allowed:

```text
SELECT queries
navigation
search
filtering
review panels
status dashboards
links back to Lean code and YAML-derived dossiers
```

Forbidden as Explorer behavior:

```text
editing Lean/YAML through the DB
manual DB rows becoming source data
SQL-side proof-edge promotion
CMS/UI edits becoming theory facts
mutating generated tables as canonical state
```

The table `explorer_readonly_query_contract` and the `v_api_*` views define the current read-only input surface for the UI.

---

## Declarations without value/proof bodies

Some Lean constants are visible to the Explorer as declarations but do not have an extracted value/proof body. These are primarily generated constants for inductive types, constructors and recursors.

They are still declaration nodes and may have type/signature dependencies. They are not extraction failures. The precise interpretation is:

```text
declaration exists in the elaborated Lean environment
no value/proof body is available for the extractor for this constant kind
```

---

## Packaging

Create a slim source/tool package with:

```bash
python3 Repository/tools/package/make_slim_source_package.py \
  --out build/packages/Repository_slim_semantic_core_package.zip \
  --report build/packages/Repository_slim_semantic_core_package_report.json
```

Package validation:

```bash
python3 Repository/tools/package/validate_semantic_core_payload.py
python3 Repository/tools/package/audit_repository_payload.py --fail-on-violations
```

Packaging does not build SQL, import MySQL, or audit the database. Use the Explorer pipeline for generated Explorer data.

---

## Troubleshooting

### The build starts a long Lean extraction

This is expected after deleting `build/`, changing Lean inputs, changing the toolchain/Lake manifest, changing the Lean extractor, or using `--force`/`--clean-current`.

### The build unexpectedly wants to extract Lean again

Inspect the cache decision:

```bash
python3 Repository/tools/explorer/build_explorer_sql.py --explain-cache
```

If valid normalized data exists but cache files are missing after a package update, use:

```bash
python3 Repository/tools/explorer/run_explorer_pipeline.py --from-existing
```

### MySQL root access fails

On many Linux systems, MySQL/MariaDB `root` uses socket authentication. Create a dedicated local `cnna` user instead of importing as root.

### LOCAL INFILE is disabled

Enable it temporarily:

```bash
sudo mysql -e "SET GLOBAL local_infile = 1;"
```

Then rerun the pipeline or import step.

### Need to prove the full path from scratch

Run:

```bash
python3 Repository/tools/explorer/run_explorer_pipeline.py --clean-current
```

This intentionally removes the current generated workdir and rebuilds the Explorer data from Lean + YAML.
