# CNNA current-state validation

## Project identity

**CNNA — From Primitive Provenance to Mathematical Structure**  
*A Response-Coupled Derivation on a Growing $b$-ary Tree*

The generalized framework is **Generalized Open Provenance Systems**. The current formal object is the finite deterministic response-coupled CNNA specialization. Universal provenance completion is explicitly a research hypothesis, not a theorem of the current DAG.

## Current verified/source state

- DAG: 145 nodes, 401 edges; P002 is active.
- P001: 142/142 declarations kernel verified.
- M003/M004: 11/11 declarations kernel verified.
- P002: six public source declarations; local kernel build still required.
- Open-provenance map: 47 role assignments across 36 nodes.
- External references: 31 sources, 57 unique uses, 18 claim assertions.
- Main paper: 29 pages, SHA-256 `dd219a5f21266ec6509fde1271ac425fcbfe1c5c5e5e540a89bb1e4d5955e939`.
- Supplement: 101 pages, SHA-256 `fa0a0ae49854277d624981fddf4cd756da490141940e39dd047c053848c1f869`.
- Native yEd-Live DAG SHA-256: `6b4d4339e2e0cc3c7e96b0f7ba61d7d900abf1dd462dd876861e4ab6b1395e6f`.

## Conceptual safeguards

- Schur/DtN elimination is not identified with partial trace or marginalization.
- The retained finite POVM is registered as a Legacy migration target, not as a current derived-only theorem.
- POVM, instrument, process tensor/comb, Weyl/GNS, and modular/AQFT structures are separated as progressively later specializations.
- Every mapped node retains its existing implementation/evidence status.
