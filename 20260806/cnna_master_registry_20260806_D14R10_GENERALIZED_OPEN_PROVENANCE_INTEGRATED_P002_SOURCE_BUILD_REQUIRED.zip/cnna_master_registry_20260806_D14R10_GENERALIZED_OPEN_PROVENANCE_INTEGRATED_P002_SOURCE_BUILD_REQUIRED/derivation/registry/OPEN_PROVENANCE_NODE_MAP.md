# Generalized Open Provenance Systems — DAG integration map

CNNA is the current finite deterministic specialization. This map is interpretive and traceability-oriented; it does not override any node implementation or evidence status.

## OPS-01 — Provenance-complete event state

- **Status:** `CURRENT_FINITE_SPECIALIZATION`
- **Nodes:** C003, C018, C005, C004

## OPS-02 — Cut-relative complement

- **Status:** `NODEWISE_CURRENT_OR_PLANNED`
- **Nodes:** M001, C020, C022, C060

## OPS-03 — Effective complement elimination

- **Status:** `NODEWISE_CURRENT_OR_PLANNED`
- **Nodes:** C006, P001, C007, C021, C025

## OPS-04 — Response-coupled event generation

- **Status:** `M003_M004_VERIFIED_C008_DOWNSTREAM`
- **Nodes:** M003, M004, C008

## OPS-05 — Immutable record, live state and backreaction

- **Status:** `DOWNSTREAM_CONSTRUCTION`
- **Nodes:** C008, C016, C017, C024, C043

## OPS-06 — Nested cuts, refinement and cocycle

- **Status:** `DOWNSTREAM_COHERENCE_PROGRAM`
- **Nodes:** C043, C044, C045, C047, C046

## OPS-AQFT-01 — Weyl/GNS/modular-AQFT specialization

- **Status:** `LATE_OPERATOR_ALGEBRAIC_SPECIALIZATION_NODEWISE_STATUS`
- **Nodes:** C060, C053, C057, C058, C059, C061, M080, M082, M086, M083

## OPS-QM-01 — Finite provenance-derived POVM migration

- **Status:** `LEGACY_MIGRATION_TARGET_NOT_CURRENT_THEOREM`
- **Nodes:** C025, C044, C047, M030, C032, C033, C053

## OPS-QM-02 — Open-quantum-process specialization

- **Status:** `LATER_QUANTUM_SPECIALIZATION_NOT_UNIVERSAL_CLAIM`
- **Nodes:** C060, C043, C053, C057

