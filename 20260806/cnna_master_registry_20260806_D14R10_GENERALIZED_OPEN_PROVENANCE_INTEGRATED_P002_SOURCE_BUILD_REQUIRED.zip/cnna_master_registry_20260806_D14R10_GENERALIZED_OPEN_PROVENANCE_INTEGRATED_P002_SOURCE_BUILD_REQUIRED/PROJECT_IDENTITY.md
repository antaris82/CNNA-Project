# CNNA — From Primitive Provenance to Mathematical Structure

**Paper title:** *From Primitive Provenance to Mathematical Structure: A Response-Coupled Derivation on a Growing $b$-ary Tree*

CNNA is the current finite, deterministic, response-coupled specialization of the broader research framework **Generalized Open Provenance Systems**. The framework asks when an empirically open description can be completed by a dynamically relevant provenance state, a cut-relative complement, and a coherent family of effective reductions.

The universal completion claim is a research hypothesis, not a theorem of the current DAG. The current formal results concern the explicitly registered finite CNNA nodes. Finite POVM, open-quantum-system, Weyl/GNS, and modular/AQFT constructions are progressively later specializations and retain their individual proof status.

The stable software namespaces remain `CNNA` and `CNNAProofs`.
